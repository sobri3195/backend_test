	<div style="display: block;padding:5px;" id="div6" >
		<ul id="tabmenu" >
			<li onClick="activeTab(1)"><a class="" id="tab1">FORM IDENTITAS PASIEN</a></li>
			<li onClick="activeTab(2)"><a class="" id="tab2">LIST DATA PASIEN</a></li>
			<li onClick="activeTab(3)"><a class="" id="tab3">LAPORAN DATA PASIEN</a></li>
		</ul>
		<div id="content" align="right">
        	<h1>Ini adalah halaman Pendaftaran identitas pasien.</h1><br />
			Untuk Melakukan Pendaftaran, Klik Tab Identitas Pasien.
            Untuk Melihat Data Pasien, Klik Tab List Data Pasien.<br />
            Untuk Melihat laporan Data Pasien, Klik Laporan Data Pasien. 
        </div>
	</div>
