<?php
include("include/PDF.php");

    if(isset($_REQUEST['idx']) && isset($_REQUEST['poly'])){
        include("include/connect.php");
		
		// Bagian SEP
		// ---------------------------------------------------
        $idx	= $_REQUEST['idx'];
        $poly	= $_REQUEST['poly'];

        $sql	= 	'select t_pendaftaran.NOMR, m_pasien.nama as pasien, m_poly.nama as poly, t_pendaftaran.idxdaftar, t_pendaftaran.NOKARTU as sep, t_pendaftaran.TGLREG, m_pasien.NO_KARTU, m_pasien.TGLLAHIR, m_pasien.JENISKELAMIN, m_pasien.NMPROVIDER, t_pendaftaran.DIAGNOSA_AWAL, m_pasien.JNS_PASIEN, m_pasien.Kelas from t_pendaftaran
                    join m_pasien on t_pendaftaran.NOMR = m_pasien.NOMR
                    join m_poly on m_poly.kode = t_pendaftaran.KDPOLY
                    where t_pendaftaran.KDPOLY ='.$poly.' and t_pendaftaran.IDXDAFTAR="'.$idx.'"';
        $res	= mysql_query($sql) or die(mysql_error());
        $nr_sep = mysql_num_rows($res);
        $data	= mysql_fetch_array($res);
        extract($data);
        $tgl    = date("d-m-Y",strtotime($TGLREG));
        $tgllhr = date("d-m-Y",strtotime($TGLLAHIR));

        $params = array(
            'no_sep'          => $sep,
            'peserta'         => $pasien,
            'tgl_sep'         => $tgl,
            'cob'             => '',
            'no_kartu'        => $NO_KARTU,
            'jns_rawat'       => 'Rawat Jalan',
            'nama_peserta'    => $pasien,
            'kelas_rawat'     => $Kelas,
            'tgl_lahir'       => $tgllhr,
            'jenis_kelamin'   => $JENISKELAMIN,
            'poli_tujuan'     => $poly,
            'asal_faskes_tk1' => $NMPROVIDER,
            'diagnosa_awal'   => $DIAGNOSA_AWAL,
            'no_mr'           => $NOMR
        );
		
		// Bagian TRACER
		// ------------------------------------
		$idx	= $_REQUEST['idx'];
		$poly	= $_REQUEST['poly'];
		$sql	= 	'select t_pendaftaran.NOMR, m_pasien.nama as pasien, m_poly.nama as poly, m_carabayar.nama as carabayar,
					t_pendaftaran.NIP, t_pendaftaran.PASIENBARU, t_pendaftaran.KDDOKTER, m_dokter.NAMADOKTER, NOW() AS now,
					t_pendaftaran.KETBAYAR,m_pasien.nomr_old,t_pendaftaran.kode_p,t_pendaftaran.kode_t
					from t_pendaftaran
					join m_pasien on t_pendaftaran.NOMR = m_pasien.NOMR
					join m_poly on m_poly.kode = t_pendaftaran.KDPOLY
					join m_carabayar on m_carabayar.KODE = t_pendaftaran.KDCARABAYAR
					JOIN m_dokter on m_dokter.KDDOKTER=t_pendaftaran.KDDOKTER
					where t_pendaftaran.KDPOLY ='.$poly.' and t_pendaftaran.IDXDAFTAR="'.$idx.'"';
		$res	= mysql_query($sql) or die(mysql_error());
		$a		= mysql_num_rows($res);
		$data	= mysql_fetch_array($res);
		
		$kode   = "";
		$kode  .= $data['kode_p'] > 0 ? "KODE P" : '';
		$kode  .= $data['kode_t'] > 0 ? "KODE T" : '';
		
		$params_tracer = array(
			'nama'       => $data['pasien'],
			'tanggal'    => date('d-m-Y', strtotime(str_replace('/','-',$data['now'])))." ".substr($data['now'],11),
			'no_mr_baru' => $data['NOMR'],
			'cara_bayar' => $data['carabayar'],
			'tujuan'     => $data['poly'],
			'no_mr_lama' => $data['nomr_old'],
			'dokter'     => $data['NAMADOKTER'],
			'kode'       => $kode
		);

    }else{
        die('IDXDAFTAR && POLY TIDAK ADA!!!');
    }

    class TRACER_SEP_PDF extends TCPDF{
		
        function print_sep($params = array()){
            $border = 0;
            $this->SetFont('times', '', 10);
            //MultiCell($w, $h, $txt, $border=0, $align='J', $fill=false, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0, $valign='T', $fitcell=false)
            $this->MultiCell(0, 0, '<strong>SURAT ELEGIBILITAS PESERTA</strong>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
            $this->MultiCell(0, 0, '<strong>RSUD Kota Bogor</strong>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
            $this->Ln();
            // Tabel
            // w,h,text,border,ln,align,fill,link,strecth,ignoremin_high, calign,valign
            $this->SetFont('times', '', 10);

            $this->Cell(3, 0, 'Nomor SEP', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['no_sep'], $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, 'Peserta', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['peserta'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Tgl SEP', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['tgl_sep'], $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, 'COB', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['cob'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'No. Kartu', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['no_kartu'], $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, 'Jns Rawat', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['jns_rawat'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Nama Peserta', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['nama_peserta'], $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, 'Kls Rawat', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['kelas_rawat'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Tgl Lahir', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['tgl_lahir'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Jenis Kelamin', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['jenis_kelamin'], $border, 0, 'L', 0, '', 0);
            $this->Cell(4.75, 0, "Pasien/Keluarga Pasien", $border, 0, 'C', 0, '', 0);
            $this->Cell(4.75, 0, "Petugas BPJS Kesehatan", $border, 1, 'C', 0, '', 0);

            $this->Cell(3, 0, 'Poli Tujuan', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['poli_tujuan'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Asal Faskes Tk. 1', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['asal_faskes_tk1'], $border, 1, 'L', 0, '', 0);


            $this->Cell(3, 0, 'Diagnosa Awal', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['diagnosa_awal'], $border, 0, 'L', 0, '', 0);
            $this->Cell(4.75, 0, "---------------------------", $border, 0, 'C', 0, '', 0);
            $this->Cell(4.75, 0, "---------------------------", $border, 1, 'C', 0, '', 0);

            $this->Cell(3, 0, 'No MR', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $params['no_mr'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Catatan', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : ", $border, 1, 'L', 0, '', 0);

            $this->Cell(0, 0, "- Saya menyetujui BPJS Kesehatan menggunakan informasi medis apabila dibutuhkan.", $border, 1, 'L', 0, '', 0);
            $this->Cell(0, 0, "- SEP bukan bukti penjamin peserta.", $border, 1, 'L', 0, '', 0);

        }
		
		function print_tracer($nama, $tanggal, $no_mr_baru, $cara_bayar, $tujuan, $no_mr_lama, $dokter, $kode){
            $border = 0;          

            //MultiCell($w, $h, $txt, $border=0, $align='J', $fill=false, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0, $valign='T', $fitcell=false)
            $this->MultiCell(9.5, 0, '<strong><u>T R A C E R</u></strong>', $border, 'C', false, 0, '', '', true, 0, true, true, 0, 'T', false );
            $this->MultiCell(9.5, 0, '<strong>( B )</strong>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
            // Tabel
			// w,h,text,border,ln,align,fill,link,strecth,ignoremin_high, calign,valign
            $this->Cell(3, 0, 'NAMA', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $nama, $border, 0, 'L', 0, '', 0);
			$this->Cell(3, 0, 'TANGGAL', $tanggal, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . "12 Agustus 2016", $border, 1, 'L', 0, '', 0);
			
			$this->Cell(3, 0, 'NOMR BARU', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $no_mr_baru, $border, 0, 'L', 0, '', 0);
			$this->Cell(3, 0, 'CARA BAYAR', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $cara_bayar, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(3, 0, 'TUJUAN', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $tujuan, $border, 0, 'L', 0, '', 0);
			$this->Cell(3, 0, 'NOMR LAMA', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $no_mr_lama, $border, 1, 'L', 0, '', 0);
			
			$ln = empty($kode) ? 1 : 0;
			$this->Cell(3, 0, 'DOKTER', $border, 0, 'L', 0, '', 0);
            $this->Cell(6.5, 0, " : " . $dokter, $border, $ln, 'L', 0, '', 0);
			if(!empty($kode)){
				$this->Cell(3, 0, 'KODE', $border, 0, 'L', 0, '', 0);
				$this->Cell(6.5, 0, " : " . $kode, $border, 1, 'L', 0, '', 0);
			}
        }
	
	}

    // Ukuran kertas (panjang x lebar)
    $STICKER_3x10_SIZE = array(9, 21);

    // Create new PDF document
    $pdf = new TRACER_SEP_PDF('L', 'cm', $STICKER_3x10_SIZE, true, 'UTF-8', false);

    // set document information
    $PDF_CREATOR  = "SIMRS RSUD Kota Bogor";
    $PDF_AUTHOR   = "Ahmad Isyfalana Amin & Fernalia";
    $TITLE        = 'SEP';
    $SUBJECT      = "Pendaftaran RSUD Kota Bogor";
    $PDF_KEYWORDS = "SIMRS SEP";

    $pdf->SetCreator($PDF_CREATOR);
    $pdf->SetAuthor($PDF_AUTHOR);
    $pdf->SetTitle($TITLE);
    $pdf->SetSubject($SUBJECT);
    $pdf->SetKeywords($PDF_KEYWORDS);

    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // set font
    $pdf->SetFont('times', '', 12);
    $pdf->setFontSpacing(0);
    $pdf->SetMargins(1,1,1,false);
    $pdf->SetAutoPageBreak(TRUE, 0);
    $pdf->SetCellPadding(0);
	
	// Cetak Tracer
    $pdf->AddPage();
	$pdf->print_tracer(
		$params_tracer['nama'],
		$params_tracer['tanggal'],
		$params_tracer['no_mr_baru'],
		$params_tracer['cara_bayar'],
		$params_tracer['tujuan'],
		$params_tracer['no_mr_lama'],
		$params_tracer['dokter'],
		$params_tracer['kode']
	);
	
	// Cetak SEP
	if($nr_sep > 0){
		$pdf->AddPage();		
		$pdf->print_sep($params);
	}    

    $pdf->lastPage();
    //Close and output PDF document
    $nama_file = "sep_" . $params['no_sep'] . '.pdf';
    $pdf->Output($nama_file, 'I');

