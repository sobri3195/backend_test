<?php 
include("../include/connect.php");
require_once('ps_pagebill.php');

?>

<div align="center">
    <div id="frame">
    <div id="frame_title">
      <h3>TAGIHAN ASKES HARI INI</h3></div>
      <form name="cari" id="cari" method="get">  
             List Berdasarkan <select name="poly" id="poly" class="text" >
               <option value="0">-Pilih Poly-</option>
             <? 
			 	$qrypoly = mysql_query("SELECT * FROM m_poly ORDER BY kode ASC")or die (mysql_error());
				while ($listpoly = mysql_fetch_array($qrypoly)){
			 ?>
                <option value="<? echo $listpoly['kode'];?>"><? echo $listpoly['nama'];?></option>
			 <? } ?>
             </select>
      <input type="hidden" name="crbayar" id="crbayar" value="2" />
          
      <input type="hidden" name="link" value="As01" />
<input type="submit" class="text" value="Cari" />

    </form>     
        <div id="cari_poly">
          <table class="tb" width="95%" style="margin:10px;" border="0" cellspacing="0" cellspading="0" title="Tagihan Data Pasien Per Hari Ini">
            <tr align="center">
            <th>NO </th>
              <th>NO RM</th>
              <th>Nama Pasien</th>
              <th>Poly</th>
              <th>Cara Bayar</th>
              <th>Tarif</th>
            </tr>
            <?
$kondisi='';			
if ($_GET['poly']!=0){
	$kpoly=' and E.kdpoly = '.$_GET['poly'];
}

$kondisi=$kpoly;
			
	 $sql="SELECT A.NOMR,A.NAMA,B.NAMA AS POLY1,C.NAMA AS CARABAYAR1,r.TOTTARIFRS, E.IDXDAFTAR, r.NOBILL
	      FROM t_bayarrajal r, m_pasien A, m_poly B, m_carabayar C, t_pendaftaran E   		  
          WHERE r.idxdaftar=E.idxdaftar AND A.NOMR=R.NOMR AND E.KDPOLY=B.KODE AND E.KDCARABAYAR=C.KODE 
                AND TGLBAYAR is null AND E.TGLREG=curdate() AND E.KDCARABAYAR = 2".$kondisi;
$NO=0;

	$pager = new PS_Pagebill($connect, $sql, 15, 5, "poly=".$_GET['poly'],"index.php?link=As01&");
	//The paginate() function returns a mysql result set 
	$rs = $pager->paginate();
	if(!$rs) die(mysql_error());
	while($data = mysql_fetch_array($rs)) {?>
            <tr <?   echo "class =";
                $count++;
                if ($count % 2) {
                echo "tr1"; }
                else {
                echo "tr2";
                }
        ?>>
              <td><? $NO=($NO+1);if ($_GET['page']==0){$hal=0;}else{$hal=$_GET['page']-1;} echo ($hal*15)+$NO;?></td>
              <td><a href="index.php?link=As03&idxb=<? echo $data['NOBILL'];?>&t=<? echo $data['TOTTARIFRS']; ?>"><? echo $data['NOMR'];?></a></td>
              <td><? echo $data['NAMA']; ?></td>
            <td><? echo $data['POLY1']; ?></td>
              <td><? echo $data['CARABAYAR1'];?></td>
              <td><? echo $data['TOTTARIFRS'];?></td>
            </tr>
            <?	} 
	
	//Display the full navigation in one go
	//echo $pager->renderFullNav();
	
	//Or you can display the inidividual links
	echo "<div style='padding:5px;' align=\"center\"><br />";
	
	//Display the link to first page: First
	echo $pager->renderFirst()." | ";
	
	//Display the link to previous page: <<
	echo $pager->renderPrev()." | ";
	
	//Display page links: 1 2 3
	echo $pager->renderNav()." | ";
	
	//Display the link to next page: >>
	echo $pager->renderNext()." | ";
	
	//Display the link to last page: Last
	echo $pager->renderLast();
	
	echo "</div>";
?>
          </table>
          <?php
	
	//Display the full navigation in one go
	//echo $pager->renderFullNav();
	
	//Or you can display the inidividual links
	echo "<div style='padding:5px;' align=\"center\"><br />";
	
	//Display the link to first page: First
	echo $pager->renderFirst()." | ";
	
	//Display the link to previous page: <<
	echo $pager->renderPrev()." | ";
	
	//Display page links: 1 2 3
	echo $pager->renderNav()." | ";
	
	//Display the link to next page: >>
	echo $pager->renderNext()." | ";
	
	//Display the link to last page: Last
	echo $pager->renderLast();
	
	echo "</div>";
			?>
        </div>
    </div>
</div>
</div>