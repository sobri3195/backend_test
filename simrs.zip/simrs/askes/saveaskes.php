<? 
include("../include/connect.php");
  
if(!empty($_POST['SHIFT'])){
$shift = $_POST['SHIFT'];

$sql = "select IDXBILL, TARIFRS  from t_billrajal
  where NOBILL = ".$_POST['nobill'];
  
$total = 0;

$get_askes =  mysql_query($sql) or die(mysql_error());
while($data = mysql_fetch_array($get_askes)){
	if(!empty($_POST['askes'.$data['IDXBILL']])){
		$idxbill = $data['IDXBILL'];
		$askes = $_POST['askes'.$data['IDXBILL']];
		$tarif = $data['TARIFRS'];
		$sharing = $tarif - $askes;
		
		$total = $total + $sharing; 
		
		$sql_update = "update t_billrajal set
						 ASKES = ".$askes.",
						 COSTSHARING = ".$sharing.",
						 SHIFT = ".$shift."
						WHERE IDXBILL = ".$idxbill;
		mysql_query($sql_update) or die(mysql_error());				
	}
}
?>
<script language="javascript" type="text/javascript" >
window.location="<?php echo _BASE_;?>index.php?link=As03&idxb=<?=$_POST['nobill']?>&t=<?=$sharing?>";
</script>  

<? }else{ ?>

<script language="javascript" type="text/javascript" >
alert("Shift Belum Diisi.");
window.location="<?php echo _BASE_;?>index.php?link=As03&idxb=<?=$_POST['nobill']?>";
</script> --> 
<? } ?>