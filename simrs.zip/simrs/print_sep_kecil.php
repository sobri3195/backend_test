<?php
    include("include/PDF.php");

    if(isset($_REQUEST['idx']) && isset($_REQUEST['poly'])){
        include("include/connect.php");
        $idx	= $_REQUEST['idx'];
        $poly	= $_REQUEST['poly'];

        $sql	= 	'select t_pendaftaran.NOMR, m_pasien.nama as pasien, m_poly.nama as poly, t_pendaftaran.idxdaftar, t_pendaftaran.NOKARTU as sep, t_pendaftaran.TGLREG, m_pasien.NO_KARTU, m_pasien.TGLLAHIR, m_pasien.JENISKELAMIN, m_pasien.NMPROVIDER, t_pendaftaran.DIAGNOSA_AWAL, m_pasien.JNS_PASIEN, m_pasien.Kelas from t_pendaftaran
                    join m_pasien on t_pendaftaran.NOMR = m_pasien.NOMR
                    join m_poly on m_poly.kode = t_pendaftaran.KDPOLY
                    where t_pendaftaran.KDPOLY ='.$poly.' and t_pendaftaran.IDXDAFTAR="'.$idx.'"';
        $res	= mysql_query($sql) or die(mysql_error());
        $a		= mysql_num_rows($res);
        $data	= mysql_fetch_array($res);
        extract($data);
        $tgl    = date("d-m-Y",strtotime($TGLREG));
        $tgllhr = date("d-m-Y",strtotime($TGLLAHIR));

        $params = array(
            'no_sep'          => $sep,
            'peserta'         => $pasien,
            'tgl_sep'         => $tgl,
            'cob'             => '',
            'no_kartu'        => $NO_KARTU,
            'jns_rawat'       => 'Rawat Jalan',
            'nama_peserta'    => $pasien,
            'kelas_rawat'     => $Kelas,
            'tgl_lahir'       => $tgllhr,
            'jenis_kelamin'   => $JENISKELAMIN,
            'poli_tujuan'     => $poly,
            'asal_faskes_tk1' => $NMPROVIDER,
            'diagnosa_awal'   => $DIAGNOSA_AWAL,
            'no_mr'           => $NOMR
        );

    }else{
        die('IDXDAFTAR && POLY TIDAK ADA!!!');
    }

    class SEP_PDF extends TCPDF{
        function print_sep($params = array()){
            $border = 0;
            $this->SetFont('times', '', 10);
            //MultiCell($w, $h, $txt, $border=0, $align='J', $fill=false, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0, $valign='T', $fitcell=false)
            $this->MultiCell(0, 0, '<strong>SURAT ELEGIBILITAS PESERTA</strong>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
            $this->MultiCell(0, 0, '<strong>RSUD Kota Bogor</strong>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
            $this->Ln();
            // Tabel
            // w,h,text,border,ln,align,fill,link,strecth,ignoremin_high, calign,valign
            $this->SetFont('times', '', 10);

            $this->Cell(3, 0, 'Nomor SEP', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['no_sep'], $border, 1, 'L', 0, '', 0);
            

            $this->Cell(3, 0, 'Tgl SEP', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['tgl_sep'], $border, 1, 'L', 0, '', 0);
            

            $this->Cell(3, 0, 'No. Kartu', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['no_kartu'], $border, 1, 'L', 0, '', 0);
			
            $this->Cell(3, 0, 'Jenis Rawat', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['jns_rawat'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Nama Peserta', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['nama_peserta'], $border, 1, 'L', 0, '', 0);
            

            $this->Cell(3, 0, 'Tgl Lahir', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['tgl_lahir'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Jenis Kelamin', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['jenis_kelamin'], $border, 1, 'L', 0, '', 0);
            

            $this->Cell(3, 0, 'Poli Tujuan', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['poli_tujuan'], $border, 1, 'L', 0, '', 0);

            $this->Cell(3, 0, 'Asal Faskes Tk. 1', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['asal_faskes_tk1'], $border, 1, 'L', 0, '', 0);


            $this->Cell(3, 0, 'Diagnosa Awal', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['diagnosa_awal'], $border, 1, 'L', 0, '', 0);
            

            $this->Cell(3, 0, 'No MR', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['no_mr'], $border, 1, 'L', 0, '', 0);
			
			$this->Cell(3, 0, 'Peserta', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['peserta'], $border, 1, 'L', 0, '', 0);
			
			$this->Cell(3, 0, 'COB', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['cob'], $border, 1, 'L', 0, '', 0);
			
			$this->Cell(3, 0, 'Kls Rawat', $border, 0, 'L', 0, '', 0);
            $this->Cell(5.5, 0, " : " . $params['kelas_rawat'], $border, 1, 'L', 0, '', 0);
			
			$this->Cell(5.5, 0, " ", $border, 1, 'L', 0, '', 0);
			
			$this->Cell(4, 0, "Pasien/Keluarga Pasien", $border, 0, 'C', 0, '', 0);
            $this->Cell(4, 0, "Petugas BPJS Kesehatan", $border, 1, 'C', 0, '', 0);
			
			$this->Cell(5.5, 0, " ", $border, 1, 'L', 0, '', 0);
			$this->Cell(5.5, 0, " ", $border, 1, 'L', 0, '', 0);
			
			$this->Cell(4, 0, "---------------------------", $border, 0, 'C', 0, '', 0);
            $this->Cell(4, 0, "---------------------------", $border, 1, 'C', 0, '', 0);

            $this->Cell(3, 0, 'Catatan : ', $border, 1, 'L', 0, '', 0);

            $this->Cell(0, 0, "- Saya menyetujui BPJS Kesehatan menggunakan", $border, 1, 'L', 0, '', 0);
            $this->Cell(0, 0, "  informasi medis apabila dibutuhkan.", $border, 1, 'L', 0, '', 0);
            $this->Cell(0, 0, "- SEP bukan bukti penjamin peserta.", $border, 1, 'L', 0, '', 0);

        }
    }

    // Ukuran kertas (width x height)
    //$STICKER_3x10_SIZE = array(14, 9.5);
	$PAPER_SIZE = array(9.5, 14);

    // Create new PDF document
    $pdf = new SEP_PDF('P', 'cm', $PAPER_SIZE, true, 'UTF-8', false);

    // set document information
    $PDF_CREATOR  = "SIMRS RSUD Kota Bogor";
    $PDF_AUTHOR   = "Ahmad Isyfalana Amin & Fernalia";
    $TITLE        = 'SEP';
    $SUBJECT      = "Pendaftaran RSUD Kota Bogor";
    $PDF_KEYWORDS = "SIMRS SEP";

    $pdf->SetCreator($PDF_CREATOR);
    $pdf->SetAuthor($PDF_AUTHOR);
    $pdf->SetTitle($TITLE);
    $pdf->SetSubject($SUBJECT);
    $pdf->SetKeywords($PDF_KEYWORDS);

    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // set font
    $pdf->SetFont('times', '', 9);
    $pdf->setFontSpacing(0);
    $pdf->SetMargins(1,1,0.5,false);
    $pdf->SetAutoPageBreak(TRUE, 0);
    $pdf->SetCellPadding(0);

    $pdf->AddPage('P');

    $pdf->print_sep($params);

    $pdf->lastPage();
    //Close and output PDF document
    $nama_file = "sep_" . $params['no_sep'] . '.pdf';
    $pdf->Output($nama_file, 'I');

