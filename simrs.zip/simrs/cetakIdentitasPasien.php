<?php
    ob_start();
	session_start();
	include 'include/function.php';
	
	$nomr		= $_GET['NOMR'];
	
	$datapasien	= ambildatapasein($nomr);
	
	$nomor_kartu = $_GET['NOMR'];
	$jml = strlen($nomor_kartu);
	$j = 0;
	$new_no = '';
	//echo $jml;
	
	for($i=1; $i<=$jml; $i++){
		if($i == $jml){
			$new_no = $new_no.substr($nomor_kartu, $j , 2) ;
		}
		else if(($i % 2) == 0 && $i != $jml){
			$new_no = $new_no.substr($nomor_kartu, $j , 2) . "-";
			$j = $j + 2;
		}
	}
?>

<html>
	<body>
		<img src="img/header_logo.png" width="200px	;">
		<br/>
		<table>
			<tr>
				<th width="620px;" align="center;"><h1>IDENTITAS PASIEN</h1></th>
			</tr>
		</table>
			<br/>
    
    	<div style="border: 2px black solid;"><table border="0">
    			<tr>
    				<td></td>
    				<td></td>
    				<td></td>
    			</tr>
				<tr>
					<td width="150px;">No. Dokumen Medik </td>
					<td width="10px;">:</td>
					<td><b><?php echo $new_no; ?></b><br/><br/></td>
	                <td></td>
	                <td></td>
	                <td></td>
				</tr>
				<tr>
					<td width="150px;">Nama</td>
					<td width="10px;">:</td>
					<td width="270px;"><?php echo strtoupper($datapasien['NAMA']); ?></td>
					<td width="100px">Jenis Pasien</td>
					<td width="10px;">:</td>
					<td></td>
				</tr>
				<tr>
					<td>Jenis Kelamin</td>
					<td>:</td>
					<td>
						<?php
							$jenkel	= $datapasien['JENISKELAMIN'];
							
							if($jenkel == "L"){
								$jenkel = "Laki-laki";
							}
							else{
								$jenkel	= "Perempuan";
							}
							
							echo strtoupper($jenkel);
						?>
					</td>
					<td>No. KTP/SIM</td>
					<td>:</td>
					<td><?php echo $datapasien['NOKTP']; ?></td>
				</tr>
				<tr>
					<td>Tempat Lahir</td>
					<td>:</td>
					<td><?php echo strtoupper($datapasien['TEMPAT']); ?></td>
					<td>No. Asuransi</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Tanggal Lahir</td>
					<td>:</td>
					<td>
						<?php
							echo detailTgl($datapasien['TGLLAHIR']);
						?>
					</td>
				</tr>
				<tr>
					<td>Umur</td>
					<td>:</td>
					<td>
						<?php 
							$a = datediff($datapasien['TGLLAHIR'], date("Y/m/d"));
							echo $a[years] . " Tahun, " . $a[months] . " Bulan, " . $a[days] . " Hari ";
						?>
					</td>
				</tr>
				<tr>
					<td>Status Pasien</td>
					<td>:</td>
					<td>
						<?php 
							$status	= $datapasien['STATUS'];
							
							switch ($status){
								case 1 :
										$status	= "Belum Kawin";
										break;
								case 2 :
										$status	= "Kawin";
										break;
								case 3 :
										$status	= "Janda";
										break;
							}
							echo strtoupper($status); 
						?>
					</td>
				</tr>
				<tr>
					<td>Pendidikan</td>
					<td>:</td>
					<td>
						<?php 
							$pend	= $datapasien['PENDIDIKAN'];
							
							switch ($pend){
								case 1 :
										$pend	= "SD";
										break;
								case 2 :
										$pend	= "SLTP";
										break;
								case 3 :
										$pend	= "SMU";
										break;
								case 4	:
										$pend	= "D3/Akademik";
										break;
								case 5	: 
										$pend	= "Universitas";
										break;
								case 6  :
										$pend	= "Belum Sekolah";
										break;
							}
							echo $pend; 
						?>
					</td>
				</tr>
				<tr>
					<td>Agama</td>
					<td>:</td>
					<td>
						<?php 
							$agama	= $datapasien['AGAMA'];
							
							switch ($agama){
								case 1 :
										$agama	= "islam";
										break;
								case 2 :
										$agama	= "kristen protestan";
										break;
								case 3 :
										$agama	= "katholik";
										break;
								case 4	:
										$agama	= "hindu";
										break;
								case 5	: 
										$agama	= "budha";
										break;
								case 6  :
										$agama	= "lain-lain";
										break;
							}
							echo strtoupper($agama); 
						?>
					</td>
				</tr>
				<tr>
					<td>Kewarganegaraan</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Alamat Rumah</td>
					<td>:</td>
					<td>
						<?php 
							$kelurahan	= $datapasien['KELURAHAN'];
							$kelurahan	= getkelurahan($kelurahan);
							$kecamatan	= $datapasien['KDKECAMATAN'];
							$kecamatan	= getkecamatan($kecamatan);
							$kota		= $datapasien['KOTA'];
							$kota		= getkota($kota);
							$provinsi	= $datapasien['KDPROVINSI'];
							$provinsi	= getprovinsi($provinsi);

							$alamat_lengkap = $datapasien['ALAMAT'] == "" ? "" : $datapasien['ALAMAT'] . ", ";
							$alamat_lengkap = $kelurahan == "" ? $alamat_lengkap : $alamat_lengkap . $kelurahan . ", <br/>";
							$alamat_lengkap = $alamat_lengkap . $kecamatan . ", " . $kota . ", " . $provinsi;
							echo $alamat_lengkap;
						?>
					</td>
				</tr>
				<tr>
					<td>Telepon</td>
					<td>:</td>
					<td><?php echo $datapasien['NOTELP']; ?></td>
				</tr>
				<tr>
					<td>Pekerjaan</td>
					<td>:</td>
					<td><?php echo $datapasien['PEKERJAAN']; ?></td>
				</tr>
				<tr>
					<td>Alamat Kantor</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Telepon</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Golongan Darah</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td colspan="6"><hr/></td>
					<td><hr/></td>
				</tr>
				<tr>
					<td width="150px;">Orang tua/Wali</td>
					<td width="10px;">:</td>
					<td><?php echo $datapasien['SUAMI_ORTU']; ?></td>
				</tr>
				<tr>
					<td>Suami/Istri</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>No. KTP/SIM</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>No. Asuransi</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Alamat Rumah</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Telepon</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Pekerjaan</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Alamat Kantor</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td>Telepon</td>
					<td>:</td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td colspan="6"><hr/></td>
					<td><hr/></td>
				</tr>
				<tr>
				<td width="150px;">Penanggung Jawab</td>
				<td width="10px;">:</td>
				<td width="200px;"><?php echo $datapasien['PENANGGUNGJAWAB_NAMA']; ?></td>
			</tr>
			<tr>
				<td>Pembayaran</td>
				<td>:</td>
				<td></td>
			</tr>
			<tr>
				<td>Hubungan Dengan Pasien</td>
				<td>:</td>
				<td><?php echo $datapasien['PENANGGUNGJAWAB_HUBUNGAN']; ?></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td>:</td>
				<td><?php echo $datapasien['PENANGGUNGJAWAB_ALAMAT']; ?></td>
			</tr>
			<tr>
				<td>Telepon</td>
				<td>:</td>
				<td><?php echo $datapasien['PENANGGUNGJAWAB_PHONE']; ?></td>
			</tr>
			<tr>
				<td>
					<br/>
				</td>
			</tr>
			</table>
    	</div>
		<br/>
    Petugas : <?php echo $_SESSION['NIP']; ?><br/>
    Tanggal :
    <?php
    $tgl    = datenow2();
    echo date("d/m/Y", strtotime($tgl));;
    ?>
	</body>
</html>
<?php
    $html      = ob_get_contents();
    $file_name = "Cetak Identitas Pasien";
    ob_end_clean();
    include "include/PDF.php";
    include "include/cetak_pdf_calibri.php";
?>

<!--<script>-->
<!--	window.print();-->
<!--</script>-->