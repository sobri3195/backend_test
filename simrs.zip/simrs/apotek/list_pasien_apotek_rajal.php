<?php
    require_once('ps_pagination.php');
    unset($_SESSION['apotekrajal']);

    $start 	= date('Y-m-d');
    $end 	= date('Y-m-d');
    if($_REQUEST['tgl_kunjungan'] != ''){
        $start = $_REQUEST['tgl_kunjungan'];
    }
    if($_REQUEST['tgl_kunjungan2'] != ''){
        $end = $_REQUEST['tgl_kunjungan2'];
    }

    $search = ' and (a.TGLREG BETWEEN "'.$start.'" and "'.$end.'")';
    $norm   = "";
    if(!empty($_GET['norm'])) {
        $norm =$_GET['norm'];
    }

    if($norm !="") {
        $search = $search." AND a.NOMR = '".$norm."' ";
    }

    $nama = "";
    if(!empty($_GET['nama'])) {
        $nama =$_GET['nama'];
    }

    if($nama !="") {
        $search = $search." AND b.NAMA LIKE '%".$nama."%' ";
    }
?>

<style>
    input[type="text"]{
        width:95%;
        height:16px;
        padding-left: 6px
    }
</style>

<div align="center">
    <div id="frame" style="width: 100%;">
        <div id="frame_title"><h3>LIST OBAT PASIEN RAJAL [DEVELOP]</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table width="300" border="0" cellspacing="0" class="tb">
                        <tr>
                        <td width="52">No RM</td>
                        <td width="192">
                            <input type="text" name="norm" id="norm"
                             value="<? if($norm!="") { echo $norm;}?>" class="text" >
                        </td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td>
                            <input type="text" name="nama" id="nama"
                                   value="<? if($nama!="") { echo $nama; }?>" class="text">
                        </td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td>
                            <input type="text" name="tgl_kunjungan" id="tgl_pesan" readonly="readonly" class="text datepicker"
                                   value="<? if($_REQUEST['tgl_kunjungan'] !=""): echo $_REQUEST['tgl_kunjungan']; else: echo date('Y-m-d'); endif; ?>"/>
                        </td>
                    </tr>
                    </tr>
                    <tr>
                        <td>Sd</td>
                        <td>
                            <input type="text" name="tgl_kunjungan2" id="tgl_pesan2" readonly="readonly" class="text datepicker"
                                   value="<? if($_REQUEST['tgl_kunjungan2'] !=""): echo $_REQUEST['tgl_kunjungan2']; else: echo date('Y-m-d'); endif; ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>
                            <input type="checkbox" value="" id="filter_sudah_diproses" />
                            <label for="filter_sudah_diproses">Tampilan Yang Sudah Diproses</label>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>
                            <input type="submit" value="Cari" class="text" />
                            <input type="hidden" name="link" value="list_pasien_apotek_rajal" />
                        </td>
                    </tr>
                </table>
            </form>

            <div id="table_search">
                <table class="tb" width="95%" style="margin:10px;" border="0" cellspacing="1" cellspading="1" title="List Kunjungan Data Pasien Per Hari Ini">
                    <tr align="center">
                        <th style="width:20px;">No</th>
                        <th style="width:80px;">TGL Daftar</th>
                        <th style="width:80px;">No RM</th>
                        <th>Nama Pasien</th>
                        <th style="width:100px;">Poli/ Ruang</th>
                        <th>Dokter</th>
                        <th width="70px">Cara Bayar</th>
                        <th width="100px">&nbsp;</th>
                    </tr>
                <?php
                    $NO=0;
                    $sql = "SELECT
                              a.IDXDAFTAR,
                              a.TGLREG,
                              a.NOMR,
                              a.KDPOLY,
                              a.KDDOKTER,
                              a.KDCARABAYAR,
                              a.flag_apotek_rajal,
                              b.NAMA,
                              c.nama AS poly,
                              d.NAMADOKTER AS dokter,
                              e.NAMA AS carabayar
                            FROM t_pendaftaran a
                                JOIN m_pasien b    ON b.NOMR = a.NOMR
                                JOIN m_poly c      ON c.kode = a.KDPOLY
                                JOIN m_dokter d    ON d.KDDOKTER = a.KDDOKTER
                                JOIN m_carabayar e ON e.KODE = a.KDCARABAYAR
                            WHERE a.KDPOLY != 0 ".$search." ORDER BY a.TGLREG ASC";

                    $pager = new PS_Pagination($connect, $sql, 15, 5, "tgl_kunjungan=".$tgl_kunjungan."&nama=".$nama."&norm=".$norm,"index.php?link=list_pasien_apotek_rajal&");
                    $rs    = $pager->paginate();
                    if(!$rs) die(mysql_error());
					$i     = 1;
					$count = 1;
                ?>

                <?php
                    while($data = mysql_fetch_array($rs)) {
                ?>
                    <tr class="<?=$count++ % 2 == 0 ? 'tr1' : 'tr2' ?>">
                        <td><?= (!isset($_REQUEST['page'])) or ($_REQUEST['page'] == 1) ? $i++ : ($_REQUEST['page'] - 1) * 15 + $i++; ?> </td>
                        <td><?= $data['TGLREG'];?></td>
                        <td><?= $data['NOMR'];?></td>
                        <td><?= $data['NAMA'];?></td>
                        <td><?= $data['poly'];?></td>
                        <td><?= $data['dokter'];?></td>
                        <td><?= $data['carabayar'];?></td>
                        <td>
                            <?php if( $data['flag_apotek_rajal'] == 0) {?>
                            <a href="<?=_BASE_?>index.php?link=add_resep&nomr=<?=$data['NOMR']?>&idx=<?=$data['IDXDAFTAR'];?>&rajal=1">
                                <input type='button' value='PROSESS' class='text'/>
                            </a>
                            <?php }else{ ?>
                                <a href="<?=_BASE_?>index.php?link=add_resep&nomr=<?=$data['NOMR']?>&idx=<?=$data['IDXDAFTAR'];?>&rajal=1">
                                    <input type='button' value='PROSESS' class='text'/>
                                </a>
                            <?php }?>
                        </td>
                    </tr>
                <?php
					}
                ?>
                    <div style='padding:5px;' align="center"><br />
                        <?php
                        echo $pager->renderFirst()." | ";
                        echo $pager->renderPrev() ." | ";
                        echo $pager->renderNav()  ." | ";
                        echo $pager->renderNext() ." | ";
                        echo $pager->renderLast();
                        ?>
                    </div>
                </table>

                <div style='padding:5px;' align="center"><br />
                    <?php
                        echo $pager->renderFirst()." | ";
                        echo $pager->renderPrev()." | ";
                        echo $pager->renderNav()." | ";
                        echo $pager->renderNext()." | ";
                        echo $pager->renderLast();
                    ?>
                </div>
            </div>
        </div>
    </div>
    <br />
</div>

<!--Modal Jenis Obat-->
<div id="dialog-form" >
    <p class="validateTips"></p>

    <form method="post">
        <fieldset>

        </fieldset>
    </form>
</div>

<script>
    jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 300,
        width: 350,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        buttons: {
            Simpan: function(){
                console.log("-->sendFormData()");
                sendFormData();
            },
            Batal: function() {
                jQuery(this).dialog("close");
            }
        },
        close: function() {

        },
        open: function(event, ui){

        }
    });

//    jQuery("#dialog-form").dialog({
//        title: "Jenis Pelayanan"
//    }).dialog("open");
</script>