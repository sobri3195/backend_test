<?php session_start();
	require_once ("../include/connect.php");
//    $sql = "select * from m_obat where nama_obat like '%{$_REQUEST['q']}%' and group_obat IN (1,2) and STATUS = 'aktif' ORDER BY group_obat,nama_obat,harga desc";
//	$mysql 	= mysql_query($sql);
//	if(mysql_num_rows($mysql) > 0){
//		while($dsql = mysql_fetch_array($mysql)){
//			echo $dsql['nama_obat']." - (".$dsql['stok'].") - (".$dsql['tahun'].") - (".$dsql['merk'].")|".$dsql['kode_obat']."|".$dsql['harga']."|".$dsql['satuan']."\n";
//		}
//	}

    $unit_amprahan = get_kode_amprah($_SESSION['KDUNIT']);

    $sql = "SELECT
                m_barang.kode_barang,
                m_barang.nama_barang,
                m_barang.satuan,
                m_barang.harga + (m_barang.harga * m_far_barang_unit.margin_keuntungan/100) AS harga,
                m_barang_group.nama_group,
                m_far_barang_unit.margin_keuntungan,
                m_far_golongan_barang.golongan,
                (SELECT saldo FROM t_barang_stok WHERE t_barang_stok.kode_barang = m_barang.kode_barang AND kode_amprah = '{$unit_amprahan}' ORDER BY t_barang_stok.kd_stok DESC LIMIT 1) as stok
            FROM m_barang
                 INNER JOIN m_barang_group ON m_barang.group_barang = m_barang_group.group_barang
                 INNER JOIN m_far_barang_unit ON m_barang.kode_barang = m_far_barang_unit.kode_barang
                 INNER JOIN m_far_golongan_barang ON m_barang.golongan = m_far_golongan_barang.id_golongan
            WHERE m_barang_group.farmasi='1' AND m_far_barang_unit.kode_amprah = '{$unit_amprahan}' AND m_barang.nama_barang LIKE '%{$_REQUEST['q']}%' LIMIT 0,10;";

    $mysql 	= mysql_query($sql);
    if(mysql_num_rows($mysql) > 0){
        while($dsql = mysql_fetch_array($mysql)){
            echo $dsql['nama_barang'] ."|". $dsql['kode_barang'] ."|".  $dsql['harga'] ."|". $dsql['satuan'] ."\n";
        }
    }


    function get_kode_amprah($kode_unit){
        $sql  = "SELECT kode_amprah FROM m_login WHERE KDUNIT='{$kode_unit}';";
        $rs   = mysql_query($sql);
        $data = mysql_fetch_array($rs);
        return $data['kode_amprah'];
    }