<?php
include 'include/connect.php';
include 'include/function.php';
?>
<script type="text/javascript">
	jQuery.noConflict();
</script>
<script>
jQuery(document).ready(function(){
	jQuery('.batal').click(function(){
		var idxbayar	= jQuery(this).attr('id');
		jQuery.post('<?php echo _BASE_;?>cartbill_cancel_tmp.php',{idxbayar:idxbayar},function(data){
			jQuery('#load_tmp_cartbayar').load('<?php echo _BASE_;?>tmp_cartbayar.php');
		});
	});
    jQuery('.batal_alkes').click(function(){
		var idxbayar	= jQuery(this).attr('id');
        var alkes       = jQuery(this).attr('id');
		jQuery.post('<?php echo _BASE_;?>cartbill_cancel_tmp.php',{idxbayar:idxbayar},function(data){
			jQuery('#load_tmp_cartbayar').load('<?php echo _BASE_;?>tmp_cartbayar.php?alkes='+alkes);
		});
	});
	jQuery('#simpan').click(function(){
		var nomr		= jQuery('#nomr').val();
		var idxdaftar	= jQuery('#idxdaftar').val();
		var carabayar	= jQuery('#carabayar').val();
		var poly		= jQuery('#poly').val();
		var retribusi	= jQuery('#retribusi').val();
		var kddokter	= jQuery('#kddokter').val();
		var aps			= jQuery('#aps').val();
		var nip         = jQuery('#nip').val();
		if(aps == 1){
			var file = 'cartbill_save_bayar_aps.php'
		}else{
			var file = 'cartbill_save_bayar.php'
		}

        var saldo       = jQuery(this).attr('saldo');
		jQuery.post('<?php echo _BASE_;?>'+file,{nomr:nomr,idxdaftar:idxdaftar,carabayar:carabayar,poly:poly,kddokter:kddokter,saldo:saldo,tindakan:1,nip:nip},function(data){

			window.close();
			if (window.opener && !window.opener.closed) {
				window.opener.location.reload();
			}
		});
	});

    jQuery('#simpan_alkes').click(function(){
        var nomr		= jQuery('#nomr').val();
        var idxdaftar	= jQuery('#idxdaftar').val();
        var carabayar	= jQuery('#carabayar').val();
        var poly		= jQuery('#poly').val();
        var retribusi	= jQuery('#retribusi').val();
        var kddokter	= jQuery('#kddokter').val();
        var aps			= jQuery('#aps').val();
        var file        = 'cartbill_save_alkes.php';
        var nip         = jQuery('#nip').val();

        var saldo       = jQuery(this).attr('saldo');
        jQuery.post('<?php echo _BASE_;?>'+file,{nomr:nomr,idxdaftar:idxdaftar,carabayar:carabayar,poly:poly,kddokter:kddokter,saldo:saldo,tindakan:0,nip:nip},function(data){

            window.close();
            if (window.opener && !window.opener.closed) {
                window.opener.location.reload();
            }
        });
    });
});
</script>
<?php
if(isset($_REQUEST['alkes'])){
	$query	= 'select a.KODETARIF, a.QTY, a.IDXBAYAR, a.ID, a.POLY, b.nama_barang, a.tarif as harga, a.saldo, a.kd_barang
			   from tmp_cartbayar a
			   join m_barang b on b.kode_barang = a.kd_barang
			   where a.IP = "'.getRealIpAddr().'"';
	$query = mysql_query($query);
	if(mysql_num_rows($query) > 0):
		$i = 1;
		$total	= 0;
		echo '<table width="340px" style="float:right;" class="popup-table">';
		echo '<tr><th>No</th><th>Nama Tindakan</th><th>Harga</th><th>Qty</th><th>Aksi</th></tr>';
		echo '<tbody>';
		while($data = mysql_fetch_array($query)){
			echo '<tr><td>'.$i.'</td><td>'.$data['nama_barang'].'</td><td style="text-align:right;">'.curformat($data['harga'],2).'</td><td style="text-align:center;">'.$data['QTY'].'</td><td><span class="batal_alkes" alkes="1" id="'.$data['IDXBAYAR'].'">Batal</span></td></tr>';
			$i++;
			$total  = $total + ($data['harga'] * $data['QTY']);
            $saldo  = $data['saldo'];
		}
		echo '<tr class="footer"><td colspan="2">Total</td><td style="text-align:right;">'.curformat($total).'</td><td>&nbsp;</td></tr>';
		echo '</tbody>';
		echo '<tr><td colspan="4"><span class="simpan_alkes" id="simpan_alkes" saldo="'.$saldo.'">SIMPAN</span></td></tr>';
		echo '</table>';
	endif;
}
else{
	$query	= 'select a.KODETARIF, a.QTY, a.IDXBAYAR, a.ID, a.POLY, b.nama_tindakan, a.tarif as harga from tmp_cartbayar a join m_tarif2012 b on b.kode_tindakan = a.KODETARIF where a.IP = "'.getRealIpAddr().'"';
	$query = mysql_query($query);
	if(mysql_num_rows($query) > 0):
		$i = 1;
		$total	= 0;
		echo '<table width="340px" style="float:right;" class="popup-table">';
		echo '<tr><th>No</th><th>Nama Tindakan</th><th>Harga</th><th>Qty</th><th>Aksi</th></tr>';
		echo '<tbody>';
		while($data = mysql_fetch_array($query)){
			echo '<tr><td>'.$i.'</td><td>'.$data['nama_tindakan'].'</td><td style="text-align:right;">'.curformat($data['harga'],2).'</td><td style="text-align:center;">'.$data['QTY'].'</td><td><span class="batal" id="'.$data['IDXBAYAR'].'">Batal</span></td></tr>';
			$i++;
			$total = $total + ($data['harga'] * $data['QTY']);
		}
		echo '<tr class="footer"><td colspan="2">Total</td><td style="text-align:right;">'.curformat($total).'</td><td>&nbsp;</td></tr>';
		echo '</tbody>';
		echo '<tr><td colspan="4"><span class="simpan" id="simpan" saldo="0">SIMPAN</span></td></tr>';
		echo '</table>';
	endif;
}
?>
<input type="hidden" id="nomr" value="<?=$_REQUEST['nomr'];?>"/>
<input type="hidden" id="idxdaftar" value="<?=$_REQUEST['idx'];?>"/>
<input type="hidden" id="poly" value="<?=$_REQUEST['poly'];?>"/>
<input type="hidden" id="kddokter" value="<?=$_REQUEST['dokter'];?>"/>
<input type="hidden" id="nip" value="<?= $_REQUEST['nip']; ?>">