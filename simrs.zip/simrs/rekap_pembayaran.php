<?php
include("include/connect.php");
require_once('new_pagination.php');
if($_REQUEST['tgl_reg'] != ''){
	$start	= $_GET['tgl_reg'];
	$end	= $_GET['tgl_reg2'];
	if($start == ''){
		$start = date('Y-m-d');
	}
	if($end	== ''){
		$end	= date('Y-m-d');
	}
	$search	= 'and (TGLBAYAR between "'.$start.'" and "'.$end.'")';
}else{
	$search	= 'and (TGLBAYAR between "'.date('Y-m-d').'" and "'.date('Y-m-d').'")';
}
?>

<div align="center">
	<div id="frame" style="width:80%;">
		<div id="frame_title">
			<h3>REKAP PENDAPATAN</h3></div>
			<div align="right" style="margin:5px;">
				<form name="formsearch" method="get" action="<?php $_SERVER['PHP_SELF']; ?>" >
				<table width="248" border="0" cellspacing="0" class="tb">
				<tr><td>Tanggal</td><td><input type="text" name="tgl_reg" id="tgl_pesan" readonly="readonly" class="text datepicker" value="<? if($tgl_reg!="") {
echo $tgl_reg; }?>" style="width:100px;"/></td><td ></td><td></td>
				</tr>
                <tr><td>Sd</td><td><input type="text" name="tgl_reg2" id="tgl_pesan2" readonly="readonly" class="text datepicker" value="<? if($tgl_reg2!="") {
echo $tgl_reg2;}?>" style="width:100px;" /></td><td ><input type="hidden" name="link" value="31" /></td><td><input type="submit" value=" C a r i " class="text"/></td>
				</tr>
				</table>
				</form>
			</div>
            <?php
				$sql	= 'select TGLBAYAR, SHIFT from t_bayarrajal where TGLBAYAR is not null and STATUS = "LUNAS" '.$search.' group by TGLBAYAR';
//				$sql	= 'select TGLBAYAR, SHIFT from t_bayarrajal where TGLBAYAR is not null and STATUS = "LUNAS"  group by TGLBAYAR';
				$qry	= mysql_query($sql);
			?>
			<div id="table_search" style="min-height:300px;">
				<table width="95%" border="0" class="tb" cellspacing="0" cellspading="0">
					<tr align="center"><th width="156">TGL BAYAR</th><th width="129">SHIFT I</th><th width="130">SHIFT II</th><th width="116">SHIFT III</th><th width="204">Total Pendapatan Perhari</th></tr>
                    <?php
					while($data = mysql_fetch_array($qry)){
						$sql_1	= mysql_query('SELECT TGLBAYAR, SHIFT,TOTTARIFRS,SUM(JMBAYAR) AS total FROM t_bayarrajal WHERE TGLBAYAR ="'.$data['TGLBAYAR'].'" AND SHIFT ="1" AND STATUS = "LUNAS"');
						$shift_1= mysql_fetch_array($sql_1);

						$sql_2	= mysql_query('SELECT TGLBAYAR, SHIFT,TOTTARIFRS,SUM(JMBAYAR) AS total FROM t_bayarrajal WHERE TGLBAYAR ="'.$data['TGLBAYAR'].'" AND SHIFT ="2" AND STATUS = "LUNAS"');
						$shift_2= mysql_fetch_array($sql_2);

						$sql_3	= mysql_query('SELECT TGLBAYAR, SHIFT,TOTTARIFRS,SUM(JMBAYAR) AS total FROM t_bayarrajal WHERE TGLBAYAR ="'.$data['TGLBAYAR'].'" AND SHIFT ="3" AND STATUS = "LUNAS"');
						$shift_3= mysql_fetch_array($sql_3);

						echo '<tr>
								<td>'.$data['TGLBAYAR'].'  ['.'<a href="index.php?link=31pertanggal&tgl='.$data['TGLBAYAR'].'">Rekap</a>
								<a href="index.php?link=31pertanggal_det&tgl='.$data['TGLBAYAR'].'"> | Det ]</a>
								</td>
								<td align="right">'.curformat($shift_1['total']).'</td>
								<td align="right">'.curformat($shift_2['total']).'</td>
								<td align="right">'.curformat($shift_3['total']).'</td>
								<td align="right">'.curformat($shift_1['total']+$shift_2['total']+$shift_3['total']).'</td></tr>';
					}

					?>
				</table>
				<!-- added 07082015 -->
				<div style="text-align: left;padding:30px;" >
					<?php 
						$sqltimedb	= datenow();
						
						if($_GET['tgl_reg'] == ''){
							$jmlbatal	= jmlbatal2($sqltimedb);
							echo "Jumlah Pasien Batal Tanggal $sqltimedb = ".$jmlbatal;
						}else{
							if($start == $end){
								$start		= str_replace('/', '-', $start);
								$end		= str_replace('/', '-', $end);
								$jmlbatal	= jmlbatal2($start);
								echo "Jumlah Pasien Batal Tanggal $start = ".$jmlbatal;
							}else{
								$start		= str_replace('/', '-', $start);
								$end		= str_replace('/', '-', $end);
								$end2		= $end;
								$enderlier	= substr($end, 0, 8);
								$endtgl		= substr($end, 8, 2);
								$endtgl		= $endtgl+1;
								$end		= $enderlier.$endtgl;
								$jmlbatal	= jmlbatal3($start,$end);
								echo "Jumlah Pasien Batal Tanggal $start s/d $end2 = ".$jmlbatal;
							}
						}
					?>
				</div>
				<!-- added 07082015 -->
            </div>
		</div>             
	</div>
</div>