<table width="609" class="tb">
  <tr>
    <td width="411"><p>- Keluhan utama :</p>
    <p>
      <textarea name="textarea" id="textarea" cols="40" rows="5"></textarea>
    </p></td>
    <td width="338" rowspan="3"><table width="342" border="0" cellspacing="0">
      <tr>
        <td width="175">- Pusing</td>
        <td width="86"><input type="checkbox" name="checkbox" id="checkbox" />
          Ya</td>
        <td width="75"><input type="checkbox" name="checkbox9" id="checkbox9" />
          Tidak</td>
      </tr>
      <tr>
        <td>- Pingsan</td>
        <td><input type="checkbox" name="checkbox2" id="checkbox2" />
Ya</td>
        <td><input type="checkbox" name="checkbox10" id="checkbox10" />
          Tidak</td>
      </tr>
      <tr>
        <td>- Amnesia</td>
        <td><input type="checkbox" name="checkbox3" id="checkbox3" />
Ya</td>
        <td><input type="checkbox" name="checkbox11" id="checkbox11" />
          Tidak</td>
      </tr>
      <tr>
        <td>- Retrograde</td>
        <td><input type="checkbox" name="checkbox4" id="checkbox4" />
Ya</td>
        <td><input type="checkbox" name="checkbox12" id="checkbox12" />
          Tidak</td>
      </tr>
      <tr>
        <td>- Muntah</td>
        <td><input type="checkbox" name="checkbox5" id="checkbox5" />
Ya</td>
        <td><input type="checkbox" name="checkbox13" id="checkbox13" />
          Tidak</td>
      </tr>
      <tr>
        <td>- Diare</td>
        <td><input type="checkbox" name="checkbox6" id="checkbox6" />
Ya</td>
        <td><input type="checkbox" name="checkbox14" id="checkbox14" />
          Tidak</td>
      </tr>
      <tr>
        <td>- Kejang</td>
        <td><input type="checkbox" name="checkbox7" id="checkbox7" />
Ya</td>
        <td><input type="checkbox" name="checkbox15" id="checkbox15" />
          Tidak</td>
      </tr>
      <tr>
        <td>- Sesak napas</td>
        <td><input type="checkbox" name="checkbox8" id="checkbox8" />
Ya</td>
        <td><input type="checkbox" name="checkbox16" id="checkbox16" />
          Tidak</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><p>- Keluhan tambahan</p>
      <p>
        <textarea name="textarea2" id="textarea2" cols="40" rows="5"></textarea>
    </p></td>
  </tr>
  <tr>
    <td><p>- Penyebab luar kecelakaan (kode E.I.C.D)</p>
      <p>
        <textarea name="textarea3" id="textarea3" cols="40" rows="5"></textarea>
    </p></td>
  </tr>
</table>
<p align="center">&nbsp;</p>
