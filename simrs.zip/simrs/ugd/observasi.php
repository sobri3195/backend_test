<table width="900" border="0" cellspacing="0" class="tb">
  <tr>
    <th width="100"><div align="center">Tanggal</div></th>
    <th width="100"><div align="center">Jam </div></th>
    <th width="100"><div align="center">Suhu</div></th>
    <th width="100"><div align="center">Kesadaran</div></th>
    <th width="100"><div align="center">Nadi</div></th>
    <th width="100"><div align="center">Tekanan Darah</div></th>
    <th width="100"><div align="center">Pernapasan</div></th>
    <th width="100"><div align="center">Obat/ Tindakan</div></th>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
