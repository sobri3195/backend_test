<table width="969" border="0" cellspacing="0">
  <tr>
    <td>1</td>
    <td>PEMERIKSAAN RONTGEN</td>
    <td width="206">No&nbsp;<input type="text" name="textfield" id="textfield"></td>
    <td colspan="2">Jam&nbsp;<input type="text" name="textfield2" id="textfield2"></td>
  </tr>
  <tr>
    <td width="24">&nbsp;</td>
    <td colspan="4"><input name="textfield3" type="text" id="textfield3" size="120"></td>
  </tr>
  <tr>
    <td>2</td>
    <td width="268">PEMERIKSAAN LAB</td>
    <td><input type="checkbox" name="checkbox" id="checkbox">
      HB</td>
    <td width="261"><input type="checkbox" name="checkbox3" id="checkbox3">
      Leus</td>
    <td width="200"><input type="checkbox" name="checkbox5" id="checkbox5">
      Ureum</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox2" id="checkbox2">
      Urine</td>
    <td><input type="checkbox" name="checkbox4" id="checkbox4">
      Glukosa</td>
    <td><input type="checkbox" name="checkbox6" id="checkbox6">
      Kreatinin</td>
  </tr>
  <tr>
    <td>3</td>
    <td>PEMERIKSAAN KHUSUS</td>
    <td colspan="3"><input name="textfield4" type="text" id="textfield4" size="78"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="4"><input name="textfield5" type="text" id="textfield5" size="120"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>4</td>
    <td>DIAGNOSIS</td>
    <td colspan="3"><input name="textfield6" type="text" id="textfield6" size="78"></td>
  </tr>
  <tr>
    <td>5</td>
    <td>TINDAKAN YANG DILAKUKAN</td>
    <td colspan="3"><input name="textfield7" type="text" id="textfield7" size="78"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="4"><input name="textfield8" type="text" id="textfield8" size="120"></td>
  </tr>
  <tr>
    <td>6</td>
    <td>OBAT - OBATAN YANG DIBERIKAN</td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="4" rowspan="5"><textarea name="textarea" id="textarea" cols="120" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>7</td>
    <td>HASIL PENGANGANAN DI UGD</td>
    <td colspan="3"><input type="checkbox" name="checkbox7" id="checkbox7">
      Pulang untuk berobat jalan</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3"><input type="checkbox" name="checkbox8" id="checkbox8">
      Observasi dan boleh pulang</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3"><input type="checkbox" name="checkbox9" id="checkbox9">
      Pindah rawat inap</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox10" id="checkbox10">
    Meninggal di UGD</td>
    <td colspan="2"><input type="checkbox" name="checkbox15" id="checkbox15">
      &lt; 2 jam 
      <input type="checkbox" name="checkbox16" id="checkbox16"> 
      &gt; 2 jam</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox11" id="checkbox11">
      Meninggal di ruangan</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox12" id="checkbox12">
    Penyebab kematian</td>
    <td colspan="2"><input type="text" name="textfield9" id="textfield9"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox13" id="checkbox13">
    Dirujuk ke</td>
    <td colspan="2"><input type="text" name="textfield10" id="textfield10"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox14" id="checkbox14">
    Atas dasar</td>
    <td colspan="2"><input type="checkbox" name="checkbox17" id="checkbox17">
      Tempat penuh</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><input type="checkbox" name="checkbox18" id="checkbox18">
      Perlu pasilitas lebih baik</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><input type="checkbox" name="checkbox19" id="checkbox19">
      Permintaan pasien</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox20" id="checkbox20">
    Diantar oleh</td>
    <td colspan="2"><input type="checkbox" name="checkbox21" id="checkbox21"> 
      Ambulance Rumah Sakit
</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><input type="checkbox" name="checkbox22" id="checkbox22">
    Ambulance lain</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><input type="checkbox" name="checkbox23" id="checkbox23">
      Kendaraan umum</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><input type="checkbox" name="checkbox24" id="checkbox24">
      Kendaraan pribadi</td>
  </tr>
</table>
