<table width="865" class="tb">
  <tr>
    <td width="961" colspan="6"><p>Kesadaran</p>
    <p>
      <textarea name="textarea" id="textarea" cols="100%" rows="5"></textarea>
    </p></td>
  </tr>
  <tr>
    <td>
  <table width="859">  
  <tr>  
    <td width="110">Kepala</td>
    <td width="148"><input type="text" name="textfield" id="textfield"></td>
    <td width="58">Perut</td>
    <td width="322" rowspan="3"><textarea name="textarea2" id="textarea2" cols="45" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>Telinga</td>
    <td><input type="text" name="textfield2" id="textfield2"></td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td>Hidung</td>
    <td><input type="text" name="textfield3" id="textfield3"></td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td>Mulut</td>
    <td><input type="text" name="textfield4" id="textfield4"></td>
    <td>Kandungan</td>
    <td rowspan="3"><textarea name="textarea3" id="textarea3" cols="45" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>Gigi</td>
    <td><input type="text" name="textfield5" id="textfield5"></td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td>Tenggorok</td>
    <td><input type="text" name="textfield6" id="textfield6"></td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td>Leher</td>
    <td><input type="text" name="textfield7" id="textfield7"></td>
    <td>Kemaluan</td>
    <td><input type="text" name="textfield9" id="textfield9"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>Ekstremitas</td>
    <td><input type="text" name="textfield10" id="textfield10" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td valign="top"><p>Bunyi jantung I Murmur +/-&nbsp;</p>
      <p></p>
      Bunyi jantung II </td>
    <td><textarea name="textarea4" id="textarea4" cols="45" rows="10"></textarea></td>
  </tr>
  <tr>
    <td>Dada</td>
    <td><input type="text" name="textfield8" id="textfield8"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   </table> 
    </td>
  </tr>
</table>
