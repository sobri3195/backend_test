<table width="749" border="0" cellspacing="0">
  <tr>
    <td width="25">1</td>
    <td width="115">Regio</td>
    <td colspan="3"><input name="textfield" type="text" id="textfield" size="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>Jenis Luka</td>
    <td width="167"><input type="text" name="textfield2" id="textfield2"></td>
    <td width="59">Ukuran</td>
    <td width="373"><input type="text" name="textfield3" id="textfield3"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox" id="checkbox">
    Hematoma</td>
    <td colspan="2"><input type="checkbox" name="checkbox3" id="checkbox3">
    Nyeri tekan</td>
    <td><input type="checkbox" name="checkbox5" id="checkbox5">
      Nyeri sumbu</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox2" id="checkbox2">
    Kreptasi</td>
    <td colspan="2"><input type="checkbox" name="checkbox4" id="checkbox4">
    Functio laesa</td>
    <td><input type="checkbox" name="checkbox6" id="checkbox6">
      Putus tendon</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Regio</td>
    <td colspan="3"><input name="textfield4" type="text" id="textfield4" size="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>Jenis Luka</td>
    <td colspan="2"><input type="text" name="textfield5" id="textfield5"></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox7" id="checkbox7">
Hematoma</td>
    <td colspan="2"><input type="checkbox" name="checkbox9" id="checkbox9">
Nyeri tekan</td>
    <td><input type="checkbox" name="checkbox11" id="checkbox11">
Nyeri sumbu</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox8" id="checkbox8">
Kreptasi</td>
    <td colspan="2"><input type="checkbox" name="checkbox10" id="checkbox10">
Functio laesa</td>
    <td><input type="checkbox" name="checkbox12" id="checkbox12">
Putus tendon</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Regio</td>
    <td colspan="3"><input name="textfield6" type="text" id="textfield6" size="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>Jenis Luka</td>
    <td colspan="2"><input type="text" name="textfield7" id="textfield7"></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox13" id="checkbox13">
Hematoma</td>
    <td colspan="2"><input type="checkbox" name="checkbox15" id="checkbox15">
Nyeri tekan</td>
    <td><input type="checkbox" name="checkbox17" id="checkbox17">
Nyeri sumbu</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="checkbox" name="checkbox14" id="checkbox14">
Kreptasi</td>
    <td colspan="2"><input type="checkbox" name="checkbox16" id="checkbox16">
Functio laesa</td>
    <td><input type="checkbox" name="checkbox18" id="checkbox18">
Putus tendon</td>
  </tr>
</table>
