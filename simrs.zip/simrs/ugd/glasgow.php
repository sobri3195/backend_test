<table width="676" height="496"  class="tb">
  <tr>
    <td width="424" height="121"><table width="200" height="105" border="0" cellspacing="0">
      <tr>
        <td height="21" colspan="2">Membuka mata</td>
        </tr>
      <tr>
        <td width="150" height="21"><input type="checkbox" name="checkbox" id="checkbox" />
          Spontan</td>
        <td width="46">4</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox2" id="checkbox2" />
          Pada perintah</td>
        <td>3</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox3" id="checkbox3" />
          Pada nyeri</td>
        <td>2</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox4" id="checkbox4" />
          Tidak ada</td>
        <td>1</td>
      </tr>
    </table></td>
    <td width="308"><table width="287" height="105" border="0" cellspacing="0">
      <tr>
        <td height="21" colspan="3">Trauma score</td>
        </tr>
      <tr>
        <td height="21">Res. rate</td>
        <td height="21"><input type="checkbox" name="checkbox8" id="checkbox8" />
10-24/ mnt</td>
        <td width="52">4</td>
      </tr>
      <tr>
        <td width="92" height="21">&nbsp;</td>
        <td width="137"><input type="checkbox" name="checkbox9" id="checkbox9" />
24-35/ mnt</td>
        <td>3</td>
      </tr>
      <tr>
        <td height="21">Res. expans</td>
        <td height="21"><input type="checkbox" name="checkbox10" id="checkbox10" /> 
          Normal
</td>
        <td>1</td>
      </tr>
      <tr>
        <td height="21">&nbsp;</td>
        <td height="21"><input type="checkbox" name="checkbox11" id="checkbox11" />
          Reactive</td>
        <td>0</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="200" height="147" border="0" cellspacing="0">
      <tr>
        <td height="21" colspan="2">Respon motor</td>
        </tr>
      <tr>
        <td width="150" height="21"><input type="checkbox" name="checkbox" id="checkbox" />
          Menurut perintah</td>
        <td width="46">6</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox2" id="checkbox2" />
          Pada rangsangan</td>
        <td>5</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox3" id="checkbox3" />
          Fleksi menarik</td>
        <td>4</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox6" id="checkbox6" />
          Fleksi abnormal</td>
        <td>3</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox5" id="checkbox5" />
          Ekstensi</td>
        <td>2</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox4" id="checkbox4" />
          Tanpa Respon</td>
        <td>1</td>
      </tr>
    </table></td>
    <td><table width="287" height="126" border="0" cellspacing="0">
      <tr>
        <td height="21" colspan="2">Tekanan darah syntolic</td>
        </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox12" id="checkbox12" /> 
          &gt;&gt; 90 mm Hg</td>
        <td width="52">4</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox13" id="checkbox13" />
          70-89 mm Hg</td>
        <td>3</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox14" id="checkbox14" />
          50-69 mm Hg</td>
        <td>2</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox15" id="checkbox15" />
0-49 mm Hg</td>
        <td>1</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox16" id="checkbox16" /> 
          Pulse</td>
        <td>0</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="200" height="126" border="0" cellspacing="0">
      <tr>
        <td height="21" colspan="2">Respon</td>
        </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox7" id="checkbox7" />
          Orientasi baik</td>
        <td>5</td>
      </tr>
      <tr>
        <td width="150" height="21"><input type="checkbox" name="checkbox" id="checkbox" />
          Orientasi buruk</td>
        <td width="46">4</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox2" id="checkbox2" />
          Bicara ngacau</td>
        <td>3</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox3" id="checkbox3" />
          Tanpa arti</td>
        <td>2</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox4" id="checkbox4" />
          Tanpa respon</td>
        <td>1</td>
      </tr>
    </table></td>
    <td><table width="287" height="84" border="0" cellspacing="0">
      <tr>
        <td height="21" colspan="2">Capillary</td>
        </tr>
      <tr>
        <td width="229" height="21"><input type="checkbox" name="checkbox8" id="checkbox8" />
          Normal</td>
        <td width="52">2</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox9" id="checkbox9" />
          Terlambat</td>
        <td>1</td>
      </tr>
      <tr>
        <td height="21"><input type="checkbox" name="checkbox10" id="checkbox10" />
          Tidak ada</td>
        <td>0</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="277" height="53" border="0" cellspacing="0">
      <tr>
        <td width="149" height="21">Nilai tertinggi </td>
        <td width="271">4 + 5 + 6 = 15</td>
        </tr>
      <tr>
        <td height="21">Nilai terendah</td>
        <td height="21">1 + 1 + 1 = 3</td>
        </tr>
    </table></td>
    <td></td>
  </tr>
</table>
</body>
</html>