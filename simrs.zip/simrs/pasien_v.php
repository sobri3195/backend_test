<?php 
	include 'include/connect.php';
	include 'include/function.php';
?>
<div align="center">
	<div id="frame">
		<div id="frame_title"><h3>Data Pasien</h3></div>
	   	<fieldset class="fieldset">
	   		<legend>Identitas</legend>
	   		<div style="margin:35px; text-align:left;">
	   			<?php 
	   				$cekPasien		= cek_pasienStatus($_REQUEST['nomr'], $_REQUEST['idx']);
	   				$cekPasienAPS	= cek_pasienAPSStatus($_REQUEST['nomr'], $_REQUEST['idx']);
	   				
	   				if($cekPasien > 0){
	   					$data_pasien 		= cek_pasien($_REQUEST['nomr']);
	   					while($dp = mysql_fetch_array($data_pasien)){
	   						$nomr 			= $dp['NOMR'];
	   						$title 			= $dp['TITLE'];
	   						$nama			= $dp['NAMA'];
	   						$tempat 		= $dp['TEMPAT'];
	   						$tgllhr			= $dp['TGLLAHIR'];
	   						$jenkel			= $dp['JENISKELAMIN'];
	   						$detailjenkel	= getJenkelDetail($jenkel);
	   						$alamat			= $dp['ALAMAT'];
	   						$kel 			= $dp['KELURAHAN'];
	   						$namakel		= getkelurahan($kel);
	   						$kec 			= $dp['KDKECAMATAN'];
	   						$namakec 		= getkecamatan($kec);
	   						$kota 			= $dp['KOTA'];
	   						$namakota 		= getkota($kota);
	   						$prov 			= $dp['KDPROVINSI'];
	   						$namaprov 		= getprovinsi($prov);
	   						$telp 			= $dp['NOTELP'];
	   						$status 		= $dp['STATUS'];
	   						$statusdetail 	= getStatusDetail($status);
	   						$agama 			= $dp['AGAMA'];
	   						$agamadetail	= getAgamaDetail($agama);
	   						$pend	 		= $dp['PENDIDIKAN'];
	   						$penddetail 	= getPendidikanDetail($pend);
	   						$crbayar 		= $dp['KDCARABAYAR'];
	   						$crbyralldata	= getallcarabayar($crbayar);
	   						$namacrbayar	= $crbyralldata['NAMA']; 
	   					}
	   				}
	   				else{
	   					$data_pasien 		= getPasienAPS($_REQUEST['nomr']);
	   					while($dp = mysql_fetch_array($data_pasien)){
	   						$nomr 			= $dp['NOMR'];
	   						$title 			= $dp['TITLE'];
	   						$nama			= $dp['NAMA'];
	   						$tempat 		= $dp['TEMPAT'];
	   						$tgllhr			= $dp['TGLLAHIR'];
	   						$jenkel			= $dp['JENISKELAMIN'];
	   						$detailjenkel	= getJenkelDetail($jenkel);
	   						$alamat			= $dp['ALAMAT'];
	   						$kel 			= $dp['KELURAHAN'];
	   						$namakel		= getkelurahan($kel);
	   						$kec 			= $dp['KDKECAMATAN'];
	   						$namakec 		= getkecamatan($kec);
	   						$kota 			= $dp['KOTA'];
	   						$namakota 		= getkota($kota);
	   						$prov 			= $dp['KDPROVINSI'];
	   						$namaprov 		= getprovinsi($prov);
	   						$telp 			= $dp['NOTELP'];
	   						$status 		= $dp['STATUS'];
	   						$statusdetail 	= getStatusDetail($status);
	   						$agama 			= $dp['AGAMA'];
	   						$agamadetail	= getAgamaDetail($agama);
	   						$pend	 		= $dp['PENDIDIKAN'];
	   						$penddetail 	= getPendidikanDetail($pend);
	   						$crbayar 		= $dp['KDCARABAYAR'];
	   						$crbyralldata	= getallcarabayar($crbayar);
	   						$namacrbayar	= $crbyralldata['NAMA'];
	   					}
	   				}
	   			?>
	   			<table width="100%">
	   				<tr>
	   					<td>
	   						<label>No. MR</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $nomr; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Nama</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php 
	   							if($title != ''){
	   								echo $nama.", ".$title; 
	   							}
	   							else{
	   								echo $nama;
	   							}
	   						?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Tempat Lahir</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $tempat; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Tanggal Lahir</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $tgllhr; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Jenis Kelamin</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $detailjenkel; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Alamat</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $alamat; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Kelurahan</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namakel; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Kecamatan</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namakec; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Kota</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namakota; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Provinsi</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namaprov; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Telepon</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $telp; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Status</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $statusdetail; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Agama</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $agamadetail; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Pendidikan</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $penddetail; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Tanggal Lahir</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namacrbayar; ?>
	   					</td>
	   					<td>
	   						<br/>
	   					</td>
	   					<td style="text-align: right">
	   						<button class="button edit" id="edit_pasien">Edit</button>
	   					</td>
	   				</tr>
	   			</table>
	   		</div>
	   	</fieldset>
	</div>
</div>

<?php /*?><div id="dialog-form" >
    <p class="validateTips">Harap isi semua field yang dibutuhkan..</p>

    <form method="post">
        <fieldset>
            <table>
            	<tr>
	   				<td>
	   					<label for="nomr" id="label_nomr">No. MR</label>
	   				</td>
	   				<td> : </td>
	   				<td>
	   					<input type="text" name="nomr" id="nomr" value="<?php echo $nomr; ?>" autofocus  class="text ui-widget-content ui-corner-all">
	   				</td>
	   			</tr>
	   			<tr>
	   				<td>
	   					<label for="nama" id="label_nama">Nama</label>
	   				</td>
	   				<td> : </td>
	   				<td>
	   					<?php 
	   						$cetaknama 	= '';
	   						if($title != ''){
	   							$cetaknama = $nama.", ".$title; 
	   						}
	   						else{
	   							$cetaknama = $nama;
	   						}
	   					?>
	   					<input type="text" name="nama" id="nama" value="<?php echo $cetaknama; ?>"  class="text ui-widget-content ui-corner-all">
	   				</td>
	   			</tr>
	   			<tr>
	   				<td>
	   					<label for="tempat" id="label_tempat">Tempat Lahir</label>
	   				</td>
	   				<td> : </td>
	  				<td>
	   					<input type="text" name="tempat" id="tempat" value="<?php echo $tempat; ?>"   class="text ui-widget-content ui-corner-all">
	   				</td>
	   			</tr>
	   			<tr>
	  				<td>
	   					<label for="tgllhr" id="label_tgllhr">Tanggal Lahir</label>
	   				</td>
	   				<td> : </td>
	   				<td>
	   					<input type="text" name="tgllhr" id="tgllhr" value="<?php echo $tgllhr; ?>"  class="text ui-widget-content ui-corner-all datepicker">
	   				</td>
	   			</tr>
	   			<tr>
	   				<td>
	   					<label for="jenkel" id="jenkel">Jenis Kelamin</label>
	   				</td>
	   				<td> : </td>
	   				<td>
	   					<?php echo $detailjenkel; ?>
	   					<select name="jenkel" id="jenkel" class="text ui-widget-content ui-corner-all select2">
	   						<option value="L">Laki-laki</option>
	   						<option value="P">Perempuan</option>
	   					</select>
	   				</td>
	   			</tr>
	   				<tr>
	   					<td>
	   						<label for="alamat" id="alamat">Alamat</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<input type="text" name="alamat" id="alamat" value="<?php echo $alamat; ?>" class="text ui-widget-content ui-corner-all">
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label for="kelurahan" id="kelurahan">Kelurahan</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<input type="hidden" id="keltemp" value="<?php $kel; ?>" />
	   						<select name="kelurahan" id="kelurahan" class="text ui-widget-content ui-corner-all">
		   						<?php 
		   							for($i = 0; $i < $jmlRowKel; $i++){
		   								if($idkel[$i] == $kel){
		   									$sel = 'selected';
		   								}
		   								else{
		   									$sel = '';
		   								}
		   						?>
		   							<option value="<?php echo $idkel[$i]; ?>" <?php echo $sel; ?> ><?php echo $namakel[$i]; ?></option>
		   						<?php
		   							}
		   						?>
		   					</select>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Kecamatan</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namakec; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Kota</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namakota; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Provinsi</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namaprov; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Telepon</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $telp; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Status</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $statusdetail; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Agama</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $agamadetail; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Pendidikan</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $penddetail; ?>
	   					</td>
	   				</tr>
	   				<tr>
	   					<td>
	   						<label>Tanggal Lahir</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<?php echo $namacrbayar; ?>
	   					</td>
	   				</tr>
            </table>
        </fieldset>
    </form>
</div><?php */?>

<script type="text/javascript">
	jQuery(".datepicker").datepicker({dateFormat: "yy-mm-dd", changeMonth:true, changeYear:true, currentText: "Now"});
	jQuery(".select2").select2();

	var url 	= "include/pasien.php";
	
	jQuery(".edit").button({icons: {primary: "ui-icon-pencil"}});

	jQuery(".edit").click(function(){
		window.location = "<?php echo _BASE_ ?>index.php?link=pasien01&nomr=<?php echo $_REQUEST['nomr']; ?>&idx=<?php echo $_REQUEST['idx']; ?>&opsi=2";
	});
	
	/*jQuery(".edit").click(function(){
		jQuery("#dialog-form").find("form").attr("action", url + "?opsi=2");
		jQuery("#dialog-form").dialog({
            title: "Edit Pasien"
        }).dialog("open");
	});

	jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 450,
        width: 350,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        buttons: {
            Simpan: function(){
                sendFormData();
            },
            Batal: function() {
                jQuery(this).dialog("close");
            }
        },
        close: function() {
            jQuery(".validateTips").html("Harap isi semua field yang dibutuhkan..");
        }
    });

	function sendFormData(){
        if(validateForm()){
            jQuery("#dialog-form").find("form").submit();
        }
    }*/
</script>