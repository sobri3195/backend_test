<script language="javascript" src="include/cal3.js"></script>
<script language="javascript" src="include/cal_conf3.js"></script>

<?php
//added 07082015
if ($_GET['KDCARABAYAR'] == '') {
    $_GET['KDCARABAYAR'] = 5;
}
//added 07082015
?>

<?php
//added 24072015
//$sqlrak = "SELECT * from m_maxnomr where status='1'";
//$rsqlrak = mysql_query($sqlrak);
//$rowsqlrak = mysql_fetch_array($rsqlrak);
//
//if ($rowsqlrak['last1'] >= $rowsqlrak['kapasitas']) {
//    $rak = $rowsqlrak['no_rak'] + 1;
//    //mysql_query("UPDATE m_maxnomr SET no_rak='$rak', last1=0, last2=0, status=1");
//
//    if ($rak < 10) {
//        $rak = "0" . $rak;
//    }
//
//    $nomr = $rak . getLastNoM("1") . getLastMR("1");
//} else if ($rowsqlrak['last2'] >= $rowsqlrak['kapasitas2']) {
//    $rak = $rowsqlrak['last1'] + 1;
//    //mysql_query("update m_maxnomr set last1='$rak', last2=0, status=1 where no_rak='". $rowsqlrak['no_rak']. "'");
//    //mysql_query("update m_maxnomr set status=0 where no_rak='" .$rowsqlrak['no_rak']. "'");
//
//    if ($rak < 10) {
//        $rak = "0" . $rak;
//    }
//
//    $nomr = $rowsqlrak['no_rak'] . getLastNoM("1") . $rak;
//    #$nomor1=$rowsqlrak[nomor]+1;
//    #mysql_query("update m_maxnomr set nomor='".$nomor1."' where no_rak='" .$rowsqlrak['no_rak']. "'");
//} else {
//    $rak = $rowsqlrak['no_rak'];
//    $nomor1 = $rowsqlrak['last2'] + 1;
//    //mysql_query("update m_maxnomr set last2='".$nomor1."' where no_rak='" .$rowsqlrak['no_rak']. "'");
//
//    if ($nomor1 < 10) {
//        $nomor1 = "0" . $nomor1;
//    }
//
//    $nomr = $rowsqlrak['no_rak'] . $nomor1 . getLastMR("1");
//}
//$ketemu	= 0;
//added 24072015
/*$sql = "SELECT NOMR FROM m_pasien ORDER BY NOMR DESC LIMIT 1;";
$rs  = mysql_query($sql);

if(mysql_num_rows($rs)){
    $data  = mysql_fetch_array($rs);
    $no_mr = intval($data['NOMR']);
    $nomr  = sprintf("%06d", ++$no_mr);
}else{
    $nomr  = sprintf("%06d", 1);
}*/
$nomr="";
?>

<script language="javascript" type="text/javascript">
    //added 25062015
    function set_nmr() {
        document.getElementById('NOMR').value = '<?php echo $_GET['rm'];?>';
        jQuery('#set_nomr').show();
        jQuery('#NOMR').attr('readonly', true);
    }

    function autocompleteICD() {
        alert();
    }
</script>

<script type="text/javascript">
    function startjam() {
        var d = new Date();
        var curr_hour = d.getHours();
        var curr_min = d.getMinutes();
        var curr_sec = d.getSeconds();
        document.getElementById('start_daftar').value = (curr_hour + ":" + curr_min + ":" + curr_sec);
    }
    function cek() {
        document.getElementById('nokartu').show = true;
        document.getElementById('norujukan').disabled = true;
        document.getElementById('tglrujuk').disabled = true;
        document.getElementById('noppk').disabled = true;
        //document.getElementById('diagnosa').disabled=true;
    }
    function cek_ena() {
        document.getElementById('nokartu').disabled = false;
        document.getElementById('norujukan').disabled = false;
        document.getElementById('tglrujuk').disabled = false;
        document.getElementById('noppk').disabled = false;
        //document.getElementById('diagnosa').disabled=false;
    }

    // JavaScript Document
    jQuery(document).ready(function () {
//cek();
        jQuery(".select2").select2();
		
		jQuery('#list_alias_poli').hide();

        jQuery(".select2").on("change", function (e) {
            var id = jQuery(".carabayar").val();
            cekCaraBayar(id);

            var kdcarabayar = jQuery(".kdrujuk").val();
            kdrujukan(kdcarabayar);
        });
        jQuery('#kelas_perawatan').hide();

        //added 07082015
        function defaultCaraBayar() {
            cek_ena();
            jQuery('#NK').show().addClass('required');
            jQuery('#jns_peserta').show().addClass('required');
            jQuery('#nokartu').show().addClass('required');
            jQuery('#noppk').show().addClass('required');
            jQuery('#norujukan').show().addClass('required');
            jQuery('#tglrujuk').show().addClass('required');
            jQuery('#diagnosa').show().addClass('required');
            jQuery('#label_nokartubpjs').show();
            jQuery('#btnrujukan').show();
            jQuery('#tr_nokartubpjs').show();
            jQuery('#tr_nopeserta').show();
            jQuery('#label_nopeserta').show();
            jQuery('#tr_norujukan').show();
            jQuery('#label_notujukan').show();
            jQuery('#tr_tglrujukan').show();
            jQuery('#label_tglrujukan').show();
            jQuery('#tr_ppkrujukan').show();
            jQuery('#label_ppkrujukan').show();
            jQuery('#tr_diagnosaawal').show();
            jQuery('#label_diagnosaawal').show();
            jQuery('#tr_nosep').show();
            jQuery('#label_nosep').show();
            jQuery('#btnsep').show();
            jQuery('#tr_nokaryawan').hide();
            jQuery('#label_nokaraywan').hide();
            jQuery('#tr_jkn').show();
            jQuery('#nokaryawan').hide();
            jQuery('#nokaryawan').val('');
            jQuery('#btncarikaryawan').hide();
            jQuery('#nama_penanggungjawab').val('BPJS Kesehatan');
            jQuery('#hubungan_penanggungjawab').val('Asuransi Kesehatan');
            jQuery('#alamat_penanggungjawab').val('');
            jQuery('#phone_penanggungjawab').val('');
        }
        jQuery('#NOMR').attr('readonly','readonly');
        //added 07082015
        //added 13082015
        function cekCaraBayar(val) {
            if (val == 5) {
                cek_ena();
                //added and edited 06082015
                jQuery('#NK').show().addClass('required');
                jQuery('#jns_peserta').show().addClass('required');
                jQuery('#nokartu').show().addClass('required');
                jQuery('#noppk').show().addClass('required');
                jQuery('#norujukan').show().addClass('required');
                jQuery('#tglrujuk').show().addClass('required');
                jQuery('#diagnosa').show().addClass('required');
                jQuery('#label_nokartubpjs').show();
                jQuery('#btnrujukan').show();
                jQuery('#tr_nokartubpjs').show();
                jQuery('#tr_nopeserta').show();
                jQuery('#label_nopeserta').show();
                jQuery('#tr_norujukan').show();
                jQuery('#label_notujukan').show();
                jQuery('#tr_tglrujukan').show();
                jQuery('#label_tglrujukan').show();
                jQuery('#tr_ppkrujukan').show();
                jQuery('#label_ppkrujukan').show();
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#tr_nosep').show();
                jQuery('#label_nosep').show();
                jQuery('#btnsep').show();
                jQuery('#tr_jkn').show();
                jQuery('#ket_jkn').show().css("width","150px");
                jQuery('#tr_nokaryawan').hide();
                jQuery('#label_nokaraywan').hide();
                jQuery('#nokaryawan').hide();
                jQuery('#btncarikaryawan').hide();
                jQuery('#label_namapj').val('Penanggung Jawab');
                //jQuery('#nama_penanggungjawab').val('BPJS Kesehatan');
                jQuery('#nama_penanggungjawab').val(jQuery("#ket_jkn").val());
                jQuery('#hubungan_penanggungjawab').val('Asuransi Kesehatan');
                jQuery('#alamat_penanggungjawab').val('');
                jQuery('#phone_penanggungjawab').val('');
                jQuery('#nokaryawan').val('');
            }
            else if (val == 1) {
                jQuery('#NK').hide().removeClass('required');
                jQuery('#jns_peserta').hide().removeClass('required');
                cek();
                jQuery('#nokartu').hide().removeClass('required');
                jQuery('#noppk').hide().removeClass('required');
                jQuery('#norujukan').hide().removeClass('required');
                jQuery('#tglrujuk').hide().removeClass('required');
                jQuery('#diagnosa').hide().removeClass('required');
                jQuery('#label_nokartubpjs').hide();
                jQuery('#btnrujukan').hide();
                jQuery('#tr_nokartubpjs').hide();
                jQuery('#tr_nopeserta').hide();
                jQuery('#label_nopeserta').hide();
                jQuery('#tr_norujukan').hide();
                jQuery('#label_notujukan').hide;
                jQuery('#tr_tglrujukan').hide();
                jQuery('#label_tglrujukan').hide();
                jQuery('#tr_ppkrujukan').hide();
                jQuery('#label_ppkrujukan').hide();
                jQuery('#tr_diagnosaawal').hide();
                jQuery('#label_diagnosaawal').hide();
                jQuery('#tr_nosep').hide();
                jQuery('#label_nosep').hide();
                jQuery('#btnsep').hide();
                jQuery('#tr_nokaryawan').hide();
                jQuery('#label_nokaraywan').hide();
                jQuery('#nokaryawan').hide();
                jQuery('#btncarikaryawan').hide();
                jQuery('#nama_penanggungjawab').val('');
                jQuery('#hubungan_penanggungjawab').val('');
                jQuery('#alamat_penanggungjawab').val('');
                jQuery('#phone_penanggungjawab').val('');
                jQuery('#nokaryawan').val('');
                jQuery('#tr_jkn').hide();
                jQuery('#ket_jkn').hide();
            }
            else if (val == 10) {
                jQuery('#tr_nokaryawan').show();
                jQuery('#label_nokaraywan').show();
                jQuery('#nokaryawan').show();
                jQuery('#btncarikaryawan').show();
                jQuery('#btncarikaryawanpj').hide();
                jQuery('#NK').hide().removeClass('required');
                jQuery('#jns_peserta').hide().removeClass('required');
                cek();
                jQuery('#nokartu').hide().removeClass('required');
                jQuery('#noppk').hide().removeClass('required');
                jQuery('#norujukan').hide().removeClass('required');
                jQuery('#tglrujuk').hide().removeClass('required');
                jQuery('#diagnosa').hide().removeClass('required');
                jQuery('#label_nokartubpjs').hide();
                jQuery('#btnrujukan').hide();
                jQuery('#tr_nokartubpjs').hide();
                jQuery('#tr_nopeserta').hide();
                jQuery('#label_nopeserta').hide();
                jQuery('#tr_norujukan').hide();
                jQuery('#label_notujukan').hide;
                jQuery('#tr_tglrujukan').hide();
                jQuery('#label_tglrujukan').hide();
                jQuery('#tr_ppkrujukan').hide();
                jQuery('#label_ppkrujukan').hide();
                jQuery('#tr_diagnosaawal').hide();
                jQuery('#label_diagnosaawal').hide();
                jQuery('#tr_nosep').hide();
                jQuery('#label_nosep').hide();
                jQuery('#btnsep').hide();
                jQuery('#nama_penanggungjawab').val('RSUD KOTA BOGOR');
                jQuery('#hubungan_penanggungjawab').val('Perusahaan');
                jQuery('#alamat_penanggungjawab').val('Jl. Dr. Semeru No. 120 Bogor');
                jQuery('#phone_penanggungjawab').val('02518312292');
                jQuery('#tr_jkn').hide();
                jQuery('#ket_jkn').hide();
            }
            else if (val == 11) {
                jQuery('#tr_nokaryawan').show();
                jQuery('#label_nokaraywan').show();
                jQuery('#nokaryawan').show();
                jQuery('#btncarikaryawan').hide();
                jQuery('#btncarikaryawanpj').show();
                jQuery('#NK').hide().removeClass('required');
                jQuery('#jns_peserta').hide().removeClass('required');
                cek();
                jQuery('#nokartu').hide().removeClass('required');
                jQuery('#noppk').hide().removeClass('required');
                jQuery('#norujukan').hide().removeClass('required');
                jQuery('#tglrujuk').hide().removeClass('required');
                jQuery('#diagnosa').hide().removeClass('required');
                jQuery('#label_nokartubpjs').hide();
                jQuery('#btnrujukan').hide();
                jQuery('#tr_nokartubpjs').hide();
                jQuery('#tr_nopeserta').hide();
                jQuery('#label_nopeserta').hide();
                jQuery('#tr_norujukan').hide();
                jQuery('#label_notujukan').hide;
                jQuery('#tr_tglrujukan').hide();
                jQuery('#label_tglrujukan').hide();
                jQuery('#tr_ppkrujukan').hide();
                jQuery('#label_ppkrujukan').hide();
                jQuery('#tr_diagnosaawal').hide();
                jQuery('#label_diagnosaawal').hide();
                jQuery('#tr_nosep').hide();
                jQuery('#label_nosep').hide();
                jQuery('#btnsep').hide();
                jQuery('#nama_penanggungjawab').val('');
                jQuery('#hubungan_penanggungjawab').val('');
                jQuery('#alamat_penanggungjawab').val('');
                jQuery('#phone_penanggungjawab').val('');
                jQuery('#tr_jkn').hide();
                jQuery('#ket_jkn').hide();
            }
            else {
                jQuery('#NK').hide().removeClass('required');
                jQuery('#jns_peserta').hide().removeClass('required');
                cek();
                jQuery('#nokartu').hide().removeClass('required');
                jQuery('#noppk').hide().removeClass('required');
                jQuery('#norujukan').hide().removeClass('required');
                jQuery('#tglrujuk').hide().removeClass('required');
                jQuery('#diagnosa').hide().removeClass('required');
                jQuery('#label_nokartubpjs').hide();
                jQuery('#btnrujukan').hide();
                jQuery('#tr_nokartubpjs').hide();
                jQuery('#tr_nopeserta').hide();
                jQuery('#label_nopeserta').hide();
                jQuery('#tr_norujukan').hide();
                jQuery('#label_notujukan').hide;
                jQuery('#tr_tglrujukan').hide();
                jQuery('#label_tglrujukan').hide();
                jQuery('#tr_ppkrujukan').hide();
                jQuery('#label_ppkrujukan').hide();
                jQuery('#tr_diagnosaawal').hide();
                jQuery('#label_diagnosaawal').hide();
                jQuery('#tr_nosep').hide();
                jQuery('#label_nosep').hide();
                jQuery('#btnsep').hide();
                jQuery('#tr_nokaryawan').hide();
                jQuery('#label_nokaraywan').hide();
                jQuery('#nokaryawan').hide();
                jQuery('#btncarikaryawan').hide();
                jQuery('#nama_penanggungjawab').val(jQuery('.carabayar').find('option:selected').text());
                jQuery('#hubungan_penanggungjawab').val('Perusahaan');
                jQuery('#alamat_penanggungjawab').val('');
                jQuery('#phone_penanggungjawab').val('');
                jQuery('#nokaryawan').val('');
                jQuery('#tr_jkn').hide();
                jQuery('#ket_jkn').hide();
                //added and edited 06082015
            }
        }

        //added 13082015

        function kdrujukan(val) {
            if (val == 2) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Puskesmas');
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#diagnosa').show();
            }
            else if (val == 3) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama RS Lain');
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#diagnosa').show();
            }
            else if (val == 5) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Dokter');
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#diagnosa').show();
            }
            else if (val == 6) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Instansi');
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#diagnosa').show();
            }
            else if (val == 7) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Poliklinik');
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#diagnosa').show();
            }
            else if (val == 4) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Lain-lain');
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#diagnosa').show();
            }
            else if (val == 1) {
                jQuery('#kdrujuk_lain').hide().removeClass('required');
            }
            else {
                jQuery('#kdrujuk_lain').hide().removeClass('required');
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#diagnosa').show();
            }
        }

        defaultCaraBayar();
        set_nmr();

        // 	jQuery('#tr_nomr').hide();

        jQuery("#ket_jkn").change(function(){
            jQuery('#nama_penanggungjawab').val(jQuery(this).val());
            jQuery('#hubungan_penanggungjawab').val('Asuransi Kesehatan');
            jQuery('#alamat_penanggungjawab').val('');
            jQuery('#phone_penanggungjawab').val('');
        });

        jQuery("#myform").validate();

        jQuery('.loader').hide();
        //jQuery('#NK').hide();
        //jQuery('#kartu1').hide();
        //jQuery('#jns_peserta').hide();

        // START DIDIKREASI EDIT
        /*
        <?php if($_REQUEST['xNOMR'] == ''): ?>

         jQuery('#NOMR').attr('disabled','disabled').val('-automatic-');
        <? endif; ?>
         */
        // AKHIR DIDIKREASI EDIT
        jQuery('.statuspasien').change(function () {
            var status_val = jQuery(this).val();
            if (status_val == 1) {
                jQuery('#PASIENBARU').val(1);
                jQuery('#NAMA').val('');
                jQuery('#TEMPAT').val('');
                jQuery('#TGLLAHIR').val('');
                //jQuery('#umur').val(newdata[5]);
                jQuery('#ALAMAT').val('');
                jQuery('#ALAMAT_KTP').val('');
                jQuery('#KELURAHAN').val('');
                jQuery('#KECAMATAN').val('');
                jQuery('#KOTA').val('');
                jQuery('#KDPROVINSI').val('');
                jQuery('#notelp').val('');
                jQuery('#NOKTP').val('');
                jQuery('#SUAMI_ORTU').val('');
                jQuery('#kartu1').val('');
                jQuery('#PEKERJAAN').val('');
                jQuery('#JENISKELAMIN_' + newdata[5]).removeAttr('checked');
                jQuery('#status_' + newdata[15]).removeAttr('checked');
                jQuery('#PENDIDIKAN_' + newdata[17]).removeAttr('checked');
                jQuery('#AGAMA_' + newdata[16]).removeAttr('checked');
                jQuery('#carabayar_' + newdata[18]).removeAttr('checked');
                document.getElementById('diagnosa').disabled = false;
                jQuery('.loader').hide();
                jQuery('#set_nomr').show();


            } else {
                document.getElementById('NOMR').disabled = false;
                document.getElementById('NOMR').value = '';
                jQuery('#PASIENBARU').val(0);
                jQuery('#set_nomr').hide();
                jQuery('#NOMR').attr('readonly', false);
            }
        });
        jQuery('#TGLLAHIR').blur(function () {
            var tgl = jQuery(this).val();
            if (tgl == ('0000/00/00') || tgl == ('0000-00-00') || tgl == ('00-00-0000') || tgl == ('00/00/0000')) {
                alert('Tanggal Lahir Tidak Boleh 00-00-0000');
                jQuery(this).val('');
            }
        });
		
		jQuery('#NOMR').bind("enterKey",function(e){
            nomr_blur();
        });

        jQuery('#NOMR').keyup(function(e){
            if(e.keyCode == 13) {
                jQuery(this).trigger("enterKey");
            }
        });
		
        jQuery('#NOMR').blur(function () {
            nomr_blur();
        });

        function nomr_blur(){
            var nomr = jQuery('#NOMR').val();
            if (nomr != '') {
                jQuery('.loader').show();
                jQuery.ajax({
					method: 'post',
					url: '<?php echo _BASE_;?>models/cek_status_ranap.php',
					data: {nomr:nomr},
					success: function(data){
						if(data == 0){
							jQuery.ajax({
								method: 'post',
								url: '<?php echo _BASE_;?>models/cek_pasien.php',
								data: {nomr:nomr},
								success: function(data){
									if(data != ''){
										alert(data);
										jQuery(".btn_simpan").attr('disabled', 'disabled');
									} else{
										jQuery.get('<?php echo _BASE_; ?>include/process.php?psn=' + nomr, function (data) {
											newdata = data.split("|");
											jQuery('#NOMR').attr('readonly','');
											//jQuery('#STATUSPASIEN_'+newdata[0]).attr('checked','checked');
											if (newdata[0] == 1) {
												jQuery('#NOMR').attr('readonly','readonly');
											}
											jQuery('#NAMA').val(newdata[2]);
											jQuery('#TEMPAT').val(newdata[3]);
											jQuery('#nomr_old').val(newdata[31]);
											var tahun = newdata[4].substr(0, 4);
											var bulan = newdata[4].substr(5, 2);
											var hari = newdata[4].substr(8, 2);
											jQuery('#TGLLAHIR').val(hari + "/" + bulan + "/" + tahun);
											//jQuery('#umur').val(newdata[5]);
											jQuery('#ALAMAT').val(newdata[6]);
											jQuery('#ALAMAT_KTP').val(newdata[19]);
											jQuery('#KELURAHAN').val(newdata[7]);
											jQuery('#KECAMATAN').val(newdata[8]);
											jQuery('#KELURAHANHIDDEN').val(newdata[7]);
											jQuery('#KECAMATANHIDDEN').val(newdata[8]);
											jQuery('#KOTAHIDDEN').val(newdata[9]);
											jQuery('#KDPROVINSI').val(newdata[10]).change();
											jQuery('#KOTA').val(newdata[9]).change();
											jQuery('#notelp').val(newdata[11]);
											jQuery('#NOKTP').val(newdata[12]);
											jQuery('#SUAMI_ORTU').val(newdata[13]);
											jQuery('#PEKERJAAN').val(newdata[14]);
											jQuery('#umur').val(newdata[20]);
											jQuery('#CALLER option[value=' + newdata[21] + ']').attr('selected', 'selected');
											jQuery('#kartu1').val(newdata[26]);
											jQuery('#nama_penanggungjawab').val(newdata[22]);
											jQuery('#hubungan_penanggungjawab').val(newdata[23]);
											jQuery('#alamat_penanggungjawab').val(newdata[24]);
											jQuery('#phone_penanggungjawab').val(newdata[25]);
											jQuery('#JENISKELAMIN_' + newdata[5]).attr('checked', 'checked');
											jQuery('#status_' + newdata[15]).attr('checked', 'checked');
											jQuery('#PENDIDIKAN_' + newdata[17]).attr('checked', 'checked');
											jQuery('#AGAMA_' + newdata[16]).attr('checked', 'checked');
											jQuery('#carabayar_' + newdata[18]).attr('selected', 'selected');
											cekCaraBayar(newdata[18]);
											jQuery('#nama_penanggungjawab').val(newdata[22]);
											jQuery('#nokartu').val(newdata[26]);
											jQuery('#noppk').val(newdata[28]);
											jQuery('#namappk').val(newdata[29]);
											//jQuery('#kdrujuk_lain').val(newdata[29]);
											jQuery('#jns_pasien').val(newdata[27]);
											jQuery('#kelas').val(newdata[30]);
											jQuery('.loader').hide();
											
											//jQuery('#nokartu').attr('readonly', 'readonly');
											//jQuery('#nokartu').attr('readonly','readonly');
											if ((newdata[18]) == "5") {
												cek_ena();
											}
											else {
												cek();
											}

										});
									}
								}
							});
						} else{
							alert("Pasien masih terdaftar di IGD/Rawat Inap");
						}
					}
				});
                
            } else{
                jQuery('#NOMR').attr('readonly','readonly');
            }
        }
		
		nomr_blur();
        //jQuery('#carabayar_lain').hide();
        //jQuery('#kdrujuk_lain').hide();
        jQuery('.carabayar').click(function () {
            var val = jQuery(this).val();
            if (val == 5) {
                cek_ena();
                //added and edited 06082015
                jQuery('#NK').show().addClass('required');
                jQuery('#jns_peserta').show().addClass('required');
                jQuery('#nokartu').show().addClass('required');
                jQuery('#noppk').show().addClass('required');
                jQuery('#norujukan').show().addClass('required');
                jQuery('#tglrujuk').show().addClass('required');
                jQuery('#diagnosa').show().addClass('required');
                jQuery('#label_nokartubpjs').show();
                jQuery('#btnrujukan').show();
                jQuery('#tr_nokartubpjs').show();
                jQuery('#tr_nopeserta').show();
                jQuery('#label_nopeserta').show();
                jQuery('#tr_norujukan').show();
                jQuery('#label_notujukan').show();
                jQuery('#tr_tglrujukan').show();
                jQuery('#label_tglrujukan').show();
                jQuery('#tr_ppkrujukan').show();
                jQuery('#label_ppkrujukan').show();
                jQuery('#tr_diagnosaawal').show();
                jQuery('#label_diagnosaawal').show();
                jQuery('#tr_jkn').show();
                jQuery('#ket_jkn').show();
                jQuery('#tr_nosep').show();
                jQuery('#label_nosep').show();
                jQuery('#btnsep').show();
                jQuery('#tr_nokaryawan').hide();
                jQuery('#label_nokaraywan').hide();
                jQuery('#nokaryawan').hide();
                jQuery('#btncarikaryawan').hide();
                jQuery('#label_namapj').val('Penanggung Jawab');
                jQuery('#nama_penanggungjawab').val('BPJS Kesehatan');
                jQuery('#hubungan_penanggungjawab').val('Asuransi Kesehatan');
            }
            else if (val == 1) {
                jQuery('#NK').hide().removeClass('required');
                jQuery('#jns_peserta').hide().removeClass('required');
                cek();
                jQuery('#nokartu').hide().removeClass('required');
                jQuery('#noppk').hide().removeClass('required');
                jQuery('#norujukan').hide().removeClass('required');
                jQuery('#tglrujuk').hide().removeClass('required');
                jQuery('#diagnosa').hide().removeClass('required');
                jQuery('#label_nokartubpjs').hide();
                jQuery('#btnrujukan').hide();
                jQuery('#tr_nokartubpjs').hide();
                jQuery('#tr_nopeserta').hide();
                jQuery('#label_nopeserta').hide();
                jQuery('#tr_norujukan').hide();
                jQuery('#label_notujukan').hide;
                jQuery('#tr_tglrujukan').hide();
                jQuery('#label_tglrujukan').hide();
                jQuery('#tr_ppkrujukan').hide();
                jQuery('#label_ppkrujukan').hide();
                jQuery('#tr_diagnosaawal').hide();
                jQuery('#label_diagnosaawal').hide();
                jQuery('#tr_nosep').hide();
                jQuery('#label_nosep').hide();
                jQuery('#btnsep').hide();
                jQuery('#tr_nokaryawan').hide();
                jQuery('#label_nokaraywan').hide();
                jQuery('#nokaryawan').hide();
                jQuery('#btncarikaryawan').hide();
                jQuery('#nama_penanggungjawab').val('');
                jQuery('#hubungan_penanggungjawab').val('');
                jQuery('#tr_jkn').hide();
                jQuery('#ket_jkn').hide();
            }
            else if (val == 10 || val == 11) {
                if (val == 10) {
                    jQuery('#tr_nokaryawan').show();
                    jQuery('#label_nokaraywan').show();
                    jQuery('#nokaryawan').show();
                    jQuery('#btncarikaryawan').show();
                }
                else {
                    jQuery('#tr_nokaryawan').hide();
                    jQuery('#label_nokaraywan').hide();
                    jQuery('#nokaryawan').hide();
                    jQuery('#btncarikaryawan').hide();
                }
                jQuery('#NK').hide().removeClass('required');
                jQuery('#jns_peserta').hide().removeClass('required');
                cek();
                jQuery('#nokartu').hide().removeClass('required');
                jQuery('#noppk').hide().removeClass('required');
                jQuery('#norujukan').hide().removeClass('required');
                jQuery('#tglrujuk').hide().removeClass('required');
                jQuery('#diagnosa').hide().removeClass('required');
                jQuery('#label_nokartubpjs').hide();
                jQuery('#btnrujukan').hide();
                jQuery('#tr_nokartubpjs').hide();
                jQuery('#tr_nopeserta').hide();
                jQuery('#label_nopeserta').hide();
                jQuery('#tr_norujukan').hide();
                jQuery('#label_notujukan').hide;
                jQuery('#tr_tglrujukan').hide();
                jQuery('#label_tglrujukan').hide();
                jQuery('#tr_ppkrujukan').hide();
                jQuery('#label_ppkrujukan').hide();
                jQuery('#tr_diagnosaawal').hide();
                jQuery('#label_diagnosaawal').hide();
                jQuery('#tr_nosep').hide();
                jQuery('#label_nosep').hide();
                jQuery('#btnsep').hide();
                jQuery('#nama_penanggungjawab').val('RSUD KOTA BOGOR');
                jQuery('#hubungan_penanggungjawab').val('Perusahaan');
                jQuery('#alamat_penanggungjawab').val('Jl. Dr. Semeru No. 120 Bogor');
                jQuery('#phone_penanggungjawab').val('02518312292');
                jQuery('#tr_jkn').hide();
                jQuery('#ket_jkn').hide();
            }
            else {
                jQuery('#NK').hide().removeClass('required');
                jQuery('#jns_peserta').hide().removeClass('required');
                cek();
                jQuery('#nokartu').hide().removeClass('required');
                jQuery('#noppk').hide().removeClass('required');
                jQuery('#norujukan').hide().removeClass('required');
                jQuery('#tglrujuk').hide().removeClass('required');
                jQuery('#diagnosa').hide().removeClass('required');
                jQuery('#label_nokartubpjs').hide();
                jQuery('#btnrujukan').hide();
                jQuery('#tr_nokartubpjs').hide();
                jQuery('#tr_nopeserta').hide();
                jQuery('#label_nopeserta').hide();
                jQuery('#tr_norujukan').hide();
                jQuery('#label_notujukan').hide;
                jQuery('#tr_tglrujukan').hide();
                jQuery('#label_tglrujukan').hide();
                jQuery('#tr_ppkrujukan').hide();
                jQuery('#label_ppkrujukan').hide();
                jQuery('#tr_diagnosaawal').hide();
                jQuery('#label_diagnosaawal').hide();
                jQuery('#tr_nosep').hide();
                jQuery('#label_nosep').hide();
                jQuery('#btnsep').hide();
                jQuery('#tr_nokaryawan').hide();
                jQuery('#label_nokaraywan').hide();
                jQuery('#nokaryawan').hide();
                jQuery('#btncarikaryawan').hide();
                jQuery('#nama_penanggungjawab').val(jQuery('.carabayar').find('option:selected').text());
                jQuery('#hubungan_penanggungjawab').val('Perusahaan');
                jQuery('#tr_jkn').hide();
                jQuery('#ket_jkn').hide();
                //added and edited 06082015
            }
        });
        jQuery('.kdrujuk').click(function () {
            var val = jQuery(this).val();
            if (val == 2) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Puskesmas');
            }
            else if (val == 3) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama RS Lain');
            }
            else if (val == 5) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Dokter');
            }
            else if (val == 6) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Instansi');
            }
            else if (val == 7) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Poliklinik');
            }
            else if (val == 4) {
                jQuery('#kdrujuk_lain').show().addClass('required');
                jQuery('#kdrujuk_lain').attr('placeholder', 'Lain-lain');
            }
            else {
                jQuery('#kdrujuk_lain').hide().removeClass('required');
            }
        });
		
		jQuery('#btnmanual').click(function(){
			jQuery('#NK').val('0133R');
		});
		
        /*jQuery('#btnrujukan').click(function () {
			var nomr 	  = jQuery('#NOMR').val();
			var nama 	  = jQuery('#NAMA').val();
			var tgllahir  = jQuery('#TGLLAHIR').val();
			var nopeserta = jQuery('#nokartu').val();
			
            if (nopeserta == "") {
                alert("NO Kartu Jaminan Masih Kosong");
                jQuery('#nokartu').focus();
                return false;
            }
            else {
				jQuery.post('<?php echo _BASE_;?>bridging_bpjs.php', {
                    nopeserta: nopeserta,
                    reqdata: 'peserta_by_nokartu'
                }, function (data) {
					jQuery.ajax({
						method: 'post',
						url: "<?=_BASE_?>models/pendaftaran/cek_pasien_bpjs.php",
						data: {nomr:nomr, nama:nama, tgllahir:tgllahir, no_peserta: nopeserta, json_data:data},
						success: function(data){
							jQuery("#list_pasien").html(data);
						},
						error: function(xhr, ajaxOptions, thrownError){
							alert(xhr.status + " " + thrownError);
						}
					});
				});
            }
        });*/
		jQuery('#btnrujukan').click(function () {
			var nopeserta = jQuery('#nokartu').val();
			
            if (nopeserta == "") {
                alert("NO Kartu Jaminan Masih Kosong");
                jQuery('#nokartu').focus();
                return false;
            }
            else {
				jQuery.post('<?php echo _BASE_;?>bridging_bpjs.php', {
                    nopeserta: nopeserta,
                    reqdata: 'peserta_by_nokartu_testing_vclaim'
                }, function (data) {
					var response = eval("(" + data + ")");
					if(response.metaData.code == "200"){
						if(response.response.peserta.statusPeserta.keterangan == "AKTIF"){
							jQuery('#NAMA').val(response.response.peserta.nama);
							jQuery('#NOKTP').val(response.response.peserta.nik);
							jQuery('#kartu1').val(response.response.peserta.noKartu);
							jQuery('#noppk').val(response.response.peserta.provUmum.kdProvider);
							jQuery('#namappk').val(response.response.peserta.provUmum.nmProvider);
							jQuery('#kdrujuk_lain').val(response.response.peserta.provUmum.nmProvider);
							jQuery('#kelas').val(response.response.peserta.hakKelas.kode);
							jQuery('#jns_peserta').val(response.response.peserta.jenisPeserta.keterangan);

							//added 24072015
							var sex = response.response.peserta.sex;
							if (sex == 'L') {
								jQuery('#JENISKELAMIN_L').attr('checked', true);
							}
							else {
								jQuery('#JENISKELAMIN_P').attr('checked', true);
							}

							var tglLahir = response.response.peserta.tglLahir;
							var thnLahir = tglLahir.substr(0, 4);
							var blnLahir = tglLahir.substr(5, 2);
							var tLhrnya = tglLahir.substr(8, 2);
							var ttlnya = tLhrnya + "/" + blnLahir + "/" + thnLahir;
							jQuery('#TGLLAHIR').val(ttlnya);
							console.log(ttlnya);
							//added 24072015
							
							jQuery.post('<?php echo _BASE_;?>bridging_bpjs.php', {
								nopeserta: nopeserta,
								reqdata: 'rujukan_by_nopeserta_from_pcare_testing_vclaim'
							}, function (data) {
								var response = eval("(" + data + ")");
								if(response.metaData.code == "200"){
									jQuery("#norujukan").val(response.response.rujukan.noKunjungan);
									jQuery("#diagnosa").val(response.response.rujukan.diagnosa.kode);
									jQuery(".kdrujuk").val(2);
								} else{
									jQuery.post('<?php echo _BASE_;?>bridging_bpjs.php', {
										nopeserta: nopeserta,
										reqdata: 'rujukan_by_nopeserta_from_rs'
									}, function (data) {
										var response = eval("(" + data + ")");
										if(response.metadata.code == "200"){
											jQuery("#norujukan").val(response.response.rujukan.noKunjungan);
											jQuery("#diagnosa").val(response.response.rujukan.diagnosa.kode);
											jQuery(".kdrujuk").val(3);
										} 
									});
								}
							});
						} else{
							alert(response.response.peserta.statusPeserta.keterangan);
							//jQuery('.btn_simpan').attr('disabled', true);
						}
					} else{
						alert(response.metadata.message);
						//jQuery('.btn_simpan').attr('disabled', true);
					}
                });
				
				//cek duplikasi data bpjs
				jQuery.ajax({
                url: "<?= _BASE_ ?>models/cek_duplikasi_bpjs.php",
                method: "post",
                data: {nopeserta:nopeserta},
                success: function(data){
					if(data != ''){
						jQuery('#STATUSPASIEN_0').attr('checked', 'true');
						jQuery('#NOMR').val(data);
						//nomr_blur();
					}
                }
            });
            }
        });

        //added 18082015
        jQuery('#btncarikaryawanpj').click(function () {
            var nokaryawan = jQuery('#nokaryawan').val();

            jQuery.post('<?php echo _BASE_?>caripegawai.php', {nokaryawan: nokaryawan, pilihan: 1}, function (data) {
                var json = JSON.parse(data);

                jQuery('#nama_penanggungjawab').val(json.Nama);
                jQuery('#alamat_penanggungjawab').val(json.Alamat + ", " + json.Kota);
            });
        });

        jQuery('#btncarikaryawan').click(function () {
            var nokaryawan = jQuery('#nokaryawan').val();

            jQuery.post('<?php echo _BASE_?>caripegawai.php', {nokaryawan: nokaryawan, pilihan: 1}, function (data) {
                var json = JSON.parse(data);
                jQuery('#NAMA').val(json.Nama);

                var jenkel = json.Kelamin;
                if (jenkel == "Laki-laki") {
                    jQuery('#JENISKELAMIN_L').attr('checked', true);
                }
                else {
                    jQuery('#JENISKELAMIN_P').attr('checked', true);
                }

                jQuery('#TEMPAT').val(json.TmpLahir);

                var tglLahir = json.TglLahir;
                var thnLahir = tglLahir.substr(0, 4);
                var blnLahir = tglLahir.substr(5, 2);
                var tLhrnya = tglLahir.substr(8, 2);
                var ttlnya = tLhrnya + "/" + blnLahir + "/" + thnLahir;
                jQuery('#TGLLAHIR').val(ttlnya);

                var agama = json.Agama;
                switch (agama) {
                    case "Islam":
                        jQuery('#AGAMA_1').attr('checked', true);
                        break;
                    case "Protestan":
                        jQuery('#AGAMA_2').attr('checked', true);
                        break;
                    case "Katholik":
                        jQuery('#AGAMA_3').attr('checked', true);
                        break;
                    case "Hindu":
                        jQuery('#AGAMA_4').attr('checked', true);
                        break;
                    case "Budha":
                        jQuery('#AGAMA_5').attr('checked', true);
                        break;
                    default:
                        jQuery('#AGAMA_6').attr('checked', true);
                        break;
                }

                jQuery('#ALAMAT').val(json.Alamat);

                var pend = json.Pendidikan;
                var pendnow = pend.substring(4);
                switch (pendnow) {
                    case "SD":
                        jQuery('#PENDIDIKAN_1').attr('checked', true);
                        break;
                    case "SMP":
                        jQuery('#PENDIDIKAN_2').attr('checked', true);
                        break;
                    case "SMA":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SMU":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "STM":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SMK":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SMEA":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SMKK":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    default:
                        jQuery('#PENDIDIKAN_5').attr('checked', true);
                        break;
                }

                var status = json.NoStatusnya;
                jQuery.post('<?php echo _BASE_?>caripegawai.php', {status: status, pilihan: 2}, function (data) {
                    var ketstatus = data;
                    switch (ketstatus) {
                        case "Kawin ":
                            jQuery('#status_2').attr('checked', true);
                            break;
                        case "Belum Kawin":
                            jQuery('#status_1').attr('checked', true);
                            break;
                        case "Janda":
                            jQuery('#status_3').attr('checked', true);
                            break;
                        default:
                            jQuery('#status_1').attr('checked', true);
                            break;
                    }
                });
            });
        });
        //added 18082015

        jQuery('#btnsep').click(function () {
            var nopeserta = jQuery('#nokartu').val();
            var noppk = jQuery('#noppk').val();
            var norujukan = jQuery('#norujukan').val();
            var diagnosa = jQuery('#diagnosa').val();
            var tglrujuk = jQuery('#tglrujuk').val();
			var kdrujuk = jQuery('.kdrujuk').val();
			var notelp = jQuery('#notelp').val();
			var nomr = jQuery('#NOMR').val() == "" ? "0" : jQuery('#NOMR').val();

            //added 24072015
            var tglsep = jQuery('#tglrujuk').val;
            var ppkpelayanan = '0113R035';
            var jnspelayanan = '2';
            var catatan = '';
			
			var politmp = jQuery('#kdpoly').val() == 31 ? 34 : jQuery('#kdpoly').val();
			var politmp = jQuery('#kdpoly').val() == 53 ? jQuery('#kdpoly_alias').val() : politmp;
			var politmp = jQuery('#kdpoly').val() == 57 ? 3 : politmp;
			var politmp = jQuery('#kdpoly').val() == 52 ? 1 : politmp;
			
            var politujuan = politmp;
			
			var id_poli_bpjs = jQuery('option:selected', '#kdpoly').attr('id_poli_bpjs');
            var klsrawat = jQuery('#kelas').val();
            var user = '<?php echo $_SESSION['NIP']; ?>';
            //console.log(user);
            //jQuery.post('<?php echo _BASE_;?>bridging_proses.php',{nopeserta:nopeserta,tglsep:tglsep,ppkpelayanan:ppkpelayanan,jnspelayanan=jnspelayanan,catatan:catatan,politujuan:politujuan,klsrawat:klsrawat,user:user,nomr:nomr,noppk:noppk,norujukan:norujukan,diagnosa:diagnosa,tglrujuk:tglrujuk,reqdata:'sep'},function(data){
            //added 24072015

           jQuery.post('<?php echo _BASE_;?>bridging_bpjs.php', {
                nopeserta: nopeserta,
                noppk: noppk,
                norujukan: norujukan,
                diagnosa: diagnosa,
                tglrujuk: tglrujuk,
                politujuan:id_poli_bpjs,
                user: user,
                tglsep: tglsep,
				klsrawat:klsrawat,
				nomr:nomr,
				kdrujuk:kdrujuk,
				notelp:notelp,
                reqdata: 'sep_testing_vclaim'
            }, function (data) {
                //var n = data.split("|");
                //jQuery('#kddokter').val(n[0]);
				if(data.substring(0,5) == "0133R"){
					jQuery('#NK').val(data);
				} else{
					alert(data + ". HARAP CEK KEMBALI! atau Cek di Program SEP Lama. ");
					jQuery('#NK').val("TIDAK BISA DITRANSAKSIKAN!");
					//jQuery('.btn_simpan').attr("disabled", true);
				}
                //jQuery('#loader_namadokter').hide();
            });
        });

        jQuery('#diagnosa').autocomplete("vk/autocomplete_vk2.php", {
            width: 260,
            selectFirst: true
        });

        jQuery('#set_nomr').click(function(){
            var nomr    = jQuery('#NOMR').val();

            jQuery.post('models/set_nomr.php', {nomr:nomr}, function(data){
                if(data==1){
                    jQuery('#set_nomr').hide();
                }
                else{
                    location.reload();
                }
            });
        });

        jQuery("#btn_kode_p").click(function(){
            jQuery("#kode_p").val(1);
            jQuery(this).attr("disabled", true);
        });
		
		jQuery("#btn_kode_t").click(function(){
            jQuery("#kode_t").val(1);
            jQuery(this).attr("disabled", true);
        });

        function get_pasien_by_old_nomr(nomr){
            jQuery.post('include/cari_pasien.php', {NOMR:nomr,pilihan:8}, function(data){
//                alert(data);
                var obj = JSON.parse(data);
                jQuery("#NAMA").val(obj.NAMAPAS);
                jQuery("#ALAMAT").val(obj.ALRUMPAS);
                jQuery("#notelp").val(obj.TLRUMPAS);
                jQuery("#TEMPAT").val(obj.TPLAHIR);

                var tglLahir    = obj.TGLAHIR;
                var thnLahir    = tglLahir.substr(0, 4);
                var blnLahir    = tglLahir.substr(5, 2);
                var tLhrnya     = tglLahir.substr(8, 2);
                var ttlnya      = tLhrnya + "/" + blnLahir + "/" + thnLahir;
                jQuery("#TGLLAHIR").val(ttlnya);

                var jenkel = obj.KELAMIN;
                if (jenkel == "L") {
                    jQuery('#JENISKELAMIN_L').attr('checked', true);
                }
                else {
                    jQuery('#JENISKELAMIN_P').attr('checked', true);
                }

                var agama = obj.AGAMA;
                switch (agama) {
                    case "ISLAM":
                        jQuery('#AGAMA_1').attr('checked', true);
                        break;
                    case "PROTESTAN":
                        jQuery('#AGAMA_2').attr('checked', true);
                        break;
                    case "KATHOLIK":
                        jQuery('#AGAMA_3').attr('checked', true);
                        break;
                    case "Hindu":
                        jQuery('#AGAMA_4').attr('checked', true);
                        break;
                    case "BUDHA":
                        jQuery('#AGAMA_5').attr('checked', true);
                        break;
                    default:
                        jQuery('#AGAMA_6').attr('checked', true);
                        break;
                }

                var pend = obj.PENDIDIK;
                var pendnow = pend.substring(4);
                switch (pendnow) {
                    case "SD":
                        jQuery('#PENDIDIKAN_1').attr('checked', true);
                        break;
                    case "SMP":
                        jQuery('#PENDIDIKAN_2').attr('checked', true);
                        break;
                    case "SLTP":
                        jQuery('#PENDIDIKAN_2').attr('checked', true);
                        break;
                    case "SMA":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SMU":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SLTA":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "STM":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SMK":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SMEA":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    case "SMKK":
                        jQuery('#PENDIDIKAN_3').attr('checked', true);
                        break;
                    default:
                        jQuery('#PENDIDIKAN_5').attr('checked', true);
                        break;
                }

                var ketstatus = obj.KAWIN;
                switch (ketstatus) {
                    case "K":
                        jQuery('#status_2').attr('checked', true);
                        break;
                    case "T":
                        jQuery('#status_1').attr('checked', true);
                        break;
                    case "J":
                        jQuery('#status_3').attr('checked', true);
                        break;
                    case "D":
                        jQuery('#status_3').attr('checked', true);
                        break;
                    default:
                        jQuery('#status_1').attr('checked', true);
                        break;
                }

                jQuery("#PEKERJAAN").val(obj.PEKPASIEN);
                jQuery("#SUAMI_ORTU").val(obj.NAMAWALI);
				
				var kdwil = obj.KDWIL;
                switch(kdwil){
                    case "B":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1698);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "T":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1701);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "G":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1700);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "U":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1702);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "S":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1699);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "H":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1703);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "D":
                        jQuery("#KOTAHIDDEN").val(127);
                        jQuery("#KECAMATANHIDDEN").val(1267);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(127).change();
                        break;
                    case "L":
                        jQuery("#KOTAHIDDEN").val(142);
                        jQuery("#KECAMATANHIDDEN").val(1667);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(142).change();
                        break;
                }
            });
        }

        function load_pasien_old(word){
            jQuery.ajax({
                url: "<?=_BASE_?>models/get_oldpasien.php?param="+word,
                success: function(data){
                    //alert(data);
                    jQuery("#list_pasien").html(data);
                }
            });
        }

        jQuery("#cari_pasien_by_oldnomr").click(function(){
            jQuery("#list_pasien").html('');
            var data    = jQuery("#nomr_old").val();

            var data2   = data.substring(0,2);
            if(isNaN(data2) == false){
                get_pasien_by_old_nomr(data);
            }
            else{
                load_pasien_old(data);
            }
        });
    });

    function js_yyyy_mm_dd_hh_mm_ss () {
        now = new Date();
        year = "" + now.getFullYear();
        month = "" + (now.getMonth() + 1); if (month.length == 1) { month = "0" + month; }
        day = "" + now.getDate(); if (day.length == 1) { day = "0" + day; }
        hour = "" + now.getHours(); if (hour.length == 1) { hour = "0" + hour; }
        minute = "" + now.getMinutes(); if (minute.length == 1) { minute = "0" + minute; }
        second = "" + now.getSeconds(); if (second.length == 1) { second = "0" + second; }
        return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
    }
    //alert("Data Telah Disimpan. \n Nama Pasien : <?php echo $NAMADATA; ?> \n No MR <?php echo $nomr; ?>");
</script>

<style type="text/css">
    .loader {
        background: url(js/loading.gif) no-repeat;
        width: 16px;
        height: 16px;
        float: right;
        margin-right: 30px;
    }

    input.error {
        border: 1px solid #F00;
    }

    label.error {
        color: #F00;
        font-weight: bold;
    }

</style>

<div id="list_pasien"></div>

<div align="center">
    <div id="frame">
        <div id="frame_title"><h3 align="left">DATA ADMINISTRASI PASIEN</h3>
        </div>
        <div id='val'></div>

        <form name="myform" id="myform" action="models/pendaftaran.php" method="post">

            <!--<legend>Daftar</legend>-->
            <?
            unset($_SESSION['register_nomr']);
            unset($_SESSION['register_nama']);
            #  echo $pmb -> begin_round("100%","FFF","CCC","CCC"); //  (width, fillcolor, edgecolor, shadowcolor)
            ?>

            <fieldset>
                <legend>Data Medis</legend>
                <table width="96%" border="0" title=" ">
                    <tr>
                        <td>
                            Jam Mulai Pendaftaran
                        </td>
                        <td>
                            <input type="text" class="text" name="masuk" value="" id="masuk" size="25" required />
                            <input type="button" class="text" name="save2" onclick="jQuery('#masuk').val(js_yyyy_mm_dd_hh_mm_ss()); jQuery(this).hide();" value=" M a s u k " />
                        </td>
                    </tr>
                    <tr>
                        <td>Status Pasien</td>
                        <td>
                            <div id="psn">
                                <script src="js/custom-js.js" language="JavaScript" type="text/javascript"></script>
<!--                                <input type="hidden" name="PASIENBARU" id="PASIENBARUS"-->
<!--                                       value="--><?php //$_GET['PASIENBARU'] ?><!--">--><?//
//                                if (!isset($_GET['PASIENBARU'])) {
//                                    echo '<input type="hidden" name="PASIENBARU" id="PASIENBARU" value="1">';
//                                    ?>
<!--                                    <input type="radio" name="STATUSPASIEN" id="STATUSPASIEN_1" class="statuspasien"-->
<!--                                           value="1" --><?php //if ($_GET['PASIENBARU'] != '0'): echo 'checked="checked"'; endif; ?>
<!--                                           onchange="set_nmr();"> Pasien Baru-->
<!--                                    <input type="radio" name="STATUSPASIEN" id="STATUSPASIEN_0" class="statuspasien"-->
<!--                                           value="0" --><?php //if ($_GET['PASIENBARU'] == '0'): echo 'checked="checked"'; endif; ?><!-- >Pasien Lama-->
<!--                                --><?php
//                                } else {
//                                    echo '<input type="hidden" name="PASIENBARU" id="PASIENBARU" value="0">';
//                                    ?>
<!--                                    <input type="radio" name="STATUSPASIEN" id="STATUSPASIEN_1" class="statuspasien"-->
<!--                                           value="1" --><?php //if ($_GET['PASIENBARU'] != '0'): echo 'checked="checked"'; endif; ?>
<!--                                           onchange="set_nmr();"> Pasien Baru-->
<!--                                    <input type="radio" name="STATUSPASIEN" id="STATUSPASIEN_0" class="statuspasien"-->
<!--                                           value="0" --><?php //if ($_GET['PASIENBARU'] == '0'): echo 'checked="checked"'; endif; ?><!-- >Pasien Lama-->
<!--                                --><?php
//                                }
//                                ?>
                                <input type="hidden" name="PASIENBARU" id="PASIENBARU"
                                       value="1">
                                <input type="radio" name="STATUSPASIEN" id="STATUSPASIEN_1" class="statuspasien"
                                       value="1" <?php if ($_GET['PASIENBARU'] != '0'): echo 'checked="checked"'; endif; ?>
                                       onchange="set_nmr();">
								<label for="STATUSPASIEN_1">Pasien Baru</label>
                                <input type="radio" name="STATUSPASIEN" id="STATUSPASIEN_0" class="statuspasien"
                                       value="0" <?php if ($_GET['PASIENBARU'] == '0'): echo 'checked="checked"'; endif; ?>>
								<label for="STATUSPASIEN_0">Pasien Lama</label>
                            </div>
                        </td>
                        <td align="right">&nbsp;</td>
                    </tr>
                    <tr id="tr_nomr">
                        <td width="16%">No RM</td>
                        <td width="20%">
							<!--<input type="text" id="param_nomr" value="<?= $_GET['rm']; ?>"/>-->
                            <input class="text" type="text" name="NOMRID" id="NOMR" size="25" value=""/>
                            <!--<input type="button" value="SET NOMR" name="set_nomr" id="set_nomr" class="text button"/>-->
                            <div class="loader"></div>
                        <td width="53%" align="right">
                            <?php
                            //added by ferna 25062015
                            //waktu sekarang pada database
                            $sql = mysql_query("SELECT TIME(now()) as time");
                            while ($ds = mysql_fetch_array($sql)) {
                                $now = $ds['time'];
                                $jam = substr($now, 0, 2);
                                $menit = substr($now, 3, 2);
                                $detik = substr($now, 6, 2);
                            }

                            $jam_now = new DateTime($now);
                            $jam_pagi_bawah = new DateTime("07:00:00");
                            $jam_pagi_atas = new DateTime("14:15:00");
                            $jam_sore_atas = new DateTime("21:15:00");
                            ?>
                            "Shift Petugas Jaga"
                            <input type="radio" name="SHIFT" class="required" title="*"
                                   value="1" <? if ($jam_now > $jam_pagi_bawah && $jam_now < $jam_pagi_atas) echo "Checked"; ?>/>
                            Pagi
                            <input type="radio" name="SHIFT" class="required" title="*"
                                   value="2" <? if ($jam_now > $jam_pagi_atas && $jam_now < $jam_sore_atas) echo "Checked"; ?>/>
                            Sore
                            <input type="radio" name="SHIFT" class="required" title="*"
                                   value="3" <? if ($t_pendaftaran->SHIFT == "3" || $_GET['SHIFT'] == "3") echo "Checked"; ?>
                                   hidden/>
                            <!--Malam-->
                    </tr>
                    <tr>
                        <td>NO RM Lama/Nama Pasien</td>
                        <td>
                            <input type="text" name="nomr_old" id="nomr_old" class="text" size="25" placeholder="Masukkan NOMR lama/Nama Pasien" />
                            <input type="button" id="cari_pasien_by_oldnomr" class="text" value="CARI" />
                        </td>
                        <td width="53%" align="right" rowspan="4">
                            <!--<input type="button" class="text button" id="btn_kode_p" value="K o d e - P" style="width: 15%;height: 80%;">-->
                            <input type="hidden" id="kode_p" name="kode_p" value="0" />
							<input type="button" class="text button" id="btn_kode_t" value="K o d e - T" style="width: 15%;height: 80%;">
                            <input type="hidden" id="kode_t" name="kode_t" value="0" />
                        </td>
                    </tr>

                    <!-- // START DIDIKREASI EDIT-->
                    <tr>

                    <tr>
                        <td>Poli / dokter yang dituju</td>
                        <td>
                            <span>
								<input type="hidden" id="param_poli" value="<?= $_REQUEST['poli']; ?>"/>
                                <input type="hidden" id="param_dokter" value="<?= $_REQUEST['dokter']; ?>"/>
                                <select name="KDPOLY" id="kdpoly" class="selectbox text required select2" title="*"
                                        style="float:left; margin-right:20px;">
                                    <option value=""> - Pilih klinik -</option>
                                    <?php
                                    $sql = mysql_query('select * from m_poly order by nama asc');
                                    while ($data = mysql_fetch_array($sql)) {
                                        if ($_GET['KDPOLY'] == $data['kode']): $zx = 'selected="selected"';
                                        else: $zx = ''; endif;
                                        echo '<option value="' . $data['kode'] . '" id_poli_bpjs="' . $data['id_poli_bpjs'] . '" ' . $zx . '>' . $data['nama'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </span>
							
							<div id="list_alias_poli" >
								<select name="KDPOLY_alias" id="kdpoly_alias" class="selectbox text select2" title="*"
                                        style="float:left; margin-right:20px;">
                                    <option value="0"> - Pilih Alias klinik -</option>
                                    <?php
                                    $sql = mysql_query('select * from m_poly order by nama asc');
                                    while ($data = mysql_fetch_array($sql)) {
                                        if ($_GET['KDPOLY'] == $data['kode']): $zx = 'selected="selected"';
                                        else: $zx = ''; endif;
                                        echo '<option value="' . $data['kode'] . '" ' . $zx . '>' . $data['nama'] . '</option>';
                                    }
                                    ?>
								</select>
							</div>

                            <div id="listdokter_jaga">
                                <?php
                                if ($_GET['KDPOLY'] != '') {
                                    //$sqldokter	= mysql_query('select distinct(a.kddokter) as kddokter, b.NAMADOKTER from m_dokter_jaga a join m_dokter b on a.KDDOKTER = b.kddokter where a.kdpoly = "'.$_GET['KDPOLY'].'" ORDER BY NAMADOKTER asc');
                                    $sqldokter = mysql_query("SELECT DISTINCT KDDOKTER AS kddokter, NAMADOKTER
												FROM m_dokter WHERE KDPOLY='" . $_GET['KDPOLY'] . "' WHERE st_aktif = 0  AND KDDOKTER != 0 ORDER BY NAMADOKTER ASC");
                                    if (mysql_num_rows($sqldokter) > 0) {
                                        echo '<select name="KDDOKTER" id="kddokter" class="dokter_jaga select2">';
                                        while ($datadok = mysql_fetch_array($sqldokter)) {
                                            if ($_GET['KDDOKTER'] == $datadok['kddokter']): $sel = 'selected="selected"';
                                            else: $sel = ''; endif;
                                            echo '<option value="' . $datadok['kddokter'] . '" ' . $sel . '>' . $datadok['NAMADOKTER'] . '</option>';
                                        }
                                        echo '</select>';
                                    } else {
                                        echo 'Tidak ada dokter jaga di poli tersebut';
                                    }
                                    #echo getDokterName($_GET['KDDOKTER']);
                                }
                                ?>
                            </div>

                            <span>
                                <select id="kelas_perawatan" class="text" name="kelas_perawatan">
                                    <option value="">--Pilih Kelas Perawatan--</option>
                                    <option value="1">Kelas I</option>
                                    <option value="2">Kelas III</option>
                                </select>
                            </span>
                        </td>

                    </tr>
                    <tr>
                        <td>Minta Rujukan</td>
                        <td><input type="checkbox" name="minta_rujukan" id="minta_rujukan" value="1"/></td>
                    </tr>
                    <tr>
                        <!--<td>&nbsp;</td>-->
                        <td>Tanggal Daftar</td>
                        <td><input type="text" name="TGLREG" class="text" value="<?php if (!empty($_GET['TGLREG'])) {
                                echo $_GET['TGLREG'];
                            } else {
                                date_default_timezone_set("Asia/Bangkok");
                                echo date("Y-m-d");
                            } ?>" size="20"/>
                            <input type='hidden' name='start_daftar' id='start_daftar'/></td>
                        <td align="right">

                        </td>
                    </tr>
                    <!--<tr><td>&nbsp;</td>-->
                    <td>Cara Bayar</td>
                    <td colspan="2">
                        <?php
                        $ss = mysql_query('select * from m_carabayar order by ORDERS ASC');

                        //old --> memakai radio button
                        /*while($ds = mysql_fetch_array($ss)){
                          if($_GET['KDCARABAYAR'] == $ds['KODE']): $sel = "Checked"; else: $sel = ''; endif;
                          echo '<input type="radio" name="KDCARABAYAR" id="carabayar_'.$ds['KODE'].'" title="*" class="carabayar required" '.$sel.' value="'.$ds['KODE'].'" /> '.$ds['NAMA'].'&nbsp;';
                        }*/

                        //added 14082015
                        //new --> memakai dropdown
                        echo '<select name="KDCARABAYAR" class="carabayar required select2" style="font-size:8pt;">';
                        while ($ds = mysql_fetch_array($ss)) {
                            if ($_GET['KDCARABAYAR'] == $ds['KODE']): $sel = "Selected";
                            else: $sel = ''; endif;
                            echo '<option id="carabayar_' . $ds['KODE'] . '" ' . $sel . ' value="' . $ds['KODE'] . '" svn="' . $ds['NAMA'] . '">' . $ds['NAMA'] . '</option>';
                        }
                        echo '</select>';
                        //added 14082015

                        $cssb = 'style="display:none;"';
                        if ($_GET['KETBAYAR'] != ''):
                            $cssb = 'style="display:inline;"';
                        endif;
                        ?>
                        <!--<input type="text" name="KETBAYAR" title="*" id="carabayar_lain" <?php echo $cssb; ?> value="<?php echo $_REQUEST['KETBAYAR']; ?>" class="text"/></td></tr>-->
                        <tr id="tr_nokaryawan">
                            <td>
                                <label id="label_nokaryawan">NO Karyawan</label>
                            </td>
                            <td colspan="2">
                                <input type="text" name="nokaryawan" id="nokaryawan" value="" class="text"/>
                                <input type="button" id="btncarikaryawan" class="text" value="cari"/>
                                <input type="button" id="btncarikaryawanpj" class="text" value="cari"/>
                            </td>
                        </tr>
                        <tr id="tr_jkn">
                            <td>Keterangan JKN</td>
                            <td>
                                <select class="select2" id="ket_jkn" name="ket_jkn">
                                    <option value=" ">--pilih JKN--</option>
                                    <?php
                                        $sql    = mysql_query("SELECT * FROM m_jkn");
                                        while($data = mysql_fetch_array($sql)){
                                    ?>
                                            <option value="<?php echo $data['nama_jkn']; ?>"><?php echo $data['nama_jkn']; ?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr id="tr_nokartubpjs">
                            <td><label id="label_nokartubpjs">NO Kartu BPJS</label></td>
                            <td colspan="2"><input type="text" name="nokartu" title="*" id="nokartu" <?php echo $ppk; ?>
                                                   value="" class="text"/>
                                <input type='button' id='btnrujukan' class='text' value='cari'>
                            </TD>
                        </tr>
                        <tr id="tr_nopeserta">
                            <td><label id="label_nopeserta">Kelompok Peserta</label></td>
                            <td colspan="2"><input type="text" name="jns_peserta" title="*"
                                                   id="jns_peserta" <?php echo $ppk; ?> value="" class="text"/></td>
                        </tr>
                        <tr>
                            <!--<td>&nbsp;</td>-->
                            <td>Rujukan</td>
                            <td colspan="2">
                                <?php
                                $ss = mysql_query('select * from m_rujukan order by ORDERS ASC');
                                echo '<select name="KDRUJUK" class="kdrujuk required text" style="font-size:8pt;">';
                                while ($ds = mysql_fetch_array($ss)) {
                                    if ($_GET['KDRUJUK'] == $ds['KODE']): $sel = "Checked";
                                    else: $sel = ''; endif;
                                    echo '<option type="radio" id="asal' . $ds['KODE'] . '" title="*" ' . $sel . ' value="' . $ds['KODE'] . '" /> ' . $ds['NAMA'] . '</option>';
                                }
                                echo '</select>';

                                $css = 'style="display:none; float:left;"';
                                if ($_GET['KETRUJUK'] != ''):
                                    $css = 'style="display:inline;"';
                                endif;
                                ?>
                                <input type="text" title="*" name="KETRUJUK" <?php echo $css; ?>
                                       value="<?php echo $_GET['KETRUJUK']; ?>" id="kdrujuk_lain" class="text"/>

                            </td>
                        </tr>


                        <tr id="tr_norujukan">
                            <td><label id="label_norujukan">NO Rujukan</label></td>
                            <td colspan=2><input type="text" name="norujukan" title="*"
                                                 id="norujukan" <?php echo $norujukan; ?> value="" class="text"/></td>
                        </tr>
                        <tr id="tr_tglrujukan">
                            <!--<td>&nbsp;</td>-->
                            <td><label id="label_tglrujukan">Tanggal Rujukan</label></td>
                            <td><input type="text" name="tglrujuk" id="tglrujuk" class="text"
                                       value="<?php if (!empty($_GET['TGLREG'])) {
                                           echo $_GET['TGLREG'];
                                       } else {
                                           echo date("Y-m-d H:i:s");
                                       } ?>" size="20"/>
                                <input type='hidden' name='start_daftar' id='start_daftar'/></td>
                            <td align="right">

                            </td>
                        </tr>
                        <tr id="tr_ppkrujukan">
                            <td><label id="label_ppkrujukan">KODE PPK Rujukan</label></td>
                            <td colspan="2"><input type="text" name="noppk" title="*" id="noppk" <?php echo $ppk; ?>
                                                   value="" class="text"/>
                                <input type="hidden" name="namappk" title="*" id="namappk" <?php echo $ppk; ?> value=""
                                       class="text"/></TD>
                        </tr>
                        <tr id="tr_diagnosaawal">
                            <td>
                                <label id="label_diagnosaawal">Diagnosa Awal</label>
                            </td>
                            <td colspan="2">
                                <input type="text" name="diagnosa" title="*" id="diagnosa" <?php echo $ppk; ?> value=""
                                       class="text"/>
                            </td>
                        </tr>
                        <tr>
                            <!--<td>&nbsp;</td>-->
                            <td>Kelas Perawatan</td>
                            <td><input type="text" name="kelas" id="kelas" class="text"
                                       value="<?php if (!empty($_GET['Kelas'])) {
                                           echo $_GET['Kelas'];
                                       } else {
                                           echo "3";
                                       } ?>" size="3"/>
                                <input type='hidden' name='start_daftar' id='start_daftar'/></td>
                            <td align="right">

                            </td>
                        </tr>
                        <tr id="tr_nosep">

                            <td><label id="label_nosep">NO SEP</label></td>
                            <td colspan="2">
                                <input type="text" readonly name="NK" id="NK" value="" class="text"/>
								&nbsp;<input type='button' id='btnsep' class='text' value='create No SEP'>
								
                            </td>
                        </tr>

                        <!--        // start edit didikreassi-->
                        <tr>
                            <td colspan="4" align="right">
                                <!--<input style="background:#088F11;" type="submit" name="daftar" class="text" value="  Simpan SKP  "
                                onclick="stopjam();" />-->

                                <!--          <a href="#" onclick="cetak();" >
                                          <input type="button" name="print" class="text" value=" Print Kartu Pasien " />-->
                                <!--          <input/>-->
                                <!--          </a>-->
                            </td>
                        </tr>
                </table>
            </fieldset>
            <!--        // ending edit didikreasi-->
            <!--        <td width="23%">Nama Lengkap Pasien</td>-->
            <fieldset>
                <legend>Data Pasien</legend>
                <table width="50%" border="0" cellpadding="0" cellspacing="0"
                       title=" From Ini Berfungsi Sebagai Form Entry Data Pasien Baru." style="float:left;">
                    <tr>
                        <!--              <td valign="top" width="3%" rowspan="12"><img src="img/data.png" /></td>-->
                        <td valign="top" width="3%" rowspan="12"></td>
                        <!--          <td width="23%">Nama Lengkap Pasien</td>
          <td width="54%"><span id="nam"><input title="*" class="text required" type="text" name="NAMA" size="30" value="<? if (!empty($_GET['NAMA'])) {
                            echo $_GET['NAMA'];
                        } ?>" id="NAMA"  /></span>
          <select name="CALLER" class="text" id="CALLER">
          	<option selected="selected" value="">- Alias -</option>
            <option value="Tn" <? if ($_GET['CALLER'] == "Tn") echo "selected=selected"; ?>> Tn </option>
            <option value="Ny" <? if ($_GET['CALLER'] == "Ny") echo "selected=selected"; ?>> Ny </option>
            <option value="Nn" <? if ($_GET['CALLER'] == "Nn") echo "selected=selected"; ?>> Nn </option>
	     <option value="An" <? if ($_GET['CALLER'] == "An") echo "selected=selected"; ?>> An </option>

          </select>
          </td>-->

                    </tr>
                    <tr>
                        <td>Nama Pasien</td>
                        <!--          <td width="54%"><span id="nam"><input title="*" class="text required" type="text" name="NAMA" size="30" value="<? if (!empty($_GET['NAMA'])) {
                            echo $_GET['NAMA'];
                        } ?>" id="NAMA"  /></span>-->
                        <td width="54%"><span id="nam"><input title="*" class="text required" type="text" name="NAMA"
                                                              size="30" value="<? if (!empty($_GET['NAMA'])) {
                                    echo $_GET['NAMA'];
                                } ?>" id="NAMA"/></span>
                            <select name="CALLER" class="text select2" id="CALLER">
                                <option selected="selected" value="">- Alias -</option>
                                <option value="Tn" <? if ($_GET['CALLER'] == "Tn") echo "selected=selected"; ?>> Tn
                                </option>
                                <option value="Ny" <? if ($_GET['CALLER'] == "Ny") echo "selected=selected"; ?>> Ny
                                </option>
                                <option value="Nn" <? if ($_GET['CALLER'] == "Nn") echo "selected=selected"; ?>> Nn
                                </option>
                                <option value="An" <? if ($_GET['CALLER'] == "An") echo "selected=selected"; ?>> An
                                </option>

                            </select>
                        </td>
                    </tr>
                    <!--              // start didikreasi edit-->
                    <tr>
                        <td>Nama Wali</td>
                        <td><input class="text" type="text" value="<? if (!empty($_GET['SUAMI_ORTU'])) {
                                echo $_GET['SUAMI_ORTU'];
                            } else {
                                echo $m_pasien->SUAMI_ORTU;
                            } ?>" name="SUAMI_ORTU" id="SUAMI_ORTU" size="25"/></td>
                    </tr>

                    <!--              //akhir didikreasi edit-->

                    </td>
                    </tr>
                    <!--        //AKHIR DIDIKREASI EDIT-->

                    <?
                    #echo $pmb -> end_round();
                    ?>


                    <div id="all">
                        <? include("include/view_prosess.php"); ?>
                    </div>
            </fieldset>
        </form>

    </div>
</div>

<script>
	function poli_blur(){
        var nomr   = jQuery('#NOMR').val();
        var val    = jQuery('#kdpoly').val() == 31 ? 34 : jQuery('#kdpoly').val();
		var dokter = jQuery('#param_dokter').val();
		
        val = val == 52 ? 1 : val;
        val = val == 57 ? 3 : val;
        
		jQuery.ajax({
            url: "<?= _BASE_;?>models/cek_pendaftaran.php",
			method: "post",
            data: {jenpas:jQuery('.carabayar').val(),nomr:nomr,load_pendaftaran:'true'},
            success: function (data) {
                if(data > 0){
                    alert("Pasien sudah terdaftar di SIMRS menggunakan jaminan BPJS, harap cek pada list kunjungan pasien. Jika ingin melanjutkan pasien harus menggunakan jaminan selain BPJS.");
                } else{
                    jQuery('#loader_namadokter').show();
                    jQuery.post('<?php echo _BASE_;?>//include/ajaxload.php', {
                        kdpoly: val,
						dokter:dokter,
                        load_dokter: 'true'
                    }, function (data) {
                        //var n = data.split("|");
                        //jQuery('#kddokter').val(n[0]);
                        jQuery('#listdokter_jaga').empty().append(data);
                        //jQuery('#loader_namadokter').hide();
                    });

                    if(val == 48) {
                        jQuery('#kelas_perawatan').show();
                    }
                    else{
                        jQuery('#kelas_perawatan').hide();
                    }
                        
                    if(val == 53){
                        jQuery('#list_alias_poli').show();
                    } else{
                        jQuery('#list_alias_poli').hide();
                    }
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {

            }
        });
    }

    jQuery('#kdpoly').change(function () {
        poli_blur();
    });
	
	jQuery('.carabayar').change(function () {
		var jenpas = jQuery(this).val();
		var nomr   = jQuery('#NOMR').val();
        jQuery.ajax({
            url: "<?= _BASE_;?>models/cek_pendaftaran.php",
			method: "post",
            data: {jenpas:jenpas,nomr:nomr},
            success: function (data) {
                if(data > 0){
                    alert("Pasien sudah terdaftar di SIMRS menggunakan jaminan BPJS, harap cek pada list kunjungan pasien. Jika ingin melanjutkan pasien harus menggunakan jaminan selain BPJS.");
					jQuery('.btn_simpan').attr('disabled', 'disabled');
                } else{
					jQuery('.btn_simpan').removeAttr('disabled');
				}
            },
            error: function (jqXHR, textStatus, errorThrown) {

            }
        });
    });
	
	function param_request_poli(){
		var poli = jQuery('#param_poli').val();
		
		if(poli != ''){
			jQuery('#kdpoly').val(poli);
			poli_blur();
		}
	}
	
	param_request_poli();
</script>
