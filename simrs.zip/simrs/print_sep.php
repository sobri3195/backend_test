<?php
ob_start();

if(isset($_REQUEST['idx']) && isset($_REQUEST['poly'])){
    include("include/connect.php");
    include("include/function.php");
    $idx	= $_REQUEST['idx'];
    $poly	= $_REQUEST['poly'];

    $sql	= 	'select t_pendaftaran.NOMR, 
						m_pasien.nama as pasien, 
						m_poly.nama as poly, 
						t_pendaftaran.idxdaftar, 
						t_pendaftaran.NOKARTU as sep, 
						t_pendaftaran.TGLREG, 
						t_pendaftaran.KDPOLY,
						t_pendaftaran.kdpoly_alias,
						t_pendaftaran.KDDOKTER,
						m_pasien.NO_KARTU, 
						m_pasien.TGLLAHIR, 
						m_pasien.JENISKELAMIN, 
						m_pasien.NMPROVIDER, 
						t_pendaftaran.DIAGNOSA_AWAL, 
						m_pasien.JNS_PASIEN, 
						m_pasien.Kelas 
				from t_pendaftaran
				join m_pasien on t_pendaftaran.NOMR = m_pasien.NOMR 
				join m_poly on m_poly.kode = t_pendaftaran.KDPOLY
				where t_pendaftaran.KDPOLY ='.$poly.' and t_pendaftaran.IDXDAFTAR="'.$idx.'"';
    $res	= mysql_query($sql) or die(mysql_error());
    $a		= mysql_num_rows($res);
    $data	= mysql_fetch_array($res);
    extract($data);
    $tgl= date("d-m-Y",strtotime($TGLREG));
    $tgllhr= date("d-m-Y",strtotime($TGLLAHIR));

    if($data['KDPOLY'] == 53){
        $sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
    } else if($data['KDPOLY'] == 47){
        $sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
    } else if($data['KDPOLY'] == 52){
        $sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
    } else if($data['KDPOLY'] == 31){
        $sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
    } else{
        $sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND KDDOKTER = "'.$data['KDDOKTER'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
    }
    $rs_nourut  = mysql_query($sql_nourut);
    $row_nourut = mysql_fetch_array($rs_nourut);
    $nourut	    = $row_nourut['row'];
    ?>
    <style type="text/css" media="print">
        #tbl_rs {	width:810px;
            font-family: 'Lucida ', Monaco, monospace;
            font-size: 6.5pt;
            padding-left: 50px;
        }
    </style>
    <div style="width:100%;text-align:center;">
        <b>SURAT ELIGIBILITAS PESERTA</b><br/>
        <b>RSUD Kota Bogor</b><br/>
    </div>
    <table align="left" id='tbl_rs'>
        <tr>
            <td width="125px;">Nomor SEP</td>
            <td width="160px;">: <?php echo $sep; ?></td>
            <td width="20px;"></td>
            <td>Peserta</td>
            <td>: <?php echo $JNS_PASIEN; ?></td>
        </tr>
        <tr>
            <td>TGL SEP</td>
            <td>: <?php echo $tgl; ?></td>
            <td>&nbsp;</td>
            <td>COB</td>
            <td>:</td>
        </tr>
        <tr>
            <td>No. Kartu</td>
            <td>: <?php echo $NO_KARTU; ?></td>
            <td>&nbsp;</td>
            <td>Jns Rawat</td>
            <td>: Rawat Jalan</td>
        </tr>
        <tr>
            <td>Nama Peserta</td>
            <td>: <?php echo $pasien; ?></td>
            <td>&nbsp;</td>
            <td>Kls Rawat</td>
            <td>: <?php echo $Kelas; ?></td>
        </tr>
        <tr>
            <td>Tgl Lahir</td>
            <td>: <?php echo $tgllhr; ?></td>
            <td>&nbsp;</td>
            <td valign='top' width="200px">Pasien/ Keluarga Pasien</td>
            <td valign='top' width="200px">Petugas BPJS Kesehatan</td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>: <?php echo $JENISKELAMIN; ?></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Poli Tujuan</td>
            <td>: <?= $KDPOLY == 53 ? getPolyName($kdpoly_alias) : $poly; ?></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Asal Faskes Tk.1</td>
            <td>: <?php echo $NMPROVIDER; ?></td>
            <td>&nbsp;</td>
            <td rowspan=2 valign='bottom'>------------------</td>
            <td rowspan=2 valign='bottom'>------------------</td>
        </tr>
        <tr>
            <td>Diagnosa Awal</td>
            <td>: <?php echo $DIAGNOSA_AWAL; ?></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>No MR</td>
            <td>: <?php echo $NOMR; ?></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Catatan</td>
            <td>:</td>
            <td>&nbsp;</td>
            <td rowspan=2>No. Urut Dokter</td>
            <td rowspan=2>: <?= $nourut; ?></td>
        </tr>
        <tr>
            <td colspan="6">Saya menyetujui BPJS Kesehatan menggunakan informasi medis apabila dibutuhkan</td>
        </tr>
        <tr style="">
            <td colspan="6">SEP bukan bukti penjamin peserta <b>(Cetak SEP: <?= date('d-m-Y H:s:i'); ?>)</b><br/></td>
        </tr>
    </table>

    <hr style="border-top: dotted 1px;"/>

    <div style="width:100%; text-align:center;">
        .<br/>
        <b>SURAT ELIGIBILITAS PESERTA</b><br/>
        <b>RSUD Kota Bogor</b><br/>
    </div>
    <table align="left" id='tbl_rs'>
        <tr>
            <td width="125px;">Nomor SEP</td>
            <td width="160px;">: <?php echo $sep; ?></td>
            <td width="20px;"></td>
            <td>Peserta</td>
            <td>: <?php echo $JNS_PASIEN; ?></td>
        </tr>
        <tr>
            <td>TGL SEP</td>
            <td>: <?php echo $tgl; ?></td>
            <td>&nbsp;</td>
            <td>COB</td>
            <td>:</td>
        </tr>
        <tr>
            <td>No. Kartu</td>
            <td>: <?php echo $NO_KARTU; ?></td>
            <td>&nbsp;</td>
            <td>Jns Rawat</td>
            <td>: Rawat Jalan</td>
        </tr>
        <tr>
            <td>Nama Peserta</td>
            <td>: <?php echo $pasien; ?></td>
            <td>&nbsp;</td>
            <td>Kls Rawat</td>
            <td>: <?php echo $Kelas; ?></td>
        </tr>
        <tr>
            <td>Tgl Lahir</td>
            <td>: <?php echo $tgllhr; ?></td>
            <td>&nbsp;</td>
            <td valign='top' width="200px">Pasien/ Keluarga Pasien</td>
            <td valign='top' width="200px">Petugas BPJS Kesehatan</td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>: <?php echo $JENISKELAMIN; ?></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Poli Tujuan</td>
            <td>: <?= $KDPOLY == 53 ? getPolyName($kdpoly_alias) : $poly; ?></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Asal Faskes Tk.1</td>
            <td>: <?php echo $NMPROVIDER; ?></td>
            <td>&nbsp;</td>
            <td rowspan=2 valign='bottom'>------------------</td>
            <td rowspan=2 valign='bottom'>------------------</td>
        </tr>
        <tr>
            <td>Diagnosa Awal</td>
            <td>: <?php echo $DIAGNOSA_AWAL; ?></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>No MR</td>
            <td>: <?php echo $NOMR; ?></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Catatan</td>
            <td>:</td>
            <td>&nbsp;</td>
            <td rowspan=2>No. Urut Dokter</td>
            <td rowspan=2>: <?= $nourut; ?></td>
        </tr>
        <tr>
            <td colspan="6">Saya menyetujui BPJS Kesehatan menggunakan informasi medis apabila dibutuhkan</td>
        </tr>
        <tr>
            <td colspan="6">SEP bukan bukti penjamin peserta <b>(Cetak SEP: <?= date('d-m-Y H:s:i'); ?>)</b></td>
            <td colspan=2>&nbsp;</td>
        </tr>

    </table>
    <?php
}
$html      = ob_get_contents();
$file_name = "Cetak SEP";
ob_end_clean();
include "include/PDF.php";
include "include/cetak_sep_pdf.php";
?>