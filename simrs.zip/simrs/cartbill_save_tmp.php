<?php 
	session_start();
	include 'include/connect.php';
	include 'include/function.php';
	$dokter	= $_REQUEST['dokter'];
	$jenis = "e";
	$faktor = 1;
    if(isset($_REQUEST['saldo'])){
        $saldo  = $_REQUEST['saldo'];
    }
    else{
        $saldo  = 0;
    }

	if($_REQUEST['cito'] == 'c'){
		$jenis = 'c';
		$faktor = 1.25;
	}
	if(isset($_REQUEST['alkes'])){
		$sql=mysql_query("select * from tmp_cartbayar where IP='".getRealIpAddr()."' and ID = '".$_REQUEST["id"]."' and KDDOKTER = '".$dokter."' and JENIS = '".$jenis."'");
		if(mysql_num_rows($sql) > 0){
			mysql_query("update tmp_cartbayar set QTY=QTY+1 where IP='".getRealIpAddr()."' and ID='".$_REQUEST["id"]."' and KDDOKTER = '".$dokter."' and JENIS = '".$jenis."'");
		}else{
			$tarif	= $_REQUEST['tarif'];
			mysql_query('insert into tmp_cartbayar set KODETARIF = "'.$_REQUEST['kode'].'", IP = "'.getRealIpAddr().'", ID = "'.$_REQUEST['id'].'", QTY=1, poly ='.$_REQUEST['poly'].',KDDOKTER = "'.$dokter.'",UNIT="'.$_SESSION['KDUNIT'].'", TARIF = "'.$tarif * $faktor.'", DISCOUNT="0", TOTTARIF="'.$tarif * $faktor.'", JASA_SARANA = "'. 0 * $faktor.'", JASA_PELAYANAN = "'. 0 * $faktor.'", JENIS = "'.$jenis.'", saldo='.$saldo.', kd_barang='.$_REQUEST['id']);
		}
	}
    else if(isset($_REQUEST['obat'])){
        $qty    = $_REQUEST['qty'];
        $sql=mysql_query("select * from tmp_cartbayar where IP='".getRealIpAddr()."' and ID = '".$_REQUEST["id"]."' and KDDOKTER = '".$dokter."' and JENIS = '".$jenis."'");
        if(mysql_num_rows($sql) > 0){
            mysql_query("update tmp_cartbayar set QTY=QTY+$qty where IP='".getRealIpAddr()."' and ID='".$_REQUEST["id"]."' and KDDOKTER = '".$dokter."' and JENIS = '".$jenis."'");
        }else{
            $tarif	= $_REQUEST['tarif'];
            mysql_query('insert into tmp_cartbayar set KODETARIF = "'.$_REQUEST['kode'].'", IP = "'.getRealIpAddr().'", ID = "'.$_REQUEST['id'].'", QTY='.$qty.', poly ='.$_REQUEST['poly'].',KDDOKTER = "'.$dokter.'",UNIT="'.$_SESSION['KDUNIT'].'", TARIF = "'.$tarif * $faktor.'", DISCOUNT="0", TOTTARIF="'.$tarif * $faktor.'", JASA_SARANA = "'. 0 * $faktor.'", JASA_PELAYANAN = "'. 0 * $faktor.'", JENIS = "'.$jenis.'", saldo='.$saldo.', kd_barang='.$_REQUEST['id']);
        }
        echo mysql_num_rows($sql);
    }
	else{
		$sql=mysql_query("select * from tmp_cartbayar where IP='".getRealIpAddr()."' and ID = '".$_REQUEST["id"]."' and KDDOKTER = '".$dokter."' and JENIS = '".$jenis."'");
		if(mysql_num_rows($sql) > 0){
			mysql_query("update tmp_cartbayar set QTY=QTY+1 where IP='".getRealIpAddr()."' and ID='".$_REQUEST["id"]."' and KDDOKTER = '".$dokter."' and JENIS = '".$jenis."'");
		}else{
			$tarif	= getTarif($_REQUEST['kode']);
			mysql_query('insert into tmp_cartbayar set KODETARIF = "'.$_REQUEST['kode'].'", IP = "'.getRealIpAddr().'", ID = "'.$_REQUEST['id'].'", QTY=1, poly ='.$_REQUEST['poly'].',KDDOKTER = "'.$dokter.'",UNIT="'.$_SESSION['KDUNIT'].'", TARIF = "'.$tarif['tarif'] * $faktor.'", DISCOUNT="0", TOTTARIF="'.$tarif['tarif'] * $faktor.'", JASA_SARANA = "'.$tarif['jasa_sarana'] * $faktor.'", JASA_PELAYANAN = "'.$tarif['jasa_pelayanan'] * $faktor.'", JENIS = "'.$jenis.'"');
		}
	}
?>