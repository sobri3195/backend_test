<? include("include/connect.php"); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?= ucwords($rstitle)?></title>
	<link rel="shortcut icon" href="rsud.ico" />
    <link href="dq_sirs.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="css/slideshow/style1.css" />
    <link type="text/css" rel="stylesheet" href="css/jquery-ui-smoothness.min.css" />
    <link type="text/css" rel="stylesheet" href="css/modal/style.css" />
    <script type="text/javascript" language="javascript" src="include/ajaxrequest.js"></script>
    <script src="js/jquery-1.7.min.js" language="JavaScript" type="text/javascript"></script>
    <script type="text/javascript" src="js/jquery/jquery-ui.js" ></script>
    <script type="text/javascript" src="js/slideshow/modernizr.custom.86080.js"></script>
    <script type="text/javascript" src="js/modal/jquery.leanModal.min.js"></script>
    <SCRIPT>
        function jumpTo (link){
            var new_url=link;
            if ((new_url != "")  &&  (new_url != null))
                window.location=new_url;
        }

        jQuery(document).ready(function(){
            /*jQuery("#NIP").keyup(function(event){
                if(event.keyCode == 13){
                    MyAjaxRequest('valid_nip','include/process.php?NIP=','NIP');
                    jQuery("#PWD").focus();
                }
            });*/

            jQuery("#PWD").keyup(function(event){
                if(event.keyCode == 13){
                    //MyAjaxRequest('valid_pwd','include/process.php?PWD=','PWD');
                    jQuery('#frm').submit();
                }
            });
        });
    </script>
</head>

<body id="page">
<div id="header" class="container">
    <div id="bg_variation">
        <div id="logo">
        </div>
        <div id="info_header">
            <div id="info_isi">
                <div><?=strtoupper($singrstitl)?> <?=strtoupper($singhead1)?></div>
                <div>
                    <?php
                    if(isset($_SESSION['SES_REG'])){
                        echo '<a href="log_out.php">Sign Out</a> | User : '.$_SESSION['NIP'];
                    }else{
                        echo '<button href="#modal" id="modal_trigger" class="btn_signin" style="margin-top:5px;margin-bottom: 5px;">Sign In</button>';
                    }
                    ?>
                </div>
                <div class="date"><?php echo date("l, F Y"); ?></div>
                <div class="date">
                    <?php
                    if(isset($_SESSION['KDUNIT']) != ''):
                        $dep  = "SELECT * FROM m_login WHERE KDUNIT = '".$_SESSION['KDUNIT']."' AND ROLES = '".$_SESSION['ROLES']."'";
                        $qe   = mysql_query($dep);
                        if($qe){
                            $deps = mysql_fetch_assoc($qe);
                            echo "<div><b>".$deps['DEPARTEMEN']."</b></div>";
                        }
                    endif;
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!--<div id="slideshow">
    <ul class="cb-slideshow">
        <li><span>Image 01</span></li>
        <li><span>Image 02</span></li>
        <li><span>Image 03</span></li>
        <li><span>Image 04</span></li>
        <li><span>Image 05</span></li>
        <li><span>Image 06</span></li>
        <li><span>Image 07</span></li>
    </ul>
</div>-->

<div class="container">
    <div id="modal" class="popupContainer" style="display:none;">
        <header class="popupHeader">
            <span class="header_title">Login</span>
            <span class="modal_close"><i class="fa fa-times"></i></span>
        </header>

        <section class="popupBody">
            <form name="frm" id="frm" action="user_level.php" method="post">
                <?php
                if(isset($_POST['signin'])){
                    require_once("login.php");
                }
                ?>
                <div align="center">
                    <table width="100%" border="0">
                        <tr>
                            <td width="19%" rowspan="6" valign="top"><img src="img/log.png" /></td>
                            <td width="19%"><div id="usr">USERNAME </div></td>
                            <td width="62%"><input class="text" id="NIP" type="text" size="25" name="USERNAME"  /><span id="valid_nip"></span></td>
                        </tr>
                        <tr>
                            <td><div id="pas">PASSWORD </div></td>
                            <td><input class="text" type="password" id="PWD" size="25" name="PWD" /> <input type="button" value=" LOGIN " class=" text "  name="LOGIN" id="LOGIN" onclick="document.getElementById('frm').submit();"/><span id="valid_pwd"></span></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                    </table>
                </div>
            </form>
        </section>
    </div>
</div>

<div id="fixed-footer">
    <div id="footer-inner">
        <ul class="footer-navigation">
            <li><a href=""><?= ucwords($rstitle)?> &copy; <?php echo date("Y"); ?></a></li>
        </ul>
    </div>
</div>
</body>
</html><div>
</div>


<script>
    jQuery(".btn_signin").button({icons: {primary: "ui-icon-locked"}});

    jQuery("#modal_trigger").leanModal({top : 250, overlay : 0.7, closeButton: ".modal_close" });

    jQuery(function(){
        // Calling Login Form
        jQuery("#login_form").click(function(){
            jQuery(".social_login").hide();
            jQuery(".user_login").show();
            return false;
        });

        // Calling Register Form
        jQuery("#register_form").click(function(){
            jQuery(".social_login").hide();
            jQuery(".user_register").show();
            jQuery(".header_title").text('Register');
            return false;
        });

        // Going back to Social Forms
        jQuery(".back_btn").click(function(){
            jQuery(".user_login").hide();
            jQuery(".user_register").hide();
            jQuery(".social_login").show();
            jQuery(".header_title").text('Login');
            return false;
        });

    })
</script>