<?php

include_once('ExportToExcel.class.php');
$exp=new ExportToExcel();
$exp->exportWithPage("rekbayar_pertgl_rajal_xls1.php","rekbayar_pertgl_rajal.xls");
?>				