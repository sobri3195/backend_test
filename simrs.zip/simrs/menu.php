<?php session_start();
    if(!isset($_SESSION['SES_REG'])){
        header("location:login.php");
    }

    if($_SESSION['ROLES']=="3") { ?>
        <link href="../css/dropdown/dropdown.css" media="all" rel="stylesheet" type="text/css" />
        <link href="../css/dropdown/themes/default/default.css" media="all" rel="stylesheet" type="text/css" />
    <? }else { ?>
        <link href="css/dropdown/dropdown.css" media="all" rel="stylesheet" type="text/css" />
        <link href="css/dropdown/themes/default/default.css" media="all" rel="stylesheet" type="text/css" />
    <? } ?>


<?php
    // Menu dari aplikasi SIM RS GOS
    // ------------------------------
    switch( $_SESSION['ROLES'] ){
        default :
            include("menu/not_foud.php");
            break;
        case "1" :
            include("menu/menu_pendaftaran.php");
            break;
        case "2" :
            include("menu/menu_pembayaran.php");
            break;
        case "4" :
            include("menu/menu_vk.php");
            break;
        case "5" :
            include("menu/menu_laboratorium.php");
            break;
        case "6" :
            include("menu/menu_radiologi.php");
            break;
        case "7" :
            include("menu/menu_gudang.php");
            break;
        case "8" :
            include("menu/menu_logistik.php");
            break;
        case "9" :
            include("menu/menu_apotek.php");
            break;
        case "10" :
            include("menu/menu_roles_10.php");
            break;
        case "11" :
            include("menu/menu_perina_ranap.php");
            break;
        case "12" :
            include("menu/menu_rekam_medik.php");
            break;
        case "13" :
            include("menu/menu_jamkesmas.php");
            break;
        case "15" :
            include("menu/menu_gizi.php");
            break;
        case "16" :
            include("menu/menu_eksekutif.php");
            break;
        case "17" :
            include("menu/menu_admission.php");
            break;
        case "19" :
            include("menu/menu_kamar_operasi.php");
            break;
        case "22" :
            include("menu/menu_askes.php");
            break;
        case "23" ;
            include("menu/menu_keuangan.php");
            break;
        case "24" :
            include("menu/menu_jaspel.php");
            break;
        case "26" :
            include("menu/menu_rajal.php");
            break;
        case "27" :
            include("menu/menu_keperawatan.php");
            break;
        case "28" :
            include("menu/menu_fisioterapi.php");
            break;
        case "100" :
            include("menu/menu_pendaftaran.php");
            break;
        case "200" :
            include("menu/menu_pa.php");
            break;
		case "201" :
            include("menu/menu_bank_darah.php");
            break;
        case "1017" :
            include("menu/menu_adm.php");
            break;

    } // Akhir dari menu

