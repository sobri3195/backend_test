<?php
///**
// * Created by PhpStorm.
// * User: Fernalia
// * Date: 11/01/2016
// * Time: 10:09
// */
//
include "include/connect.php";
include "include/function.php";

$sql_nourut = "SELECT NOLAB FROM t_orderlab ORDER BY IDXORDERLAB DESC LIMIT 1";
	$get_nourut = mysql_query($sql_nourut);
	if(mysql_num_rows($get_nourut) > 0){
	     $dat_nourut = mysql_fetch_assoc($get_nourut);
		 $no_last    = $dat_nourut['NOLAB'] + 1;
		 $nourut     = sprintf("%08d", $no_last);
	}else{
	     $nourut     = sprintf("%08d", 1);
	}
	echo $nourut;
//datediff3("2016-04-22", "1990-03-03");
//
//$sql    = mysql_query("SELECT * FROM m_tarif2012 WHERE kode_gruptindakan LIKE '01.02.4%'");
//while($data = mysql_fetch_array($sql)){
//    $kdtindakan     = $data['kode_tindakan'];
//    $jpelayanan     = $data['jasa_pelayanan'];
//    $tarif          = $data['tarif'];
//    $persen         = 10/100;
//    $jsarana        = $tarif * $persen;
//    $jpelayanan     = $tarif;
//    $tarif          = $tarif + $jsarana;
//
//    mysql_query("UPDATE m_tarif2012 SET jasa_sarana=".$jsarana.",
//                                        jasa_pelayanan=".$jpelayanan.",
//                                        tarif=".$tarif."
//                                    WHERE kode_tindakan='".$kdtindakan."'");
//}
//echo "sukses";

//    $fdbf = fopen('F:/0/DATABOAT.DBF','r');
//    $fields = array();
//    $buf = fread($fdbf,32);
//    $header=unpack( "VRecordCount/vFirstRecord/vRecordLength", substr($buf,4,8));
//    echo 'Header: '.json_encode($header).'<br/>';
//    $goon = true;
//    $unpackString='';
//    while ($goon && !feof($fdbf)) { // read fields:
//        $buf = fread($fdbf,32);
//        if (substr($buf,0,1)==chr(13)) {$goon=false;} // end of field list
//        else {
//            $field=unpack( "a11fieldname/A1fieldtype/Voffset/Cfieldlen/Cfielddec", substr($buf,0,18));
//            echo 'Field: '.json_encode($field).'<br/>';
//            $unpackString.="A$field[fieldlen]$field[fieldname]/";
//            array_push($fields, $field);}}
//    fseek($fdbf, $header['FirstRecord']+1); // move back to the start of the first record (after the field definitions)
//    for ($i=1; $i<=$header['RecordCount']; $i++) {
//        $buf = fread($fdbf,$header['RecordLength']);
//        $record=unpack($unpackString,$buf);
//        echo 'record: '.json_encode($record).'<br/>';
//        echo $i.$buf.'<br/>';} //raw record
//    fclose($fdbf);

    /*$replace = str_replace("-", "", "2016-04-22 ");
    $replace = str_replace(" ", "", $replace);
    $replace = $replace . "000000";
    echo $replace;*/
?>