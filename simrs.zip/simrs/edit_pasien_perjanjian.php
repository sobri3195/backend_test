<?php
	include "include/connect.php";
	
	$nomr = $_REQUEST['nomr'];
	$idx  = $_REQUEST['idx'];
	
	$sql = "SELECT t_pendaftaran.IDXDAFTAR,
				   t_pendaftaran.TGLREG,
				   t_pendaftaran.NOMR,
				   m_pasien.NAMA,
				   t_pendaftaran.KDPOLY,
				   m_poly.nama AS poli,
				   t_pendaftaran.KDDOKTER,
				   m_dokter.NAMADOKTER,
				   t_pendaftaran.tgl_kontrol,
				   m_pasien.NOTELP
			FROM t_pendaftaran
			JOIN m_pasien ON m_pasien.NOMR = t_pendaftaran.NOMR
			JOIN m_poly ON m_poly.kode = t_pendaftaran.KDPOLY
			JOIN m_dokter ON m_dokter.KDDOKTER = t_pendaftaran.KDDOKTER
			WHERE t_pendaftaran.IDXDAFTAR = '".$idx."'
			  AND t_pendaftaran.NOMR = '".$nomr."'";
	
	$rs  = mysql_query($sql);
	$row = mysql_fetch_array($rs);
?>
 <div align="justify">
    <div id="frame">
        <div id="frame_title"><h3>EDIT PASIEN PERJANJIAN</h3></div>
		<div style="padding:20px;">
			<fieldset style="padding:20px;">
				<form name="myform" id="myform">
					<table>
						<tr>
							<td width="150px">
								<label>NOMR</label>
							</td>
							<td>
								<?= $nomr; ?>
								<input type="hidden" name="idxdaftar" value="<?= $idx; ?>"/>
								<input type="hidden" name="nomr" value="<?= $nomr; ?>"/>
							</td>
						</tr>
						<tr>
							<td>
								<label>NAMA</label>
							</td>
							<td>
								<?= $row['NAMA']; ?>
							</td>
						</tr>
						<tr>
							<td>
								<label>TGL Registrasi</label>
							</td>
							<td>
								<?= $row['TGLREG']; ?>
							</td>
						</tr>
						<tr>
							<td>
								<label>Poli</label>
							</td>
							<td>
								<?= $row['poli']; ?>
							</td>
						</tr>
						<tr>
							<td>
								<label>Dokter</label>
							</td>
							<td>
								<?= $row['NAMADOKTER']; ?>
							</td>
						</tr>
						<tr>
							<td>
								<label>No TELP</label>
							</td>
							<td>
								<input type="text" class="text" id="no_telp" name="no_telp" value="<?= $row['NOTELP']; ?>"/>
							</td>
						</tr>
						<tr>
							<td>
								<label>TGL Kontrol</label>
							</td>
							<td>
								<input type="text" class="text datepicker" id="tgl_kontrol" name="tgl_kontrol" value="<?= $row['tgl_kontrol']; ?>" readonly/>
							</td>
							<td>
								<input type="button" class="text" id="btn_simpan" value="S i m p a n"/>
							</td>
						</tr>
					</table>
				</form>
			</fieldset>
		</div>
	</div>
</div>

<script>
	jQuery(document).ready(function(){
		jQuery('#btn_simpan').click(function(){
			jQuery.ajax({
				url: "models/edit_pasien_perjanjian_by_idx_and_nomr.php",
				method: "post",
				data: jQuery('#myform').serialize(),
				success: function(data){
					window.location="<?= _BASE_ ?>index.php?link=22_1";
				}
			});
		});
	});
</script>