<?
include("signature.php");
include('include/connect.php');


if ($_POST) {
	extract($_POST);
	if($reqdata == "sep"){
		$tgl=date("Y-m-d H:i:s");
		$scml.="
		<request>";
		 $scml.="<data>";
		  $scml.="<t_sep>";
		   $scml.="<noKartu>$nopeserta</noKartu>
		   <tglSep>$tgl</tglSep>
		   <tglRujukan>$tgl</tglRujukan>
		   <noRujukan>$norujukan</noRujukan>
		   <ppkRujukan>$noppk</ppkRujukan>
		   <ppkPelayanan>0133R018</ppkPelayanan>
		   <jnsPelayanan>2</jnsPelayanan>
		   <catatan>$catatan</catatan>
		   <diagAwal>$diagnosa</diagAwal>
		   <poliTujuan>$politujuan</poliTujuan>
		   <klsRawat>$klsrawat</klsRawat>
		   <user>$user</user>
		   <noMr>$nomr</noMr>";
		  $scml.="</t_sep>";
		 $scml.="</data>";
		$scml.="</request>
		";
		$url= "http://192.168.0.228:8082/SepLokalRest/sep/";
		$process = curl_init($url); 
		curl_setopt($process, CURLOPT_HTTPHEADER,
				array("Content-Type: application/xml\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($process, CURLOPT_HEADER, false); 
		curl_setopt($process, CURLOPT_TIMEOUT, 30); 
		curl_setopt($process, CURLOPT_POST, true); 
		curl_setopt($process, CURLOPT_POSTFIELDS, $scml); 
		curl_setopt($process, CURLOPT_RETURNTRANSFER, TRUE); 
		$return = curl_exec($process); 
		curl_close($process);
		$response = json_decode($return, true);
		$no_sep=$response[response];
		echo $no_sep;
	} 
	
	if($reqdata == "sep_testing"){
		$tgl=date("Y-m-d H:i:s");
		$scml='
        {
            "request":
				{
					"t_sep":
						{
							"noKartu":"'.$nopeserta.'",
							"tglSep":"'.$tgl.'",
							"tglRujukan":"'.$tgl.'",
							"noRujukan":"'.$norujukan.'",
							"ppkRujukan":"'.$noppk.'",
							"ppkPelayanan":"0133R018",
							"jnsPelayanan":"2",
							"catatan":"'.$catatan.'",
							"diagAwal":"'.$diagnosa.'",
							"poliTujuan":"'.$politujuan.'",
							"klsRawat":"'.$klsrawat.'",
							"lakaLantas":"2",
							"lokasiLaka":"",
							"user":"'.$user.'",
							"noMr":"'.$nomr.'" 
						}
				}
        }';
        $url= "http://192.168.0.228:8082/wslokalrest/SEP/insert";
        $process = curl_init($url); 
        curl_setopt($process, CURLOPT_HTTPHEADER,
                array("Content-Type: Application/x-www-form-urlencoded\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
        curl_setopt($process, CURLOPT_HEADER, false); 
        curl_setopt($process, CURLOPT_TIMEOUT, 30); 
        curl_setopt($process, CURLOPT_POST, true); 
        curl_setopt($process, CURLOPT_POSTFIELDS, $scml); 
        curl_setopt($process, CURLOPT_RETURNTRANSFER, TRUE); 
        $return = curl_exec($process); 
        curl_close($process);
        $response = json_decode($return, true);
		if($response[metadata][code] == "200"){
			$return=$response[response];
		} else{
			$return=$response[metadata][message];
		}
        
        echo $return;
	} 
	
	if($reqdata == "peserta_by_nokartu"){
		$tgl	= date("Y-m-d H:i:s");

		$ip		= "http://192.168.0.228:8082/wslokalrest/Peserta/Peserta";
		$nilai1 = $nopeserta;
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);

		$json_response = curl_exec($curl);

		curl_close($curl);

		$response = json_decode($json_response, true);
		$rest=$response[metaData]['message']; 
		echo $json_response;
	} 
	
	if($reqdata == "rujukan_by_nopeserta_from_pcare"){
		$tgl	= date("Y-m-d H:i:s");

		$ip		= "http://192.168.0.228:8082/wslokalrest/Rujukan/Peserta/";
		$nilai1 = $nopeserta;
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);

		$json_response = curl_exec($curl);

		curl_close($curl);

		$response = json_decode($json_response, true);
		$rest=$response[metaData]['message']; 
		echo $json_response;
	} 
	
	if($reqdata == "rujukan_by_nopeserta_from_rs"){
		$tgl	= date("Y-m-d H:i:s");

		$ip		= "http://192.168.0.228:8082/wslokalrest/Rujukan/RS/Peserta/";
		$nilai1 = $nopeserta;
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);

		$json_response = curl_exec($curl);

		curl_close($curl);

		$response = json_decode($json_response, true);
		$rest=$response[metaData]['message']; 
		echo $json_response;
	} 
	
	if($reqdata == "norujukan"){
		$tgl=date("Y-m-d H:i:s");

		$ip= "http://192.168.0.228:8082/SepLokalRest/rujukan/";
		$nilai1=$norujuk;
		$url= "".$ip."/$nilai1";
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);
		#curl_setopt($curl, CURLOPT_POSTFIELDS, $content);

		$json_response = curl_exec($curl);

		#$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

		curl_close($curl);

		$response = json_decode($json_response, true);
		$rest=$response[metaData]['message']; 
		if($rest==200){
		$diagnosa=$response[response]['item']['diagnosa']['kdDiag'];
		echo $diagnosa;
		}
		else{
		echo "error";
		}
	}
	
	/*
	** Testing V-claim V.1.0
	**/
	if($reqdata == "sep_testing_vclaim_old"){
		$tgl=date("Y-m-d");
		$scml = '
		{
           "request": {
              "t_sep": {
                 "noKartu": "'.$nopeserta.'",
                 "tglSep": "'.$tgl.'",
                 "ppkPelayanan": "0133R018",
                 "jnsPelayanan": "2",
                 "klsRawat": "'.$klsrawat.'",
                 "noMR": "'.$nomr.'",
                 "rujukan": {
                    "asalRujukan": "1",
                    "tglRujukan": "'.$tgl.'",
                    "noRujukan": "'.$norujukan.'",
                    "ppkRujukan": "'.$noppk.'"
                 },
                 "catatan": "test",
                 "diagAwal": "'.$diagnosa.'",
                 "poli": {
                    "tujuan": "'.$politujuan.'",
                    "eksekutif": "0"
                 },
                 "cob": {
                    "cob": "0"
                 },
                 "jaminan": {
                    "lakaLantas": "0",
                    "penjamin": "",
                    "lokasiLaka": ""
                 },
                 "noTelp": "'.$notelp.'",
                 "user": "'.$user.'"
              }
           }
        }';
        $url= "http://api.bpjs-kesehatan.go.id:8080/vclaim-rest/SEP/insert";
        $process = curl_init($url); 
        curl_setopt($process, CURLOPT_HTTPHEADER,
                array("Content-Type: Application/x-www-form-urlencoded\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
        curl_setopt($process, CURLOPT_HEADER, false); 
        curl_setopt($process, CURLOPT_TIMEOUT, 300); 
        curl_setopt($process, CURLOPT_POST, true); 
        curl_setopt($process, CURLOPT_POSTFIELDS, $scml); 
        curl_setopt($process, CURLOPT_RETURNTRANSFER, TRUE); 
        $return = curl_exec($process); 
        curl_close($process);
        $response = json_decode($return, true);
		if($response['metaData']['code'] == "200"){
			$message = $response['response']['sep']['noSep'];
		} else{
			$message = $response['metaData']['message'];
		}
        
        echo $message;
	} 
	
	if($reqdata == "peserta_by_nokartu_testing_vclaim_old"){
		$tgl	= date("Y-m-d");

		$ip		= "http://api.bpjs-kesehatan.go.id:8080/vclaim-rest/Peserta/nokartu/";
		$nilai1 = $nopeserta;
		$url	= "".$ip."{$nilai1}/tglSEP/{$tgl}";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_HTTPGET, true);

		$json_response = curl_exec($curl);

		curl_close($curl);
		echo $json_response;
	}
	
	if($reqdata == "rujukan_by_nopeserta_from_pcare_testing_vclaim_old"){
		$ip		= "http://api.bpjs-kesehatan.go.id:8080/vclaim-rest/Rujukan/Peserta";
		$nilai1 = $nopeserta;
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);

		$json_response = curl_exec($curl);

		curl_close($curl);
		echo $json_response;
	}
	
	if($reqdata == "rujukan_by_nopeserta_from_rs_vclaim_old"){
		$ip		= "http://api.bpjs-kesehatan.go.id:8080/vclaim-rest/Rujukan/RS/Peserta/";
		$nilai1 = $nopeserta;
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);

		$json_response = curl_exec($curl);

		curl_close($curl);
		echo $json_response;
	} 
	
	/*
	** Testing V-claim V.1.1
	**/
//	$host = 'https://dvlp.bpjs-kesehatan.go.id/vclaim-rest/';
	$host = 'https://new-api.bpjs-kesehatan.go.id:8080/new-vclaim-rest/';
	if($reqdata == "sep_testing_vclaim"){
		$tgl=date("Y-m-d");
        $scml = '  {
           "request": {
              "t_sep": {
                 "noKartu": "'. $nopeserta .'",
                 "tglSep": "'. $tgl .'",
                 "ppkPelayanan": "0133R018",
                 "jnsPelayanan": "2",
                 "klsRawat": "'. $klsrawat .'",
                 "noMR": "'. $nomr .'",
                 "rujukan": {
                    "asalRujukan": "'. $id_rujukan_bpjs .'",
                    "tglRujukan": "'. $tglrujuk .'",
                    "noRujukan": "'. $norujukan .'",
                    "ppkRujukan": "'. $noppk .'"
                 },
                 "catatan": "-",
                 "diagAwal": "'.$diagnosa.'",
                 "poli": {
                    "tujuan": "'.$politujuan.'",
                    "eksekutif": "0"
                 },
                 "cob": {
                    "cob": "0"
                 },
                 "katarak": {
                    "katarak": "0"
                 },
                 "jaminan": {
                    "lakaLantas": "0",
                    "penjamin": {
                        "penjamin": "",
                        "tglKejadian": "",
                        "keterangan": "",
                        "suplesi": {
                            "suplesi": "0",
                            "noSepSuplesi": "",
                            "lokasiLaka": {
                                "kdPropinsi": "",
                                "kdKabupaten": "",
                                "kdKecamatan": ""
                                }
                        }
                    }
                 },
                 "skdp": {
                    "noSurat": "'. $no_surat_kontrol .'",
                    "kodeDPJP": "'. $id_dokter_bpjs .'"
                 },
                 "noTelp": "'. $notelp .'",
                 "user": "'. $user .'"
              }
           }
        }       ';
		

        $url= $host."SEP/1.1/insert";
		
        $process = curl_init($url); 
        curl_setopt($process, CURLOPT_HTTPHEADER,
                array("Content-Type: Application/x-www-form-urlencoded\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
        curl_setopt($process, CURLOPT_HEADER, false); 
        curl_setopt($process, CURLOPT_TIMEOUT, 300); 
        curl_setopt($process, CURLOPT_POST, true); 
        curl_setopt($process, CURLOPT_POSTFIELDS, $scml); 
        curl_setopt($process, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($process, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($process, CURLOPT_SSL_VERIFYPEER, 0);
        $return = curl_exec($process); 
        curl_close($process);
        $response = json_decode($return, true);
		if($response['metaData']['code'] == "200"){
			$message = $response['response']['sep']['noSep'];
		} else{
			$message = $response['metaData']['message'];
		}
        
        echo $message;
	} 
	
	if($reqdata == "peserta_by_nokartu_testing_vclaim"){
		$tgl	= date("Y-m-d");

		$ip		= $host."Peserta/nokartu/";
		$nilai1 = $nopeserta;
		$url	= "".$ip."{$nilai1}/tglSEP/{$tgl}";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_HTTPGET, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

		$json_response = curl_exec($curl);

		curl_close($curl);
		echo $json_response;
	}
	
	//CUNDA: Pencarian data pasien berdasarkan nomor rujukan - PCARE
	if($reqdata == "pasien_by_norujukan_from_pcare"){
		$ip		= $host."Rujukan/";
		$nilai1 = $norujukan;
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

		$json_response = curl_exec($curl);

		curl_close($curl);
		echo $json_response;
	}
	
	//CUNDA: Pencarian data pasien berdasarkan nomor rujukan - RS
	if($reqdata == "pasien_by_norujukan_from_rs"){
		$ip		= $host."Rujukan/RS/";
		$nilai1 = $norujukan;
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

		$json_response = curl_exec($curl);

		curl_close($curl);
		echo $json_response;
	}
	
	if($reqdata == "rujukan_by_nopeserta_from_pcare_testing_vclaim"){
		$ip		= $host."Rujukan/Peserta";
		$nilai1 = $nopeserta;
		
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

		$json_response = curl_exec($curl);

		curl_close($curl);
		echo $json_response;
	}
	
	if($reqdata == "rujukan_by_nopeserta_from_rs_vclaim"){
		$ip		= $host."Rujukan/RS/Peserta/";
		$nilai1 = $nopeserta;
		$url	= "".$ip."/$nilai1";
		$curl 	= curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
		curl_setopt($curl, CURLOPT_GET, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

		$json_response = curl_exec($curl);

		curl_close($curl);
		echo $json_response;
	}

    if($reqdata == "refrensi_dokter_dpjp"){
        $tgl	= date("Y-m-d");

        $q      = $nopeserta;
        $ip		= $host."referensi/dokter/pelayanan/1/tglPelayanan/{$tgl}/Spesialis/{$q}";
        $curl 	= curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER,
            array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
        curl_setopt($curl, CURLOPT_HTTPGET, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

        $json_response = curl_exec($curl);

        curl_close($curl);
        echo $json_response;
    }

    if($reqdata == "refrensi_faskes"){
        $method  = "referensi/faskes/";

        $url	 = $host.$method.$q.'/'.$jenis_pelayanan;

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER,
            array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
        curl_setopt($curl, CURLOPT_HTTPGET, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

        $json_response = curl_exec($curl);

        curl_close($curl);

        echo $json_response;
    }
}
?>