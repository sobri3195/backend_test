 <?php
	session_start();
    include("include/connect.php");
	
	$start = "";
    if(!empty($_GET['start'])) {
        $start = $_GET['start'];
    }
    else{
        $start = date('Y-m-d');
    }
	
	$end = "";
    if(!empty($_GET['end'])) {
        $end = $_GET['end'];
    }
    else{
        $end = date('Y-m-d');
    }
 ?>
 
 <div align="center">
    <div id="frame">
        <div id="frame_title"><h3>LIST PASIEN PERJANJIAN</h3></div>
        <div align="right" style="margin:5px;">
			<form name="formsearch" method="get" style="padding:20px;">
				Tanggal 
				<input type="text" name="start" id="start" readonly="readonly" class="text datepicker" value="<?= $start; ?>" style="width:100px;"/>
				s/d
				<input type="text" name="end" id="end" readonly="readonly" class="text datepicker" value="<?= $end; ?>" style="width:100px;"/>
				<input type="hidden" name="link" value="22_1" />
				<input type="submit" value=" C a r i " class="text"/>
			</form>
		
			<?php
				$query = "SELECT DISTINCT v_list_perjanjian.*, t_pendaftaran.TGLREG
						  FROM v_list_perjanjian
						  LEFT JOIN t_pendaftaran ON t_pendaftaran.NOMR = v_list_perjanjian.NOMR
							AND t_pendaftaran.TGLREG = v_list_perjanjian.TGL_BOOKING
						  WHERE v_list_perjanjian.TGL_BOOKING BETWEEN '{$start}' AND '{$end}'
							AND v_list_perjanjian.IS_BATAL_KONTROL = 0
						  ORDER BY v_list_perjanjian.DOKTER ASC, 
							v_list_perjanjian.TGL_BOOKING ASC, 
							v_list_perjanjian.JAM_BOOKING ASC ;";
				$rs = mysql_query($query);
			?>
			
			<div align="center">
                <form name="formprint" method="post" action="report/pendaftaran/list_pasien_perjanjian_excel.php" target="_blank" >
                    <input type="hidden" name="query" value="<?= $query; ?>" />
                    <input type="hidden" name="header" value="LIST PASIEN PERJANJIAN" />
                    <input type="hidden" name="filename" value="list_pasien_perjanjian" />
                    <button id="export">Export Excel</button>
                </form>
            </div>
			
            <br/>
            <div id="table_search">
                <table id="table">
                    <thead>
                    <tr>
                        <th>NO </th>
                        <th>POLI</th>
                        <th>DOKTER</th>
                        <th>NAMA</th>
                        <th>RM</th>
                        <th>JAMINAN</th>
						<th>TELP</th>
                        <th>TGL KUNJUNGAN</th>
                        <th>TGL BOOKING</th>
                        <th>NO SURAT KONTROL</th>
                        <th>AKSI</th>
                    </tr>
                    </thead>
                    <tbody>
						<?php 
							$i = 1; 
							while($row = mysql_fetch_array($rs)){ 
							$sql = "SELECT COUNT(*) AS jml 
									FROM ri_pendaftaran 
									WHERE no_mr = '".$row['NOMR']."'
									  AND is_pulang = 0 
									  AND is_batal = 0";
							$rs_inap  = mysql_query($sql);
							$row_inap = mysql_fetch_array($rs_inap);
						?>
							<tr <?= $row['TGLREG'] != '' ? 'style="background-color: #8BC34A;"' : ''; ?>>
								<td><?= $i++; ?></td>
								<td><?= $row['POLI']; ?></td>
								<td><?= $row['DOKTER']; ?></td>
								<td><?= $row['NAMA']; ?></td>
								<td>
									<?php
										if($row_inap['jml'] == 0){
									?>
										<a href="<?= _BASE_ ?>index.php?link=2&rm=<?= $row['RM']; ?>&poli=<?= $row['KDPOLY']; ?>&dokter=<?= $row['KDDOKTER']; ?>&no_surat_kontrol=<?= $row['no_surat_kontrol']; ?>"><?= $row['RM']; ?></a>
									<?php
										} else{
											echo $row['RM'];
										}
									?>
									</td>
                                <td><?= $row['JAMINAN']; ?></td>
								<td><?= $row['NOTELP']; ?></td>
								<td><?= detailTgl($row['TGL_KUNJUNGAN']); ?></td>
								<td><?= detailTgl($row['TGL_BOOKING']); ?></td>
								<td><?= $row['no_surat_kontrol']; ?></td>
								<td>
									<?php
										if($row_inap['jml'] == 0){
									?>
									<button class="text btn_edit_perjanjian" idxdaftar="<?= $row['IDXDAFTAR']; ?>" nomr="<?= $row['NOMR']; ?>">Edit</button>
									<button class="text btn_batal" idxdaftar="<?= $row['IDXDAFTAR']; ?>" nomr="<?= $row['NOMR']; ?>">Batal</button>
									<?php
										} else{
											echo "<b>PASIEN TERDAFTAR DI IGD/RAWAT INAP</b>";
										}
									?>
								</td>
							</tr>
						<?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <br />
</div>

<div id="dialog-form" >
    <form method="post">
        <fieldset>
			Apakah anda yakin akan membatalkan transaksi ini? <br/><br/>
			<input type="hidden" id="idxdaftar_batal"/>
			<input type="hidden" id="nomr_batal"/>
			<button class="text" id="btn_batal_yes">Batalkan</button>
        </fieldset>
    </form>
</div>

<script>
	jQuery("#table").dataTable({
        "paging": false
    });
	
	jQuery(".btn_edit_perjanjian").click(function(){
		var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
		
		window.location = "?link=22_2&nomr=" + nomr + "&idx=" + idxdaftar;
	});
	
	jQuery(".btn_batal").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
		
		jQuery('#idxdaftar_batal').val(idxdaftar);
		jQuery('#nomr_batal').val(nomr);
  
		jQuery("#dialog-form").dialog("open");
    });
	
	jQuery("#btn_batal_yes").click(function(){
		var idxdaftar = jQuery('#idxdaftar_batal').val();
		var nomr 	  = jQuery('#nomr_batal').val();
		
		jQuery.ajax({
            url: "models/pembatalan_pasien_perjanjian.php",
            method: "post",
            data: {idxdaftar:idxdaftar,nomr:nomr},
            success: function(data){
                alert("Pasien sudah dibatalkan");
                location.reload();
            },
            error: function(jqXHR, textStatus, errorThrown){
                alert("Perubahan tidak gagal dilakukan!");
            }
        });
	});
	
	jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 200,
        width: 700,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        close: function() {
            jQuery("#dialog-form").dialog('destroy');
        }
    });
	
	function show(){
        var Digital=new Date();
        var hours=Digital.getHours();
        var minutes=Digital.getMinutes();
        var seconds=Digital.getSeconds();
        var curTime =
            ((hours < 10) ? "0" : "") + hours + ":"
            + ((minutes < 10) ? "0" : "") + minutes + ":"
            + ((seconds < 10) ? "0" : "") + seconds;
        var dn="AM";

        if (hours>12){
            dn="PM";
            hours=hours-12
        }
        if (hours==0)
            hours=12;
        if (minutes<=9)
            minutes="0"+minutes;
        if (seconds<=9)
            seconds="0"+seconds;
		jQuery(".status_kembali").val(curTime);
        setTimeout("show()",1000)
    }
    show();
    //-->
    <!-- hide; from; old; browsers;
    var curDateTime = new Date();
    var curHour = curDateTime.getHours();
    var curMin = curDateTime.getMinutes();
    var curSec = curDateTime.getSeconds();
    var curTime =
        ((curHour < 10) ? "0" : "") + curHour + ":"
        + ((curMin < 10) ? "0" : "") + curMin + ":"
        + ((curSec < 10) ? "0" : "") + curSec;
    //-->
</script>