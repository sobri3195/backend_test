<script src="include/date-functions.js" type="text/javascript"></script>
<script src="include/datechooser.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="include/datechooser.css"/>
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
<tr><td width="24%" valign="top"></td><td width="46%">
          	<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
				<form  method="get" name="cariNama" >
                <input type="hidden" name="link" value="2f" />
			<tr>
      			<td colspan="3" background="img/frame_title.png" bgcolor="#FFFFFF">
                <div align="center"><strong><font color="#FFFFFF">Cari Berdasarkan Nama atau Nomor peserta</font></strong></div></td>
    		</tr>
    		<tr>
      			<td width="34%">&nbsp;</td>
      			<td width="3%">&nbsp;</td>
      			<td width="63%">&nbsp;</td>
    		</tr>
    		<tr>
      			<td>Asuransi</td>
      			<td>:</td>
      			<td>
      				
      				<!-- added september 2015 -->
	                <select name="asuransi" id="asuransi" class="select2">
	                	<?php 
	                		$crbayar = getCaraBayarEx1();
	                		while($datacrbayar = mysql_fetch_array($crbayar)){ 
	                	?>
	                		<option value="<?php echo $datacrbayar['KODE']; ?>"><?php echo $datacrbayar['NAMA']; ?></option>
	                	<?php 
	                		}
	                	?>
	                </select>
	            </td>
    		</tr>
    		<tr>
          		<td>Nama</td>
      			<td>:</td>
      			<td ><input type="text" name="nama" id="nama" value="<?=$_GET['nama']?>"></td>
    		</tr>
    		<!--<tr>
      			<td >Nomor Peserta</td>
      			<td>:</td>
      			<td><input id="nopeserta" name="nopeserta" type="text" value="<?=$_GET['nopeserta']?>"></td>
          	</tr>
    		<tr>
      			<td >Alamat</td>
      			<td>:</td>
      			<td><input id="alamat" name="alamat" type="text" value="<?=$_GET['alamat']?>"></td>
          	</tr>-->           
    		<tr>
      			<td>&nbsp;</td>
      			<td>&nbsp;</td>
      			<td><input type="submit" name="button" id="button" value="cari" /></td>
    		</tr>
    		<tr>
      			<td colspan="3" background="img/bg_menu_master.png" height="64"></td>
      		</tr>
				</form>   
		</table>
    
    </td>
    <td width="30%" valign="top">   
        </td>
  </tr>
</table>
<br /><br />
<table class="table">
	<thead>
		<tr>
			<th>Nomor Medrek</th>
			<!--<th>Nomor Peserta</th>-->
			<th>Nama Lengkap</th>
			<th>Jenis Kelamin</th>
			<th>Tanggal Lahir</th>
			<th>Alamat</th>
		</tr>
	</thead>
	<tbody>
		<?php 
			$asuransi	= $_GET['asuransi'];
			$nama 		= $_GET['nama'];
			//$no 		= $_GET['nopeserta'];

			if($asuransi != '' || $nama != '' || $no != ''){
				$pasien	= getPasienAusransi($asuransi, $nama);
				while($dtapasien = mysql_fetch_array($pasien)){
		?>
				<tr>
					<td>
						<?php echo $dtapasien['NOMR']; ?>
					</td>
					<!--<td></td>-->
					<td>
						<?php echo $dtapasien['NAMA']; ?>
					</td>
					<td>
						<?php echo $dtapasien['JENISKELAMIN']; ?>
					</td>
					<td>
						<?php echo $dtapasien['TEMPAT'].", ".$dtapasien['TGLLAHIR']; ?>
					</td>
					<td>
						<?php echo $dtapasien['ALAMAT']; ?>	
					</td>
				</tr>
		<?php 
				}
			}
		?>
	</tbody>
</table>
<br /><br />
<?php 
 //include("daftarCariAsuransi.php");
?>
<script type="text/javascript">
	jQuery(".select2").select2();
	jQuery(".table").dataTable();
</script>
