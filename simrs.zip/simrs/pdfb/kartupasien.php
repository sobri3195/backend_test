<?php
error_reporting (E_ALL);
ini_set('display_errors', 1);
include('phpqrcode/qrlib.php');

extract($_GET);

// how to save PNG codes to server
$codeContents = $_GET['NOMR'];
$directory = 'qrcode_pasien/';
$fileName = $codeContents.'.png';
$pngAbsoluteFilePath = $directory.$fileName;
$urlRelativeFilePath = $pngAbsoluteFilePath;

// generating
if (!file_exists($pngAbsoluteFilePath)) {
    QRcode::png($codeContents, $pngAbsoluteFilePath);
}
$nomor_kartu = $_GET['NOMR'];
$jml = strlen($nomor_kartu);
$j = 0;
$new_no = '';
//echo $jml;

for($i=1; $i<=$jml; $i++){
    if($i == $jml){
        $new_no = $new_no.substr($nomor_kartu, $j , 2) ;
    }
    else if(($i % 2) == 0 && $i != $jml){
        $new_no = $new_no.substr($nomor_kartu, $j , 2) . "-";
        $j = $j + 2;
    }
}

echo '<body>';
echo '<br/>';
echo '<br/>';
echo '<br/>';
echo '<div style="width:330px;">';
echo '<center>';
echo '<font style="font-family:calibri;font-size:22pt;"><b>'.$new_no.'</b></font><br/>';
echo '<font style="font-family:calibri;font-size:12pt;">'.strtoupper($_GET['NAMA']).'</font>';
echo '</center>';
echo '</div>';
// displaying 
echo '<img src="'.$urlRelativeFilePath.'" width="75px" />';

echo '</body>';
?>

<script>
    window.print();
</script>