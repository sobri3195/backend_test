<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 30/12/2015
 * Time: 13:30
 */

    include 'include/connect.php';
    include 'include/function.php';
?>
<html>
    <head>
    </head>
    <body>
        <div id="popup-windows">
            <form id="form-popup">
                <input type="hidden" name="aps" id="aps" value="<?php echo $_REQUEST['aps'];?>" />
                <input type="hidden" name="nomr" id="nomr" value="<?php echo $_REQUEST['nomr'];?>" />
                <input type="hidden" name="idxdaftar" id="idxdaftar" value="<?php echo $_REQUEST['idx'];?>" />
                <input type="hidden" name="carabayar" id="carabayar" value="<?php echo $_REQUEST['carabayar'];?>" />
                <input type="hidden" name="poly" id="poly" value="<?php echo $_REQUEST['poly'];?>" />
                <input type="hidden" name="retribusi" id="retribusi" value="<?php echo $_REQUEST['retribusi'];?>" />
                <h3>
                    <?php
                    echo 'Daftar Alat Kesehatan';
                    ?>
                </h3>
                <?php if(isset($_REQUEST['nip'])){ ?>
                <input type="hidden" id="nip" value="<?= $_REQUEST['nip']; ?>">
                <?php } else{ ?>
                <input type="hidden" id="nip" value="">
                <?php } ?>
                <label id="label_keterangan" style="color: #FF0000">*Untuk koma menggunakan titik (.)</label><br/>
                <?php
                mysql_query('delete from tmp_cartbayar where IP ="'.getRealIpAddr().'"');
                $sql5       = mysql_query("SELECT kode_amprah FROM m_login WHERE KDUNIT=".$_REQUEST['poly']);
                $data5      = mysql_fetch_array($sql5);
                $kd_amprah  = $data5['kode_amprah'];

                $sql 	= mysql_query('SELECT a.*, b.* FROM m_far_barang_unit AS a
                                    INNER JOIN m_barang AS b ON a.kode_barang = b.kode_barang
                                    WHERE kode_amprah='.$kd_amprah.' AND b.group_barang!=1');
                ?>
                <table width="600px" border="0" cellpadding="0" cellspacing="0" class="popup-table" id="table" style="float:left;" >
                    <thead>
                    <tr>
                        <th style="width:20px;">No</th>
                        <th>Jenis Tindakan</th>
                        <th style="width:120px;">Tarif</th>
                        <th>QTY</th>
                        <th style="width:70px;">Pilih</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    if(mysql_num_rows($sql) > 0):
                    $i = 1;

                    while($data = mysql_fetch_array($sql)){
                        $kode 	    = $data['kode_barang'];
                        $margin     = $data['margin_keuntungan'];
                        $sql3 	    = mysql_query("SELECT nama_barang, harga FROM m_barang WHERE kode_barang=".$kode);
                        $data3 	    = mysql_fetch_array($sql3);
                        $harga      = $data3['harga'];
                        $harga 	    = $harga + ($harga * ($margin/100));
                        $sql6       = mysql_query("SELECT saldo FROM t_barang_stok WHERE kode_barang=".$kode." ORDER BY kd_stok DESC");
                        $data6      = mysql_fetch_array($sql6);
                        $saldo      = mysql_num_rows($sql6) > 0 ? $data6['saldo'] : 0;
                        echo'
                        <tr>
                            <td style="widtd:20px;">'.$i.'</td>
                            <td>'.$data3['nama_barang'].'</td>
                            <td style="widtd:120px; text-align:right;">
                                Rp. '.curformat($harga).'
                                <input type="hidden" id="tarif_'.str_replace('.','_',$data['kode_barang']).'" value="'.$harga.'"/>
                            </td>
                            <td>
                                <input type="text" id="qty_'.str_replace('.','_',$data['kode_barang']).'" name="qty" style="text-alignment:right; width: 50px;" value="1" />
                            </td>
                            <td style="widtd:70px;"><input type="button" value="add" id="'.str_replace('.','_',$data['kode_barang']).'" svn="'.$_REQUEST['nomr'].'" kode="'.$data['kode_barang'].'" class="add" poly="'.$_REQUEST['poly'].'" saldo="'.$saldo.'"></td>
                        </tr>
                        ';
                        $i++;
                    }
                    ?>
                    </tbody>

                </table><?php
            else:
                echo 'Tidak ada Alkes';
            endif;
            ?>
                <div id="load_tmp_cartbayar" style="width:340px; float:right;">
                </div>
                <br clear="all">
            </form>
            <?php
            $sql4 	= mysql_query("SELECT KDDOKTER FROM t_pendaftaran WHERE NOMR='".$_REQUEST['nomr']."' AND IDXDAFTAR=".$_REQUEST['idx']);
            $data4 	= mysql_fetch_array($sql4);
            ?>
            <input type="hidden" id="dokter" value="<?php echo $data4['KDDOKTER']; ?>" />
        </div>
    </body>
</html>

<script type="text/javascript">
    // jQuery('#table').dataTable({
    //     "paging": false
    // });
</script>
<style type="text/css">
    #popup-windows {font-size:10px; font-family:Verdana,Geneva,sans-serif;}
    .popup-table{ border:1px solid #999; border-collapse:0px; border-spacing:0px;}
    .popup-table th{background:#069; padding:3px; font-size:11px; color:#FFF; font-weight:bold;}
    .popup-table td{padding:3px; font-size:11px;}
    .add, .batal, .simpan{cursor:pointer; border:1px solid #000; padding:2px 3px; background:#FF6; font-size:10px;}
    .popup-table tr.footer td{border-top:1px solid #666; font-weight:bold;}
    .selectbox{ font-size:10px;}
    .text { border:1px solid #000; font-size:11px;}
    .text:focus { background:#FF6;}
</style>
<body>
<script src="js/jquery-1.7.min.js" language="JavaScript" type="text/javascript"></script>
<script src="js/jqclock_201.js" language="JavaScript" type="text/javascript"></script>
<link type="text/css" rel="stylesheet" href="include/data-tables-1.10.9/css/dataTables.jqueryui.min.css"/>
<script src="include/data-tables-1.10.9/js/jquery.dataTables.min.js"></script>
<script src="include/data-tables-1.10.9/js/dataTables.jqueryui.min.js"></script>

<script type="text/javascript">
    jQuery.noConflict();
</script>
<script>
    jQuery(document).ready(function(){
        jQuery(".tab_content").hide(); //Hide all content
        jQuery("ul.tabs li:first").addClass("active").show(); //Activate first tab
        jQuery(".tab_content:first").show(); //Show first tab content
        //On Click Event
        jQuery("ul.tabs li").click(function() {
            jQuery("ul.tabs li").removeClass("active"); //Remove any "active" class
            jQuery(this).addClass("active"); //Add "active" class to selected tab
            jQuery(".tab_content").hide(); //Hide all tab content
            var activeTab = jQuery(this).find("span").attr("id"); //Find the rel attribute value to identify the active tab + content
            jQuery(activeTab).fadeIn(); //Fade in the active content
            return false;
        });

        jQuery('.add').click(function(){
            var id 		= jQuery(this).attr('id');
            var nomr	= jQuery(this).attr('svn');
            var kode	= 'RJ.01.00';
            var poly	= jQuery(this).attr('poly');
            var saldo   = jQuery(this).attr('saldo');
            var nip     = jQuery('#nip').val();
            var dokter	= jQuery('#dokter').val();
            var tarif 	= jQuery('#tarif_' + id).val();
            var qty     = jQuery('#qty_' + id).val();
            jQuery.post('<?php echo _BASE_;?>cartbill_save_tmp.php',{id:id,nomr:nomr,kode:kode,poly:poly,dokter:dokter,tarif:tarif,saldo:saldo,obat:1,qty:qty},function(data){
                jQuery('#load_tmp_cartbayar').load('<?php echo _BASE_;?>tmp_cartbayar.php?alkes=1&saldo='+saldo+'&nomr='+nomr+'&idx='+id+'&poly='+poly+'&dokter='+dokter+'&nip='+nip);
            });
        });
        jQuery('#load_tmp_cartbayar').load('<?php echo _BASE_;?>tmp_cartbayar.php');
    });
</script>
<style type="text/css">
    ul.tabs {margin: 0;padding: 0;float: left;list-style: none;height: 32px;border-bottom: 1px solid #999;border-left: 1px solid #999;width: 100%;}
    ul.tabs li {float: left;margin: 0;padding: 0 3px;height: 31px;line-height: 31px;border: 1px solid #999;border-left: none;margin-bottom: -1px;background: #e0e0e0;overflow: hidden;position: relative;}
    ul.tabs li:hover{ background:#FF9; display:block; cursor:pointer;}
    ul.tabs li a {text-decoration: none;color: #000;display: block;font-size: 10px;padding: 0 10px;border: 1px solid #fff;outline: none;}
    ul.tabs li a:hover {background: #ccc;}
    html ul.tabs li.active, html ul.tabs li.active a:hover  {background: #fff;border-bottom: 1px solid #fff;}
    .tab_container {border: 1px solid #999;	border-top: none;clear: both;float: left; width: 100%;background: #fff;	-moz-border-radius-bottomright: 5px;-khtml-border-radius-bottomright: 5px;	-webkit-border-bottom-right-radius: 5px;-moz-border-radius-bottomleft: 5px;	-khtml-border-radius-bottomleft: 5px;	-webkit-border-bottom-left-radius: 5px; padding-top:60px;}
    .tab_content {padding: 5px;font-size: 11px; text-align:left;}
</style>