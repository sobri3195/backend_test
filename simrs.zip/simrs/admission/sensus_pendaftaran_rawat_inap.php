<div align="center">
<div id="frame">
	<div id="frame_title"><h3>Sensus Pendaftaran Rawat Inap</h3></div>
	<div><h2>Sensus Pendaftaran Rawat Inap</h2></div>

<table width="95%" border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" class="tb">
	<tr align="center">
    	<th rowspan="3">No</th>
    	<th rowspan="3">No MR</th>
    	<th rowspan="3">NAMA PASIEN</th>
    	<th rowspan="3">ALAMAT</th>
    	<th colspan="2">UMUR</th>
    	<th colspan="3">CARA PENERIMAAN</th>
    	<th colspan="4">ASAL PASIEN</th>
    	<th rowspan="3">RUANG</th>
    	<th rowspan="3">KELAS</th>
    	<th colspan="4">CARA BAYAR</th>
   	  </tr>
    <tr align="center">
      <th rowspan="2">L</th>
      <th rowspan="2">P</th>
      <th rowspan="2">UGD</th>
      <th rowspan="2">POLI</th>
      <th rowspan="2">VK</th>
      <th rowspan="2">DATANG SENDIRI</th>
      <th colspan="3">RUJUKAN</th>
      <th rowspan="2">TUNAI</th>
      <th rowspan="2">ASKES</th>
      <th rowspan="2">JMKS</th>
      <th rowspan="2">SKTM</th>
    </tr>
    <tr align="center">
      <th>PKM</th>
      <th>RS LAIN</th>
      <th>LAIN-LAIN</th>
      </tr>
    <tr>
    	<td>x</td>
    	<td>x</td>
    	<td>x</td>
    	<td>x</td>
    	<td>&nbsp;</td>
    	<td>x</td>
    	<td>&nbsp;</td>
    	<td>&nbsp;</td>
    	<td>x</td>
    	<td>&nbsp;</td>
    	<td>&nbsp;</td>
    	<td>&nbsp;</td>
    	<td>&nbsp;</td>
    	<td>x</td>
    	<td>x</td>
    	<td>x</td>
    	<td>x</td>
    	<td>x</td>
    	<td>x</td>
    </tr>
</table>
</div>
</div>