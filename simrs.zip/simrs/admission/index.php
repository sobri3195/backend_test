    <div id="menu">
        <div id="menu_nama">
        <a href="?link=17">Daftar Rawat Inap</a> 
        <a href="?link=171">List Pasien Rawat Inap</a>
        <a href="?link=173">Kamar Rawat Inap</a>
        <a href="?link=177">Pencarian Pasien</a>
		<a href="?link=179">Sensus Pendaftaran Pasien Rawat Inap</a>
        </div>
    </div>
