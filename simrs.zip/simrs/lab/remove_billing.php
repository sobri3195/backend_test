<?php
	include '../include/connect.php';
	
	if($_REQUEST['opsi'] == 1){
		$sql_pr='CALL pr_savebill_tindakanrajal_dokter_delete("'.$_REQUEST['idxdaftar'].'","'.$_REQUEST['nobill'].'","'.$_REQUEST['idxbill'].'")';
		mysql_query($sql_pr);
	}
	else if($_REQUEST['opsi'] == 2){
		$idxbill	= $_REQUEST['idxbill'];
		$nomr 		= $_REQUEST['nomr'];
		$nolab 		= $_REQUEST['nobill'];
		$idxdaftar	= $_REQUEST['idxdaftar'];
		
		$getdatabayar 	= mysql_query("SELECT * FROM t_bayarlab WHERE idxbayarlab=".$idxbill);
		$data			= mysql_fetch_array($getdatabayar);
		$kode_tindakan	= $data['kode_tindakan'];
		
		//delete pada tabel t_bayarlab
		mysql_query("DELETE FROM t_bayarlab WHERE idxbayarlab=".$idxbill);
		
		//delete pada tabel t_orderlab
		mysql_query("DELETE FROM t_orderlab WHERE KODE='".$kode_tindakan."' AND IDXDAFTAR=".$idxdaftar);
	}
?>