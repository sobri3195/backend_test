<?php 
	$nomr 		= $_REQUEST['nomr'];
	$idxdaftar	= $_REQUEST['idxdaftar'];
	
	$unit 		= getUnitByNama("Laboratorium");
	$dataunit	= mysql_fetch_array($unit);
	$kdunit 	= $dataunit['kode_unit'];
?>
<div align="center">
	<div id="frame">
		<div id="frame_title"><h3>Cart Bayar Laboratorium</h3></div>
	   	<fieldset class="fieldset">
	   		<legend>Identitas </legend>
	   		<?php 
	   			$getPasien	= getPasienAPS($nomr);
	   			$dataPasien = mysql_fetch_array($getPasien);
	   			$tgllahir 	= $dataPasien['TGLLAHIR'];
	   			
	   			$getPendAPS	= getPendaftaranAPS($idxdaftar);
	   			$pendAPS	= mysql_fetch_array($getPendAPS);
	   			$kdcrbyr	= $pendAPS['KDCARABAYAR'];
	   			$carabyr	= getallcarabayar($kdcrbyr);
	   			$detailcrbyr= $carabyr['NAMA'];
	   		?>
	   		
	   		<input type="hidden" value="<?php echo $nomr; ?>" id="nomr" />
	   		<input type="hidden" value="<?php echo $idxdaftar; ?>" id="idxdaftar" />
	   		<input type="hidden" value="<?php echo $kdunit; ?>" id="kdunit" />
	   		
	   		<div align="left" style="margin:20px">
		   		<table>
		   			<tr>
		   				<td>No MR</td>
		   				<td>:</td>
		   				<td><?php echo $nomr;?></td>
		   			</tr>
		   			<tr>
		   				<td>Nama Lengkap Pasien</td>
		   				<td>:</td>
		   				<td><?php echo $dataPasien['NAMA']; ?></td>
		   			</tr>
		   			<tr>
		   				<td>Alamat Pasien</td>
		   				<td>:</td>
		   				<td><?php echo $dataPasien['ALAMAT']; ?></td>
		   			</tr>
		   			<tr>
		   				<td>Jenis Kelamin</td>
		   				<td>:</td>
		   				<td>
		   					<?php 
		   						$jenkel 		= $dataPasien['JENISKELAMIN'];
		   						$jenkelDetail	= getJenkelDetail($jenkel);
		   						
		   						echo $jenkelDetail." (".$jenkel.")";
		   					?>
		   				</td>
		   			</tr>
		   			<tr>
		   				<td>Tanggal Lahir</td>
		   				<td>:</td>
		   				<td><?php echo $dataPasien['TEMPAT'].", ".$tgllahir; ?></td>
		   			</tr>
		   			<tr>
		   				<td>Umur</td>
		   				<td>:</td>
		   				<td>
		   					<?php 
		   						echo getUmur($tgllahir);
		   					?>
		   				</td>
		   			</tr>
		   			<tr>
		   				<td>Cara Bayar</td>
		   				<td>:</td>
		   				<td>
		   					<?php echo $detailcrbyr; ?>
		   					&nbsp;
			        		<?php
			        			if($kdcrbyr == 1){
			        		?>
			        			<select name="carabayarumum" class="carabayarumum select2" style="font-size:8pt;">
			        				<option value="1" selected>Cash</option>
			        				<option value="2">Debet</option>
			        				<option value="3">Credit</option>
			        				<option value="4">Angsuran</option>
			        			</select>
			        			&nbsp;
			        			<select name="idbank" id="idbank" class="idbank text select2" style="font-size: 8pt;">
			        				<?php
			        					$sql4	= getAllBank();
			        					while ($data = mysql_fetch_array($sql4, MYSQL_NUM)){
			        						
			        				?>
			        				<option value="<?php echo $data[0]; ?>"><?php echo $data[1]; ?></option>
			        				<?php 
			        					}
			        				?>
			        			</select>
			        			&nbsp;
			        			<input type="text" id="subcarabayar" class="subcarabayar text" style="font-size: 8pt; text-align: right;" size="5" /><label id="label_subcarabayar">%</label>
			        			&nbsp;
			        			<input type="button" id="btnSubcarabayar" value="Pilih" class="btnSubcarabayar text" style="font-size: 8pt;" />
			        			&nbsp;
			        			<label id="label_keterangan" style="color: #FF0000">*Untuk koma menggunakan titik (.)</label>
			        		<?php	
			        			}
			        		?>
		   				</td>
		   			</tr>
		   		</table>
	   		</div>
     	</fieldset>  
	</div>
	<div id="tmp_print"></div>
	
	<div id="frame">
		<div id="frame_title"><h3>List Pembayaran</h3></div>
			<form name="byr1" action="include/process.php" method="post" id="byr1">
				<fieldset>
					<legend>Cart List Bayar</legend>
					<br/>
					<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tb">
						<tr>
							<th>Nama Pemeriksaan</th>
							<!--<th>Keringanan</th>-->
							<th>Tarif</th>
							<th>Shift</th>
							<th>Aksi</th>
						</tr>
						<?php 
							$jmlCartLab = getJmlCartLabLunas($nomr, $idxdaftar);
							if($jmlCartLab > 0){
								$total 		= 0;
								$cartLab	= getCartBillLab($nomr, $idxdaftar);
								$jmlDataLab	= mysql_num_rows($cartLab);
								while($dataCartLab = mysql_fetch_array($cartLab)){
									$nolab			= $dataCartLab['NOLAB'];
									$kode 			= $dataCartLab['kode_tindakan'];
									$idxbayarlab	= get_idxbayarlab($kode, $idxdaftar);
									$tariflab		= getTottariflab($nomr, $idxdaftar, $kode);
									$total 			= $total + $tariflab;
								}
								if($jmlDataLab > 0){
						?>
						<tr>
							<td>
								Pembayaran Laboratorium
							</td>
							<!--<td>
								<span class="form_keringanan" style="cursor:pointer; font-weight:bold;" id="<?php echo $idxbayarlab; ?>">Form Keringanan</span>
							</td>-->
							<td>
								<?php 
									echo "Rp. ".CurFormat($total,2);
								?>
							</td>
							<td>
								<select name="shift" id="shift_<?php echo $nolab; ?>" class="text shift">
        		
					        		<!-- /* edited 08072015 */ -->
					        		<?php
										//added by ferna 25062015
										//waktu sekarang pada database
										$sql = getNow();
										while($ds = mysql_fetch_array($sql)){
											$now = $ds['time'];
											$jam = substr($now, 0, 2);
											$menit = substr($now, 3, 2);
											$detik = substr($now, 6, 2);
										}
										
										$jam_now = new DateTime($now);
										$jam_pagi_bawah = new DateTime("07:00:00");
										$jam_pagi_atas = new DateTime("14:15:00");
										$jam_sore_atas = new DateTime("21:15:00");
									?>
					        		
					                <option value=""> Pilih Shift </option>
					                <option value="1" <? if($jam_now > $jam_pagi_bawah && $jam_now < $jam_pagi_atas) echo "Selected";?>> Pagi </option>
					                <option value="2" <? if($jam_now > $jam_pagi_atas && $jam_now < $jam_sore_atas) echo "Selected";?>> Sore </option>
					                <option value="3" hidden="true"> 3 </option>
					            	<!-- /* edited 08072015 */ -->
					            
					            </select>
					            <input type="hidden" name="total" id="hiden_total_bayar_<?php echo $nolab; ?>" value="<?php echo $total; ?>" />
					            <input type="hidden" name="keringanan" id="hiden_keringanan_<?php echo $nolab; ?>" value="0" />
					            <input type="hidden" name="alasan" id="hiden_alasan_<?php echo $nolab; ?>" value="" />
					            <span id="text_shift_<?php echo $nolab;?>"></span>
							</td>
							<td>
								<input type="button" name="Submit" value="Bayar"  class="text bayar" id="bayar_<?php echo $nolab; ?>" rel="<?php echo $idxbayarlab; ?>" svn="<?php echo $nolab; ?>" idxd="<?php  echo $idxdaftar; ?>" />
    							<!--<input type="button" name="Cancel" value="Batal" class="text cancel" idxdaftar="<?php echo $idxdaftar;?>" kode="<?php echo $kode;?>" id="cancel_<?php echo $nolab; ?>" rel="<?php echo $idxbayarlab; ?>" svn="<?php echo $nolab; ?>" />-->
							</td>
						</tr>
						<?php
								}
								else{
									$databatal 	= get_t_bayarlab($nomr, $idxdaftar);
									while($dt_batal = mysql_fetch_array($databatal)){
										$nolab 		= $dt_batal['nobilllab'];
										$kode 		= $dt_batal['kode_tindakan'];
										$idxbayarlab= $dt_batal['idxbayarlab'];
										$tariflab	= getTottariflab($nomr, $idxdaftar, $kode);
										$total		= $total + $tariflab;
										$shift		= $dt_batal['shif'];
									}
						?>
						<tr>
							<td>
								Pembayaran Laboratorium
							</td>
							<!--<td>
								-
							</td>-->
							<td>
								<?php 
									echo "Rp. ".CurFormat($total,2);
								?>
							</td>
							<td>
								<?php 
									if($shift == 1){
										echo "Pagi";
									}else{
										echo "Sore";
									}
								?>
							</td>
							<td>
								-
    						</td>
						</tr>
						<?php
								}	 
							}else{
								$total			= 0;
								$status			= 'BATAL';
								$dataCartLab2 	= get_t_bayarlabbystatus($nomr, $idxdaftar,$status);
								$jmldata 		= mysql_num_rows($dataCartLab2);
								while($rowCartLa2 = mysql_fetch_array($dataCartLab2)){
									$nolab 		= $rowCartLa2['nobilllab'];
									$kode 		= $rowCartLa2['kode_tindakan'];
									$idxbayarlab= $rowCartLa2['idxbayarlab'];
									$tariflab	= getTottariflab($nomr, $idxdaftar, $kode);
									$total		= $total + $tariflab;
									$shift		= $rowCartLa2['shif'];
								}
								if($jmldata > 0){
						?>
						<tr>
							<td>
								Pembayaran Laboratorium
							</td>
							<!--<td>
								-
							</td>-->
							<td>
								<?php 
									echo "Rp. ".CurFormat($total,2);
								?>
							</td>
							<td>
								<?php 
									if($shift == 1){
										echo "Pagi";
									}else{
										echo "Sore";
									}
								?>
							</td>
							<td>
								<!--<input type="button" name="Cancel" value="Batal" class="text cancel" idxdaftar="<?php echo $idxdaftar;?>" kode="<?php echo $kode;?>" id="cancel_<?php echo $nolab; ?>" rel="<?php echo $idxbayarlab; ?>" svn="<?php echo $nolab; ?>" />-->
								-
    						</td>
						</tr>
						<?php
								}
								else{
									$databatal 	= get_t_bayarlab($nomr, $idxdaftar);
									while($dt_batal = mysql_fetch_array($databatal)){
										$nolab 		= $dt_batal['nobilllab'];
										$kode 		= $dt_batal['kode_tindakan'];
										$idxbayarlab= $dt_batal['idxbayarlab'];
										$tariflab	= getTottariflab($nomr, $idxdaftar, $kode);
										$total		= $total + $tariflab;
										$shift		= $dt_batal['shif'];
									}
						?>
						<tr>
							<td>
								Pembayaran Laboratorium
							</td>
							<!--<td>
								-
							</td>-->
							<td>
								<?php 
									echo "Rp. ".CurFormat($total,2);
								?>
							</td>
							<td>
								<?php 
									if($shift == 1){
										echo "Pagi";
									}else{
										echo "Sore";
									}
								?>
							</td>
							<td>
								-
    						</td>
						</tr>
						<?php
								}
							}
						?>
						<tr>
							<td><br/></td>
						</tr>
						<tr>
							<td><br/></td>
						</tr>
						<tr style="font-size: 9pt; color: #FF0000">
							<td><b>Total yang Belum di Bayar: <input type="text" id="totbelumbayar" disabled value="<?php echo "Rp. ". CurFormat(getsisapembayaranlab($_REQUEST['idxdaftar']),2); ?>" style="font-size: 9pt; color: #FF0000; font-weight:bold;" /></b></td>
						</tr>
						<tr style="font-size: 9pt; color: #FF0000">
							<td>
								<b>
									<label id="label_bayar">Bayar: </label>
									<input type="number" id="bayarsisa" style="font-size: 12pt; color: #FF0000; font-weight:bold;" />
								</b>
								<input type="button" id="btn_bayarsisa" value="Bayar" class="text" style="font-size:10pt;"/>
							</td>
						</tr>
						<tr>
							<td><br/></td>
						</tr>
						<tr>
							<td><br/></td>
						</tr>
						<tr>
							<td colspan="2">No.Bill	: <?php echo $nolab; ?></td>
							<td colspan="2">
								<input type="button" name="tutup_pembayaran" value="Tutup Pembayaran Pasien" class="text tutup_pembayaran" id="tutup_<?php echo $nolab; ?>" rel="<?php echo $idxdaftar; ?>" svn="<?php echo $_REQUEST['nomr']; ?>" style="display:block; float:right; padding:5px; margin:5px;"/>
								<input type="button" name="print" value="Print" class="text print" id="print_<?php echo $nolab?>" rel="<?php echo $idxdaftar; ?>" svn="<?php echo $nolab; ?>" onclick="print_pembayaran()" style="display:block; float:right; padding:5px; margin:5px;"/>
								<!-- added 03072015 -->
								<input type="hidden" id="rel" name="rel" value="<?php echo $idxdaftar; ?>" />
								<input type="hidden" id="svn" name="svn" value="<?php echo $nolab; ?>" />
								<!-- added 03072015 -->
								
								<div id="callback_<?php echo $nolab; ?>" style="float:right;"></div>
							</td>
						</tr>
					</table>
					<br/>
					<br/>
				</fieldset>
			</form>
	</div>
</div>

<script type="text/javascript">
	//jQuery('.select2').select2();

	jQuery(document).ready(function(){
		jQuery('#label_bayar').hide();
		jQuery('#bayarsisa').hide();
		jQuery('#btn_bayarsisa').hide();
		jQuery('#bayarsisa').attr('disabled','disabled');
		jQuery('#btn_bayarsisa').attr('disabled','disabled');
		jQuery('#subcarabayar').hide();
		jQuery('#label_subcarabayar').hide();
		jQuery('#btnSubcarabayar').show();
		jQuery('#subcarabayar').val(0);
		jQuery('#label_keterangan').hide();
		jQuery('#idbank').hide();
		jQuery('#idbank').val(0);
		jQuery(".print").button({icons: {primary: "ui-icon-print"}});
		jQuery(".tutup_pembayaran").button({icons: {primary: "ui-icon-print"}});
		start();

		function start(){
			var nomr		= jQuery('#nomr').val();
			var idxdaftar	= jQuery('#idxdaftar').val();
			jQuery.post('<?php echo _BASE_; ?>include/cari_pasien.php',{NOMR:nomr,IDXDAFTAR:idxdaftar,pilihan:4},function(data){
				var json	= JSON.parse(data);
				if(json.carabayar == 1){
					if(json.subcarabayar > 0){
						jQuery('#subcarabayar').val(json.presentase);
						jQuery('.carabayarumum').val(json.subcarabayar);
						jQuery('#idbank').val(json.idbank);
						restart();
						if(json.subcarabayar == 2){
							jQuery('#subcarabayar').show();
							jQuery('#idbank').show();
							jQuery('#label_subcarabayar').show();
							jQuery('#label_keterangan').show();
						}
						else if(json.subcarabayar == 3){
							jQuery('#idbank').show();
						}
						else if(json.subcarabayar == 4){
							jQuery('#bayarsisa').removeAttr('disabled');
							jQuery('#btn_bayarsisa').removeAttr('disabled');
							jQuery('#label_bayar').show();
							jQuery('#bayarsisa').show();
							jQuery('#btn_bayarsisa').show();
							jQuery.post('<?php echo _BASE_;?>include/cari_pasien.php',{NOMR:nomr,IDXDAFTAR:idxdaftar,pilihan:5},function(data){
								jQuery('#totbelumbayar').val("Rp. "+ data);
							});
						}
						jQuery('#btnSubcarabayar').hide();
					}
					else{
						jQuery('.bayar').attr('disabled','disabled');
						jQuery('.cancel').attr('disabled','disabled');
						jQuery('.printpertindakan').attr('disabled','disabled');
						jQuery('.print').attr('disabled','disabled');
						jQuery('.shift').attr('disabled','disabled');
					}
				}
			});
		}

		function restart(){
			jQuery('.bayar').removeAttr('disabled');
			jQuery('.cancel').removeAttr('disabled');
			jQuery('.printpertindakan').removeAttr('disabled');
			jQuery('.print').removeAttr('disabled');
			jQuery('.shift').removeAttr('disabled');
		}

		jQuery('.carabayarumum').click(function(){
			var val	= jQuery('.carabayarumum').val();
			if(val == 2){
				jQuery('#label_bayar').hide();
				jQuery('#bayarsisa').hide();
				jQuery('#btn_bayarsisa').hide();
				jQuery('#subcarabayar').show();
				jQuery('#idbank').show();
				jQuery('#label_subcarabayar').show();
				jQuery('#btnSubcarabayar').show();
				jQuery('#subcarabayar').val(0);
				jQuery('#label_keterangan').show();
			}
			else if(val == 3){
				jQuery('#label_bayar').hide();
				jQuery('#bayarsisa').hide();
				jQuery('#btn_bayarsisa').hide();
				jQuery('#idbank').show();
				jQuery('#subcarabayar').hide();
				jQuery('#label_subcarabayar').hide();
				jQuery('#btnSubcarabayar').show();
				jQuery('#label_keterangan').hide();
			}
			else if(val == 4){
				jQuery('#label_bayar').show();
				jQuery('#bayarsisa').show();
				jQuery('#btn_bayarsisa').show();
				jQuery('#subcarabayar').hide();
				jQuery('#label_subcarabayar').hide();
				jQuery('#btnSubcarabayar').show();
				jQuery('#label_keterangan').hide();
				jQuery('#idbank').hide();
			}
			else{
				jQuery('#label_bayar').hide();
				jQuery('#bayarsisa').hide();
				jQuery('#btn_bayarsisa').hide();
				jQuery('#subcarabayar').hide();
				jQuery('#label_subcarabayar').hide();
				jQuery('#btnSubcarabayar').show();
				jQuery('#label_keterangan').hide();
				jQuery('#idbank').hide();
			}
		});

		jQuery('#btnSubcarabayar').click(function(){
			var nomr 			= jQuery('#nomr').val();
			var idxdaftar 		= jQuery('#idxdaftar').val();
			var carabayarumum	= jQuery('.carabayarumum').val();
			var subcarabayar	= jQuery('#subcarabayar').val();
			var pengguna		= "pembayaran";
			var pilihan 		= 1;

			if(carabayarumum == 2 || carabayarumum == 3){
				var idbank		= jQuery('#idbank').val();
			}
			else{
				var idbank		= 0;
			}
			
			jQuery.post('<?php echo _BASE_; ?>include/updatesubcarabayarlab.php',{NOMR:nomr, IDXDAFTAR:idxdaftar, kdsubcarabayar:carabayarumum, presentase:subcarabayar, idbank:idbank, pengguna:pengguna}, function(data){
				alert("Berhasil di update");
				location.reload();
				restart();
			});
		});

		jQuery('.bayar').click(function(){
			var nomr		= jQuery('#nomr').val();
			var idxbayar	= jQuery(this).attr('rel');
			var nolab		= jQuery(this).attr('svn');
			var idxdaftar	= jQuery(this).attr('idxd');
			var shif		= jQuery('#shift_'+idxdaftar).val();
			var total		= jQuery('#hiden_total_bayar_'+idxdaftar).val();
			var carabayar	= jQuery('#carabayar').val();
			var keringanan	= jQuery('#hiden_keringanan_'+idxdaftar).val();
			var alasan		= jQuery('#hiden_alasan_'+idxdaftar).val();
			var shif_ket    = "";
			var crbyr		= jQuery('.carabayarumum').val();
			
			if(shif == ''){
				alert('Shift belum dipilih');
				return false;
			}
			
			jQuery.post('<?php echo _BASE_; ?>include/process.php?lab=1',{nomr:nomr,idxbayar:idxbayar,nolab:nolab,idxdaftar:idxdaftar,shif:shif,total:total,carabayar:carabayar,keringanan:keringanan,alasan:alasan,crbyr:crbyr},function(data){
				if(data == 'ok'){
					location.reload();
				}else{
					alert('Lost Connection');
					return false;
				}
			});
		});

		jQuery('.cancel').click(function(){
			var nolab 		= jQuery(this).attr('svn');
			var nomr		= jQuery('#nomr').val();
			var kode		= jQuery(this).attr('kode');
			var idxdaftar 	= jQuery(this).attr('idxdaftar');
			var kdunit		= jQuery('#kdunit').val();
			
			jQuery.post('<?php echo _BASE_;?>include/cartbill_pembayaran_batal_penunjang.php?opsi=1',{nolab:nolab,nomr:nomr,kode:kode,idxdaftar:idxdaftar,kdunit:kdunit},function(data){
				location.reload();
			});
		});

		jQuery('.print').click(function(){
			var idxdaftar	= jQuery(this).attr('rel');
			var nolab		= jQuery(this).attr('svn');

			window.open("lab/print_pembayaran_lab.php?nolab="+nolab+"&idxdaftar="+idxdaftar+"&nomr=<?php echo $_REQUEST['nomr']; ?>");
		});

		jQuery('#btn_bayarsisa').click(function(){
			var nomr 				= jQuery('#nomr').val();
			var idxdaftar 			= jQuery('#idxdaftar').val();
			var totalygdibayarkan	= jQuery('#bayarsisa').val();

			jQuery.post('<?php echo _BASE_; ?>include/cari_pasien.php',{NOMR:nomr, IDXDAFTAR:idxdaftar, totalygdibayarkan:totalygdibayarkan, pilihan:6}, function(data){
				alert('Transaksi Pembayaran Berhasil');
				location.reload();
			});
		});

		jQuery(".tutup_pembayaran").click(function(){
			var nomr 	= jQuery(this).attr('svn');
			var idxd 	= jQuery(this).attr('rel');
			
			window.location.href	= '<?php echo _BASE_ ?>include/pasien.php?opsi=8&nomr='+nomr+'&idxd='+idxd;
		});
	});
</script>