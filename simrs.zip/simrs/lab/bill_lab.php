<?php 
	include("../include/connect.php");
	
	$nomr 	= $_REQUEST['cnomr'];
	$nama 	= $_REQUEST['cnama'];
	$crbayar= $_REQUEST['crbayar'];
	$start	= $_REQUEST['start'];
	$end	= $_REQUEST['end'];
?>

<div align="center">
    <div id="frame">
	    <div id="frame_title">
	      <h3>TAGIHAN LABORATORIUM/ HARI INI</h3>
	      <br/>
	      <br/>
	      <div align="center" style="margin:5px;">
		      <form name="formsearch" id="cari" method="get" action="<?php ?>">
		      	   cari nama  <input type="text" name="cnama" class="text" <?php echo $_REQUEST['cnama']; ?>/>
                   / No MR 
        		  <input type="text" name="cnomr" size="10" class="text" <?php echo $_REQUEST['cnomr']; ?>/> 
        		  <select name="crbayar" id="crbayar" class="text select2" >
		             <option value="" <?php if($_GET['crbayar'] == ''): echo 'selected="selected"'; endif; ?>>--Pilih Cara Bayar--</option>
		             <?php 
		             	$carabayar 	= getCaraBayar();
		             	while($crbyr = mysql_fetch_array($carabayar)){
		             ?>
		             <option value="<?php echo $crbyr['KODE']; ?>" <?php if($_GET['crbayar'] == $crbyr['KODE']): echo 'selected="selected"'; endif; ?>><?php echo $crbyr['NAMA']; ?></option>
		             <?php 
		             	}
		             ?>
		          </select>
			      <?php
			      	if($_SESSION['ROLES'] == 23){
			      ?>
			      <input type="text" size="10" class="text datepicker3" id="TGLREG" name="start" value="<?php if($_REQUEST['start'] != ''): echo $_REQUEST['start']; else: echo date('Y/m/d'); endif;?>" readonly /> - 
			      <input type="text" size="10" class="text datepicker3" id="TGLREG2" name="end" value="<?php if($_REQUEST['end'] != ''): echo $_REQUEST['end']; else: echo date('Y/m/d'); endif;?>" readonly />
			      <?php 
			      	}
			      ?>
				  <input type="submit" class="text" value="Cari" />
				  <input type="hidden" name="link" value="billlab" />
	    	  </form> 
    	  </div> 
	      <br/>
	      <br/>
	      <table class="table">
	      	<thead>
		      	<tr>
		      		<th>No</th>
		      		<th>NO RM</th>
		      		<th>Nama Pasien</th>
		      		<th>Cara Bayar</th>
		      		<th>Status</th>
		      		<th>Aksi</th>
		      	</tr>
	      	</thead>
	      	<tbody>
	      		<?php 
	      			$i = 1;
	      			if($_SESSION['ROLES'] == 23){
	      				$tp 	= 1;
	      			}
	      			else{
	      				$tp 	= 0;
	      			}
	      			$dataBillLab	= getBillLab($nomr, $nama, $crbayar, $start, $end, $tp);
	      			while($BillLab 	= mysql_fetch_array($dataBillLab)){
	      		?>
	      		<tr>
		      		<td>
		      			<?php
		      				echo $i++;	
		      			?>
		      		</td>
		      		<td>
		      			<?php
		      				echo $BillLab['nomr'];
		      			?>
		      		</td>
		      		<td>
		      			<?php 
		      				echo $BillLab['NAMA'];
		      			?>
		      		</td>
		      		<td>
		      			<?php 
		      				echo $BillLab['NAMACARABAYAR'];
		      			?>
		      		</td>
		      		<td>
		      			<?php 
		      				$status = '';
		      				$status	= getStatusBayarLab($BillLab['nomr'], $BillLab['idxdaftar']);
		      				echo $status;
		      			?>
		      		</td>
		      		<td>
		      			<a href="index.php?link=billlab2&nomr=<?php echo $BillLab['nomr']; ?>&idxdaftar=<?php echo $BillLab['idxdaftar'];?>"> <input type="button" class="text" value="Prosess" /></a>
		      		</td>
		      	</tr>
		      	<?php 
	      			}
		      	?>
	      	</tbody>
	      </table>
	    </div>
   	</div>
</div>
</div>

<script type="text/javascript">
	jQuery(".table").dataTable();
	jQuery(".select2").select2();
</script>