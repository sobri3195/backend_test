<div align="center">
    <div id="frame" style="width: 100%;">
        <div id="frame_title">
			<h3>FORM EDIT RINCIAN LAB</h3>
		</div>
		<fieldset class="fieldset">
			<legend>RINCIAN LABORATORIUM</legend>
			<?php
				$sql ="SELECT t_orderlab.IDXDAFTAR,
							  t_orderlab.NOMR,
							  t_orderlab.TANGGAL,
							  t_orderlab.DRPENGIRIM,
							  m_dokter.NAMADOKTER,
							  t_orderlab.KDPOLY,
							  m_poly.nama AS poli,
							  t_orderlab.kd_ruang,
							  ri_ruang.NM_RUANG,
							  t_orderlab.NOLAB
					   FROM t_orderlab
					   LEFT JOIN m_dokter ON m_dokter.KDDOKTER = t_orderlab.DRPENGIRIM
					   LEFT JOIN m_poly ON m_poly.kode = t_orderlab.KDPOLY
					   LEFT JOIN ri_ruang ON ri_ruang.KD_RUANG = t_orderlab.kd_ruang
					   WHERE NOMR = '{$_REQUEST['nomr']}'
					     AND IDXDAFTAR = '{$_REQUEST['idx']}'
						 AND NOLAB = '{$_REQUEST['nolab']}'";
					
				$rs_lab  = mysql_query($sql);
				$row_lab = mysql_fetch_array($rs_lab);
				
				$sql_lis_order = "SELECT * FROM log_sysmex_lis_order
								  WHERE ONO = '{$_REQUEST['nolab']}'
								    AND VISITNO = '{$_REQUEST['idx']}'
								  ORDER BY ID DESC";
								  
				$rs_lis_order  = mysql_query($sql_lis_order);
				$row_lis_order = mysql_fetch_array($rs_lis_order);
			?>
			<form method="post" action="lab/model/edit_rincian_lab.php">
				<table width="90%" cellpadding="2">
					<tr>
						<td width="100px;">
							<label>NOLAB</label>
						</td>
						<td width="20px;"> : </td>
						<td width="300px	;">
							<?= $row_lab['NOLAB']; ?>
						</td>
						<td></td>
					</tr>
					<tr>
						<td width="100px;">
							<label>NOMR</label>
						</td>
						<td width="20px;"> : </td>
						<td>
							<?= $row_lab['NOMR']; ?>
						</td>
						<td></td>
					</tr>
					<tr>
						<td width="100px;">
							<label>ALAMAT</label>
						</td>
						<td width="20px;"> : </td>
						<td>
							<?= $row_lis_order['ADDRESS1']; ?>
						</td>
						<td></td>
					</tr>
					<tr>
						<td width="100px;">
							<label>JENIS KELAMIN</label>
						</td>
						<td width="20px;"> : </td>
						<td>
							<select class="text" name="jenkel">
								<option value="1" <?= $row_lis_order['SEX'] == 1 ? "selected" : "" ; ?>>Laki-laki</option>
								<option value="2" <?= $row_lis_order['SEX'] == 2 ? "selected" : "" ; ?>>Perempuan</option>
							</select>
						</td>
						<td></td>
					</tr>
					<tr>
						<td width="100px;">
							<label>POLI/RUANG</label>
						</td>
						<td width="20px;"> : </td>
						<td><?= $row_lab['KDPOLY'] == "" ? $row_lab['NM_RUANG'] : $row_lab['poli']; ?></td>
						<td></td>
					</tr>
					<tr>
						<td width="100px;">
							<label>DOKTER PENGIRIM</label>
						</td>
						<td width="20px;"> : </td>
						<td>
							<select class="text" name="dokter" id="dokter">
								<?php
									$sql_dokter = "SELECT * FROM m_dokter 
												   WHERE st_aktif = 0";
									$rs_dokter  = mysql_query($sql_dokter);
									while($row_dokter = mysql_fetch_array($rs_dokter)){
								?>
									<option value="<?= $row_dokter['KDDOKTER']; ?>" <?= $row_dokter['KDDOKTER'] == $row_lab['DRPENGIRIM'] ? "selected" : ""; ?>><?= $row_dokter['NAMADOKTER']; ?></option>
								<?php
									}
								?>
							</select>
						</td>
						<td></td>
					</tr>
					<tr>
						<td width="100px;">
							<label>TANGGAL ORDER</label>
						</td>
						<td width="20px;"> : </td>
						<td>
							<input type="text" name="tgl_order" id="tgl_order" readonly="readonly" class="text datepicker"
							value="<?= $row_lab['TANGGAL']; ?>"/>
						</td>
						<td></td>
					</tr>
					<tr>
						<td width="100px;">
							<label>JAM ORDER</label>
						</td>
						<td width="20px;"> : </td>
						<td>
							<?php
								$end 	= substr($row_lis_order['REQUEST_DT'], 6);
								$chunks = str_split($end, 2);
								$result = implode(':', $chunks);
							?>
							<input class="text" type="text" name="jam_order" value="<?= $result; ?>"/>
						</td>
						<td></td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td>
							<input type="hidden" name="nomr" value="<?= $_REQUEST['nomr']; ?>"/>
							<input type="hidden" name="idx" value="<?= $_REQUEST['idx']; ?>"/>
							<input type="hidden" name="nolab" value="<?= $_REQUEST['nolab']; ?>"/>
							<input type="hidden" name="nama_dokter" id="nama_dokter" value="<?= $row_lab['NAMADOKTER']; ?>"/>
							
							<!--data lis order-->
							<input type="hidden" name="pname" value="<?= $row_lis_order['PNAME']; ?>"/>
							<input type="hidden" name="address1" value="<?= $row_lis_order['ADDRESS1']; ?>"/>
							<input type="hidden" name="ptype" value="<?= $row_lis_order['PTYPE']; ?>"/>
							<input type="hidden" name="birth_dt" value="<?= $row_lis_order['BIRTH_DT']; ?>"/>
							<input type="hidden" name="ono" value="<?= $row_lis_order['ONO']; ?>"/>
							<input type="hidden" name="source" value="<?= $row_lis_order['SOURCE']; ?>"/>
							<input type="hidden" name="priority" value="<?= $row_lis_order['PRIORITY']; ?>"/>
							<input type="hidden" name="visitno" value="<?= $row_lis_order['VISITNO']; ?>"/>
							<input type="hidden" name="order_testid" value="<?= $row_lis_order['ORDER_TESTID']; ?>"/>
							
							<button class="text">Simpan</button>
						</td>
					</tr>
				</table>
			</form>
		</fieldset>
	</div>
</div>

<script>
	jQuery('#dokter').change(function(){
		var nama_dokter = jQuery('#dokter option:selected').html();
		jQuery('#nama_dokter').val(nama_dokter);
	});
</script>