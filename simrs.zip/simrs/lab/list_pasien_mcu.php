<?php 
	session_start();
	include '../include/connect.php';
	include '../include/function.php';
	
	require_once('ps_pagination.php');
	
	$start 	= date('Y-m-d');
	$end 	= date('Y-m-d');
	if($_REQUEST['tgl_kunjungan'] != ''){
		$start = $_REQUEST['tgl_kunjungan'];
	}
	if($_REQUEST['tgl_kunjungan2'] != ''){
		$end = $_REQUEST['tgl_kunjungan2'];
	}

    $search = "";

	$no_register = "";
	if(!empty($_GET['no_regoster'])) {
        $no_register =$_GET['no_regoster'];
	}
	
	if($no_register !="") {
		$search = $search." AND mcu_registrasi.id_registrasi = '".$no_register."' ";
	}
	
	$nama = "";
	if(!empty($_GET['nama'])) {
		$nama =$_GET['nama'];
	}

    if($nama !="") {
        $search = $search." AND mcu_registrasi.nama  LIKE '%" . $nama . "%' ";
    }
?>
<div align="center">
    <div id="frame" style="width: 100%;">
        <div id="frame_title"><h3>LIST ORDER LAB (MCU)</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table width="248" border="0" cellspacing="0" class="tb">
                        <tr>
                        <td width="52">No.Register</td>
                        <td width="192"><input type="text" name="no_register" id="no_register" value="<? if($no_register!="") {
                                                   echo $no_register;
                        }?>" class="text" style="width:80px;"></td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td><input type="text" name="nama" id="nama" value="<? if($nama!="") {
                            echo $nama;
                        }?>" class="text"></td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td><input type="text" name="tgl_kunjungan" id="tgl_pesan" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($_REQUEST['tgl_kunjungan'] !=""): echo $_REQUEST['tgl_kunjungan']; else: echo date('Y-m-d'); endif; ?>"/></td>
                    </tr>
                    </tr>
                    <tr>
                        <td>Sd</td>
                        <td><input type="text" name="tgl_kunjungan2" id="tgl_pesan2" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($_REQUEST['tgl_kunjungan2'] !=""): echo $_REQUEST['tgl_kunjungan2']; else: echo date('Y-m-d'); endif; ?>"/></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td><input type="submit" value="Cari" class="text"/>
                            <input type="hidden" name="link" value="pasien01" /></td>
                            <input type="hidden" name="opsi" value="4" /></td>
                    </tr>
                </table>

            </form>
            <div id="table_search">
                <table class="tb" width="95%" style="margin:10px;" border="0" cellspacing="1" cellspading="1" title="List Kunjungan Data Pasien Per Hari Ini">
				<tr align="center">
                    <th>No.</th>
                    <th>Tgl Daftar</th>
                    <th>No. Register</th>
                    <th>Nama</th>
                    <th>Tgl Lahir</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th width="70px">Cara Bayar</th>
                    <th width="200px">&nbsp;</th>
                </tr>
                    <?
                    $NO=0;
                    $sql = 'SELECT mcu_registrasi.tgl_daftar,
                                   mcu_registrasi.id_registrasi,
                                   mcu_registrasi.nama,
                                   mcu_registrasi.jenis_kelamin,
                                   mcu_registrasi.tgl_lahir,
                                   mcu_registrasi.alamat,
                                   mcu_registrasi.jenis_pasien,
                                   rsud_jenis_pasien.nama AS jenis_pasien
                            FROM mcu_registrasi
                            JOIN rsud_jenis_pasien ON rsud_jenis_pasien.kode = mcu_registrasi.jenis_pasien
                            WHERE mcu_registrasi.tgl_daftar BETWEEN "'.$start.'" AND "'.$end.'" ' . $search;

                    $pager = new PS_Pagination($connect, $sql, 15, 5, "tgl_kunjungan=".$tgl_kunjungan."&nama=".$nama."&norm=".$norm,"index.php?link=6&");
                    $rs = $pager->paginate();
                    if(!$rs) die(mysql_error());
					$i = 1;
					$count = 1;
                    while($data = mysql_fetch_array($rs)) {?>
                    <?php
                        $count++;
                        if ($count % 2) {
                                echo '<tr class="tr1">';
    					}else{
								echo '<tr class="tr1">';
                        }
                         ?>
                        <td>
						<?php
						if( (!isset($_REQUEST['page'])) or ($_REQUEST['page'] == 1) ){
							echo $i;
						}else{
							echo ($_REQUEST['page'] - 1) * 15 + $i;
						}
						?></td>
                        <td><?= detailTgl($data['tgl_daftar']);?></td>
                        <td><?= $data['id_registrasi'];?></td>
                        <td><?= $data['nama'];?></td>
                        <td><?= $data['tgl_lahir'];?></td>
                        <td><?= $data['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan';?></td>
                        <td><?= $data['alamat'];?></td>
                        <td><?= $data['jenis_pasien'];?></td>
                        <td>
						<?php
							echo '<a href="'._BASE_.'index.php?link=62formorderlab_mcu&id_register='.$data['id_registrasi'].'"><input type="button" value="TAMBAH PEMERIKSAAN" class="text"/></a>';
						?>
                        </td>
                    </tr>
                        <?	$i++;
						}

                    //Display the full navigation in one go
                    //echo $pager->renderFullNav();

                    //Or you can display the inidividual links
                    echo "<div style='padding:5px;' align=\"center\"><br />";

                    //Display the link to first page: First
                    echo $pager->renderFirst()." | ";

                    //Display the link to previous page: <<
                    echo $pager->renderPrev()." | ";

                    //Display page links: 1 2 3
                    echo $pager->renderNav()." | ";

                    //Display the link to next page: >>
                    echo $pager->renderNext()." | ";

//Display the link to last page: Last
echo $pager->renderLast();

                echo "</div>";
                ?>

                </table>

                <?php

                //Display the full navigation in one go
                //echo $pager->renderFullNav();

                //Or you can display the inidividual links
                echo "<div style='padding:5px;' align=\"center\"><br />";

                //Display the link to first page: First
                echo $pager->renderFirst()." | ";

                //Display the link to previous page: <<
                echo $pager->renderPrev()." | ";

                //Display page links: 1 2 3
                echo $pager->renderNav()." | ";

                //Display the link to next page: >>
                echo $pager->renderNext()." | ";

//Display the link to last page: Last
echo $pager->renderLast();

    echo "</div>";
    ?>
            </div>
        </div>
    </div>
    <br />
    <?
    $qry_excel = "SELECT DISTINCT view_orderlab.TANGGAL,
					view_orderlab.NOMR, 
					view_orderlab.NAMA AS NAMA_PASIEN,
					view_orderlab.ALAMAT, 
					view_orderlab.POLY, 
					view_orderlab.NAMADOKTER AS DOKTER_PENGIRIM, 
					view_orderlab.CARABAYAR AS STATUS_BAYAR,
  					view_orderlab.RUJUKAN
			FROM view_orderlab 
			WHERE view_orderlab.STATUS = '0' ".$search;
?>
    <div align="left">
        <form name="formprint" method="post" action="gudang/excelexport.php" target="_blank" >
            <input type="hidden" name="query" value="<?=$qry_excel?>" />
            <input type="hidden" name="header" value="LIST ORDER LABORATORIUM" />
            <input type="hidden" name="filename" value="list_lab" />
            <input type="submit" value="Export To Ms Excel Document" class="text" />
        </form>
    </div>
</div>
