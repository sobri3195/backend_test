 <?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 18/01/2016
 * Time: 14:01
 */

session_start();

include("include/connect.php");

$search = " AND t_orderlab.TANGGAL = CURDATE()";

$tgl_kunjungan = "";
if(!empty($_GET['tgl_kunjungan'])) {
    $tgl_kunjungan =$_GET['tgl_kunjungan'];
}

if($tgl_kunjungan !="") {
    $search = " AND t_orderlab.TANGGAL BETWEEN  '".$tgl_kunjungan."' ";
}

$tgl_kunjungan2 = "";
if(!empty($_GET['tgl_kunjungan2'])) {
    $tgl_kunjungan2 =$_GET['tgl_kunjungan2'];
}

if($tgl_kunjungan !="") {
    if($tgl_kunjungan2 !="") {
        $search = $search." AND '".$tgl_kunjungan2."' ";
    }else {
        $search = $search." AND '".$tgl_kunjungan."' ";
    }
}
?>
<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>DAFTAR KUNJUNGAN LABORATORIUM</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table border="0" cellspacing="0" class="tb">
                    <tr>
                        <td>Tanggal</td>
                        <td><input type="text" name="tgl_kunjungan" id="tgl_pesan" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan!="") {
                                       echo $tgl_kunjungan;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>Sd</td>
                        <td><input type="text" name="tgl_kunjungan2" id="tgl_pesan2" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan2!="") {
                                       echo $tgl_kunjungan2;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td align="right"><input type="submit" value="C A R I" class="text"/>
                            <input type="hidden" name="link" value="report_lab03" />
                        </td>
                    </tr>
                </table>
            </form>
            <br/>
            <table class="tb" width="95%" style="margin:10px;" border="0" cellspacing="1" cellspading="1">
                <thead>
                <tr>
                    <th>No.</th>
                    <th>Tanggal</th>
                    <th>Rawat Jalan</th>
                    <th>Rawat Inap</th>
                    <th>IGD</th>
                    <th>ICU</th>
                    <th>Rujukan</th>
                    <th>MCU</th>
                    <th>Jumlah</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $no 	= 0;
				$query  = "SELECT DISTINCT t_orderlab.TANGGAL FROM t_orderlab
										WHERE 1=1 ". $search ." 
						   ORDER BY t_orderlab.TANGGAL ASC;";
                $sql	= mysql_query($query);
				
                while($data = mysql_fetch_array($sql)){
                    //Rawat Jalan
					$sql_rj = 'SELECT DISTINCT t_orderlab.NOLAB
								FROM t_orderlab
								  JOIN t_pendaftaran ON t_pendaftaran.IDXDAFTAR = t_orderlab.IDXDAFTAR
								WHERE t_pendaftaran.BATAL = 0
								  AND t_orderlab.APS = 0
                                  AND t_orderlab.is_batal = 0
								  AND t_orderlab.TANGGAL ="'.$data['TANGGAL'].'"';
					$rs_rj  = mysql_query($sql_rj);
					$row_rj = mysql_num_rows($rs_rj);
					
                    //Rujukan
					$sql_aps = 'SELECT DISTINCT t_orderlab.NOLAB
								FROM t_orderlab
								  JOIN t_pendaftaran_aps ON t_pendaftaran_aps.IDXDAFTAR = t_orderlab.IDXDAFTAR
								WHERE t_pendaftaran_aps.batal = 0
                                  AND t_orderlab.APS = 1 
                                  AND t_orderlab.is_batal = 0
								  AND t_orderlab.TANGGAL ="'.$data['TANGGAL'].'"';
					$rs_aps  = mysql_query($sql_aps);
					$row_aps = mysql_num_rows($rs_aps);

                    //Ranap
                    $sql_ranap = 'SELECT DISTINCT t_orderlab.NOLAB
                                  FROM t_orderlab
                                  JOIN ri_pendaftaran ON ri_pendaftaran.id_register = t_orderlab.IDXDAFTAR
                                  WHERE ri_pendaftaran.is_batal = 0
                                    AND t_orderlab.RAJAL = 0 
                                    AND t_orderlab.is_batal = 0
                                    AND t_orderlab.kd_ruang NOT IN("RUGD","RUPK","RICCU")
                                    AND t_orderlab.TANGGAL ="'.$data['TANGGAL'].'"';
                    $rs_ranap  = mysql_query($sql_ranap);
                    $row_ranap = mysql_num_rows($rs_ranap);

                    //IGD
                    $sql_igd = 'SELECT DISTINCT t_orderlab.NOLAB
                                FROM t_orderlab
                                JOIN ri_pendaftaran ON ri_pendaftaran.id_register = t_orderlab.IDXDAFTAR
                                WHERE ri_pendaftaran.is_batal = 0
                                  AND t_orderlab.RAJAL = 0 
                                  AND t_orderlab.is_batal = 0
                                  AND t_orderlab.kd_ruang IN("RUGD")
                                  AND t_orderlab.TANGGAL ="'.$data['TANGGAL'].'"';
                    $rs_igd  = mysql_query($sql_igd);
                    $row_igd = mysql_num_rows($rs_igd);

                    //ICU
                    $sql_icu = 'SELECT DISTINCT t_orderlab.NOLAB
                                FROM t_orderlab
                                JOIN ri_pendaftaran ON ri_pendaftaran.id_register = t_orderlab.IDXDAFTAR
                                WHERE ri_pendaftaran.is_batal = 0
                                  AND t_orderlab.RAJAL = 0 
                                  AND t_orderlab.is_batal = 0
                                  AND t_orderlab.kd_ruang IN("RUPK","RICCU")
                                  AND t_orderlab.TANGGAL ="'.$data['TANGGAL'].'"';
                    $rs_icu  = mysql_query($sql_icu);
                    $row_icu = mysql_num_rows($rs_icu);

                    //MCU
                    $sql_mcu = 'SELECT DISTINCT t_orderlab.NOLAB
                                FROM t_orderlab
                                JOIN mcu_registrasi ON mcu_registrasi.id_registrasi = t_orderlab.IDXDAFTAR
                                WHERE mcu_registrasi.is_batal = 0
                                  AND t_orderlab.is_mcu = 1 
                                  AND t_orderlab.is_batal = 0
                                  AND t_orderlab.TANGGAL ="'.$data['TANGGAL'].'"';
                    $rs_mcu  = mysql_query($sql_mcu);
                    $row_mcu = mysql_num_rows($rs_mcu);
                    ?>
                    <tr>
                        <td><?= $no + 1; ?></td>
                        <td><?= date("d-m-Y",strtotime($data['TANGGAL'])) ?></td>
                        <td><?= $row_rj; ?></td>
                        <td><?= $row_ranap; ?></td>
                        <td><?= $row_igd; ?></td>
                        <td><?= $row_icu; ?></td>
                        <td><?= $row_aps; ?></td>
                        <td><?= $row_mcu; ?></td>
                        <td><?= $row_rj + $row_ranap + $row_igd + $row_icu + $row_aps + $row_mcu; ?></td>
                    </tr>
                <?php
                $no++;
				}
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<br/>
<div align="left">
    <form name="formprint" method="post" action="lab/report/laporan_daftar_kunjungan_excel.php" target="_blank" >
        <input type="hidden" name="query" value="<?php echo $search; ?>" />
        <input type="submit" value="Export To Ms Excel Document" class="text" />
    </form>
</div>

<script type="text/javascript">
    //jQuery("#table").dataTable();
    jQuery(".select2").select2();
</script>