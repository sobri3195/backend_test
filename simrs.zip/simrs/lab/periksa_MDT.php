<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 29/12/2015
 * Time: 10:20
 */
?>
<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>FORM PERIKSA DOKTER</h3></div>
        <form id="formperiksaradiologi" name="formperiksaradiologi" method="post" action="lab/model/m_lab.php">
            <table width="700" border="0" cellspacing="0" cellpadding="2" align="center" class="tb">
                <tr>
                    <td>&nbsp;</td>
                    <td width="522"><? if($_GET['psn'] !=''){echo $psn;}?></td>
                </tr>
                <tr>
                    <td width="158">No. Order</td>
                    <td>
                        <?php
                            $sql    = mysql_query("SELECT * FROM t_orderlab WHERE NOMR='".$_REQUEST['nomr']."'
                                                    AND IDXDAFTAR='".$_REQUEST['idx']."'");
                            $data   = mysql_fetch_array($sql);
                        ?>
                        <?php echo $data['IDXORDERLAB']; ?>
                        <input name="idxorder" type="hidden" id="idxorder" value="<? echo $data['IDXORDERLAB'];?>" />
                        <input name="idxdaftar" type="hidden" id="idxdaftar" value="<?php echo $_REQUEST['idx']; ?>" />
                        <input name="nomr" type="hidden" id="nomr" value="<?php echo $_REQUEST['nomr']; ?>" />
                        <input name="opsi" type="hidden" id="opsi" value="1" />
                    </td>
                </tr>
                <tr valign="top">
                    <td> Dokter</td>
                    <td rowspan="2">
                        <select name="dokter" class="text select2" >
                            <?php
                            $sel 	= mysql_query('SELECT dr_pemeriksa FROM t_orderlab where IDXORDERLAB='.$data['IDXORDERLAB']);
                            $row 	= mysql_fetch_array($sel);
                            $kddok	= $row['dr_pemeriksa'];
                            $sql_dokter = "select KDDOKTER, NAMADOKTER from m_dokter WHERE KDPOLY = ".$_SESSION['KDUNIT'];
                            $get_dokter = mysql_query($sql_dokter);
                            while($dat_dokter = mysql_fetch_array($get_dokter)){
                                if($dat_dokter['KDDOKTER'] == $kddok){
                                    $sel 	= 'selected';
                                }
                                else{
                                    $sel 	= '';
                                }
                                ?>
                                <option value="<?php echo $dat_dokter['KDDOKTER']; ?>" <?php echo $sel; ?>><?php echo $dat_dokter['NAMADOKTER']; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td valign="top">Hasil Expertise</td>
                    <td>
                        <?php $sel = mysql_query('select KETERANGAN from t_orderlab where IDXORDERLAB='.$data['IDXORDERLAB']);
                        $row = mysql_fetch_array($sel);
                        ?>
                        <textarea name="resume" cols="70" rows="10" ><?php echo $row['KETERANGAN'];?></textarea></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <?php if(isset($_REQUEST['readonly']) == 1): ?>
                            <input class="text" type="button" name="kembali" id="kembali" value="K e m b a l i" onClick="history.back();" />
                        <?php else: ?>
                            <input class="text" type="submit" name="submit"  value="U p d a t e" />
                            <input class="text" type="button" name="kembali" id="kembali" value="K e m b a l i" onClick="history.back();" />
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </form>
    </div></div>

<script type="text/javascript">
    jQuery(".select2").select2();
</script>
