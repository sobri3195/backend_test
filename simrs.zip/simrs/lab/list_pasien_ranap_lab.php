<?php #session_start();
#include("./include/connect.php");
require_once('ps_pagination.php');

$search = '';

$norm = "";
if(!empty($_GET['norm'])) {
    $norm =$_GET['norm'];
} 

if($norm !="") {
    $search = $search." AND ri_pendaftaran.no_mr = '".$norm."' ";
}

$nama = "";
if(!empty($_GET['nama'])) {
    $nama =$_GET['nama'];
} 

if($nama !="") {
    $search = $search." AND m_pasien.NAMA LIKE '%".$nama."%' ";
}
?>

<div align="center">
    <div id="frame" style="width: 100%;">
        <div id="frame_title"><h3>LIST ORDER LAB (Rawat Inap)</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table width="248" border="0" cellspacing="0" class="tb">
                        <tr>
                        <td width="52">No RM</td>
                        <td width="192"><input type="text" name="norm" id="norm" value="<? if($norm!="") {
                                                   echo $norm;
}?>" class="text" style="width:80px;"></td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td><input type="text" name="nama" id="nama" value="<? if($nama!="") {
    echo $nama;
}?>" class="text"></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td><input type="submit" value="Cari" class="text"/>
                            <input type="hidden" name="link" value="list_pasien_ranap_lab" /></td>
                    </tr>
                </table>

            </form>
            <div id="table_search">
                <table class="tb" width="95%" style="margin:10px;" border="0" cellspacing="1" cellspading="1" title="List Kunjungan Data Pasien Per Hari Ini">
				<tr align="center">
					<th>No</th>
					<th>TGL Masuk</th>
					<th>No RM</th>
					<th>Nama Pasien</th>
					<th>Alamat</th>
					<th>Ruang</th>
					<th width="70px">Cara Bayar</th>
					<th width="200px">&nbsp;</th>
				</tr>
                    <?
                    $NO=0;
                    $sql = 'SELECT ri_pendaftaran.id_register,
								   ri_pendaftaran.tgl_daftar,
							   	   ri_pendaftaran.no_mr,
								   m_pasien.NAMA,
							       m_pasien.ALAMAT,
								   ri_pendaftaran.id_ruang,
								   ri_ruang.NM_RUANG,
								   ri_pendaftaran.id_bed,
								   ri_pendaftaran.id_cara_bayar,
								   rsud_jenis_pasien.nama AS cara_bayar
							FROM ri_pendaftaran
							JOIN m_pasien ON m_pasien.NOMR = ri_pendaftaran.no_mr
							JOIN ri_ruang ON ri_ruang.KD_RUANG = ri_pendaftaran.id_ruang
							JOIN rsud_jenis_pasien ON rsud_jenis_pasien.kode = ri_pendaftaran.id_cara_bayar
							WHERE ri_pendaftaran.is_tutup_transaksi = 0
							  AND ri_pendaftaran.is_batal = 0 '.$search.'
							ORDER BY ri_pendaftaran.id_register ASC';
                    $pager = new PS_Pagination($connect, $sql, 15, 5, "tgl_kunjungan=".$tgl_kunjungan."&nama=".$nama."&norm=".$norm,"index.php?link=6&");
                    $rs = $pager->paginate();
                    if(!$rs) die(mysql_error());
					$i = 1;
					$count = 1;
                    while($data = mysql_fetch_array($rs)) {?>
                    <?php
                        $count++;
                        if ($count % 2) {
                                echo '<tr class="tr1">';
    					}else{
								echo '<tr class="tr1">';
                        }
                         ?>
                        <td>
						<?php
						if( (!isset($_REQUEST['page'])) or ($_REQUEST['page'] == 1) ){
							echo $i;
						}else{
							echo ($_REQUEST['page'] - 1) * 15 + $i;
						}
						?></td>
                        <td><? echo $data['tgl_daftar'];?></td>
                        <td><? echo $data['no_mr'];?></td>
                        <td><? echo $data['NAMA']; ?></td>
                        <td><? echo $data['ALAMAT']; ?></td>
                        
                        <td><?php echo $data['NM_RUANG'].' / '.$data['id_bed'];?></td>
                        <td><? echo $data['cara_bayar']; ?></td>
                        <td>
						<?php
							echo '<a href="'._BASE_.'index.php?link=62formorderlab_ranap&nomr='.$data['no_mr'].'&idx='.$data['id_register'].'"><input type="button" value="TAMBAH PEMERIKSAAN" class="text"/></a>';
						?>
                        </td>
                    </tr>
                        <?	$i++;
						}

                    //Display the full navigation in one go
                    //echo $pager->renderFullNav();

                    //Or you can display the inidividual links
                    echo "<div style='padding:5px;' align=\"center\"><br />";

                    //Display the link to first page: First
                    echo $pager->renderFirst()." | ";

                    //Display the link to previous page: <<
                    echo $pager->renderPrev()." | ";

                    //Display page links: 1 2 3
                    echo $pager->renderNav()." | ";

                    //Display the link to next page: >>
                    echo $pager->renderNext()." | ";

					//Display the link to last page: Last
					echo $pager->renderLast();

                echo "</div>";
                ?>

                </table>

                <?php

                //Display the full navigation in one go
                //echo $pager->renderFullNav();

                //Or you can display the inidividual links
                echo "<div style='padding:5px;' align=\"center\"><br />";

                //Display the link to first page: First
                echo $pager->renderFirst()." | ";

                //Display the link to previous page: <<
                echo $pager->renderPrev()." | ";

                //Display page links: 1 2 3
                echo $pager->renderNav()." | ";

                //Display the link to next page: >>
                echo $pager->renderNext()." | ";

				//Display the link to last page: Last
				echo $pager->renderLast();

    echo "</div>";
    ?>
            </div>
        </div>
    </div>
    <br />
    <?
    $qry_excel = "SELECT DISTINCT view_orderlab.TANGGAL,
					view_orderlab.NOMR, 
					view_orderlab.NAMA AS NAMA_PASIEN,
					view_orderlab.ALAMAT, 
					view_orderlab.POLY, 
					view_orderlab.NAMADOKTER AS DOKTER_PENGIRIM, 
					view_orderlab.CARABAYAR AS STATUS_BAYAR,
  					view_orderlab.RUJUKAN
			FROM view_orderlab 
			WHERE view_orderlab.STATUS = '0' ".$search;
?>
    <div align="left">
        <form name="formprint" method="post" action="gudang/excelexport.php" target="_blank" >
            <input type="hidden" name="query" value="<?=$qry_excel?>" />
            <input type="hidden" name="header" value="LIST ORDER LABORATORIUM" />
            <input type="hidden" name="filename" value="list_lab" />
            <input type="submit" value="Export To Ms Excel Document" class="text" />
        </form>
    </div>
</div>