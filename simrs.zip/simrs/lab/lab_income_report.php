<?php
/**
 * Created by Fernalia.
 * Contact : fernalia.h@gmail.com
 * User: Ferna
 * Date: 08/08/2016
 * Time: 21:53
 * Dea 16 Mei 2019 - Penataan dan Penambahan Script
 */

$tgl_kunjungan = "";

if(!empty($_GET['tgl_kunjungan']))
{
    $tgl_kunjungan =$_GET['tgl_kunjungan'];
}

$tgl_kunjungan2 = "";

if(!empty($_GET['tgl_kunjungan2']))
{
    $tgl_kunjungan2 =$_GET['tgl_kunjungan2'];
}

$sql = "SELECT DISTINCT ri_pendaftaran.tgl_daftar AS TANGGAL
        FROM ri_pendaftaran
            WHERE ri_pendaftaran.tgl_daftar BETWEEN '".$tgl_kunjungan."' AND '".$tgl_kunjungan2."' 
		UNION 
		SELECT DISTINCT t_pendaftaran.TGLREG AS TANGGAL
		FROM t_pendaftaran
		    WHERE t_pendaftaran.TGLREG BETWEEN '".$tgl_kunjungan."' AND '".$tgl_kunjungan2."'
		ORDER BY TANGGAL";

$rs  = mysql_query($sql);

while($row = mysql_fetch_array($rs))
{
    $tgl[] = $row['TANGGAL'];

    /* PENDAPATAN RAWAT JALAN */
    $sql_income = "SELECT t_billrajal.TANGGAL,
                          t_billrajal.CARABAYAR,
                          rsud_jenis_pasien.nama,
                          SUM(m_tarif2012.tarif * t_billrajal.QTY)AS subtotal
                    FROM t_billrajal
                        JOIN t_pendaftaran ON t_pendaftaran.IDXDAFTAR = t_billrajal.IDXDAFTAR AND t_pendaftaran.NOMR = t_billrajal.NOMR
                        JOIN rsud_jenis_pasien ON rsud_jenis_pasien.kode = t_billrajal.CARABAYAR
                        JOIN m_tarif2012 ON m_tarif2012.kode_tindakan = t_billrajal.KODETARIF
                        JOIN t_bayarrajal ON t_bayarrajal.NOBILL = t_billrajal.NOBILL
                            WHERE t_bayarrajal.STATUS != 'BATAL'
                            AND t_billrajal.KODETARIF LIKE '06.01.%'
                            AND t_billrajal.TANGGAL = '".$row['TANGGAL']."'
                            AND t_billrajal.APS = 0
                            AND t_pendaftaran.BATAL = 0
                            GROUP BY t_billrajal.CARABAYAR";

    $rs_income = mysql_query($sql_income);

    if(mysql_num_rows($rs_income))
    {
		$temp_umum 		 = 0;
		$temp_perusahaan = 0;
		
        while($row_income = mysql_fetch_array($rs_income))
        {
			if($row_income['CARABAYAR'] == 1)
			    {$temp_umum += $row_income['subtotal'];}
			else
			    {$temp_perusahaan += $row_income['subtotal'];}
        }
		$umum[] 	  = $temp_umum;
		$perusahaan[] = $temp_perusahaan;
    }
    else
    {
        $umum[]       = 0;
        $perusahaan[] = 0;
    }

    /* PENDAPATAN RAWAT INAP */
    $sql_income_inap = "SELECT ri_billing.tanggal,
					           ri_pendaftaran.id_cara_bayar,
							   rsud_jenis_pasien.nama,
							   SUM(ri_billing.tarif_rs * ri_billing.qty) AS subtotal,
							   ri_pendaftaran.is_ranap,
							   ri_billing.id_ruang
					    FROM ri_billing
                            JOIN ri_pendaftaran ON ri_pendaftaran.id_register = ri_billing.id_register
                            JOIN rsud_jenis_pasien ON rsud_jenis_pasien.kode = ri_pendaftaran.id_cara_bayar
                                WHERE ri_billing.is_batal = 0
                                AND ri_billing.id_group_tindakan = 'E02'
                                AND ri_billing.tanggal = '".$row['TANGGAL']."'
                                AND ri_pendaftaran.is_batal = 0 
                                GROUP BY ri_pendaftaran.id_cara_bayar, ri_pendaftaran.is_ranap";

    $rs_income_inap = mysql_query($sql_income_inap);
    if(mysql_num_rows($rs_income_inap)){
        $temp_umum_igd 		 = 0;
        $temp_perusahaan_igd = 0;

        $temp_umum_icu 		 = 0;
        $temp_perusahaan_icu = 0;

        $temp_umum_inap 	  = 0;
        $temp_perusahaan_inap = 0;

        /* script khusus yang memisahkan pendapatan melalui pendaftaran IGD kemudian menjadi rawat inap - Dea 16 Mei 2019
         * jika digunakan kembali script ini jgn lupa copy paste ke lab_income_report_excel.php

                while($row_income = mysql_fetch_array($rs_income_inap))
                {
                    if($row_income['is_ranap'] == 1 and $row_income['id_ruang'] == 'RUPK')
                    {
                        if($row_income['id_cara_bayar'] == 1)
                            {$temp_umum_icu += $row_income['subtotal'];}
                        else
                            {$temp_perusahaan_icu += $row_income['subtotal'];}
                    }
                    elseif($row_income['is_ranap'] == 1 and $row_income['id_ruang'] == 'RUGD')
                    {
                        if($row_income['id_cara_bayar'] == 1)
                            {$temp_umum_igd += $row_income['subtotal'];}
                        else
                            {$temp_perusahaan_igd += $row_income['subtotal'];}
                    }
                    elseif ($row_income['is_ranap'] == 1 and $row_income['id_ruang'] != 'RUGD' and $row_income['id_ruang'] != 'RUPK')
                    {
                        if($row_income['id_cara_bayar'] == 1)
                            {$temp_umum_inap += $row_income['subtotal'];}
                        else
                            {$temp_perusahaan_inap += $row_income['subtotal'];}
                    }
                    else
                    {
                        if($row_income['id_cara_bayar'] == 1)
                            {$temp_umum_igd += $row_income['subtotal'];}
                        else
                            {$temp_perusahaan_igd += $row_income['subtotal'];}
                    }
                }
        */

        while($row_income = mysql_fetch_array($rs_income_inap))
        {
            if($row_income['is_ranap'] == 1)
            {
                if($row_income['id_ruang'] == 'RUPK')
                {
                    if($row_income['id_cara_bayar'] == 1)
                    {$temp_umum_icu += $row_income['subtotal'];}
                    else
                    {$temp_perusahaan_icu += $row_income['subtotal'];}
                }
                else
                {
                    if($row_income['id_cara_bayar'] == 1)
                    {$temp_umum_inap += $row_income['subtotal'];}
                    else
                    {$temp_perusahaan_inap += $row_income['subtotal'];}
                }
            }
            else
            {
                if($row_income['id_cara_bayar'] == 1)
                {$temp_umum_igd += $row_income['subtotal'];}
                else
                {$temp_perusahaan_igd += $row_income['subtotal'];}
            }
        }


        $umum_igd[]       = $temp_umum_igd;
        $perusahaan_igd[] = $temp_perusahaan_igd;

        $umum_icu[]       = $temp_umum_icu;
        $perusahaan_icu[] = $temp_perusahaan_icu;

        $umum_inap[]       = $temp_umum_inap;
        $perusahaan_inap[] = $temp_perusahaan_inap;
    } else{
        $umum_igd[]       = 0;
        $perusahaan_igd[] = 0;

        $umum_icu[]       = 0;
        $perusahaan_icu[] = 0;

        $umum_inap[]       = 0;
        $perusahaan_inap[] = 0;
    }

	/* PENDAPATAN LUAR RS */
	$sql_income_aps = "SELECT t_billrajal.TANGGAL,
						      t_billrajal.CARABAYAR,
						      rsud_jenis_pasien.nama,
						      SUM(m_tarif2012.tarif * t_billrajal.QTY)AS subtotal
						FROM t_billrajal
						    JOIN t_pendaftaran_aps ON t_pendaftaran_aps.IDXDAFTAR = t_billrajal.IDXDAFTAR AND t_pendaftaran_aps.NOMR = t_billrajal.NOMR
                            JOIN rsud_jenis_pasien ON rsud_jenis_pasien.kode = t_billrajal.CARABAYAR
                            JOIN m_tarif2012 ON m_tarif2012.kode_tindakan = t_billrajal.KODETARIF
                            JOIN t_bayarrajal ON t_bayarrajal.NOBILL = t_billrajal.NOBILL
                                WHERE t_bayarrajal.STATUS != 'BATAL'
                                AND t_billrajal.KODETARIF LIKE '06.01.%'
                                AND t_billrajal.TANGGAL = '".$row['TANGGAL']."'
                                AND t_billrajal.APS = 1
                                AND t_pendaftaran_aps.batal = 0 ";

	$rs_income_aps = mysql_query($sql_income_aps);

    if(mysql_num_rows($rs_income_aps)){
        while($row_income_aps = mysql_fetch_array($rs_income_aps))
        {
            $luar_rs[] = $row_income_aps['subtotal'];
        }
    }
    else
    {
        $luar_rs[] = 0;
    }

    /* PENDAPATAN MCU */
    $sql_income_mcu = "SELECT SUM(mcu_detail_paket.tarif_margin) AS subtotal
                        FROM t_orderlab 
                            JOIN mcu_registrasi ON mcu_registrasi.id_registrasi = t_orderlab.IDXDAFTAR
                            JOIN mcu_detail_paket ON mcu_detail_paket.id_paket = mcu_registrasi.id_paket
                                WHERE t_orderlab.is_mcu = 1
                                AND t_orderlab.is_batal = 0
                                AND mcu_registrasi.is_batal = 0
                                AND t_orderlab.KODE LIKE '06.01.%'
                                AND mcu_detail_paket.kode_tindakan LIKE '06.01.%'
                                AND t_orderlab.TANGGAL = '".$row['TANGGAL']."' ";

    $rs_income_mcu = mysql_query($sql_income_mcu);

    if(mysql_num_rows($rs_income_mcu))
    {
        while($row_income_mcu = mysql_fetch_array($rs_income_mcu))
        {
            $mcu[] = $row_income_mcu['subtotal'];
        }
    }
    else
    {
        $mcu[] = 0;
    }
}

?>

<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>DAFTAR PENDAPATAN LABORATORIUM</h3>
        </div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table border="0" cellspacing="0" class="tb">
                    <tr>
                        <td>Tanggal</td>
                        <td><input type="text" name="tgl_kunjungan" id="tgl_pesan" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan!="") {
                                       echo $tgl_kunjungan;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>Sd</td>
                        <td><input type="text" name="tgl_kunjungan2" id="tgl_pesan2" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan2!="") {
                                       echo $tgl_kunjungan2;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                        <td>&nbsp;</td>
                        <td align="right"><input type="submit" value="C A R I" class="text"/>
                            <input type="hidden" name="link" value="report_lab04" /></td>
                    </tr>
                </table>
            </form>
            <div id="table_search" style="overflow: auto;">
                <table class="tb" width="95%" style="margin:10px;" border="0" cellspacing="1" cellspading="1">
                    <thead>
                    <tr>
                        <th rowspan="2">No. Urut</th>
                        <th rowspan="2">Tanggal</th>
                        <th colspan="2">Rawat Jalan</th>
                        <th colspan="2">Rawat Inap</th>
                        <th colspan="2">IGD</th>
                        <th colspan="2">ICU</th>
						<th rowspan="2">Luar RS</th>
						<th rowspan="2">MCU</th>
                    </tr>
                    <tr>
                        <th>Umum</th>
                        <th>Perusahaan</th>
						
						<th>Umum</th>
                        <th>Perusahaan</th>
						
						<th>Umum</th>
                        <th>Perusahaan</th>

						<th>Umum</th>
                        <th>Perusahaan</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php 
						$tot_um = 0; 
						$tot_prs = 0; 
						
						$tot_um_inap = 0;
						$tot_prs_inap = 0;
						
						$tot_um_igd = 0; 
						$tot_prs_igd = 0; 

						$tot_um_icu = 0; 
						$tot_prs_icu = 0; 
						
						$totluarrs = 0;

                        $totmcu = 0;
						
						for($i = 0; $i < mysql_num_rows($rs); $i++){ 
						$tot_um += $umum[$i]; 
						$tot_prs += $perusahaan[$i]; 
						
						$tot_um_inap += $umum_inap[$i];
						$tot_prs_inap += $perusahaan_inap[$i]; 
						
						$tot_um_igd += $umum_igd[$i]; 
						$tot_prs_igd += $perusahaan_igd[$i]; 

						$tot_um_icu += $umum_icu[$i]; 
						$tot_prs_icu += $perusahaan_icu[$i];
						
						$totluarrs += $luar_rs[$i];

						$totmcu += $mcu[$i];
					?>
                        <tr>
                            <td><?= $i + 1; ?></td>
                            <td><?= detailTgl($tgl[$i]); ?></td>
							
                            <td><?= CurFormat($umum[$i]); ?></td>
                            <td><?= CurFormat($perusahaan[$i]); ?></td>
							
							<td><?= CurFormat($umum_inap[$i]); ?></td>
                            <td><?= CurFormat($perusahaan_inap[$i]); ?></td>
							
							<td><?= CurFormat($umum_igd[$i]); ?></td>
                            <td><?= CurFormat($perusahaan_igd[$i]); ?></td>

                            <td><?= CurFormat($umum_icu[$i]); ?></td>
                            <td><?= CurFormat($perusahaan_icu[$i]); ?></td>
							
							<td><?= CurFormat($luar_rs[$i]); ?></td>

                            <td><?= CurFormat($mcu[$i]); ?></td>
                        </tr>
                    <?php } ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <td></td>
                        <td>Jumlah</td>
                        <td><?= CurFormat($tot_um); ?></td>
                        <td><?= CurFormat($tot_prs); ?></td>
						
						<td><?= CurFormat($tot_um_inap); ?></td>
                        <td><?= CurFormat($tot_prs_inap); ?></td>
						
						<td><?= CurFormat($tot_um_igd); ?></td>
                        <td><?= CurFormat($tot_prs_igd); ?></td>

                        <td><?= CurFormat($tot_um_icu); ?></td>
                        <td><?= CurFormat($tot_prs_icu); ?></td>
						
                        <td><?= CurFormat($totluarrs); ?></td>

                        <td><?= CurFormat($totmcu); ?></td>
                    </tr>
                    </tfoot>
                </table>
                <br/>
                <div style="alignment: left;">
                    <h4>JUMLAH SELURUHNYA : Rp. <?= CurFormat($tot_um+$tot_prs
															  +$tot_um_inap+$tot_prs_inap
															  +$tot_um_igd+$tot_prs_igd
															  +$tot_um_icu+$tot_prs_icu
															  +$totluarrs+$totmcu); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <br/>
    <div align="left">
        <form name="formprint" method="post" action="lab/report/lab_income_report_excel.php" target="_blank" >
            <input type="hidden" name="query" value="<?php echo $sql; ?>" />
            <input type="hidden" name="tgl1" value="<?php echo detailTgl($tgl_kunjungan); ?>" />
            <input type="hidden" name="tgl2" value="<?php echo detailTgl($tgl_kunjungan2); ?>" />
            <input type="hidden" name="filename" value="PENDAPATAN LABORATORIUM" />
            <input type="submit" value="Export To Ms Excel Document" class="text" />
        </form>
    </div>
</div>