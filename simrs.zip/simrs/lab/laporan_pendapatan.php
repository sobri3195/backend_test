<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 18/01/2016
 * Time: 13:40
 */

	session_start();

	include("include/connect.php");

	$search = " AND a.TANGGAL = CURDATE()";

	$tgl_kunjungan = "";
	if(!empty($_GET['tgl_kunjungan'])) {
        $tgl_kunjungan =$_GET['tgl_kunjungan'];
    }

	if($tgl_kunjungan !="") {
        $search = " AND a.TANGGAL BETWEEN  '".$tgl_kunjungan."' ";
    }

	$tgl_kunjungan2 = "";
	if(!empty($_GET['tgl_kunjungan2'])) {
        $tgl_kunjungan2 =$_GET['tgl_kunjungan2'];
    }


	if($tgl_kunjungan !="") {
        if($tgl_kunjungan2 !="") {
            $search = $search." AND '".$tgl_kunjungan2."' ";
        }else {
            $search = $search." AND '".$tgl_kunjungan."' ";
        }
    }

	$norm = "";
	if(!empty($_GET['norm'])) {
        $norm =$_GET['norm'];
    }

	if($norm !="") {
        $search = $search." AND a.NOMR = '".$norm."' ";
    }

	$nama = "";
	if(!empty($_GET['nama'])) {
        $nama =$_GET['nama'];
    }

	if($nama !="") {
        $search = $search." AND b.NAMA LIKE '%".$nama."%' ";
    }

	$jenisperiksa = "";
	if(!empty($_GET['jenisperiksa'])) {
        $jenisperiksa =$_GET['jenisperiksa'];
    }

	if($jenisperiksa !="") {
        $search = $search." AND a.KODE = '".$jenisperiksa."'";
    }

	$kdunit = "";
	if(!empty($_GET['kdunit'])) {
        $kdunit =$_GET['kdunit'];
    }

	if($kdunit !="") {
        $search = $search." AND a.KDPOLY = '".$kdunit."' ";
    }

	$jenisbayar = "";
	if(!empty($_GET['jenisbayar'])) {
        $jenisbayar =$_GET['jenisbayar'];
    }

	if($jenisbayar !="") {
        $search = $search . " and u.NAMA = '".$jenisbayar."' ";
    }

?>

<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>LAPORAN PENDAPATAN LABORATORIUM</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table border="0" cellspacing="0" class="tb">
                    <tr>
                        <td >No RM</td>
                        <td ><input type="text" name="norm" id="norm" value="<? if($norm!="") {
                                echo $norm;
                            }?>"
                                    class="text" style="width:80px;">
                        </td>
                        <td>Jns Pemeriksaan</td>
                        <td> <select class="text select2" name="jenisperiksa" id="jp">
                                <option value="" > -- </option>
                                <?
                                $q1="select * from m_tarif2012 where kode_unit= '16'";
                                $h1=mysql_query($q1);
                                while($b1=mysql_fetch_array($h1)) {
                                    ?>
                                    <option value="<?=$b1['kode_tindakan'];?>" <? if($b1['kode_tindakan']==$_GET['jenisperiksa']) echo "selected=selected"; ?> ><?=$b1['nama_tindakan'];?></option>
                                <? }?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td><input type="text" name="nama" id="nama" value="<? if($nama!="") {
                                echo $nama;
                            }?>" class="text"></td>
                        <td>Ruang / Poli</td>
                        <td> <select name="kdunit" id="kdunit" class="text select2">
                                <option value="" > -- </option>
                                <?php
                                $unit	= mysql_query("SELECT * FROM m_poly");
                                while($dataunit = mysql_fetch_array($unit)){
                                    ?>
                                    <option value="<?php echo $dataunit['kode']; ?>" <? if($dataunit['kode']==$_GET['kdunit']) echo "selected=selected"; ?>> <?php echo $dataunit['nama']; ?></option>
                                <?php
                                }
                                ?>
                            </select> </td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td><input type="text" name="tgl_kunjungan" id="tgl_pesan" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan!="") {
                                       echo $tgl_kunjungan;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                        <!--<td>Jns Bayar</td>
	                        <td><select class="text select2" name="jenisbayar" id="carab">
	                                <option value="" > -- </option>
	                                <? $q="select * from m_carabayar";
                        $h=mysql_query($q);

                        while($b=mysql_fetch_array($h)) {
                            ?>
	                                <option value="<?=$b['NAMA'];?>" <? if($b['NAMA']==$_GET['jenisbayar']) echo "selected=selected"; ?> ><?=$b['NAMA'];?></option>
	                                    <? }?>
	                            </select></td>-->
                    </tr>
                    <tr>
                        <td>Sd</td>
                        <td><input type="text" name="tgl_kunjungan2" id="tgl_pesan2" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan2!="") {
                                       echo $tgl_kunjungan2;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                        <td>&nbsp;</td>
                        <td align="right"><input type="submit" value="C A R I" class="text"/>
                            <input type="hidden" name="link" value="report_lab01" /></td>
                    </tr>
                </table>
            </form>
            <br/>
            <table id="table">
                <thead>
                <tr>
                    <th>No.</th>
                    <th>No. Registrasi</th>
                    <th>No. Medik</th>
                    <th>Nama</th>
                    <th>Jenis Pasien</th>
                    <th>Ruang / Poli</th>
                    <th>Jenis Pemeriksaan</th>
                    <th>Hospital Cost</th>
                    <th>Biaya Obat</th>
                    <th>Biaya Penunjang</th>
                    <th>Jumlah Biaya</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i 		= 0;
                $sql 	= mysql_query('SELECT a.TANGGAL,a.NOMR,b.NAMA,b.JENISKELAMIN,c.nama_unit,e.jasa_sarana,e.jasa_pelayanan,e.tarif,
												CASE a.rajal WHEN "1" THEN
													(SELECT u.NAMA FROM t_pendaftaran r JOIN m_carabayar u ON u.KODE = r.KDCARABAYAR
					                        		WHERE a.IDXDAFTAR = r.IDXDAFTAR)
												ELSE
													(SELECT u.NAMA FROM t_admission r JOIN m_carabayar u ON u.KODE = r.statusbayar
					                        		WHERE a.IDXDAFTAR = r.id_admission) END AS carabayar,a.IDXORDERLAB,e.nama_tindakan
												FROM t_orderlab a
												JOIN m_pasien b ON a.NOMR = b.NOMR
												JOIN m_unit c ON c.kode_unit = a.KDPOLY
					                            JOIN m_tarif2012 e ON e.kode_tindakan = a.KODE
												WHERE a.APS=0 '.$search.'
												UNION
												SELECT a.TANGGAL,a.NOMR,b.NAMA,b.JENISKELAMIN,c.nama_unit,e.jasa_sarana,e.jasa_pelayanan,e.tarif,
												CASE a.rajal WHEN "1" THEN
													(SELECT u.NAMA FROM t_pendaftaran_aps r JOIN m_carabayar u ON u.KODE = r.KDCARABAYAR
					                        		WHERE a.IDXDAFTAR = r.IDXDAFTAR) END AS carabayar,a.IDXORDERLAB,e.nama_tindakan
												FROM t_orderlab a
												JOIN m_pasien_aps b ON a.NOMR = b.NOMR
												JOIN m_unit c ON c.kode_unit = a.KDPOLY
					                            JOIN m_tarif2012 e ON e.kode_tindakan = a.KODE
												WHERE a.APS=1 '.$search);

                while($data = mysql_fetch_array($sql)){
                    ?>
                    <tr>
                        <td><?php echo ++$i . "."; ?></td>
                        <td><?php echo $data['IDXORDERLAB']; ?></td>
                        <td><?php echo $data['NOMR'];  ?></td>
                        <td><?php echo $data['NAMA']; ?></td>
                        <td><?php echo $data['carabayar']; ?></td>
                        <td><?php echo $data['nama_unit']; ?></td>
                        <td><?php echo $data['nama_tindakan']; ?></td>
                        <td><?php echo CurFormat($data['jasa_sarana']); ?></td>
                        <td><?php echo '-'; ?></td>
                        <td><?php echo CurFormat($data['tarif']); ?></td>
                        <td><?php echo CurFormat($data['jasa_sarana'] + $data['jasa_pelayanan']); ?></td>
                    </tr>
                <?php
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<br/>
<div align="left">
    <form name="formprint" method="post" action="lab/report/laporan_pendapatan_excel.php" target="_blank" >
        <input type="hidden" name="query" value="<?php echo $search; ?>" />
        <input type="submit" value="Export To Ms Excel Document" class="text" />
    </form>
</div>

<script type="text/javascript">
    jQuery("#table").dataTable();
    jQuery(".select2").select2();
</script>