<?php
    ob_start();
	session_start(); 
	include '../include/connect.php';
	include '../include/function.php';
	
	$total = 0;
	
	$sql_header = "SELECT DISTINCT t_orderlab.NOLAB,
						  t_orderlab.NOMR,
						  m_pasien.NAMA,
						  t_orderlab.TANGGAL,
						  t_orderlab.kd_ruang,
						  ri_ruang.NM_RUANG,
						  t_orderlab.DRPENGIRIM,
						  m_dokter.NAMADOKTER,
						  ri_pendaftaran.id_cara_bayar,
						  rsud_jenis_pasien.nama AS jenis_pasien
				   FROM t_orderlab
				   JOIN m_pasien ON m_pasien.NOMR = t_orderlab.NOMR
				   JOIN ri_ruang ON ri_ruang.KD_RUANG = t_orderlab.kd_ruang
				   JOIN m_dokter ON m_dokter.KDDOKTER = t_orderlab.DRPENGIRIM
				   JOIN ri_pendaftaran ON ri_pendaftaran.id_register = t_orderlab.IDXDAFTAR
				   JOIN rsud_jenis_pasien ON rsud_jenis_pasien.kode = ri_pendaftaran.id_cara_bayar
				   WHERE t_orderlab.NOMR = '".$_REQUEST['nomr']."'
					 AND t_orderlab.IDXDAFTAR = ".$_REQUEST['idx'];
					 
	$rs_header  = mysql_query($sql_header);
	$row_header = mysql_fetch_array($rs_header);
?>
	<div>
		<table cellspacing="0">
			<tr>
				<td colspan="3">
					<h2>Rawat Inap</h2>
				</td>			
			</tr>
			<tr>
				<td colspan="3">RSUD KOTA BOGOR</td>			
			</tr>
			<tr>
				<td colspan="3">
					Jl. Dr. Sumeru No. 120 Bogor Telp.(0251)312292
					<br />
				</td>			
			</tr>
			<tr>
				<td width="55px;">No.Rinci</td>
				<td width="10px;">:</td>
				<td><?php echo sprintf("%010d", $row_header['NOLAB']) . " / " . $row_header['NOMR'];?></td>
			</tr>
			<tr>
				<td>Tanggal</td>
				<td>:</td>
				<td><?php echo detailTgl($row_header['TANGGAL']); ?></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td>:</td>
				<td><?php echo strtoupper($row_header['NAMA']); ?></td>
			</tr>
			<tr>
				<td>Rujukan</td>
				<td>:</td>
				<td><?php echo $row_header['NM_RUANG']; ?></td>
			</tr>
			<tr>
				<td>Pengirim</td>
				<td>:</td>
				<td><?php echo $row_header['NAMADOKTER']; ?></td>
			</tr>
			<tr>
				<td>JP</td>
				<td>:</td>
				<td><?php echo $row_header['jenis_pasien']; ?></td>
			</tr>
		</table>
		<br/>
		<br/>
		
		<table class="table" width="330px;">
			<tr>
                <th colspan="3">
                    RINCIAN BIAYA LABORATORIUM
				</th>
			</tr>
			<tr>
                <th width="180px" style="border-style:dashed;border-bottom:dashed #000000;border-left:none;border-right:none;border-bottom-width: 1px;">Jenis Pemeriksaan</th>
                <th width="30px" style="border-style:dashed;border-bottom:dashed #000000;border-left:none;border-right:none;border-bottom-width: 1px;"></th>
                <th width="95px" style="border-style:dashed;border-bottom:dashed #000000;border-left:none;border-right:none;border-bottom-width: 1px;">Biaya</th>
			</tr>
			<?php 
				$getRincian 	= getRincianLabRanap($_REQUEST['nomr'], $_REQUEST['idx'], $_REQUEST['nolab']);
				while($row = mysql_fetch_array($getRincian)){
			?>
                <tr>
                    <td width="180px"><?php echo $row['nama_tindakan']; ?></td>
					<td width="30px" style="text-align:right">Rp.</td>
					<td style="text-align:right" width="95px">
						<?php 
							echo CurFormat($row['tarif_rs'],2); 
							$total 	= $total + $row['tarif_rs'];
						?>
					</td>
				</tr>
			<?php
				}
			?>
			<tr>
                <td style="border-top:dashed #000000;border-left:none;border-right:none;border-bottom:none;border-top-width: 1px;" >Jumlah Biaya</td>
				<td width="30px" style="text-align:right;border-top:dashed #000000;border-left:none;border-right:none;border-bottom:none;border-top-width: 1px;">Rp.</td>
				<td style="text-align:right;border-top:dashed #000000;border-left:none;border-right:none;border-bottom:none;border-top-width: 1px;">
					<?php echo CurFormat($total,2); ?>
				</td>
			</tr>
		</table>
		<br/>
		<br/>
	</div>
<?php
    $html      = ob_get_contents();
    $file_name = "Rincian Laboratorium";
    ob_end_clean();
    include "../include/PDF.php";
    include "../include/cetak_rincian_pdf.php";
?>