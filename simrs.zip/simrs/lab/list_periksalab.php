<?php session_start();
    include("../include/connect.php");
    require_once('ps_pagination.php');

    $start 	= date('Y-m-d');
    $end 	= date('Y-m-d');
    if($_REQUEST['tgl_kunjungan'] != ''){
        $start = $_REQUEST['tgl_kunjungan'];
    }
    if($_REQUEST['tgl_kunjungan2'] != ''){
        $end = $_REQUEST['tgl_kunjungan2'];
    }
    $search = 'and t_orderlab.TANGGAL BETWEEN "'.$start.'" and "'.$end.'"';
    $norm = "";
    if(!empty($_GET['norm'])) {
        $norm =$_GET['norm'];
    }

    $search2 = "";
    if($norm !="") {
        $search = $search." AND t_orderlab.NOMR = '".$norm."' ";
		$search2 = " OR b.NOMR_RS = '".$norm."' ";
    }

    $nama = "";
    if(!empty($_GET['nama'])) {
        $nama =$_GET['nama'];
    }

    $search_name1 = "";
    $search_name2 = "";
    $search_name3 = "";
    if($nama !="") {
        $search_name1 = ' AND b.NAMA LIKE "%'.$nama.'%" ';
        $search_name2 = ' AND m_pasien.NAMA LIKE "%'.$nama.'%" ';
        $search_name3 = ' AND mcu_registrasi.nama LIKE "%'.$nama.'%" ';
    }

    $filter = $_REQUEST['filter'] == true ? $_REQUEST['filter'] : 0;

?>

<div align="center">
    <div id="frame" style="width: 100%;">
        <div id="frame_title"><h3>LIST PEMERIKSAAN LAB</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table width="248" border="0" cellspacing="0" class="tb">
                    <tr>
                        <td width="52">No RM</td>
                        <td width="192"><input type="text" name="norm" id="norm" value="<? if($norm!="") {
                                echo $norm;
                            }?>" class="text" style="width:80px;"></td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td><input type="text" name="nama" id="nama" value="<? if($nama!="") {
                                echo $nama;
                            }?>" class="text"></td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td><input type="text" name="tgl_kunjungan" id="tgl_pesan" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($_REQUEST['tgl_kunjungan'] !=""): echo $_REQUEST['tgl_kunjungan']; else: echo date('Y-m-d'); endif; ?>"/></td>
                    </tr>
                    </tr>
                    <tr>
                        <td>Sd</td>
                        <td><input type="text" name="tgl_kunjungan2" id="tgl_pesan2" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($_REQUEST['tgl_kunjungan2'] !=""): echo $_REQUEST['tgl_kunjungan2']; else: echo date('Y-m-d'); endif; ?>"/></td>
                    </tr>
                    <tr>
                        <td>Filter</td>
                        <td>
                            <select class="text" name="filter" id="filter">
                                <option value="0" <?= $filter == 0 ? 'selected' : ''; ?>>Rawat Jalan</option>
                                <option value="1" <?= $filter == 1 ? 'selected' : ''; ?>>Rawat Inap</option>
                                <option value="2" <?= $filter == 2 ? 'selected' : ''; ?>>MCU</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td><input type="submit" value="Cari" class="text"/>
                            <input type="hidden" name="link" value="6order" /></td>
                    </tr>
                </table>

            </form>
            <div id="table_search">
                <table class="tb" width="95%" style="margin:10px;" border="0" cellspacing="1" cellspading="1" title="List Kunjungan Data Pasien Per Hari Ini">
                    <tr align="center">
                        <th>No</th>
                        <th>No RM</th>
                        <th>Tanggal</th>
                        <th>Nama Pasien</th>
                        <th>Alamat</th>
                        <th>Poli/ Ruang</th>
                        <th>Dokter Pengirim</th>
                        <th>Cara Bayar</th>
                        <th>Rujukan</th>
                        <th>&nbsp;</th>
                    </tr>
                    <?
                    $NO		= 0;
                    if($filter == 0){
                        $sql = 'SELECT DISTINCT t_orderlab.NOMR,
								   t_orderlab.IDXDAFTAR,
								   t_orderlab.TANGGAL,
								   t_orderlab.KDPOLY, 
								   t_orderlab.DRPENGIRIM, 
								   t_orderlab.RAJAL, 
								   t_orderlab.APS,
								   CASE aps WHEN 1 THEN (SELECT nama FROM m_pasien_aps b WHERE b.NOMR=t_orderlab.NOMR ) 
								   ELSE (SELECT nama FROM m_pasien b WHERE b.NOMR=t_orderlab.NOMR) END AS NAMA,
								   CASE aps WHEN 1 THEN (SELECT ALAMAT FROM m_pasien_aps b WHERE b.NOMR=t_orderlab.NOMR) 
								   ELSE (SELECT ALAMAT FROM m_pasien b WHERE b.NOMR=t_orderlab.NOMR) END AS ALAMAT,
								   CASE rajal WHEN 1 THEN (SELECT m_unit.nama_unit FROM m_unit WHERE m_unit.kode_unit = t_orderlab.KDPOLY) 
								   ELSE (SELECT m_ruang.nama FROM m_ruang WHERE m_ruang.no = t_orderlab.KDPOLY) END AS poly_kelas,
								   m_dokter.NAMADOKTER, 
								   t_pendaftaran.KDCARABAYAR, 
								   m_carabayar.NAMA AS carabayar,
								   t_orderlab.NOLAB,
								   t_orderlab.NOMR AS NOMR_RS,
								   t_orderlab.is_mcu
							FROM t_orderlab 
							JOIN t_pendaftaran ON t_pendaftaran.IDXDAFTAR = t_orderlab.IDXDAFTAR AND t_orderlab.NOMR=t_pendaftaran.NOMR
							JOIN m_carabayar ON m_carabayar.KODE = t_pendaftaran.KDCARABAYAR
							LEFT JOIN m_dokter ON m_dokter.KDDOKTER = t_orderlab.DRPENGIRIM 
							INNER JOIN m_pasien b ON t_orderlab.NOMR = b.NOMR
							WHERE t_orderlab.STATUS = 0 
							  AND t_orderlab.APS = 0
							  AND t_orderlab.is_batal = 0 '.$search.$search_name1.'
							UNION
							SELECT DISTINCT t_orderlab.NOMR,
								   t_orderlab.IDXDAFTAR,
								   t_orderlab.TANGGAL,
								   t_orderlab.KDPOLY, 
								   t_orderlab.DRPENGIRIM, 
								   t_orderlab.RAJAL, 
								   t_orderlab.APS,
								   (SELECT nama FROM m_pasien_aps b WHERE b.NOMR=t_orderlab.NOMR ) AS NAMA,
								   (SELECT ALAMAT FROM m_pasien_aps b WHERE b.NOMR=t_orderlab.NOMR) AS ALAMAT,
								   CASE rajal WHEN 1 THEN (SELECT m_unit.nama_unit FROM m_unit WHERE m_unit.kode_unit = t_orderlab.KDPOLY) 
								   ELSE (SELECT m_ruang.nama FROM m_ruang WHERE m_ruang.no = t_orderlab.KDPOLY) END AS poly_kelas,
								   m_dokter.NAMADOKTER, 
								   t_pendaftaran_aps.KDCARABAYAR,
								   m_carabayar.NAMA AS carabayar,
								   t_orderlab.NOLAB,
								   b.NOMR_RS,
								   t_orderlab.is_mcu
							FROM t_orderlab 
							JOIN t_pendaftaran_aps ON t_pendaftaran_aps.IDXDAFTAR = t_orderlab.IDXDAFTAR AND t_orderlab.NOMR=t_pendaftaran_aps.NOMR
							JOIN m_carabayar ON m_carabayar.KODE = t_pendaftaran_aps.KDCARABAYAR
							LEFT JOIN m_dokter ON m_dokter.KDDOKTER = t_orderlab.DRPENGIRIM 
							INNER JOIN m_pasien_aps b ON t_orderlab.NOMR = b.NOMR
							WHERE t_orderlab.STATUS = 0 
							  AND t_orderlab.APS = 1
							  AND t_orderlab.is_batal = 0 '.$search.$search2.$search_name1;
                    }

                    if($filter == 1){
                        $sql = ' SELECT DISTINCT t_orderlab.NOMR,
                                       t_orderlab.IDXDAFTAR,
                                      t_orderlab.TANGGAL,
                                      t_orderlab.kd_ruang AS KDPOLY,
                                      t_orderlab.DRPENGIRIM,
                                       t_orderlab.RAJAL,
                                      t_orderlab.APS,
                                       m_pasien.NAMA,
                                       m_pasien.ALAMAT,
                                       ri_ruang.NM_RUANG AS poly_kelas,
                                       m_dokter.NAMADOKTER,
                                       ri_pendaftaran.id_cara_bayar AS KDCARABAYAR,
                                       rsud_jenis_pasien.nama AS carabayar,
                                      t_orderlab.NOLAB,
                                      t_orderlab.NOMR AS NOMR_RS,
                                      t_orderlab.is_mcu
                               FROM `t_orderlab`
                               JOIN m_pasien ON m_pasien.NOMR = t_orderlab.NOMR
                               JOIN ri_ruang ON ri_ruang.KD_RUANG = t_orderlab.kd_ruang
                               JOIN m_dokter ON m_dokter.KDDOKTER = t_orderlab.DRPENGIRIM
                               JOIN ri_pendaftaran ON ri_pendaftaran.id_register = t_orderlab.IDXDAFTAR
                               JOIN rsud_jenis_pasien ON rsud_jenis_pasien.kode = ri_pendaftaran.id_cara_bayar
                               WHERE t_orderlab.STATUS = 0
                                  AND t_orderlab.is_batal = 0 '.$search.$search_name2;
                    }

                    if($filter == 2){
                        $sql = 'SELECT DISTINCT t_orderlab.NOMR,
							       t_orderlab.IDXDAFTAR,
								   t_orderlab.TANGGAL,
								   "-" AS KDPOLY,
								   t_orderlab.DRPENGIRIM,
								   t_orderlab.RAJAL,
								   t_orderlab.APS,
								   mcu_registrasi.NAMA,
								   mcu_registrasi.ALAMAT,
								   "MCU" AS poly_kelas,
								   m_dokter.NAMADOKTER,
								   mcu_registrasi.jenis_pasien AS KDCARABAYAR,
								   rsud_jenis_pasien.nama AS carabayar,
								   t_orderlab.NOLAB,
								   t_orderlab.NOMR AS NOMR_RS,
								   t_orderlab.is_mcu
							FROM `t_orderlab`
							JOIN mcu_registrasi ON mcu_registrasi.id_registrasi = t_orderlab.IDXDAFTAR
							JOIN m_dokter ON m_dokter.KDDOKTER = t_orderlab.DRPENGIRIM
							JOIN rsud_jenis_pasien ON rsud_jenis_pasien.kode = mcu_registrasi.jenis_pasien 
							WHERE t_orderlab.STATUS = 0
							  AND t_orderlab.is_batal = 0 '.$search_name3;
                    }

                    $pager = new PS_Pagination($connect, $sql, 15, 5, "tgl_kunjungan=".$tgl_kunjungan."&nama=".$nama."&norm=".$norm,"index.php?link=6&");
                    //The paginate() function returns a mysql result set
                    $rs = $pager->paginate();
                    if(!$rs) die(mysql_error());
                    while($data = mysql_fetch_array($rs)) {?>
                        <tr <?   echo "class =";
                        $count++;
                        if ($count % 2) {
                            echo "tr1";
                        }
                        else {
                            echo "tr2";
                        }
                        ?>>
                            <td><? $NO=($NO+1);
                                if ($_GET['page']==0) {
                                    $hal=0;
                                }else {
                                    $hal=$_GET['page']-1;
                                } echo

                                    ($hal*15)+$NO;?></td>
                            <td><? echo $data['NOMR_RS'];?></td>
                            <td><? echo $data['TANGGAL']; ?></td>
                            <td><? echo $data['NAMA']; ?></td>
                            <td><? echo $data['ALAMAT']; ?></td>
                            <td><? echo $data['poly_kelas']; ?></td>
                            <td><? echo $data['NAMADOKTER']; ?></td>
                            <td><? echo $data['carabayar'];?></td>
                            <td><? echo $data['RUJUKAN'];?></td>
                            <td>
								<?php if($data['is_mcu'] != 1){ ?>
								<?php if($data['RAJAL'] == 1){ ?>
								<!--<a href="index.php?link=62&amp;nomr=<?php echo $data['NOMR']?>&idx=<?php echo $data['IDXDAFTAR']?>&rajal=<?php echo $data['RAJAL']?>" >
                                    <input type="button" value="PERIKSA" class="text"/>
                                </a>-->
                                <a href="<?php echo _BASE_ ?>index.php?link=pasien01&nomr=<?php echo $data['NOMR']?>&idx=<?php echo $data['IDXDAFTAR']?>&opsi=1">
                                    <input type="button" value="EDIT PASIEN" class="text" />
                                </a>
                                <input type="button" value="PRINT RINCIAN" class="text print" nomr="<?php echo $data['NOMR']; ?>" idx="<?php echo $data['IDXDAFTAR']; ?>" aps="<?php echo $data['APS']; ?>" nolab="<?= $data['NOLAB']; ?>"/>
								<input type="button" value="EDIT RINCIAN" class="text btn_edit" nomr="<?php echo $data['NOMR']; ?>" idx="<?php echo $data['IDXDAFTAR']; ?>" nolab="<?= $data['NOLAB']; ?>"/>
								<input type="button" value="BATAL" class="text batal_rajal" nomr="<?php echo $data['NOMR']; ?>" idx="<?php echo $data['IDXDAFTAR']; ?>" nolab="<?= $data['NOLAB']; ?>" aps="<?php echo $data['APS']; ?>" nomr_rs="<?= $data['NOMR_RS']; ?>"/>
								
								<?php } else{ ?>
								<input type="button" value="PRINT RINCIAN" class="text print_ranap" nomr="<?php echo $data['NOMR']; ?>" idx="<?php echo $data['IDXDAFTAR']; ?>" aps="<?php echo $data['APS']; ?>" nolab="<?= $data['NOLAB']; ?>"/>
								<input type="button" value="EDIT RINCIAN" class="text btn_edit"nomr="<?php echo $data['NOMR']; ?>" idx="<?php echo $data['IDXDAFTAR']; ?>" nolab="<?= $data['NOLAB']; ?>"/>
								<input type="button" value="BATAL" class="text batal_ranap" nomr="<?php echo $data['NOMR']; ?>" idx="<?php echo $data['IDXDAFTAR']; ?>" nolab="<?= $data['NOLAB']; ?>"/>
								<?php } ?>
								<?php } ?>
							</td>
                        </tr>
                    <?	}

                    //Display the full navigation in one go
                    //echo $pager->renderFullNav();

                    //Or you can display the inidividual links
                    echo "<div style='padding:5px;' align=\"center\"><br />";

                    //Display the link to first page: First
                    echo $pager->renderFirst()." | ";

                    //Display the link to previous page: <<
                    echo $pager->renderPrev()." | ";

                    //Display page links: 1 2 3
                    echo $pager->renderNav()." | ";

                    //Display the link to next page: >>
                    echo $pager->renderNext()." | ";

                    //Display the link to last page: Last
                    echo $pager->renderLast();

                    echo "</div>";
                    ?>

                </table>

                <?php

                //Display the full navigation in one go
                //echo $pager->renderFullNav();

                //Or you can display the inidividual links
                echo "<div style='padding:5px;' align=\"center\"><br />";

                //Display the link to first page: First
                echo $pager->renderFirst()." | ";

                //Display the link to previous page: <<
                echo $pager->renderPrev()." | ";

                //Display page links: 1 2 3
                echo $pager->renderNav()." | ";

                //Display the link to next page: >>
                echo $pager->renderNext()." | ";

                //Display the link to last page: Last
                echo $pager->renderLast();

                echo "</div>";
                ?>
            </div>
        </div>
    </div>
    <br />
    <?
    $qry_excel = "SELECT DISTINCT view_orderlab.TANGGAL,
					view_orderlab.NOMR, 
					view_orderlab.NAMA AS NAMA_PASIEN,
					view_orderlab.ALAMAT, 
					view_orderlab.POLY, 
					view_orderlab.NAMADOKTER AS DOKTER_PENGIRIM, 
					view_orderlab.CARABAYAR AS STATUS_BAYAR,
  					view_orderlab.RUJUKAN
			FROM view_orderlab 
			WHERE view_orderlab.STATUS = '0' ".$search;
    ?>
    <div align="left">
        <form name="formprint" method="post" action="gudang/excelexport.php" target="_blank" >
            <input type="hidden" name="query" value="<?=$qry_excel?>" />
            <input type="hidden" name="header" value="LIST ORDER LABORATORIUM" />
            <input type="hidden" name="filename" value="list_lab" />
            <input type="submit" value="Export To Ms Excel Document" class="text" />
        </form>
    </div>
</div>

<div id="table_pemeriksaan"></div>

<script type="text/javascript">
    jQuery("label").css({display: 'block',marginBottom: '10px'});
    jQuery("textarea").css({marginBottom:'12px',width: '450px',height: '200px',padding: '.4em'});
    jQuery("fieldset").css({padding:'0',border:'0', marginTop:'25px'});

    jQuery(".print").click(function(){
        var nomr 	= jQuery(this).attr('nomr');
        var idx 	= jQuery(this).attr('idx');
        var aps     = jQuery(this).attr('aps');
		var nolab 	= jQuery(this).attr('nolab');

        window.open('lab/print_rincian_periksa_lab.php?nomr='+nomr+'&idx='+idx+'&nolab='+nolab);
    });
	
	jQuery(".print_ranap").click(function(){
        var nomr 	= jQuery(this).attr('nomr');
        var idx 	= jQuery(this).attr('idx');
		var nolab 	= jQuery(this).attr('nolab');

        window.open('lab/print_rincian_periksa_lab_ranap.php?nomr='+nomr+'&idx='+idx+'&nolab='+nolab);
    });

    jQuery(".edit_pemeriksaan").click(function(){
        var nomr 	= jQuery(this).attr('nomr');
        var idx 	= jQuery(this).attr('idx');
        var aps     = jQuery(this).attr('aps');

        jQuery("#table_pemeriksaan").html('');

        jQuery.ajax({
            url: "<?=_BASE_?>lab/controller/c_lab.php",
            data: {nomr:nomr,idx:idx,aps:aps,opsi:1},
            type: "post",
            success: function(data){
                jQuery("#table_pemeriksaan").html(data);
            }
        });
    });
	
	jQuery(".btn_edit").click(function(){
		var nomr    = jQuery(this).attr('nomr');
		var idx 	= jQuery(this).attr('idx');
		var nolab 	= jQuery(this).attr('nolab');
		
		window.location.replace("<?= _BASE_ ?>index.php?link=edit_rincian_lab&nomr="+nomr+"&idx="+idx+"&nolab="+nolab);
	});
	
	jQuery('.batal_rajal').click(function(){
		var nomr    = jQuery(this).attr('nomr');
        var idx     = jQuery(this).attr('idx');
		var nolab 	= jQuery(this).attr('nolab');
		var aps     = jQuery(this).attr('aps');
		var nomr_rs = jQuery(this).attr('nomr_rs');
		var conuser = confirm('Apakah Anda yakin akan membatalkan transaksi ini?');
		if(conuser == true){
			jQuery.ajax({
				url: "<?=_BASE_?>lab/model/m_lab.php",
				data: {nomr:nomr,idx:idx,nolab:nolab,aps:aps,nomr_rs:nomr_rs,opsi:3},
				type: "post",
				success: function(data){
					location.reload();
				}
			});
		}
	});
	
	jQuery('.batal_ranap').click(function(){
		var nomr    = jQuery(this).attr('nomr');
        var idx     = jQuery(this).attr('idx');
		var nolab 	= jQuery(this).attr('nolab');
		var conuser = confirm('Apakah Anda yakin akan membatalkan transaksi ini?');
		if(conuser == true){
			jQuery.ajax({
				url: "<?=_BASE_?>lab/model/m_lab.php",
				data: {nomr:nomr,idx:idx,nolab:nolab,opsi:2},
				type: "post",
				success: function(data){
					location.reload();
				}
			});
		}
	});
</script>