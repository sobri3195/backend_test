  <?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 18/01/2016
 * Time: 14:01
 */

session_start();

include("include/connect.php");

$search = " AND t_orderlab.TANGGAL = CURDATE()";

$tgl_kunjungan = "";
if(!empty($_GET['tgl_kunjungan'])) {
    $tgl_kunjungan =$_GET['tgl_kunjungan'];
}

if($tgl_kunjungan !="") {
    $search = " AND t_orderlab.TANGGAL BETWEEN  '".$tgl_kunjungan."' ";
}

$tgl_kunjungan2 = "";
if(!empty($_GET['tgl_kunjungan2'])) {
    $tgl_kunjungan2 =$_GET['tgl_kunjungan2'];
}

if($tgl_kunjungan !="") {
    if($tgl_kunjungan2 !="") {
        $search = $search." AND '".$tgl_kunjungan2."' ";
    }else {
        $search = $search." AND '".$tgl_kunjungan."' ";
    }
}
?>
<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>DAFTAR KUNJUNGAN LABORATORIUM BERDASARKAN RUANGAN</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table border="0" cellspacing="0" class="tb">
                    <tr>
                        <td>Tanggal</td>
                        <td><input type="text" name="tgl_kunjungan" id="tgl_pesan" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan!="") {
                                       echo $tgl_kunjungan;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>Sd</td>
                        <td><input type="text" name="tgl_kunjungan2" id="tgl_pesan2" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan2!="") {
                                       echo $tgl_kunjungan2;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td align="right"><input type="submit" value="C A R I" class="text"/>
                            <input type="hidden" name="link" value="report_lab05" />
                        </td>
                    </tr>
                </table>
            </form>
            <br/>
            <table class="tb" width="95%" style="margin:10px;" border="0" cellspacing="1" cellspading="1">
                <thead>
                <tr>
                    <th>No.</th>
                    <th>Tanggal</th>
					<?php
						$id_ruang = array();
						$sql	  = "SELECT DISTINCT t_orderlab.KD_RUANG, 
										    ri_ruang.NM_RUANG
									 FROM t_orderlab
									 JOIN ri_ruang ON ri_ruang.KD_RUANG = t_orderlab.kd_ruang
									 WHERE 1=1 ". $search .";";
						$rs_ruang = mysql_query($sql);
						while($row_ruang = mysql_fetch_array($rs_ruang)){
							$id_ruang[] = $row_ruang['KD_RUANG'];
							echo '<th>'.$row_ruang['NM_RUANG'].'</th>';
						}
					?>
					<th>Total</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $no 	= 0;
				$query  = "SELECT DISTINCT t_orderlab.TANGGAL FROM t_orderlab
										WHERE 1=1 ". $search .";";
                $sql	= mysql_query($query);
				
                while($data = mysql_fetch_array($sql)){
                ?>
                    <tr>
                        <td><?= $no + 1; ?></td>
                        <td><?= date("d-m-Y",strtotime($data['TANGGAL'])) ?></td>
                        <?php
							$total = 0;
							for($i = 0; $i < count($id_ruang); $i++){
								//Ranap
								$sql_ranap = 'SELECT t_orderlab.TANGGAL,
													 t_orderlab.kd_ruang,
													 COUNT(DISTINCT t_orderlab.NOLAB) AS jml
											  FROM t_orderlab
											  JOIN ri_pendaftaran ON ri_pendaftaran.id_register = t_orderlab.IDXDAFTAR
											  WHERE ri_pendaftaran.is_batal = 0
												AND t_orderlab.RAJAL = 0 
												AND t_orderlab.is_batal = 0
												AND t_orderlab.TANGGAL = "'.$data['TANGGAL'].'" 
												AND t_orderlab.kd_ruang = "'. $id_ruang[$i] .'"
											  GROUP BY t_orderlab.kd_ruang';
								$rs_ranap  = mysql_query($sql_ranap);
								$row_ranap = mysql_fetch_array($rs_ranap);
								echo '<td>'.$row_ranap['jml'].'</td>';
								$total += $row_ranap['jml'];
							}
						?>
                        <td><?= $total; ?></td>
                    </tr>
                <?php
                $no++;
				}
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<br/>
<div align="left">
    <form name="formprint" method="post" action="lab/report/laporan_daftar_kunjungan_by_ruangan_excel.php" target="_blank" >
        <input type="hidden" name="query" value="<?php echo $search; ?>" />
        <input type="submit" value="Export To Ms Excel Document" class="text" />
    </form>
</div>

<script type="text/javascript">
    //jQuery("#table").dataTable();
    jQuery(".select2").select2();
</script>