<div align="center">
    <div id="frame" style="width:100%;">
    <div id="frame_title"><h3>ORDER LABORATORIUM</h3></div>
<?php 
include("../include/connect.php");
$sql = mysql_query('SELECT DISTINCT a.nomr,a.idxdaftar,a.tanggal,a.KDPOLY, a.DRPENGIRIM, a.NOLAB as nourut, 
CASE aps WHEN 1 THEN 
(SELECT nama FROM m_pasien_aps b WHERE b.NOMR=a.NOMR) 
ELSE 
(SELECT nama FROM m_pasien b WHERE b.NOMR=a.NOMR) END AS nama,
CASE aps WHEN 1 THEN
(SELECT alamat FROM m_pasien_aps b WHERE b.NOMR=a.NOMR) 
ELSE 
(SELECT alamat FROM m_pasien b WHERE b.NOMR=a.NOMR) END AS alamat,
CASE aps WHEN 1 THEN
(SELECT kdcarabayar FROM m_pasien_aps b WHERE b.NOMR=a.NOMR) 
ELSE 
(SELECT kdcarabayar FROM m_pasien b WHERE b.NOMR=a.NOMR) END AS KDCARABAYR,
CASE aps WHEN 1 THEN
(SELECT tgllahir FROM m_pasien_aps b WHERE b.NOMR=a.NOMR) 
ELSE 
(SELECT tgllahir FROM m_pasien b WHERE b.NOMR=a.NOMR) END AS TGLLAHIR,
CASE aps WHEN 1 THEN
(SELECT jeniskelamin FROM m_pasien_aps b WHERE b.NOMR=a.NOMR) 
ELSE 
(SELECT jeniskelamin FROM m_pasien b WHERE b.NOMR=a.NOMR) END AS JENISKELAMIN,
CASE aps WHEN 1 THEN
(SELECT c.nama FROM m_carabayar c , m_pasien_aps p WHERE c.kode=p.kdcarabayar AND a.nomr=p.nomr) 
ELSE 
(SELECT c.nama FROM m_carabayar c , m_pasien p WHERE c.kode=p.kdcarabayar AND a.nomr=p.nomr)  END AS CARABAYAR,
CASE rajal WHEN 1 THEN
(SELECT m_unit.nama_unit FROM m_unit WHERE m_unit.kode_unit = a.KDPOLY) 
ELSE 
(SELECT m_ruang.nama FROM m_ruang WHERE m_ruang.no = a.KDPOLY) 
  END AS poly_kelas,

 m_dokter.NAMADOKTER
FROM t_orderlab a
LEFT JOIN m_dokter ON m_dokter.KDDOKTER = a.DRPENGIRIM
where a.NOMR = "'.$_REQUEST['nomr'].'" and a.IDXDAFTAR = "'.$_REQUEST['idx'].'"');
$userdata	= mysql_fetch_array($sql);
/*
$idx_daftar = $_GET["idx"];

$sql = "SELECT DISTINCT M.kode_jasa, M.nama_jasa FROM m_lab M
			  WHERE kode_jasa in(SELECT m_lab.group_jasa FROM
    		  m_lab inner join t_orderlab on (m_lab.kode_jasa = t_orderlab.KODE)
			  WHERE t_orderlab.IDXDAFTAR = '$idx_daftar' AND t_orderlab.STATUS = '0')";
			  
$row = mysql_query($sql)or die(mysql_error());
*/
?>
<fieldset class="fieldset">
      <legend>Identitas </legend>
<?php
/*
if($_GET['rajal']=="1"){
	$myquery = "select distinct `t_orderlab`.`NOMR` AS `NOMR`,
    `t_orderlab`.`IDXDAFTAR` AS `IDXDAFTAR`, `t_orderlab`.`TANGGAL` AS `TANGGAL`,
    `m_pasien`.`NAMA` AS `NAMA`, `m_pasien`.`ALAMAT` AS `ALAMAT`,
    `m_pasien`.`JENISKELAMIN` AS `JENISKELAMIN`, `m_pasien`.`TGLLAHIR` AS `TGLLAHIR`,
    `m_poly`.`nama` AS `POLY`, `m_dokter`.`NAMADOKTER` AS `NAMADOKTER`,
    `m_carabayar`.`NAMA` AS `CARABAYAR`, `m_rujukan`.`NAMA` AS `RUJUKAN`,
    `t_orderlab`.`STATUS` AS `STATUS`, `t_orderlab`.`NOLAB` AS `NOLAB`,
    `t_orderlab`.RAJAL  AS RAJAL 
  from 
    ((((((`t_orderlab` join `m_pasien` on((`t_orderlab`.`NOMR` = `m_pasien`.`NOMR`))) join `m_poly` on((`t_orderlab`.`KDPOLY` = `m_poly`.`kode`))) join `t_pendaftaran` on((`t_orderlab`.`IDXDAFTAR` = `t_pendaftaran`.`IDXDAFTAR`))) join `m_carabayar` on((`t_pendaftaran`.`KDCARABAYAR` = `m_carabayar`.`KODE`))) join `m_rujukan` on((`t_pendaftaran`.`KDRUJUK` = `m_rujukan`.`KODE`))) join `m_dokter` on((`t_orderlab`.`DRPENGIRIM` = `m_dokter`.`KDDOKTER`))) 
  where 
    (`t_orderlab`.`RAJAL` = '1' and `t_orderlab`.`IDXDAFTAR` = '".$_GET["idx"]."')";
}else{
	$myquery = "select distinct `t_orderlab`.`NOMR` AS `NOMR`, `t_orderlab`.`IDXDAFTAR` AS 		
	`IDXDAFTAR`, `t_orderlab`.`TANGGAL` AS `TANGGAL`,
    `m_pasien`.`NAMA` AS `NAMA`, `m_pasien`.`ALAMAT` AS `ALAMAT`,
    `m_pasien`.`JENISKELAMIN` AS `JENISKELAMIN`, `m_pasien`.`TGLLAHIR` AS `TGLLAHIR`,
    `m_ruang`.`nama` AS `POLY`, `m_dokter`.`NAMADOKTER` AS `NAMADOKTER`,
    `m_carabayar`.`NAMA` AS `CARABAYAR`, `m_rujukan`.`NAMA` AS `RUJUKAN`,
    `t_orderlab`.`STATUS` AS `STATUS`, `t_orderlab`.`NOLAB` AS `NOLAB`, 
    `t_orderlab`.RAJAL  AS RAJAL
  from 
    ((((((`t_orderlab` join `m_pasien` on((`t_orderlab`.`NOMR` = `m_pasien`.`NOMR`))) join `m_ruang` on((`t_orderlab`.`KDPOLY` = `m_ruang`.`no`))) join `t_admission` on((`t_orderlab`.`IDXDAFTAR` = `t_admission`.`id_admission`))) join `m_carabayar` on((`t_admission`.`statusbayar` = `m_carabayar`.`KODE`))) join `m_rujukan` on((`t_admission`.`kd_rujuk` = `m_rujukan`.`KODE`))) join `m_dokter` on((`t_orderlab`.`DRPENGIRIM` = `m_dokter`.`KDDOKTER`))) 
  where 
    (`t_orderlab`.`RAJAL` = '0' and `t_orderlab`.`IDXDAFTAR` = '".$_GET["idx"]."')";
}

			  
  		$get = mysql_query ($myquery)or die(mysql_error());
		$userdata = mysql_fetch_assoc($get); 		
		$nomr=$userdata['NOMR'];
		$idxdaftar=$userdata['IDXDAFTAR'];
		$kdpoly=$userdata['POLY'];
		$kddokter=$userdata['NAMADOKTER'];
		$tglreg=$userdata['TANGGAL'];
		
$qry_jam = "SELECT NOW() AS TANGGAL, MONTH(NOW()) AS BULAN, YEAR(NOW()) AS TAHUN";
$get_jam = mysql_query($qry_jam);
$dat_jam = mysql_fetch_assoc($get_jam);

$thn = $dat_jam['TAHUN'];
$bln = $dat_jam['BULAN'];

$sql_nourut = "SELECT NOLAB FROM t_orderlab WHERE YEAR(TGL_MULAI) = '".$thn."' 
                AND MONTH(TGL_MULAI) = '".$bln."'
				AND STATUS = '1'
				ORDER BY IDXORDERLAB DESC LIMIT 1";
 $get_nourut = mysql_query($sql_nourut);				
 if(mysql_num_rows($get_nourut) > 0){
     $dat_nourut = mysql_fetch_assoc($get_nourut);
	 $no_last = $dat_nourut['NOLAB'] + 1;
	 $nourut = substr("00000",0,5-strlen($no_last)).$no_last;
 }else{
     $nourut = "00001";
 }
 
 */
?>    		
      
<table class="tb" width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td>No MR</td>
          <td width="80%"><?php echo $userdata['nomr'];?></td>
        </tr>
        <tr>
          <td width="21%">Nama Pasien</td>
          <td width="79%"><?php echo $userdata['nama'];?></td>
        </tr>
        <tr>
          <td valign="top">Alamat </td>
          <td><?php echo $userdata['alamat'];?></td>
        </tr>
        <tr>
          <td valign="top">Jenis Kelamin</td>
          <td colspan="2"><? if($userdata['JENISKELAMIN']=="l" || $userdata['JENISKELAMIN']=="L"){echo"Laki-Laki";}elseif($userdata['JENISKELAMIN']=="p" || $userdata['JENISKELAMIN']=="P"){echo"Perempuan";} ?> <?php echo"( ". $userdata['JENISKELAMIN']." )";?></td>
          </tr>
        <tr>
          <td valign="top">Tanggal Lahir</td>
          <td>
            <?php echo $userdata['TGLLAHIR'];?>
          </td>
        </tr>
        <tr>
          <td valign="top">Umur</td>
          <td><?php
		  $a = datediff($userdata['TGLLAHIR'],date('Y-m-d'));
		  echo $a[years]." tahun ".$a[months]." bulan ".$a[days]." hari"; 
		  ?></td>
        </tr>
        <tr>
          <td valign="top">Cara Bayar</td>
          <td><?php echo $userdata['CARABAYAR'];?></td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td>&nbsp;</td>
        </tr>

      </table>
    </fieldset>
    
<div id="addlab"></div>

<fieldset class="fieldset">
      <legend>Hasil Periksa</legend>
      
<div id="savelaborder" ></div>
<form id="inpLab" name="inpLab" method="post" action="lab/savelab.php">
    <table class="tb" width="100%">    
       <tr>
          <td>Dokter Pengirim</td>
          <td colspan="2" width="80%"><?php echo $userdata['NAMADOKTER']?></td>
       </tr>
        <tr>
          <td>Poly/Ruang Pengirim</td>
          <td colspan="2"><?php echo $userdata['poly_kelas']?></td>
       </tr>
       
        <tr>
          <td>Tanggal Registrasi</td>
          <td colspan="2"><?php echo $userdata['tanggal']?></td>
       </tr>
         <tr>
          <td>Jam Mulai</td>
          <td colspan="2"><div id="mulai" ><input type="text" name="jamMulai" id="jamMulai" class="text" style="width:150px" readonly="readonly" value="<?=$dat_jam['TANGGAL'];?>" />&nbsp;<input type="button" value="Skr" class="text" onclick="MyAjaxRequest('mulai','lab/getjam.php?mulai=1'); return false;" /></div></td>
       </tr>
         <tr>
          <td>Jam Selesai</td>
          <td colspan="2"><div id="selesai" ><input type="text" name="jamSelesai" id="jamSelesai" class="text" style="width:150px" readonly="readonly" />&nbsp;<input type="button" value="Skr"class="text" onclick="MyAjaxRequest('selesai','lab/getjam.php?selesai=1'); return false;"/></div></td>
       </tr>
         <tr>
           <td>Shift</td>
           <!--<td colspan="2"><input type="radio" name="SHIF" value="1"  checked="checked"/> 1 <input type="radio" name="SHIF" value="2" /> 2 <input type="radio" name="SHIF" value="3" /> 3</td>-->
           <td>
           		<?php 
	           		//added by ferna 25062015
	           		//waktu sekarang pada database
	           		$sql = mysql_query("SELECT TIME(now()) as time");
	           		while($ds = mysql_fetch_array($sql)){
	           			$now = $ds['time'];
	           			$jam = substr($now, 0, 2);
	           			$menit = substr($now, 3, 2);
	           			$detik = substr($now, 6, 2);
	           		}
	           			
	           		$jam_now = new DateTime($now);
	           		$jam_pagi_bawah = new DateTime("07:00:00");
	           		$jam_pagi_atas = new DateTime("14:15:00");
	           		$jam_sore_atas = new DateTime("21:15:00");
           		?>
	         	<input type="radio" name="SHIFT" class="required" title="*" value="1" <? if($jam_now > $jam_pagi_bawah && $jam_now < $jam_pagi_atas) echo "Checked";?>/>
				Pagi
	            <input type="radio" name="SHIFT" class="required" title="*" value="2" <? if($jam_now > $jam_pagi_atas && $jam_now < $jam_sore_atas) echo "Checked";?>/>
	            Sore
           </td>
         </tr>
         <tr>
           <td>Petugas Laboratorium</td>
           <td colspan="2"><input type="text" name="petugas" id="petugas" class="text" style="width:200px"/></td>
         </tr>
          <tr>
           <td>No Lab</td>
           <td colspan="2"><input type="text" name="nolab" id="nolab" value="<?=$userdata['nourut']?>" class="text" style="width:200px" readonly="readonly"/></td>
         </tr>
        <tr>
           <td>Catatan</td>
           <td colspan="2"><textarea name="keterangan" cols="75" rows="5" ></textarea></td>
         </tr>
    </table>
    <br />
    
    <div id="orderlab" >
    <table class="tb" width="100%">
    <tr><th width="20px">No</th><th>Jenis Pemeriksaan</th><th width="150px">Hasil</th><th>Nilai Normal</th><th width="20px" >Unit</th><th>&nbsp;</th></tr>
    <?php
    $sql_d = mysql_query('SELECT a.IDXORDERLAB, a.KODE, a.IDXDAFTAR, a.HASIL_PERIKSA, a.KETERANGAN,a.TGL_MULAI, a.TGL_SELESAI, a.STATUS, a.KET, b.nama_tindakan, 
    a.TANGGAL
    FROM t_orderlab a
    JOIN m_tarif2012 b ON (a.KODE = b.kode_tindakan)
    WHERE a.IDXDAFTAR = "'.$userdata['idxdaftar'].'" AND a.STATUS = 0');
    if(mysql_num_rows($sql_d) > 0):
		$i = 1;
		while($dlab	= mysql_fetch_array($sql_d)){
			echo '<tr>';
				echo '<td>'.$i.'</td>';
				echo '<td>'.$dlab['nama_tindakan'].'</td>';
				echo '<td><input type="text" name="hasil[]" class="text" style="width:100px" /></td>';
				//$myquery1 = 'SELECT * from m_lab where nama_jasa = "'.trim($dlab['nama_tindakan']).'"';
                $myquery1   = 'SELECT * FROM m_lab WHERE kode_jasa = "'.$dlab['KODE'].'"';
				$get1 = mysql_query ($myquery1)or die(mysql_error());
				$data = mysql_fetch_assoc($get1);
				$tampungdata = "";
				if($userdata['JENISKELAMIN']=="l" || $userdata['JENISKELAMIN']=="L"){
//					if($a[years]<1){ $tampungdata = $data['nilai_normal_lk_bayi']; }
//					else if($a[years]<5){ $tampungdata = $data['nilai_normal_lk_balita']; }
//					else if($a[years]<18){ $tampungdata = $data['nilai_normal_lk_anak']; }
//					else if($a[years]>=18){ $tampungdata = $data['nilai_normal_lk_dewasa']; }
                    $tampungdata = $data['nilai_normal_lk_dewasa'];
				}elseif($userdata['JENISKELAMIN']=="p" || $userdata['JENISKELAMIN']=="P"){
//					if($a[years]<1){ $tampungdata = $data['nilai_normal_pr_bayi']; }
//					else if($a[years]<5){ $tampungdata = $data['nilai_normal_pr_balita']; }
//					else if($a[years]<18){ $tampungdata = $data['nilai_normal_pr_anak']; }
//					else if($a[years]>=18){ $tampungdata = $data['nilai_normal_pr_dewasa']; }
                    $tampungdata = $data['nilai_normal_pr_dewasa'];
				}
				echo '<td><input type="text" name="nilainormal[]" value="'.$tampungdata.'" class="text" style="width:100px" readonly/></td>';
				echo '<td><input type="text" name="unit[]" value="'.$data['unit'].'" class="text" style="width:100px" readonly/></td>';
				echo '<td><input type="hidden" name="id[]" value="'.$dlab['IDXORDERLAB'].'"></td>';
			echo '</tr>';
			$i++;
		}
	endif;
    ?>
    </table>
    <input type="submit" value="S i m p a n"  class="text" />
    </form>
     </fieldset>
</div>
</div>
<script language="javascript" type="text/javascript" >
</script>