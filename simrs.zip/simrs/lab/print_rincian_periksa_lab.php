<?php
    ob_start();
	session_start(); 
	include '../include/connect.php';
	include '../include/function.php';
	
	$cekPasien 		= cek_pasienStatus($_REQUEST['nomr'], $_REQUEST['idx']);
	$cekPasienAPS	= cek_pasienAPSStatus($_REQUEST['nomr'], $_REQUEST['idx']);
	
	$now			= datenow();
	$tgl 			= detailTgl($now);
	
	if($cekPasien > 0){
		$datapend   = get_t_pendaftaran($_REQUEST['idx'], $_REQUEST['nomr']);
		$tgl 		= detailTgl($datapend['TGLREG']);
		$kdcarabyr  = $datapend['KDCARABAYAR'];
		$rs_jp		= getallcarabayar($kdcarabyr);
		$row_jp		= $rs_jp['NAMA'];
		$jp			= $kdcarabyr == 5 ? "BPJS" : $row_jp;
		
		$datapasien = cek_pasien($_REQUEST['nomr']);
		while ($dp = mysql_fetch_array($datapasien)){
			$nomr   = $_REQUEST['nomr'];
			$nama	= $dp['NAMA'];
			$title 	= $dp['TITLE'];
			if($title != ''){
				$nama	= $nama.", ".$title;
			}
		}
		
		$getRincian 	= getRincianLabKiriman($_REQUEST['nomr'], $_REQUEST['idx'], $_REQUEST['nolab']);
		$jmlRow 		= mysql_num_rows($getRincian);
		while($data = mysql_fetch_array($getRincian)){
			$nama_tindakan[]	= $data['nama_tindakan'];
			$tottariflab[]		= $data['tarif'];
			$nolab 				= $data['NOLAB'];
			$drpengirim			= $data['DRPENGIRIM'];
			$kdpoly 			= $data['KDPOLY'];
		}
	}
	else{
		$datapend   = getPendaftaranAPS($_REQUEST['idx']);
		$row_pend	= mysql_fetch_array($datapend);
		$tgl 		= detailTgl($row_pend['TGLREG']);
		$kdcarabyr  = $row_pend['KDCARABAYAR'];
		$rs_jp		= getallcarabayar($kdcarabyr);
		$row_jp		= $rs_jp['NAMA'];
		$jp			= $kdcarabyr == 5 ? "BPJS" : $row_jp;
		
		$datapasien = getPasienAPS($_REQUEST['nomr']);
		while ($dp = mysql_fetch_array($datapasien)){
			$nomr 	= $dp['NOMR_RS'];
			$nama	= $dp['NAMA'];
			$title 	= $dp['TITLE'];
			if($title != ''){
				$nama	= $nama.", ".$title;
			}
		}
		
		$getRincian 	= getRincianLab($_REQUEST['nomr'], $_REQUEST['idx'], $_REQUEST['nolab']);
		$jmlRow 		= mysql_num_rows($getRincian);
		while($data = mysql_fetch_array($getRincian)){
			$nama_tindakan[]	= $data['nama_tindakan'];
			$tottariflab[]		= $data['tottariflab'];
			$nolab 				= $data['NOLAB'];
			$drpengirim			= $data['DRPENGIRIM'];
			$kdpoly 			= $data['KDPOLY'];
		}
	}
	
	if($drpengirim != 0){
		$nama_dokter 	= getDokterName($drpengirim);
	}else{
		$nama_dokter	= "-";
	}
	
	if($kdpoly != 0){
		$getpoly 	= getPolyByID($kdpoly);
		$dataPoly 	= mysql_fetch_array($getpoly);
		$rujukan 	= $dataPoly['nama'];
	}
	else{
		$getpend_aps= getPendaftaranAPS($_REQUEST['idx']);
		$dataAPS 	= mysql_fetch_array($getpend_aps);
		$kdrujuk 	= $dataAPS['KDRUJUK'];
		$getrujuk	= getRujukanByID($kdrujuk);
		$rujuk		= mysql_fetch_array($getrujuk);
		$namarujuk 	= $rujuk['NAMA'];
		$ketrujuk	= $dataAPS['KETRUJUK'];
		if($namarujuk != ''){
			$rujukan = $namarujuk;
		}
		else if($ketrujuk != ''){
			$rujukan = $namarujuk." (".$ketrujuk.")";
		}
		else{
			$rujukan = '-';
		}
	}
	
	$total = 0;
?>
	<div>
		<table cellspacing="0">
			<tr>
				<td colspan="3">
					<h2>Rawat Jalan</h2>
				</td>			
			</tr>
			<tr>
				<td colspan="3">RSUD KOTA BOGOR</td>			
			</tr>
			<tr>
				<td colspan="3">
					Jl. Dr. Sumeru No. 120 Bogor Telp.(0251)312292
					<br />
				</td>			
			</tr>
			<tr>
				<td width="55px;">No.Rinci</td>
				<td width="10px;">:</td>
				<td><?php echo sprintf("%010d", $nolab) . " / " . $nomr;?></td>
			</tr>
			<tr>
				<td>Tanggal</td>
				<td>:</td>
				<td><?php echo $tgl; ?></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td>:</td>
				<td><?php echo strtoupper($nama); ?></td>
			</tr>
			<tr>
				<td>Rujukan</td>
				<td>:</td>
				<td><?php echo $rujukan; ?></td>
			</tr>
			<tr>
				<td>Pengirim</td>
				<td>:</td>
				<td><?php echo $nama_dokter; ?></td>
			</tr>
			<tr>
				<td>JP</td>
				<td>:</td>
				<td><?php echo $jp; ?></td>
			</tr>
		</table>
		<br/>
		<br/>
		
		<table class="table" width="330px;">
			<tr>
                <th colspan="3">
                    RINCIAN BIAYA LABORATORIUM
				</th>
			</tr>
			<tr>
                <th width="180px" style="border-style:dashed;border-bottom:dashed #000000;border-left:none;border-right:none;border-bottom-width: 1px;">Jenis Pemeriksaan</th>
                <th width="30px" style="border-style:dashed;border-bottom:dashed #000000;border-left:none;border-right:none;border-bottom-width: 1px;"></th>
                <th width="95px" style="border-style:dashed;border-bottom:dashed #000000;border-left:none;border-right:none;border-bottom-width: 1px;">Biaya</th>
			</tr>
			<?php 
				$getRincian 	= getRincianLab($_REQUEST['nomr'], $_REQUEST['idx'], $_REQUEST['nolab']);
				for($i=0; $i<$jmlRow; $i++){
			?>
                <tr>
                    <td width="180px"><?php echo $nama_tindakan[$i]; ?></td>
					<td width="30px" style="text-align:right">Rp.</td>
					<td style="text-align:right" width="95px">
						<?php 
							echo CurFormat($tottariflab[$i],2); 
							$total 	= $total + $tottariflab[$i];
						?>
					</td>
				</tr>
			<?php
				}
			?>
			<tr>
                <td style="border-top:dashed #000000;border-left:none;border-right:none;border-bottom:none;border-top-width: 1px;" >Jumlah Biaya</td>
				<td width="30px" style="text-align:right;border-top:dashed #000000;border-left:none;border-right:none;border-bottom:none;border-top-width: 1px;">Rp.</td>
				<td style="text-align:right;border-top:dashed #000000;border-left:none;border-right:none;border-bottom:none;border-top-width: 1px;">
					<?php echo CurFormat($total,2); ?>
				</td>
			</tr>
		</table>
		<br/>
		<br/>
<!--		Petugas : --><?php //echo $_SESSION['NIP']; ?>
	</div>
<?php
    $html      = ob_get_contents();
    $file_name = "Rincian Laboratorium";
    ob_end_clean();
    include "../include/PDF.php";
    include "../include/cetak_rincian_pdf.php";
?>
<!--<script type="text/javascript">-->
<!--	window.print();-->
<!--</script>-->