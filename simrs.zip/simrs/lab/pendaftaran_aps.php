<?php 
	session_start();
?>
<SCRIPT LANGUAGE="JavaScript">
    function startjam(){
		var d = new Date();
		var curr_hour = d.getHours();
		var curr_min = d.getMinutes();
		var curr_sec = d.getSeconds();
		document.getElementById('start_daftar').value=(curr_hour + ":" + curr_min+ ":" + curr_sec);
	}
</SCRIPT>
<script type="text/javascript">
	jQuery(document).ready(function(){
		var num = jQuery("#successalert").val();
		if(num == 1){
			alert("Pendaftaran Berhasil");
		}
	});
</script>
<?php 
	$carabayar 	= getCaraBayar();
	$rujukankd 	= getRujukan();
	
	$jmlRowRujukan		= mysql_num_rows($rujukankd);
	while($rowRujukan 	= mysql_fetch_array($rujukankd)){
		$kodeRujukan[]	= $rowRujukan['KODE'];
		$namaRujukan[]	= $rowRujukan['NAMA'];
	}
	
	//added by ferna 25062015
	//waktu sekarang pada database
	$sql = mysql_query("SELECT TIME(now()) as time");
	while($ds = mysql_fetch_array($sql)){
		$now = $ds['time'];
		$jam = substr($now, 0, 2);
		$menit = substr($now, 3, 2);
		$detik = substr($now, 6, 2);
	}
		
	$jam_now = new DateTime($now);
	$jam_pagi_bawah = new DateTime("07:00:00");
	$jam_pagi_atas = new DateTime("14:15:00");
	$jam_sore_atas = new DateTime("21:15:00");
?>
<div align="center">
  	<div id="frame" style="width:100%;">
  	<div id="frame_title"><h3 align="left">&nbsp;</h3>
	<?php 
		if(isset($_SESSION['success'])){
		  	echo '<input type="hidden" value="'.$_SESSION['success'].'" id="successalert" />';
		  	unset($_SESSION['success']);
		}
	  	echo '<input type="hidden" value="0" id="successalert" />';
	 ?>
</div>

<form name="myform" id="myform" action="lab/pendaftaran.php" method="post">
    <fieldset class="fieldset"><legend>Form Pendaftaran APS</legend>
      <table width="100%" border="0" title=" From Ini Berfungsi Sebagai Form Pendaftaran Baru.">
      <tr>
        <td width="24%">Tanggal Daftar </td>
        <td width="28%"><input type="text" name="TGLREG" class="text" value="<?php echo date("Y-m-d"); ?>" size="20"/>
          <input type='hidden' name='start_daftar' id='start_daftar' /></td>
        <td width="48%" align="right">Shift
          :
          <input type="radio" name="SHIFT" class="required" title="*" value="1" <? if($jam_now > $jam_pagi_bawah && $jam_now < $jam_pagi_atas) echo "Checked";?>/>
			Pagi
          <input type="radio" name="SHIFT" class="required" title="*" value="2" <? if($jam_now > $jam_pagi_atas && $jam_now < $jam_sore_atas) echo "Checked";?>/>
            Sore
          <input type="radio" name="SHIFT" class="required" title="*" value="3" <? if($jam_now > $jam_sore_atas || $jam_now < $jam_pagi_bawah) echo "Checked";?>/>
            Malam
          </td>
      </tr>
	  <tr>
        <td>Asal Pasien </td>
        <td>
			<select name="KDRUJUK" id="asal" class="select2">
				<?php 
					for($i=0; $i<$jmlRowRujukan; $i++){
						if($_GET['KDRUJUK'] == $kodeRujukan[$i]): $sel = "Checked"; else: $sel = ''; endif;
				?>
					<option id="asal<?php echo $kodeRujukan[$i]; ?>" value="<?php echo $kodeRujukan[$i]; ?>"><?php echo $namaRujukan[$i]; ?><?php echo $sel ?></option>
				<?php 
					}
				?>
			</select>
	        <input type="text" title="*" name="KETRUJUK" <?php echo $css; ?> value="<?php echo $_GET['KETRUJUK'];?>" id="kdrujuk_lain" class="text" />
       	</td>
      </tr>
	  <tr id="tr_nomr">
		<td>NOMR</td>
		<td>
			<input class="text" name="nomr" id="nomr"/>
			<input type="button" class="text" value="cari" id="btn_cari_pasien"/>
		</td>
	  </tr>
	  <tr id="tr_poli">
		<td>Poli</td>
		<td>
			<select name="kdpoli" id="kdpoli" class="selectbox text select2" title="*" style="float:left; margin-right:20px;">
                <option value="NULL"> - Pilih klinik -</option>
                <?php
                    $sql = mysql_query('select * from m_poly order by nama asc');
                    while ($data = mysql_fetch_array($sql)) {
						if ($_GET['KDPOLY'] == $data['kode']): $zx = 'selected="selected"';
						else: $zx = ''; endif;
						echo '<option value="' . $data['kode'] . '" ' . $zx . '>' . $data['nama'] . '</option>';
                    }
                ?>
            </select>
		</td>
	  </tr>
	  <tr id="tr_dokter">
		<td>Dokter</td>
		<td>
			<select name="kddokter" id="kddokter" class="selectbox text select2" title="*" style="float:left; margin-right:20px;">
                <option value="NULL"> - Pilih Dokter -</option>
                <?php
                    $sql_dokter = mysql_query('SELECT * FROM m_dokter WHERE st_aktif = 0 ORDER BY NAMADOKTER ASC');
                    while ($data_dokter = mysql_fetch_array($sql_dokter)) {
						echo '<option value="' . $data_dokter['KDDOKTER'] . '" >' . $data_dokter['NAMADOKTER'] . '</option>';
                    }
                ?>
            </select>
		</td>
	  </tr>
      <tr>
        <td>Cara Pembayaran</td>
        <td colspan="2">
        	<select name="KDCARABAYAR" id="KDCARABAYAR" class="select2">
				<?php 
					while($kodeCrByar = mysql_fetch_array($carabayar)){
				?>
					<option value="<?php echo $kodeCrByar['KODE']; ?>"><?php echo $kodeCrByar['NAMA']; ?></option>
				<?php 
					}
				?>
			</select>
		</td>
      </tr>
      <tr id="tr_nokartubpjs">
      	<td>
      		<label id="label_nokartubpjs">NO Kartu BPJS</label>
      	</td>
      	<td colspan="2">
      		<input type="text" name="nokartu" title="*" id="nokartu" <?php echo $ppk;?> value="" class="text"/>
			<input type='button' id='btnrujukan' class='text' value='cari'>
		</td>
	  </tr>
	  <tr id="tr_nokaryawan">
 		<td>
 			<label id="label_nokaryawan">NO Karyawan</label>
 		</td>
 		<td colspan="2">
 			<input type="text" name="nokaryawan" id="nokaryawan" value="" class="text" />
 			<input type="button" id="btncarikaryawan" class="text" value="cari" />
 		</td>
 	  </tr>
      <tr id="tr_nopeserta">
		<td>
			<label id="label_nopeserta">Kelompok Peserta</label>
		</td> 
		<td colspan="2">
			<input type="text" name="jns_peserta" title="*" id="jns_peserta" <?php echo $ppk;?> value="" class="text"/>
		</td>
	  </tr>		
     <tr id="tr_idxmcu">
       	<td>
       		<label id="label_idxmcu">No. Register MCU</label>
       	</td>
       	<td>
       		<input type="text" id="idxmcu" name="idxmcu" />
       		<input type="button" class="text" value="Cari" id="search_idxmcu" />
       	</td>
      </tr>
    </table>
    </fieldset>


   <div id="all">	
     <? include("lab/view_prosess_aps.php");?>
  </div>
       </form>

  </div>
  </div>
<script type="text/javascript">
	jQuery('.select2').select2();

	jQuery(document).ready(function(){
		function start(){
			jQuery('#tr_nokartubpjs').hide();
			jQuery('#nokartu').hide();
			jQuery('#btnrujukan').hide();
			jQuery('#tr_nokaryawan').hide();
			jQuery('#nokaryawan').hide();
			jQuery('#btncarikaryawan').hide();
			jQuery('#tr_nopeserta').hide();
			jQuery('#label_nopeserta').hide();
			jQuery('#jns_peserta').hide();
			jQuery('#kdrujuk_lain').hide();
			jQuery('#tr_idxmcu').hide();
			jQuery('#label_idxmcu').hide();
			jQuery('#idxmcu').hide();
			jQuery('#search_idxmcu').hide();
			jQuery('#tr_nomr').hide();
			jQuery('#tr_poli').hide();
			jQuery('#tr_dokter').hide();
		}
		start();

		jQuery('#KDCARABAYAR').change(function(){
			var value	= jQuery('#KDCARABAYAR').val();

			if(value == 5){
				jQuery('#tr_nokartubpjs').show();
				jQuery('#nokartu').show();
				jQuery('#btnrujukan').show();
				jQuery('#tr_nopeserta').show();
				jQuery('#label_nopeserta').show();
				jQuery('#jns_peserta').show();
				jQuery('#kdrujuk_lain').hide();
				jQuery('#tr_nokaryawan').hide();
				jQuery('#nokaryawan').hide();
				jQuery('#btncarikaryawan').hide();
			}
			else if(value == 10){
				jQuery('#tr_nokaryawan').show();
				jQuery('#label_nokaraywan').show();
				jQuery('#nokaryawan').show();
				jQuery('#btncarikaryawan').show();
				jQuery('#tr_nokartubpjs').hide();
				jQuery('#nokartu').hide();
				jQuery('#btnrujukan').hide();
				jQuery('#tr_nopeserta').hide();
				jQuery('#label_nopeserta').hide();
				jQuery('#jns_peserta').hide();
				jQuery('#kdrujuk_lain').hide();
			}
			else if(value == 11){
				jQuery('#tr_nokaryawan').show();
				jQuery('#label_nokaraywan').show();
				jQuery('#nokaryawan').show();
				jQuery('#btncarikaryawan').hide();
				jQuery('#tr_nokartubpjs').hide();
				jQuery('#nokartu').hide();
				jQuery('#btnrujukan').hide();
				jQuery('#tr_nopeserta').hide();
				jQuery('#label_nopeserta').hide();
				jQuery('#jns_peserta').hide();
				jQuery('#kdrujuk_lain').hide();
			}
			else{
				start();
			}
		});

		jQuery('#asal').change(function(){
			var val 	= jQuery('#asal').val();

			if(val == 2){
				jQuery('#kdrujuk_lain').show();
				jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Puskesmas');
				jQuery('#tr_idxmcu').hide();
				jQuery('#label_idxmcu').hide();
				jQuery('#idxmcu').hide();
				jQuery('#search_idxmcu').hide();
				jQuery('#tr_nomr').hide();
				jQuery('#tr_poli').hide();
				jQuery('#tr_dokter').hide();
			}
			else if(val == 3){
				jQuery('#kdrujuk_lain').show();
				jQuery('#kdrujuk_lain').attr('placeholder', 'Nama RS Lain');
				jQuery('#tr_idxmcu').hide();
				jQuery('#label_idxmcu').hide();
				jQuery('#idxmcu').hide();
				jQuery('#search_idxmcu').hide();
				jQuery('#tr_nomr').hide();
				jQuery('#tr_poli').hide();
				jQuery('#tr_dokter').hide();
			}
			else if(val == 5){
				jQuery('#kdrujuk_lain').show();
				jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Dokter');
				jQuery('#tr_idxmcu').hide();
				jQuery('#label_idxmcu').hide();
				jQuery('#idxmcu').hide();
				jQuery('#search_idxmcu').hide();
				jQuery('#tr_nomr').hide();
				jQuery('#tr_poli').hide();
				jQuery('#tr_dokter').hide();
			}
			else if(val == 6){
				jQuery('#kdrujuk_lain').show();
				jQuery('#kdrujuk_lain').attr('placeholder', 'Nama Instansi');
				jQuery('#tr_idxmcu').hide();
				jQuery('#label_idxmcu').hide();
				jQuery('#idxmcu').hide();
				jQuery('#search_idxmcu').hide();
				jQuery('#tr_nomr').hide();
				jQuery('#tr_poli').hide();
				jQuery('#tr_dokter').hide();
			}
			else if(val == 7){
				jQuery('#kdrujuk_lain').hide();
				jQuery('#tr_idxmcu').hide();
				jQuery('#label_idxmcu').hide();
				jQuery('#idxmcu').hide();
				jQuery('#search_idxmcu').hide();
				jQuery('#tr_nomr').show();
				jQuery('#tr_poli').show();
				jQuery('#tr_dokter').show();
			}
			else if(val == 4){
				jQuery('#kdrujuk_lain').show();
				jQuery('#kdrujuk_lain').attr('placeholder', 'Lain-lain');
				jQuery('#tr_idxmcu').hide();
				jQuery('#label_idxmcu').hide();
				jQuery('#idxmcu').hide();
				jQuery('#search_idxmcu').hide();
				jQuery('#tr_nomr').hide();
				jQuery('#tr_poli').hide();
				jQuery('#tr_dokter').hide();
			}
			else if(val == 10){
				jQuery('#tr_idxmcu').show();
				jQuery('#label_idxmcu').show();
				jQuery('#idxmcu').show();
				jQuery('#search_idxmcu').show();
				jQuery('#kdrujuk_lain').hide();
				jQuery('#tr_nomr').hide();
				jQuery('#tr_poli').hide();
				jQuery('#tr_dokter').hide();
			}
			else{
				jQuery('#kdrujuk_lain').hide();
				jQuery('#tr_idxmcu').hide();
				jQuery('#label_idxmcu').hide();
				jQuery('#idxmcu').hide();
				jQuery('#search_idxmcu').hide();
				jQuery('#tr_nomr').hide();
				jQuery('#tr_poli').hide();
				jQuery('#tr_dokter').hide();
			}
		});

		jQuery('#btnrujukan').click(function(){
			if(jQuery('#nokartu').val()==""){
				alert("NO Kartu Jaminan Masih Kosong");
				jQuery('#nokartu').focus();
				return false;
			}
			else{	
			var nopeserta	= jQuery('#nokartu').val();
			jQuery.post('<?php echo _BASE_;?>bridging_proses.php',{nopeserta:nopeserta,reqdata:'rujukan'},function(data){
				var response =  eval("(" + data + ")");
				jQuery('#NAMA').val(response.response.peserta.nama);
				jQuery('#jns_peserta').val(response.response.peserta.jenisPeserta.nmJenisPeserta);	

				var sex = response.response.peserta.sex;
				if(sex == 'L'){
					jQuery('#radioJenkel_L').attr('checked', true);
				}
				else{
					jQuery('#radioJenkel_P').attr('checked', true);
				}
		
				var tglLahir = response.response.peserta.tglLahir;
				var thnLahir = tglLahir.substr(0,4);
				var blnLahir = tglLahir.substr(5,2);
				var tLhrnya  = tglLahir.substr(8,2);
				var ttlnya   = tLhrnya + "/" + blnLahir + "/" + thnLahir;
				jQuery('#TGLLAHIR').val(ttlnya);
				console.log(ttlnya);
			});
			}
		});

		jQuery('#btncarikaryawan').click(function(){
			var nokaryawan	= jQuery('#nokaryawan').val();

			jQuery.post('<?php echo _BASE_?>caripegawai.php',{nokaryawan:nokaryawan,pilihan:1},function(data){
				var json	= JSON.parse(data);
				jQuery('#NAMA').val(json.Nama);
				
				var jenkel	= json.Kelamin;
				if(jenkel == "Laki-laki"){
					jQuery('#radioJenkel_L').attr('checked', true);
				}
				else{
					jQuery('#radioJenkel_P').attr('checked', true);
				}

				jQuery('#TEMPAT').val(json.TmpLahir);

				var tglLahir	= json.TglLahir;
				var thnLahir = tglLahir.substr(0,4);
				var blnLahir = tglLahir.substr(5,2);
				var tLhrnya  = tglLahir.substr(8,2);
				var ttlnya   = tLhrnya + "/" + blnLahir + "/" + thnLahir;
				jQuery('#TGLLAHIR').val(ttlnya);

				var agama	= json.Agama;
				switch(agama){
					case "Islam":
						jQuery('#radioAgama_1').attr('checked', true);
						break;
					case "Protestan":		
						jQuery('#radioAgama_2').attr('checked', true);
						break;
					case "Katholik":
						jQuery('#radioAgama_3').attr('checked', true);
						break;
					case "Hindu":
						jQuery('#radioAgama_4').attr('checked',true);
						break;
					case "Budha":
						jQuery('#radioAgama_5').attr('checked',true);
						break;
					default:
						jQuery('#radioAgama_6').attr('checked',true);
						break;
				}	

				jQuery('#ALAMAT').val(json.Alamat);

				var pend	= json.Pendidikan;
				var pendnow	= pend.substring(4);
				switch(pendnow){
					case "SD":
						jQuery('#radioPendidikan_1').attr('checked',true);
						break;
					case "SMP":
						jQuery('#radioPendidikan_2').attr('checked',true);
						break;
					case "SMA":
						jQuery('#radioPendidikan_3').attr('checked',true);
						break;
					case "SMU":
						jQuery('#radioPendidikan_3').attr('checked',true);
						break;
					case "STM":
						jQuery('#radioPendidikan_3').attr('checked',true);
						break;
					case "SMK":
						jQuery('#radioPendidikan_3').attr('checked',true);
						break;
					case "SMEA":
						jQuery('#radioPendidikan_3').attr('checked',true);
						break;
					case "SMKK":
						jQuery('#radioPendidikan_3').attr('checked',true);
						break;
					case "DIII":
						jQuery('#radioPendidikan_4').attr('checked',true);
						break;
					case "D3":
						jQuery('#radioPendidikan_4').attr('checked',true);
						break;
					default:
						jQuery('#radioPendidikan_5').attr('checked',true);
						break;
				}

				var status	= json.NoStatusnya;
				jQuery.post('<?php echo _BASE_?>caripegawai.php',{status:status,pilihan:2},function(data){
					var ketstatus = data;
					switch(ketstatus){
						case "Kawin ":
							jQuery('#radioStatus_2').attr('checked',true);
							break;
						case "Belum Kawin":
							jQuery('#radioStatus_1').attr('checked',true);
							break;
						case "Janda":
							jQuery('#radioStatus_3').attr('checked',true);
							break;
						default:
							jQuery('#radioStatus_1').attr('checked',true);
							break;
					}
				});
			});
		});	
		
		jQuery('#btn_cari_pasien').click(function(){
			var nomr = jQuery('#nomr').val();
			jQuery.get('<?php echo _BASE_; ?>include/process.php?psn=' + nomr, function (data) {
				console.log(data);
                newdata = data.split("|");
                jQuery('#NAMA').val(newdata[2]);
				jQuery('#TEMPAT').val(newdata[3]);
				var tahun = newdata[4].substr(0, 4);
                var bulan = newdata[4].substr(5, 2);
                var hari = newdata[4].substr(8, 2);
                jQuery('#TGLLAHIR').val(hari + "/" + bulan + "/" + tahun);
				jQuery('#ALAMAT').val(newdata[6]);
				jQuery('#KDPROVINSI').val(newdata[10]).change();
                jQuery('#KOTA').val(newdata[9]).change();
				jQuery('#KELURAHAN').val(newdata[7]);
                jQuery('#KECAMATAN').val(newdata[8]);
                jQuery('#KELURAHANHIDDEN').val(newdata[7]);
                jQuery('#KECAMATANHIDDEN').val(newdata[8]);
                jQuery('#KOTAHIDDEN').val(newdata[9]);
				jQuery('#NOTELP').val(newdata[11]);
				jQuery('#NOKTP').val(newdata[12]);
				jQuery('#SUAMI_ORTU').val(newdata[13]);
                jQuery('#PEKERJAAN').val(newdata[14]);
				jQuery('#radioJenkel_' + newdata[5]).attr('checked', 'checked');
                jQuery('#radioStatus_' + newdata[15]).attr('checked', 'checked');
                jQuery('#radioPendidikan_' + newdata[17]).attr('checked', 'checked');
                jQuery('#radioAgama_' + newdata[16]).attr('checked', 'checked');
            });
		});
	});
</script>