<?php 
	session_start();
	include '../include/connect.php';
	include '../include/function.php';
	
	$myquery	= 'SELECT a.nomr AS NOMR, b.NAMA as pasien, a.tglbayar, a.jambayar, a.jmbayar, a.unit, c.nama_unit, d.NAMA as carabayar
					FROM t_bayarlab a 
					JOIN m_pasien_aps b ON b.NOMR = a.nomr 
					JOIN m_unit c ON c.kode_unit = a.unit
					JOIN m_carabayar d ON d.KODE = a.carabayar 
					WHERE a.nomr = "'.$_REQUEST['nomr'].'"
					AND a.nobilllab = "'.$_REQUEST['nolab'].'"';
	$get = mysql_query ($myquery)or die(mysql_error());
	$userdata = mysql_fetch_assoc($get);
?>
<style type="text/css" media="screen">
#global_print{width:500px;}
#header{ height:100px; width:100%;}
#logo_cetak{float:left;}
#title{float:left; width:400px;}
#kepada{float:right; width:350px;}
#kepada .field{float:left; width:100px;}
#kepada .value{float:left; width:250px;}
#kuitansi{text-align:center; font-size:14px; font-weight:bold;}
#no_kuitansi{text-align:left; font-size:16px;}
table#table_list{width:100%; font-size:12px; border-collapse:0; border-spacing:0px;}
tr th{border-bottom:1px solid #000; border-top:1px solid #000;}
#footer{width:100%; font-size:12px;}
#last_line{font-size:11px; font-style:inherit; width:100%;}
</style>
<style type="text/css" media="print">
#global_print{width:900px;}
#header{ height:100px; width:100%;}
#logo_cetak{float:left; height:100px; width:100px;}
#title{float:left; width:400px;}
#kepada{float:right; width:350px;}
#kepada .field{float:left; width:100px;}
#kepada .value{float:left; width:250px;}
#kuitansi{text-align:center; font-size:14px; font-weight:bold; }
#no_kuitansi{text-align:left; font-size:16px;}
table#table_list{width:100%; font-size:12px; border-collapse:0; border-spacing:0px;}
tr th{border-bottom:1px solid #000; border-top:1px solid #000;}
#footer{width:100%; font-size:12px;}
#last_line{font-size:11px; font-style:inherit; width:70%; font-size:5pt;}
</style>
<div id="global_print" style="font-family:'Arial', Gadget, sans-serif; height:550px; width:600px; padding-left:75px;">
    <div id="header">
    	<br/>
        <div id="logo_cetak">
        	<img src="../img/logokotabogor.PNG" width="50px" />
        </div>
        <div id="title">
        	<br/>
        	<div id="title1"><?=strtoupper($header1)?></div>
            <div id="title2"><?=strtoupper($header2)?></div>
			<div id="title3" style="font-size:11px;"><?=$header3?></div>
			<div id="title4" style="font-size:11px;"><?=$header4?></div>
        </div>
        <div id="kepada" style="padding-top:10px; font-size:12px;">
        	<div id="kepada1">Kepada Yth</div>
            <div id="kepada2"><div class="field">Nama pasien</div><div class="value"><?php echo $userdata['pasien'];?></div></div><br clear="all" />
            <div id="kepada3"><div class="field">No RM</div><div class="value"><?php echo $_REQUEST['nomr'];?></div></div><br clear="all" />
            <div id="kepada4"><div class="field">Tanggal Bayar</div><div class="value"><?php echo $userdata['tglbayar'].' '.$userdata['jambayar'];?></div></div>
            <div id="kepada4"><div class="field">UNIT</div><div class="value"><?php echo $userdata['nama_unit'];?></div></div><br clear="all" />
            <div id="kepada4"><div class="field">Pembayaran</div><div class="value"><?php echo $userdata['carabayar'];?></div></div><br clear="all" />
        </div>
    </div>
    <br clear="all" />
    <br/>
    <div id="kuitansi"></div>
    <div id="no_kuitansi"> No Transaksi : <?php echo $_REQUEST['nolab']; ?></div>
    
    <table id="table_list">
    	<tr id="header_table">
    		<th style="text-align:left;">Nama Jasa</th>
    		<!--<th style="width:40px;">Qty</th>
    		<th style="width:80px;">Harga</th>-->
    		<th style="width:100px;">Total</th>
    		<th style="width:20px;">&nbsp;</th>
    	</tr>
    	<tbody style="height:200px;">
	    <?php
	    	$total = 0;
		    $bayarlab 	= get_t_bayarlab($_REQUEST['nomr'], $_REQUEST['idxdaftar']);
		    while($dt_lab = mysql_fetch_array($bayarlab)){
		    	$nolab 		= $dt_lab['nobilllab'];
		    	$kode 		= $dt_lab['kode_tindakan'];
		    	$idxbayarlab= $dt_lab['idxbayarlab'];
		    	$tariflab	= getTottariflab($_REQUEST['nomr'], $_REQUEST['idxdaftar'], $kode);
		    	$total		= $total + $tariflab;
		    }
		    
		    $sisabayar 	= getsisapembayaranlab($_REQUEST['idxdaftar']);
		    $byr 		= getSudahBayarLab($_REQUEST['idxdaftar']);
	    ?>
	    	<tr>
	    		<td>Pembayaran Laboratorium</td>
	    		<td style="text-align:center">Rp. <?php echo CurFormat($total,2); ?></td>
	    	</tr>
		    <tr style="height:auto;">
		    	<td colspan="4"></td>
		    </tr>
	    </tbody>
		  <tr>
		  	<td style="text-align:left; padding-right:10px; border-top:1px solid #000;">&nbsp;</td>
		  	<td style="text-align:right; padding-right:0px; border-top:1px solid #000; font-size:8pt;">Total Biaya</td>
		  	<td style="border-top:1px solid #000; text-align:right;">Rp. <?php echo curformat($total); ?></td>
		  </tr>
	   	  <tr>
	   	  	<td colspan="2" style="text-align:right; padding-right:0px; font-size:8pt;">Total Yang Sudah dibayarkan</td>
	   	  	<td style="text-align:right;">Rp. <?php echo curformat($byr); ?></td>
	   	  </tr>
	      <tr>
	      	<td style="text-align:left; padding-right:10px; border-bottom:1px solid #000;"><em>Terbilang: <?php echo Terbilang($total);?> rupiah</em></td>
	      	<td style="text-align:right; padding-right:0px; border-bottom:1px solid #000; font-size:8pt;">Total Yang Harus dibayarkan</td>
	      	<td style="text-align:right;border-bottom:1px solid #000;">Rp. <?php echo curformat($sisabayar); ?></td>
	      </tr>
    </table>
    <div id="footer">
    	<div id="footer1" style="float:left; width:400px; height:100px;">
        	<br />
            Catatan :<br />
            Lembar 1 : Pasien / Penjamin <br />
            Lembar 2 : Kasir <br />
            Lembar 3 : Keuangan <br />
		</div>
        <div id="footer2" style="float:left; width:200px;">
			<div style="text-align:center; width:100%;">Kasir</div>
            <div style="text-align:center; width:100%; padding-top:70px;">( <?php echo $_SESSION['NIP'];?> )</div>
        </div>
    	<br clear="all" />
    <div id="last_line" style="font-size: 7pt;"> Dicetak oleh : <?php echo $_SESSION['NIP']; ?> sebanyak [ 5 ] tanggal <?php echo date('d/m/Y H:i:s'); ?></div>
</div>

<!-- added 03072015 -->
<script type="text/javascript">
	window.print();
</script>
<!-- added 03072015 -->