<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 18/01/2016
 * Time: 14:01
 */

session_start();

include("include/connect.php");

$search = " AND t_orderlab.TANGGAL = CURDATE()";

$tgl_kunjungan = date('Y-m-d');
if(!empty($_GET['tgl_kunjungan'])) {
    $tgl_kunjungan =$_GET['tgl_kunjungan'];
}

if($tgl_kunjungan !="") {
    $search = " AND t_orderlab.TANGGAL BETWEEN  '".$tgl_kunjungan."' ";
}

$tgl_kunjungan2 = date('Y-m-d');
if(!empty($_GET['tgl_kunjungan2'])) {
    $tgl_kunjungan2 =$_GET['tgl_kunjungan2'];
}

if($tgl_kunjungan !="") {
    if($tgl_kunjungan2 !="") {
        $search = $search." AND '".$tgl_kunjungan2."' ";
    }else {
        $search = $search." AND '".$tgl_kunjungan."' ";
    }
}
?>
<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>LAPORAN PEMERIKSAAN LABORATORIUM</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table border="0" cellspacing="0" class="tb">
                    <tr>
                        <td>Tanggal</td>
                        <td><input type="text" name="tgl_kunjungan" id="tgl_pesan" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan!="") {
                                       echo $tgl_kunjungan;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>Sd</td>
                        <td><input type="text" name="tgl_kunjungan2" id="tgl_pesan2" readonly="readonly" class="text datepicker" style="width:100px;"
                                   value="<? if($tgl_kunjungan2!="") {
                                       echo $tgl_kunjungan2;
                                   }
                                   else{
                                       echo date('Y-m-d');
                                   }?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td align="right"><input type="submit" value="C A R I" class="text"/>
                            <input type="hidden" name="link" value="report_lab02" />
                        </td>
                    </tr>
                </table>
            </form>
            <br/>
            <table id="table">
                <thead>
                <tr>
                    <th>No.</th>
                    <th>Kode Pemeriksaan</th>
                    <th>Pemeriksaan</th>
                    <th>Jumlah</th>
                </tr>
                </thead>
				<tbody>
                    <?php
						$i = 1;
						$tot_jml = 0;
						$sql = "SELECT t_orderlab.KODE,
									   m_tarif2012.nama_tindakan,
									   COUNT(t_orderlab.IDXORDERLAB) AS jml
								FROM `t_orderlab`
								JOIN m_tarif2012 ON m_tarif2012.kode_tindakan = t_orderlab.KODE
								WHERE t_orderlab.is_batal = 0
								  AND DATE(t_orderlab.TANGGAL) BETWEEN '{$tgl_kunjungan}' AND '{$tgl_kunjungan2}'
								GROUP BY t_orderlab.KODE
								ORDER BY KODE ASC; ";
						$rs  = mysql_query($sql);
						while($row = mysql_fetch_array($rs)){
							$tot_jml += $row['jml'];
					?>
                        <tr>
                            <td><?= $i++; ?></td>
							<td><?= $row['KODE']; ?></td>
                            <td><?= $row['nama_tindakan']; ?></td>
                            <td><?= $row['jml']; ?></td>
                        </tr>
                    <?php } ?>
                 </tbody>
            </table>
        </div>
    </div>
</div>
<br/>
<div align="left">
    <form name="formprint" method="post" action="lab/report/laporan_pemeriksaan_excel.php" target="_blank" >
        <input type="hidden" name="query" value="<?php echo $search; ?>" />
        <input type="hidden" name="start" value="<?php echo $tgl_kunjungan; ?>" />
        <input type="hidden" name="end" value="<?php echo $tgl_kunjungan2; ?>" />
        <input type="submit" value="Export To Ms Excel Document" class="text" />
    </form>
</div>

<script type="text/javascript">
    jQuery("#table").dataTable();
    jQuery(".select2").select2();
</script>