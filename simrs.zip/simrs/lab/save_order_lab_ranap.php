<?php 
	session_start();
	include("../include/connect.php");
	include("../include/function.php");
	$kode 		 = $_REQUEST['checkbox'];
	$jml_kode	 = count($_REQUEST['checkbox']);
	$ip			 = getRealIpAddr();
	$jenis		 = $_REQUEST['cito_status'];
    $kode_concat = '';
	
	if($jenis == "c"){
		$faktor = 1.25;
	}else{
		$faktor = 1;
	}
	
	/*$sql_nourut = "SELECT MAX(NOLAB) AS NOLAB FROM t_orderlab WHERE TANGGAL = CURDATE() ORDER BY IDXORDERLAB DESC LIMIT 1";
	$get_nourut = mysql_query($sql_nourut);
	$dat_nourut = mysql_fetch_assoc($get_nourut);
	if($dat_nourut['NOLAB'] != ""){
		 $no_last    = $dat_nourut['NOLAB'] + 1;
		 $nourut     = sprintf("%08d", $no_last);
	}else{*/
		$sql_nourut2 = "SELECT MAX(ONO) AS NOLAB FROM log_sysmex_lis_order";
		$get_nourut2 = mysql_query($sql_nourut2);
		//if(mysql_num_rows($get_nourut) > 0){
			 $dat_nourut2 = mysql_fetch_assoc($get_nourut2);
			 $no_last2    = $dat_nourut2['NOLAB'] + 1;
			 $nourut      = sprintf("%08d", $no_last2);
		/*}else{
			 $nourut     = sprintf("%08d", 1);
		}
	//}*/

	for($y=0; $y<$jml_kode; $y++)
	{
		mysql_query('insert into tmp_orderpenunjang (kode_tindakan,nama_tindakan,qty,tarif,ip,jenis,jasa_pelayanan,jasa_sarana)
		select kode_tindakan, nama_tindakan,1,tarif,"'.$ip.'","e",jasa_pelayanan,jasa_sarana from m_tarif2012 where kode_tindakan = "'.$kode[$y].'"');

		//added 19102015 by ferna
		mysql_query("DELETE FROM tmp_orderpenunjang WHERE ip='".$ip."' AND kode_tindakan='".$kode[$y]."' AND jenis=''");
	}

    $counter = 0;
    $rs_tmp = mysql_query("SELECT * FROM tmp_orderpenunjang WHERE ip = '".$ip."';");
    while($row_tmp = mysql_fetch_array($rs_tmp)){
        $kode_concat = $counter == 0 ? $kode_concat . $row_tmp['kode_tindakan'] : $kode_concat . "~" . $row_tmp['kode_tindakan'];
        $counter++;
    }
	
	
	/*
	** add to t_order_lab
	**/
	$sql_order = 'INSERT INTO t_orderlab (KODE,
										  QTY,
										  IDXDAFTAR,
										  NOMR,
										  TANGGAL,
										  DRPENGIRIM,
										  kd_ruang,
										  RAJAL,
										  NOLAB,
										  APS,
										  JENIS,
										  tariflab,
										  jasa_pelayanan,
										  jasa_sarana,
										  is_mcu)
								   SELECT kode_tindakan, 
									 	  qty,
										  "'.$_REQUEST['idxdaftar'].'",
										  "'.$_REQUEST['nomr'].'",
										  "'.$_REQUEST['tgl_order'].'",
										  "'.$_REQUEST['kddokter'].'",
										  "'.$_REQUEST['unit'].'",
										  "0",
										  "'.$nourut.'", 
										  "0",
										  jenis,
										  tarif,
										  jasa_pelayanan,
										  jasa_sarana,
										  0
								   FROM tmp_orderpenunjang 
								   WHERE ip = "'.$ip.'"';
	mysql_query($sql_order);
				 
	/*
	** add to ri_billing
	**/
	$sql_billing = "INSERT INTO ri_billing (id_register,
											id_group_tindakan,
											id_tarif,
											no_penunjang,
											id_ruang,
											id_admin,
											shift,
											tanggal,
											jam,
											id_dokter,
											jasa_sarana,
											jasa_pelayanan,
											tarif_rs) 
									 SELECT '".$_REQUEST['idxdaftar']."',
											'E02',
											kode_tindakan,
											'".$nourut."',
											'".$_REQUEST['unit']."',
											0,
											'".getAutomaticShift()."',
											DATE(NOW()),
											TIME(NOW()),
											'".$_REQUEST['kddokter']."',
											jasa_sarana,
											jasa_pelayanan,
											tarif
									 FROM tmp_orderpenunjang 
								     WHERE ip = '".$ip."'";
	mysql_query($sql_billing);
	
    /*
    ** add lis order to sysmex_lis_order
    **/
	date_default_timezone_set('Asia/Jakarta');
	$nomr 		= $_REQUEST['aps'] > 0 ? "00" : $_REQUEST['nomr'];
    $dokter     = $_REQUEST['kddokter'] == 0 ? "" : $_REQUEST['kddokter']."^".getDokterName($_REQUEST['kddokter']);
    $unit       = $_REQUEST['unit']."^".$_REQUEST['ruang'];
    $request_dt = get_dt_replace($_REQUEST['tgl_order'] .  $_REQUEST['jam_order']);
    $ptype      = 'IN';
	$sql = "INSERT INTO sysmex_lis_order(
                    MESSAGE_DT,
                    ORDER_CONTROL,
                    PID,
                    PNAME,
                    ADDRESS1,
                    ADDRESS2,
                    ADDRESS3,
                    ADDRESS4,
                    PTYPE,
                    BIRTH_DT,
                    SEX,
                    ONO,
                    REQUEST_DT,
                    SOURCE,
                    CLINICIAN,
                    ROOM_NO,
                    PRIORITY,
                    COMMENT,
                    VISITNO,
                    ORDER_TESTID
                ) VALUES (
                    '".$request_dt."',
                    'NW',
                    '".$nomr."',
                    '".addslashes(str_replace("'","",substr($_REQUEST['nama'],0,50)))."',
                    '".substr($_REQUEST['alamat'],0,50)."',
                    '',
                    '',
                    '',
                    '".$ptype."',
                    '".$_REQUEST['ttl']."',
                    '".$_REQUEST['jenkel']."',
                    '".$nourut."',
                    '".$request_dt."',
                    '".$unit."',
                    '".$dokter."',
                    '".$_REQUEST['nott']."',
                    'R',
                    '',
                    '".$_REQUEST['idxdaftar']."',
                    '".$kode_concat."'
                );";
				echo $sql;
    mysql_query($sql);

    $sql = "INSERT INTO roche_list_order(
                        MESSAGE_DT,
                        ORDER_CONTROL,
                        PID,
                        PNAME,
                        ADDRESS1,
                        ADDRESS2,
                        ADDRESS3,
                        ADDRESS4,
                        PTYPE,
                        BIRTH_DT,
                        SEX,
                        ONO,
                        REQUEST_DT,
                        SOURCE,
                        CLINICIAN,
                        ROOM_NO,
                        PRIORITY,
                        COMMENT,
                        VISITNO,
                        ORDER_TESTID
                    ) VALUES (
                        '".$request_dt."',
                        'NW',
                        '".$nomr."',
                        '".addslashes(str_replace("'","",substr($_REQUEST['nama'],0,50)))."',
                        '".substr($_REQUEST['alamat'],0,50)."',
                        '',
                        '',
                        '',
                        '".$ptype."',
                        '".$_REQUEST['ttl']."',
                        '".$_REQUEST['jenkel']."',
                        '".$nourut."',
                        '".$request_dt."',
                        '".$unit."',
                        '".$dokter."',
                        '".$_REQUEST['nott']."',
                        'R',
                        '',
                        '".$_REQUEST['idxdaftar']."',
                        '".$kode_concat."'
                    );";
    echo $sql;
    mysql_query($sql);
	
	mysql_query('delete from tmp_orderpenunjang where ip = "'.getRealIpAddr().'"');