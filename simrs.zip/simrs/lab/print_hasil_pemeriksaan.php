<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 29/12/2015
 * Time: 11:04
 */

    include("../include/connect.php");

    $query_rscetak 	= 'SELECT IDXORDERLAB,KODE,NOMR,KDPOLY,KETERANGAN,APS,TANGGAL,IDXDAFTAR,
                       DRPENGIRIM,dr_pemeriksa,DATE(TGL_MULAI) AS TGL_MULAI,PETUGAS
                       FROM t_orderlab WHERE NOMR="'.$_REQUEST['nomr'].'" AND IDXDAFTAR='.$_REQUEST['idx'];
    $rscetak = mysql_query($query_rscetak) or die(mysql_error());
    $row_rscetak = mysql_fetch_assoc($rscetak);
    $totalRows_rscetak = mysql_num_rows($rscetak);

    if($row_rscetak['APS'] == 0){
        $sql 	= mysql_query("SELECT * FROM m_pasien WHERE NOMR='".$row_rscetak['NOMR']."'");
    }
    else{
        $sql 	= mysql_query("SELECT * FROM m_pasien_aps WHERE NOMR='".$row_rscetak['NOMR']."'");
    }
    $data 	= mysql_fetch_array($sql);
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Laporan Hasil Pemeriksaan</title>
    <style type="text/css">
        <!--
        .style3 {font-size: 11px; font-family: 'Lucida Console', Monaco, monospace; }
        .style5 {font-size: 11px; font-family: 'Lucida Console', Monaco, monospace; font-weight: bold; }
        -->
    </style>
</head>

<body>
<div id="print_selection" style="padding-left: 15px;width: 720px">
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
<table width="500px" border="0" align="center" cellpadding="1" cellspacing="1">
    <tr>
        <td ><table border="0" cellpadding="0" cellspacing="2" style="font-family: 'Lucida Console', Monaco, monospace; font-size: 11px; ">
                <tr>
                    <td colspan="6" valign="top" style="font-family: 'Lucida Console', Monaco, monospace;">
                        <div align="center">
                            <h2>LABORATORIUM PATOLOGI KLINIK</h2>
                            <br/>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" valign="top"><span class="style3">No. Registrasi</span></td>
                    <td width="216" valign="top"><span class="style3"><?=": ".$row_rscetak['IDXORDERLAB']?></span></td>
                    <td valign="top"><div align="left"><span class="style3">Nama Pasien</span></div></td>
                    <td valign="top">&nbsp;</td>
                    <td valign="top"><span class="style3"><?php echo ": ".$data['NAMA']; ?></span></td>
                </tr>
                <tr>
                    <td width="114" valign="top"><div align="left"><span class="style3">No. Medik</span></div></td>
                    <td width="8" valign="top"></td>
                    <td valign="top"><span class="style3"><?php echo ": ".$row_rscetak['NOMR']; ?></span></td>
                    <td valign="top"><div align="left"><span class="style3">Jenis Kelamin</span></div></td>
                    <td valign="top">&nbsp;</td>
                    <td valign="top"><span class="style3"><?php echo ": ".getJenkelDetail($data['JENISKELAMIN']); ?></span></td>
                </tr>
                <tr>
                    <td width="129" valign="top"><div align="left"><span class="style3">Ruang/Poli</span></div></td>
                    <td width="0" valign="top"></td>
                    <td width="215" valign="top">
                        <span class="style3">
                            <?php
                            $sql3 	= getPolyByID($row_rscetak['KDPOLY']);
                            $data3 	= mysql_fetch_array($sql3);

                            if($data3['nama'] != ''){
                                echo ": " . $data3['nama'];
                            }else{
                                echo ": -";
                            }
                            ?>
                        </span>
                    </td>
                    <td colspan="2" valign="top"><span class="style3">Umur</span></td>
                    <td valign="top">
                        <span class="style3">
                          <?php
                          $a = datediff($data['TGLLAHIR'], $row_rscetak['TGL_MULAI']);
                          echo ": ".$a[years]." tahun ".$a[months]." bulan ".$a[days]." hari"; ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <td valign="top"><div align="left"><span class="style3">Tgl. Pemeriksaan</span></div></td>
                    <td valign="top"></td>
                    <td valign="top"><span class="style3"><?php echo ": ".$row_rscetak['TGL_MULAI']; ?></span></td>
                    <td valign="top"><div align="left"><span class="style3">Dokter Pengirim</span></div></td>
                    <td valign="top"></td>
                    <td valign="top">
                        <span class="style3">
                            <?php
                            if($row_rscetak['DRPENGIRIM'] != 0){
                                $sql4  	= getNamaDokter($row_rscetak['DRPENGIRIM']);
                                $data4 	= $sql4['NAMADOKTER'];
                                echo ": ".$data4;
                            }else{
                                echo ": -";
                            }
                            ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border-top:  1px dashed #000 ">
                        <br/>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" align="center" style="font-family: 'Lucida Console', Monaco, monospace;">
                        <div align="center">
                            <h2><?php
                                $sql5 	= mysql_query("SELECT nama_tindakan FROM m_tarif2012 WHERE kode_tindakan='".$row_rscetak['KODE']."'");
                                $data5 	= mysql_fetch_array($sql5);
                                echo strtoupper($data5['nama_tindakan']);
                                ?></h2>
                            <br/>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" valign="top">
<!--                        <fieldset style="height:700px">-->
<!--                            <legend class="style3">HASIL RESUME</legend>-->
                            <textarea class="style5" style="width: 1000px; height: 380px; border: none"><?php echo $row_rscetak['KETERANGAN']; ?></textarea>
<!--                        </fieldset></td>-->
                    </td>
                </tr>
                <tr>
                    <td valign="top">
                    </td>
                    <td valign="top"></td>
                    <td colspan="2" valign="top"></td>
                    <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" valign="top">
                    </td>
                    <td colspan="3" valign="top"><div align="center" class="style3">Bogor,
                            <?=detailTgl($row_rscetak['TGL_MULAI']);?><br> Dokter Pemeriksa<BR><BR><BR><BR><BR>
                            <?php
                            $sql6 	= getNamaDokter($row_rscetak['dr_pemeriksa']);
                            $data6 	= $sql6['NAMADOKTER'];
                            echo $data6;
                            ?>
                        </div></td>
                </tr>
                <tr>
                    <td colspan="2" valign="top">&nbsp;</td>
                    <td valign="top">&nbsp;</td>
                    <td colspan="2" valign="top">&nbsp;</td>
                    <td valign="top">&nbsp;</td>
                </tr>
            </table></td>
    </tr>
</table>
</div>
<br/>
<a href="#" onClick="printIt()"><input type="button" class="text" value=" PRINT "/></a>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
<script language="javascript">
    function printIt()
    {
        content=document.getElementById('print_selection');
        w=window.open('about:blank');
        w.document.write( content.innerHTML );
        w.document.writeln("<script>");
        w.document.writeln("window.print()");
        w.document.writeln("</"+"script>");
    }
</script>
<?php
mysql_free_result($rscetak);
?>

