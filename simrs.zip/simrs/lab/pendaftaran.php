<?php 
	session_start();
	include("../include/connect.php");
	include("../include/function.php");
	
	if(empty($_POST['PENDIDIKAN'])){
		$pendidikan = "NULL";
	}else{
		$pendidikan = $_POST['PENDIDIKAN'];
	}
	if(empty($_POST['AGAMA'])){
		$agama = "NULL";
	}else{
		$agama = $_POST['AGAMA'];
	}
	if(empty($_POST['STATUS'])){
		$status = "NULL";
	}else{
		$status = $_POST['STATUS'];
	}
	
	$nomr 		= "";

    function get_next_no_mr(){
        $sql = "SELECT NOMR FROM m_pasien_aps ORDER BY NOMR DESC LIMIT 1;";
        $rs  = mysql_query($sql);

        if(mysql_num_rows($rs)){
            $data  = mysql_fetch_array($rs);
            $no_mr = intval($data['NOMR']);
            return sprintf("%06d", ++$no_mr);
        }else{
            return sprintf("%06d", 1);
        }
    }

    $nomr   = get_next_no_mr();
	
	$kdunit = $_REQUEST['kdpoli'] == "NULL" ? "16" : $_REQUEST['kdpoli'];
	
	$tmpTGLLAHIR = date('Y-m-d', strtotime(str_replace('/','-',$_POST['TGLLAHIR'])));
	$sqlinsert_pasien = "INSERT INTO m_pasien_aps ( NOMR, 
													NOMR_RS, 
													NAMA, 
													TEMPAT, 
													TGLLAHIR, 
													JENISKELAMIN, 
													ALAMAT, 
													KELURAHAN, 
													KDKECAMATAN, 
													KOTA, 
													KDPROVINSI, 
													NOTELP, 
													NOKTP, 
													SUAMI_ORTU,
													PEKERJAAN, 
													STATUS,
													AGAMA, 
													PENDIDIKAN,
													KDCARABAYAR, 
													NIP )
											 VALUES('".$nomr."',
													'".trim($_POST['nomr'])."',
													'".trim($_POST['NAMA'])."',
													'".trim($_POST['TEMPAT'])."',
													'".trim($tmpTGLLAHIR)."',
													'".trim($_POST['JENISKELAMIN'])."',
													'".trim($_POST['ALAMAT'])."',
													'".trim($_POST['KELURAHAN'])."',
													'".trim($_POST['KDKECAMATAN'])."',
													'".trim($_POST['KOTA'])."',
													'".trim($_POST['KDPROVINSI'])."',
													'".trim($_POST['NOTELP'])."',
													'".trim($_POST['NOKTP'])."',
													'".trim($_POST['SUAMI_ORTU'])."',
													'".trim($_POST['PEKERJAAN'])."',
													'".trim($status)."',
													'".trim($agama)."',
													'".trim($pendidikan)."',
													'".trim($_POST['KDCARABAYAR'])."',
													'".trim($_SESSION['NIP'])."' )";
	mysql_query($sqlinsert_pasien)or die(mysql_error());	
	
	$sqlinsert_pendaftaran_aps = " INSERT INTO t_pendaftaran_aps (NOMR, 
																  TGLREG, 
																  KDDOKTER, 
																  KDPOLY, 
																  KDRUJUK, 
																  KDCARABAYAR, 
																  NOJAMINAN, 
																  SHIFT, 
																  `STATUS`, 
																  PASIENBARU, 
																  NIP, 
																  KETRUJUK, 
																  UNIT, 
																  jns_peserta, 
																  nokar, 	
																  IDXMCU) 
														   VALUES('".$nomr."',
																  '".trim($_POST['TGLREG'])."',
																  ".trim($_POST['kddokter']).",
																  ".trim($_POST['kdpoli']).",
																  ".trim($_POST['KDRUJUK']).",
																  ".trim($_POST['KDCARABAYAR']).",
																  '".trim($_POST['nokartu'])."',
																  ".trim($_POST['SHIFT']).",
																  0,
																  "."NULL".",
																  '".trim($_SESSION['NIP'])."',
																  '".trim($_POST['KETRUJUK'])."',
																  'l',
																  '".$_POST['jns_peserta']."',
																  '".trim($_POST['nokaryawan'])."',
																  '".trim($_POST['idxmcu'])."')";
	$sqldaf = mysql_query($sqlinsert_pendaftaran_aps)or die(mysql_error());
	$idxdaftar = mysql_insert_id();
	
	mysql_query('insert into tmp_cartorderlab set IP ="'.getRealIpAddr().'", 
												  KET = "APS", 
												  UNIT = "'.$kdunit.'", 
												  KDDOKTER = '.trim($_POST['kddokter']).',
												  NOMR = "'.$nomr.'", 
												  IDXDAFTAR = "'.$idxdaftar.'", 
												  TGLDAFTAR = "'.date('Y-m-d').'", 
												  NIP = "'.$_SESSION['NIP'].'", 
												  APS = "1",
												  RAJAL = "1", 
												  CARABAYAR = "'.$_REQUEST['KDCARABAYAR'].'"');
	
	header("Location:../index.php?link=l01&success=1");
	exit;
?>