<?php 
	include("include/connect.php");
	
	$start	= 'CURDATE()';
	$end	= 'CURDATE()';
	if ($_GET['start']!=""){
		$start 	= "'".$_REQUEST['start']."'";
	}
	if ($_GET['end']!=""){
		$end 	= "'".$_REQUEST['end']."'";
	}
	$waktu	= ' and (t_pendaftaran_aps.TGLREG between '.$start.' and '.$end.')';
	$kondisi=$waktu;
?>

<div align="center">
	<div id="frame">
		<div id="frame_title">
			<h3>TAGIHAN PASIEN APS / HARI INI</h3>
		</div>
		
		<table id="table">
			<thead>
				<tr align="center">
					<th>No.</th>
					<th>Penunjang</th>
					<th>No. Registrasi</th>
					<th>Nama Pasien</th>
					<th>Nama Dokter</th>
					<th>Cara Bayar</th>
					<th>Status</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
			<?php 
				$sql	= 'SELECT t_pendaftaran_aps.NOMR, m_pasien_aps.NAMA, m_carabayar.NAMA AS carabayar, t_pendaftaran_aps.IDXDAFTAR,
				 		t_billrajal.NOBILL,t_billrajal.UNIT AS KDUNIT,(SELECT nama_unit FROM m_unit WHERE kode_unit=t_billrajal.UNIT) AS UNIT,
						t_billrajal.KDDOKTER, m_dokter.NAMADOKTER, t_bayarrajal.STATUS,t_pendaftaran_aps.IDXDAFTAR
						FROM t_pendaftaran_aps
						JOIN m_pasien_aps ON t_pendaftaran_aps.NOMR = m_pasien_aps.NOMR
						JOIN t_billrajal ON t_billrajal.IDXDAFTAR = t_pendaftaran_aps.IDXDAFTAR
						LEFT JOIN m_dokter ON m_dokter.KDDOKTER = t_billrajal.KDDOKTER
						JOIN t_bayarrajal ON t_bayarrajal.NOBILL = t_billrajal.NOBILL
						JOIN m_carabayar ON m_carabayar.KODE = t_pendaftaran_aps.KDCARABAYAR
						WHERE t_pendaftaran_aps.NOMR is not null AND t_billrajal.UNIT != 0 AND t_bayarrajal.APS=1
						 '.$kondisi.' group by t_billrajal.nobill';
				$NO=0;
				$rs 	= mysql_query($sql);
				while($data = mysql_fetch_array($rs)) {
					$ssql	= mysql_query('select COUNT(*) as tagihan from t_bayarrajal where NOMR = "'.$data['NOMR'].'" and 
											IDXDAFTAR = "'.$data['IDXDAFTAR'].'" AND LUNAS = 0');
					$sqry 	= mysql_fetch_array($ssql);
					if($sqry['tagihan'] == 0){
						$status_billing = 'Lunas';
					}else{
						$status_billing = '';
					}
			?>
				<tr>
					<td><?php echo ++$NO; ?></td>
					<td><?php echo strtoupper($data['UNIT']); ?></td>
					<td>
						<?php 
							switch ($data['KDUNIT']){
								case 16:
										echo $data['IDXDAFTAR'];
										break;
								case 17:
										$sql1	= mysql_query("SELECT IDXORDERRAD FROM t_radiologi 
																WHERE IDXDAFTAR=".$data['IDXDAFTAR']." AND NOMR='".$data['NOMR']."'");
										$data1 	= mysql_fetch_array($sql1);
										echo $data1['IDXORDERRAD'];
										break;
								case 31:
										$sql1	= mysql_query("SELECT IDXORDERFISIO FROM t_fisioterapi 
																WHERE IDXDAFTAR=".$data['IDXDAFTAR']." AND NOMR='".$data['NOMR']."'");
										$data1 	= mysql_fetch_array($sql1);
										echo $data1['IDXORDERFISIO'];
										break;
								case 200:
										$sql1	= mysql_query("SELECT IDXORDERPA FROM t_patologi_anatomi
																	WHERE IDXDAFTAR=".$data['IDXDAFTAR']." AND NOMR='".$data['NOMR']."'");
										$data1 	= mysql_fetch_array($sql1);
										echo $data1['IDXORDERPA'];
										break;
							}
						?>
					</td>
					<td><?php echo $data['NAMA']; ?></td>
					<td><?php echo $data['NAMADOKTER']; ?></td>
					<td><?php echo $data['carabayar']; ?></td>
					<td><?php echo $status_billing; ?></td>
					<td>
						<a href="index.php?link=cartbill_aps&nomr=<?php echo $data['NOMR']; ?>&idxdaftar=<? echo $data['IDXDAFTAR'];?>"> 
							<input type="button" class="text" value="Prosess" />
						</a>
					</td>
				</tr>
			<?php
				}
			?>
			</tbody>
		</table>
	</div>
</div>

<script type="text/javascript">
	jQuery("#table").dataTable();
</script>