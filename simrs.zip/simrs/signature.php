﻿<?php

    // Ubah jadi true jika masuk production
	$is_production = true;
	
	if ( $is_production ){
		$consID     = '15503';
		$consSecret = '4hY926F636';
	} else {
		$consID 	= '17121';
		$consSecret = 'rsdktbgr211016';
	}

    $timestamp 	= time();
    $data 		= $consID.'&'.$timestamp;

    // Generate Signature Key
    $signature = hash_hmac('sha256', $data, $consSecret, true);
    $encodedSignature = base64_encode($signature);