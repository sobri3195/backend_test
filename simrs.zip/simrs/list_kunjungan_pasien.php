<script language="javascript">
    function printIt()
    {
        content=document.getElementById('table_search');
        head=document.getElementById('head_report');
        w=window.open('about:blank');
        w.document.writeln("<link href='dq_sirs.css' type='text/css' rel='stylesheet' />");
        w.document.write( head.innerHTML );
        w.document.write( content.innerHTML );
        w.document.writeln("<script>");
        w.document.writeln("window.print()");
        w.document.writeln("</"+"script>");
    }
</script>
<script language="javascript" type="text/javascript">
    function dopilih(){
        document.cari.submit();
    }
</script>
<?php
    session_start();
    include("include/connect.php");
    require_once('ps_pagination_x.php');
    $search 	    = " AND E.TGLREG = curdate()";
    $tgl_reg 	    = "";
    if(!empty($_REQUEST['tgl_reg'])) {
        $tgl_reg    = $_REQUEST['tgl_reg'];
    }
    else{
        $tgl_reg    = date('Y-m-d');
    }

    if($tgl_reg !="") {
        $search     = " AND E.TGLREG BETWEEN  '".$tgl_reg."' ";
    }

    $tgl_reg2       = "";
    if(!empty($_REQUEST['tgl_reg2'])) {
        $tgl_reg2   = $_REQUEST['tgl_reg2'];
    }
    else{
        $tgl_reg2   = date('Y-m-d');
    }

    if($tgl_reg !="") {
        if($tgl_reg2 !="") {
            $search = $search." AND '".$tgl_reg2."' ";
        }else {
            $search = $search." AND '".$tgl_reg."' ";
        }
    }

    $norm           = "";
    if(!empty($_REQUEST['norm'])) {
        $norm       = $_REQUEST['norm'];
    }

    if($norm !="") {
        $search     = $search." AND A.NOMR = '".$norm."' ";
    }

    $nama           = "";
    if(!empty($_REQUEST['nama'])) {
        $nama       = $_REQUEST['nama'];
    }

    if($nama !="") {
        $search     = $search." AND A.NAMA LIKE '%".$nama."%' ";
    }

    $poly           = "";
    if(!empty($_REQUEST['poly'])) {
        $poly       = $_REQUEST['poly'];
    }

    if($poly !="") {
        $search     = $search." AND E.KDPOLY = '".$poly."' ";
    }

    $kunjungan      = "";
    if(!empty($_REQUEST['kunjungan'])) {
        $kunjungan  = $_REQUEST['kunjungan'];
    }

    if($kunjungan != "") {
        if ($kunjungan == 2) $kunjungan = 0;
        $search     = $search." AND E.PASIENBARU = '".$kunjungan."' ";
        if ($kunjungan == 0) $kunjungan = 2;
    }

    $shift          = "";
    if(!empty($_REQUEST['shift'])) {
        $shift      = $_REQUEST['shift'];
    }

    if($shift !="") {
        $search     = $search." AND E.SHIFT = '".$shift."' ";
    }
    $carabayar	    = '';
    if(!empty($_REQUEST['carabayar'])){
        $carabayar  = $_REQUEST['carabayar'];
        $search     = $search." AND c.KODE = '".$carabayar."' ";
    }
	
	$dokter	    = '';
    if(!empty($_REQUEST['dokter'])){
        $dokter  = $_REQUEST['dokter'];
        $search  = $search." AND E.KDDOKTER = '".$dokter."' ";
    }
?>

<div align="center">
    <div id="frame">
        <div id="frame_title"><h3>LIST KUNJUNGAN PASIEN</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="GET" >
                <table width="450" border="0" cellspacing="0" class="tb">
                    <tr>
                        <td width="52">No RM</td>
                        <td width="200"><input type="text" name="norm" id="norm" value="<? if($norm!="") { echo $norm; }?>" class="text" style="width:80px;"></td>
                        <td width="52">Carabayar</td><td>
                            <select name="carabayar" id="carabayar" class="text select2" >
                                <option value=""> -- </option>
                                <?
                                $qrypoly = mysql_query("SELECT * FROM m_carabayar ORDER BY orders ASC")or die (mysql_error());
                                while ($listpoly = mysql_fetch_array($qrypoly)) {
                                    ?>
                                    <option value="<? echo $listpoly['KODE'];?>" <? if($listpoly['KODE']==$carabayar) echo "selected=selected"; ?>><? echo $listpoly['NAMA'];?></option>
                                <? } ?>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td><input type="text" name="nama" id="nama" value="<? if($nama!="") {
                                echo $nama;
                            }?>" class="text"></td>
                        <td width="52">Poly</td><td>
                            <select name="poly" id="poly" class="text select2" >
                                <option value=""> -- </option>
                                <?
                                $qrypoly = mysql_query("SELECT * FROM m_poly ORDER BY kode ASC")or die (mysql_error());
                                while ($listpoly = mysql_fetch_array($qrypoly)) {
                                    ?>
                                    <option value="<? echo $listpoly['kode'];?>" <? if($listpoly['kode']==$poly) echo "selected=selected"; ?>><? echo $listpoly['nama'];?></option>
                                <? } ?>
                            </select></td>
                    </tr>
                    <tr>
						<td>Tanggal</td>
                        <td><input type="text" name="tgl_reg" id="tgl_pesan" readonly="readonly" class="text datepicker"
                                   value="<? if($tgl_reg!="") {
                                       echo $tgl_reg;
                                   }?>" style="width:100px;"/></td>
                        <td width="52">Kunjungan</td>
                        <td><select name="kunjungan" id="kunj" class="text" >
                                <option value=""> -- </option>
                                <option value="1" <? if($kunjungan=="1") echo "selected=selected"; ?>>BARU</option>
                                <option value="2" <? if($kunjungan=="2") echo "selected=selected"; ?>>LAMA</option>
                            </select></td>
                    </tr>
                    <tr>
						<td>Sd</td>
                        <td><input type="text" name="tgl_reg2" id="tgl_pesan2" readonly="readonly" class="text datepicker"
                                   value="<? if($tgl_reg2!="") {
                                       echo $tgl_reg2;
                                   }?>" style="width:100px;" /></td>
						<td>Dokter</td>
						<td>
							<select name="dokter" id="dokter" class="text select2" >
                                <option value=""> -- </option>
                                <?
                                $qrypoly = mysql_query("SELECT * FROM m_dokter WHERE st_aktif = 0 ORDER BY id_dokter ASC")or die (mysql_error());
                                while ($listpoly = mysql_fetch_array($qrypoly)) {
                                    ?>
                                    <option value="<? echo $listpoly['KDDOKTER'];?>" <? if($listpoly['KDDOKTER']==$dokter) echo "selected=selected"; ?>><? echo $listpoly['NAMADOKTER'];?></option>
                                <? } ?>
                            </select>
						</td>
                    </tr>
                    <tr>
						<td>Shift</td>
                        <td><select name="shift" id="shift" class="text" >
                                <option value=""> -- </option>
                                <option value="1" <? if($shift=="1") echo "selected=selected"; ?>>Pagi</option>
                                <option value="2" <? if($shift=="2") echo "selected=selected"; ?>>Sore</option>
                            </select></td>
                        <td width="52">Cara Daftar</td>
                        <td>
							<select name="cara_daftar" id="cara_daftar" class="text">
								<option value=""> -- </option>
								<option value=" AND E.NIP LIKE 'sms' " <?= $_REQUEST['cara_daftar'] == " AND E.NIP LIKE 'sms' " ? "selected" : ""; ?>> SMS </option>
								<option value=" AND E.NIP LIKE 'apm' " <?= $_REQUEST['cara_daftar'] == " AND E.NIP LIKE 'apm' " ? "selected" : ""; ?>> Anjungan Mandiri </option>
							</select>
						</td>
                    </tr>
					<tr>
						<td colspan="4">
							<br/>
							<input type="hidden" name="link" value="22" />
							<input type="submit" value=" C a r i " class="text"/>
						</td>
					</tr>
                </table>
                <br/>
            </form>

            <?
                $sql = "SELECT A.NOMR,
							   A.NAMA,
							   A.JENISKELAMIN,
							   A.ALAMAT,
							   B.NAMA AS POLY1,
							   C.NAMA AS CARABAYAR1,
							   D.NAMA AS RUJUKAN1, 
							   E.TGLREG,
							   E.SHIFT,
							   DR.NAMADOKTER, 
							   E.KETRUJUK, 
							   E.NORUJUKAN,
							   DATE_FORMAT(TGLREG,'%d/%m/%Y') TGLREG,
                               case PASIENBARU when 1 then 'B' else 'L' end as B_L,E.IDXDAFTAR ,
							   E.KDPOLY,
							   A.TGLLAHIR,
							   E.kode_p,
							   E.kode_t,
							   E.jam_status_kembali, 
							   TIME(E.start_daftar) AS start, 
							   TIME(E.end_daftar) end,
							   E.tutup_pembayaran,
							   SUM(t_billrajal.TARIFRS * t_billrajal.QTY) AS total,
							   E.KDCARABAYAR,
							   E.jam_kedatangan_status,
							   E.NIP,
							   DATE_FORMAT(start_daftar, '%H:%i') AS start_daftar,
						       E.is_cetak_sep
                        FROM m_pasien A, 
							 m_poly B, 
							 m_carabayar C, 
							 m_rujukan D, 
							 t_pendaftaran E
                        LEFT JOIN m_dokter DR on DR.KDDOKTER=E.KDDOKTER
						LEFT JOIN t_billrajal ON t_billrajal.IDXDAFTAR = E.IDXDAFTAR 
						                 AND t_billrajal.NOMR = E.NOMR
                        WHERE E.BATAL = 0 
						  AND A.NOMR=E.NOMR 
						  AND E.KDPOLY=B.KODE 
						  AND E.KDRUJUK=D.KODE 
						  AND E.KDCARABAYAR=C.KODE ". $_REQUEST['cara_daftar'] . " " . $search." 
						GROUP BY IDXDAFTAR
						ORDER BY E.IDXDAFTAR";
						
                $sqlcounter = "SELECT COUNT(*)
                                  FROM m_pasien A, m_poly B, m_carabayar C, m_rujukan D, t_pendaftaran E
                                  LEFT JOIN m_dokter DR on DR.KDDOKTER=E.KDDOKTER
                                  WHERE E.BATAL = 0 AND A.NOMR=E.NOMR AND E.KDPOLY=B.KODE AND E.KDRUJUK=D.KODE AND E.KDCARABAYAR=C.KODE ".$search." ORDER BY E.IDXDAFTAR";
            ?>
            <div align="center">
                <form name="formprint" method="post" action="report/pendaftaran/list_kunjungan_pasien_excel.php" target="_blank" >
                    <input type="hidden" name="query" value="<?=$sql?>" />
                    <input type="hidden" name="header" value="LIST KUNJUNGAN PASIEN" />
                    <input type="hidden" name="filename" value="list_kunjungan_pasien" />
                    <button id="export">Export Excel</button>
                </form>
            </div>
            <br/>
            <div id="head_report" style="display:none" >
                <div align="left" style="clear:both; padding:20px">
                    <div style="letter-spacing:-1px; font-size:16px; font:bold;"><?=strtoupper($header1)?></div>
                    <div style="letter-spacing:-2px; font-size:24px; color:#666; font:bold;"><?=strtoupper($header2)?></div>
                    <div><?=$header3?><br /><?=$header4?></div>
                    <hr style="margin:5px;" />
                    <h2>LIST DATA PASIEN</h2>
                </div>            
            </div>
            <div id="table_search">
                 <table width="95%" style="margin:10px;" border="0" class="tb" cellspacing="1" cellspading="1" title="List Semua Data Pasien.">
                    <tr>
                        <th>NO </th>
                        <th>Tanggal</th>
                        <th>NO RM</th>
                        <th>Nama Pasien</th>
                        <th>L/P</th>
                        <th>Alamat</th>
                        <th>Poly</th>
                        <th>Nama Dokter</th>
                        <th>Cara Bayar</th>
                        <th>Rujukan</th>
                        <th>Ket.Rujukan</th>
                        <th>No.Rujukan</th>
                        <th>B/L</th>
                        <th>Shift</th>
						<th>Jam Input</th>
						<th>Jam Daftar</th>
						<th>Jam Datang Status Ke Poli</th>
						<th>Jam Status Kembali</th>
						<th>#</th>
                        <th>Cetak</th>
                    </tr>
                    <?
                    $NO=0;

                    $pager = new PS_Pagination($connect, $sql, $sqlcounter, 15, 5, "", "index.php?link=21&");
                    $rs = $pager->paginate();
                    if(!$rs) die(mysql_error());
					$query = mysql_query($sql);
					$total = mysql_num_rows($query);
                    while($data = mysql_fetch_array($rs)) {?>
                    <tr <?   echo "class =";
                        $count++;
                        if ($count % 2) {
                            echo "tr1";
                        }
                        else {
                            echo "tr2";
                        }
                            ?>>
                        <td><?= $NO+1; $NO++;?></td>
                        <td><? echo $data['TGLREG'];?></td>
                        <td><? echo $data['NOMR'];?></td>
                        <td><? echo $data['NAMA']; ?></td>
                        <td><? echo $data['JENISKELAMIN']; ?></td>
                        <td><? echo $data['ALAMAT']; ?></td>
                        <td><? echo $data['POLY1']; ?></td>
                        <td><? echo $data['NAMADOKTER']; ?></td>
                        <td><? echo $data['CARABAYAR1'];?></td>
                        <td align="center"><? echo $data['RUJUKAN1'];?></td>
                        <td><? echo $data['KETRUJUK'];?></td>
                        <td><b><? echo $data['NORUJUKAN'];?></b></td>
                        <td><? echo $data['B_L'];?></td>
                        <td>
                            <?
                                echo get_detail_shift($data['SHIFT']);
                            ?>
                        </td>
						<td><?= $data['start']; ?></td>
						<td><?= $data['end']; ?></td>
						<td><?= $data['jam_kedatangan_status']; ?></td>
						<td><?= $data['jam_status_kembali']; ?></td>
						<td >
							<?php
								if($data['NIP'] == "sms" || $data['NIP'] == "APM"){
									$color = $data['is_cetak_sep'] == '0' ? '#BF360C' : '#00C853';
							?>
									<strong>
										<font id="font_sms_<?= $data['IDXDAFTAR']; ?>" style="font-size:14pt;color:<?= $color; ?>;"><?= $data['NIP']; ?></font>
									</strong>
							<?php
								}
							?>
						</td>
                        <td>
                            <button class="btn_kartu text" id="<?= $data['IDXDAFTAR']; ?>" nomr="<?= $data['NOMR']; ?>" nama="<?= $data['NAMA']; ?>">Kartu</button>
                            <button class="btn_identitas text" nomr="<?= $data['NOMR']; ?>">Identitas</button>
                            <button class="btn_sep text" idxdaftar="<?= $data['IDXDAFTAR']; ?>" nomr="<?= $data['NOMR']; ?>" poli="<?= $data['KDPOLY']; ?>" <?= $data['KDCARABAYAR'] != 5 ? "disabled" : ""; ?>>SEP</button>
                            <button class="btn_tracer text" idxdaftar="<?= $data['IDXDAFTAR']; ?>" nomr="<?= $data['NOMR']; ?>" poli="<?= $data['KDPOLY']; ?>">Tracer</button>
                            <button class="btn_tracer_kecil text" idxdaftar="<?= $data['IDXDAFTAR']; ?>" nomr="<?= $data['NOMR']; ?>" poli="<?= $data['KDPOLY']; ?>">Tracer Kecil</button>
                            <button class="btn_bukti_daftar_kecil text" idxdaftar="<?= $data['IDXDAFTAR']; ?>" nomr="<?= $data['NOMR']; ?>" poli="<?= $data['KDPOLY']; ?>">Bukti Daftar</button>
                            <button class="btn_tracer_sep text" idxdaftar="<?= $data['IDXDAFTAR']; ?>" nomr="<?= $data['NOMR']; ?>" poli="<?= $data['KDPOLY']; ?>" <?= $data['KDCARABAYAR'] != 5 ? "disabled" : ""; ?>>Tracer & SEP</button>
                            <button class="btn_stiker text" nomr="<?= $data['NOMR']; ?>" nama="<?= $data['NAMA']; ?>" tgllahir="<?= $data['TGLLAHIR']; ?>">LABEL</button>
                            <button class="btn_stiker_lama text" nomr="<?= $data['NOMR']; ?>" nama="<?= $data['NAMA']; ?>" tgllahir="<?= $data['TGLLAHIR']; ?>" jam_daftar="<?= $data['start_daftar']; ?>">STIKER</button>
                            <?php
								if($data['tutup_pembayaran'] == 0 ){
									$sql_bill = "SELECT * FROM rsud_trans_rj
												 WHERE idxdaftar = '". $data['IDXDAFTAR'] ."' ;";
									$rs_bill  = mysql_query($sql_bill);
									if(mysql_num_rows($rs_bill) == 0){
							?>
								<button class="btn_batal text" idxdaftar="<?= $data['IDXDAFTAR']; ?>" nomr="<?= $data['NOMR']; ?>" poli="<?= $data['KDPOLY'];  ?>" total_tarif="<?= $data['total']; ?>">BATAL</button>
							<?php 
									}
								}
							?>
							<form name="rm_status" id="rm_status" action="rajal/valid_keluar-masuk.php" method="post">
								<input type="hidden" name="NOMR" value="<? echo $data['NOMR']; ?>" />
								<input type="hidden" name="IDXDAFTAR2" value="<?php echo $data['IDXDAFTAR']; ?>"/>
								<input type="hidden" name="status_kembali" class="text status_kembali" value="" id="status_kembali" style="width:80px" />
								<? if($data['jam_status_kembali']=="00:00:00") { ?>
									<input type="submit" name="btn_ttv" class="text" value="STATUS KEMBALI" onclick="submitform (document.getElementById('rm_status'),'rajal/valid_keluar-masuk.php','valid_status',validatetask); return false;"/>
								<?  } else {
										echo "<strong> Jam Status Kembali ".$data['jam_status_kembali']."</strong>";
									} ?>
								<span id="valid_status">&nbsp;</span>
							</form>
						</td>
                    </tr>
                    <?php } 
                     //Display the full navigation in one go
                    //echo $pager->renderFullNav();

                    //Or you can display the inidividual links
                    echo "<div style='padding:5px;' align=\"center\"><br />";

                    //Display the link to first page: First
                    echo $pager->renderFirst()." | ";

                    //Display the link to previous page: <<
                    echo $pager->renderPrev()." | ";

                    //Display page links: 1 2 3
                    echo $pager->renderNav()." | ";

                    //Display the link to next page: >>
                    echo $pager->renderNext()." | ";

                    //Display the link to last page: Last
                    echo $pager->renderLast();

                    echo "</div>";?>
                </table>
                 <?php

                //Display the full navigation in one go
                //echo $pager->renderFullNav();

                //Or you can display the inidividual links
                echo "<div style='padding:5px;' align=\"center\"><br />";

                //Display the link to first page: First
                echo $pager->renderFirst()." | ";

                //Display the link to previous page: <<
                echo $pager->renderPrev()." | ";

                //Display page links: 1 2 3
                echo $pager->renderNav()." | ";

                //Display the link to next page: >>
                echo $pager->renderNext()." | ";

                //Display the link to last page: Last
                echo $pager->renderLast();

                echo "</div>";
                ?>
            </div>
        </div>
    </div>
	<font style="font-size:18pt;"><b>Jumlah Pasien: <?= $total; ?></b></font>
    <br />
</div>

<div id="dialog-form" >
    <form method="post">
        <fieldset>
            <div id="keterangan_batal"></div>
			<div>Apakah Anda yakin akan membatalkan transaksi ini? </div><br/><br/>
            <label>Alasan Pembatalan : <label>
			<input type="hidden" id="idxdaftar_batal"/>
			<input type="hidden" id="nomr_batal"/>
			<input type="hidden" id="poli_batal"/>
			<input type="text" id="alasan_batal"/>
			<button class="text" id="btn_batal_yes">Batalkan</button>
        </fieldset>
    </form>
</div>

<script>
    jQuery('.select2').select2();
    //jQuery("#table").dataTable({
    //    "paging": false
    //});
    jQuery("#export").button({icons: {primary: "ui-icon-arrowthickstop-1-s"}});
    jQuery(".btn_kartu").click(function(){
        var id   = jQuery(this).attr("id");
        var nomr = jQuery(this).attr("nomr");
        var nama = jQuery(this).attr("nama");
        window.open("pdfb/kartupasien.php?NOMR="+nomr+"&NAMA="+nama);
    });
    jQuery(".btn_identitas").click(function(){
        var nomr = jQuery(this).attr("nomr");
        window.open("cetakIdentitasPasien.php?NOMR="+nomr);
    });
    jQuery(".btn_sep").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
		jQuery.ajax({
            url: "models/cetak_sep_done.php",
            method: "post",
            data: {idxdaftar:idxdaftar,nomr:nomr,poli:poli},
            success: function(data){
				jQuery('#font_sms_'+idxdaftar).removeAttr('style', '');
				jQuery('#font_sms_'+idxdaftar).attr('style', 'font-size:14pt;color:#00C853;');
                window.open("print_sep.php?idx="+idxdaftar+"&poly="+poli+"&nomr="+nomr);
            },
            error: function(jqXHR, textStatus, errorThrown){
                alert("Perubahan gagal dilakukan!");
            }
		});
    });
    jQuery(".btn_tracer").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("print_tracer.php?idx="+idxdaftar+"&poly="+poli);
    });
	jQuery(".btn_tracer_kecil").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("tracer.php?idx="+idxdaftar+"&poly="+poli);
    });
	jQuery(".btn_bukti_daftar_kecil").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("bukti_daftar.php?idx="+idxdaftar+"&poly="+poli);
    });
    jQuery(".btn_tracer_sep").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("print_tracer_sep.php?idx="+idxdaftar+"&poly="+poli);
    });
	jQuery(".btn_stiker").click(function(){
        var nama 	 = jQuery(this).attr("nama");
        var nomr     = jQuery(this).attr("nomr");
        var tgllahir = jQuery(this).attr("tgllahir");
        window.open("stiker.php?nomr="+nomr+"&nama="+nama+"&ttl="+tgllahir);
    });
    jQuery(".btn_stiker_lama").click(function(){
        var nama     = jQuery(this).attr("nama");
        var nomr     = jQuery(this).attr("nomr");
        var tgllahir = jQuery(this).attr("tgllahir");
        var jam_daftar = jQuery(this).attr("jam_daftar");
        window.open("stiker_lama.php?nomr="+nomr+"&nama="+nama+"&ttl="+tgllahir+"&jam_daftar="+jam_daftar);
    });
    jQuery(".btn_batal").click(function(){
        var idxdaftar   = jQuery(this).attr("idxdaftar");
        var nomr        = jQuery(this).attr("nomr");
        var poli        = jQuery(this).attr("poli");
        var total_tarif = jQuery(this).attr("total_tarif");
		
		jQuery('#idxdaftar_batal').val(idxdaftar);
		jQuery('#nomr_batal').val(nomr);
		jQuery('#poli_batal').val(poli);
		
		if(total_tarif > 82000){
			jQuery('#keterangan_batal').html('<font style="font-size:14pt; color: #B71C1C; font-weight:bold;">Perhatian! Pada transaksi ini terdapat rincian penunjang dan pemeriksaan lainnya. Harap Cek kembali ke bagian kasir/keuangan.</font>');
		}
  
		jQuery("#dialog-form").dialog("open");
    });
	
	jQuery("#btn_batal_yes").click(function(){
		var idxdaftar = jQuery('#idxdaftar_batal').val();
		var nomr 	  = jQuery('#nomr_batal').val();
		var poli 	  = jQuery('#poli_batal').val();
		var alasan 	  = jQuery('#alasan_batal').val();
		if(alasan == ""){
			alert("Harap diisi dulu alasan pembatalan, untuk membatalkan transaksi ini...");
		} else{
			jQuery.ajax({
            url: "models/pembatalan_pasien.php",
            method: "post",
            data: {idxdaftar:idxdaftar,nomr:nomr,poli:poli,alasan:alasan},
            success: function(data){
                alert("Pasien sudah dibatalkan");
                location.reload();
            },
            error: function(jqXHR, textStatus, errorThrown){
                alert("Perubahan gagal dilakukan!");
            }
        });
		}
	});
	
	jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 200,
        width: 700,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        close: function() {
            jQuery("#dialog-form").dialog('destroy');
        }
    });
	
	function show(){
        var Digital=new Date();
        var hours=Digital.getHours();
        var minutes=Digital.getMinutes();
        var seconds=Digital.getSeconds();
        var curTime =
            ((hours < 10) ? "0" : "") + hours + ":"
            + ((minutes < 10) ? "0" : "") + minutes + ":"
            + ((seconds < 10) ? "0" : "") + seconds;
        var dn="AM";

        if (hours>12){
            dn="PM";
            hours=hours-12
        }
        if (hours==0)
            hours=12;
        if (minutes<=9)
            minutes="0"+minutes;
        if (seconds<=9)
            seconds="0"+seconds;
		jQuery(".status_kembali").val(curTime);
        setTimeout("show()",1000)
    }
    show();
    //-->
    <!-- hide; from; old; browsers;
    var curDateTime = new Date();
    var curHour = curDateTime.getHours();
    var curMin = curDateTime.getMinutes();
    var curSec = curDateTime.getSeconds();
    var curTime =
        ((curHour < 10) ? "0" : "") + curHour + ":"
        + ((curMin < 10) ? "0" : "") + curMin + ":"
        + ((curSec < 10) ? "0" : "") + curSec;
    //-->
</script>