 <?php
    session_start();
    
    $search 	    = " AND E.TGLREG = curdate()";
    $tgl_reg 	    = "";
    if(!empty($_GET['tgl_reg'])) {
        $tgl_reg    = $_GET['tgl_reg'];
    }
    else{
        $tgl_reg    = date('Y-m-d');
    }

    if($tgl_reg !="") {
        $search     = " AND E.TGLREG BETWEEN  '".$tgl_reg."' ";
    }

    $tgl_reg2       = "";
    if(!empty($_GET['tgl_reg2'])) {
        $tgl_reg2   = $_GET['tgl_reg2'];
    }
    else{
        $tgl_reg2   = date('Y-m-d');
    }

    if($tgl_reg !="") {
        if($tgl_reg2 !="") {
            $search = $search." AND '".$tgl_reg2."' ";
        }else {
            $search = $search." AND '".$tgl_reg."' ";
        }
    }

    $norm           = "";
    if(!empty($_GET['norm'])) {
        $norm       = $_GET['norm'];
    }

    if($norm !="") {
        $search     = $search." AND A.NOMR = '".$norm."' ";
    }

    $nama           = "";
    if(!empty($_GET['nama'])) {
        $nama       = $_GET['nama'];
    }

    if($nama !="") {
        $search     = $search." AND A.NAMA LIKE '%".$nama."%' ";
    }

    $poly           = "";
    if(!empty($_GET['poly'])) {
        $poly       = $_GET['poly'];
    }

    if($poly !="") {
        $search     = $search." AND E.KDPOLY = '".$poly."' ";
    }

    $kunjungan      = "";
    if(!empty($_GET['kunjungan'])) {
        $kunjungan  = $_GET['kunjungan'];
    }

    if($kunjungan != "") {
        if ($kunjungan == 2) $kunjungan = 0;
        $search     = $search." AND E.PASIENBARU = '".$kunjungan."' ";
        if ($kunjungan == 0) $kunjungan = 2;
    }

    $shift          = "";
    if(!empty($_GET['shift'])) {
        $shift      = $_GET['shift'];
    }

    if($shift !="") {
        $search     = $search." AND E.SHIFT = '".$shift."' ";
    }
    $carabayar	    = '';
    if(!empty($_REQUEST['carabayar'])){
        $carabayar  = $_REQUEST['carabayar'];
        $search     = $search." AND c.KODE = '".$carabayar."' ";
    }
?>
<div align="center">
    <div id="frame">
        <div id="frame_title"><h3>LIST KUNJUNGAN PASIEN</h3></div>
        <div align="right" style="margin:5px;">
            <form name="formsearch" method="get" >
                <table width="450" border="0" cellspacing="0" class="tb">
                    <tr>
                        <td width="52">&nbsp;</td>
                        <td width="200">&nbsp;</td>
                        <td width="52">Carabayar</td><td>
                            <select name="carabayar" id="carabayar" class="text select2" >
                                <option value=""> -- </option>
                                <?
                                $qrypoly = mysql_query("SELECT * FROM m_carabayar ORDER BY orders ASC")or die (mysql_error());
                                while ($listpoly = mysql_fetch_array($qrypoly)) {
                                    ?>
                                    <option value="<? echo $listpoly['KODE'];?>" <? if($listpoly['KODE']==$poly) echo "selected=selected"; ?>><? echo $listpoly['NAMA'];?></option>
                                <? } ?>
                            </select></td>
                    </tr>
                    <tr>
                        <td width="52">No RM</td>
                        <td width="200"><input type="text" name="norm" id="norm" value="<? if($norm!="") { echo $norm; }?>" class="text" style="width:80px;"></td>
                        <td width="52">Poly</td><td>
                            <select name="poly" id="poly" class="text select2" >
                                <option value=""> -- </option>
                                <?
                                $qrypoly = mysql_query("SELECT * FROM m_poly ORDER BY kode ASC")or die (mysql_error());
                                while ($listpoly = mysql_fetch_array($qrypoly)) {
                                    ?>
                                    <option value="<? echo $listpoly['kode'];?>" <? if($listpoly['kode']==$poly) echo "selected=selected"; ?>><? echo $listpoly['nama'];?></option>
                                <? } ?>
                            </select></td>
                    </tr>
                    <tr>

                        <td>Nama</td>
                        <td><input type="text" name="nama" id="nama" value="<? if($nama!="") {
                                echo $nama;
                            }?>" class="text"></td>
                        <td width="52">Kunjungan</td>
                        <td><select name="kunjungan" id="kunj" class="text" >
                                <option value=""> -- </option>
                                <option value="1" <? if($kunjungan=="1") echo "selected=selected"; ?>>BARU</option>
                                <option value="2" <? if($kunjungan=="2") echo "selected=selected"; ?>>LAMA</option>
                            </select></td>
                    </tr>
                    <tr>

                        <td>Tanggal</td>
                        <td><input type="text" name="tgl_reg" id="tgl_pesan" readonly="readonly" class="text datepicker"
                                   value="<? if($tgl_reg!="") {
                                       echo $tgl_reg;
                                   }?>" style="width:100px;"/></td>
                        <td width="52">Shift</td>
                        <td><select name="shift" id="shift" class="text" >
                                <option value=""> -- </option>
                                <option value="1" <? if($shift=="1") echo "selected=selected"; ?>>Pagi</option>
                                <option value="2" <? if($shift=="2") echo "selected=selected"; ?>>Sore</option>
                            </select></td>
                    </tr>
                    <tr>

                        <td>Sd</td>
                        <td><input type="text" name="tgl_reg2" id="tgl_pesan2" readonly="readonly" class="text datepicker"
                                   value="<? if($tgl_reg2!="") {
                                       echo $tgl_reg2;
                                   }?>" style="width:100px;" /></td>
                        <td width="52"><input type="hidden" name="link" value="22" /></td>
                        <td><input type="submit" value=" C a r i " class="text"/></td>
                    </tr>

                </table>
                <br/>
            </form>

            <div align="center">
                <form name="formprint" method="post" action="report/pendaftaran/list_kunjungan_pasien_excel.php" target="_blank" >
                    <input type="hidden" name="query" value="<?=$sql?>" />
                    <input type="hidden" name="header" value="LIST KUNJUNGAN PASIEN" />
                    <input type="hidden" name="filename" value="list_kunjungan_pasien" />
                    <button id="export">Export Excel</button>
                </form>
            </div>
            <br/>
            <div id="table_search">
                <table id="table">
                    <thead>
                    <tr>
                        <th>NO </th>
                        <th>Tanggal</th>
                        <th>NO RM</th>
                        <th>Nama Pasien</th>
                        <th>L/P</th>
                        <th>Alamat</th>
                        <th>Poly</th>
                        <th>Nama Dokter</th>
                        <th>Cara Bayar</th>
                        <th>Rujukan</th>
                        <th>Ket.Rujukan</th>
                        <th>B/L</th>
                        <th>Shift</th>
						<th>Jam Input</th>
						<th>Jam Daftar</th>
						<th>Kode</th>
                        <th>Cetak</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
    <br />
</div>

<div id="dialog-form" >
    <form method="post">
        <fieldset>
			Apakah anda yakin akan membatalkan transaksi ini? <br/><br/>
            <label>Alasan Pembatalan : <label>
			<input type="hidden" id="idxdaftar_batal"/>
			<input type="hidden" id="nomr_batal"/>
			<input type="hidden" id="poli_batal"/>
			<input type="text" id="alasan_batal"/>
			<button class="text" id="btn_batal_yes">Batalkan</button>
        </fieldset>
    </form>
</div>

<script>
    jQuery('.select2').select2();
	
    var dataTable = $('#table_search').DataTable({
        "processing":true,
        "serverSide":true,
        "order":[],
        "ajax":{
            url:"models/fetch_patient_data.php",
            type:"POST"
        },
        "columnDefs":[
            {
                "target":[0,3,4],
                "orderable":false
            }
        ]
    });
	
    jQuery("#export").button({icons: {primary: "ui-icon-arrowthickstop-1-s"}});
    jQuery(".btn_kartu").click(function(){
        var id   = jQuery(this).attr("id");
        var nomr = jQuery(this).attr("nomr");
        var nama = jQuery(this).attr("nama");
        window.open("pdfb/kartupasien.php?NOMR="+nomr+"&NAMA="+nama);
    });
    jQuery(".btn_identitas").click(function(){
        var nomr = jQuery(this).attr("nomr");
        window.open("cetakIdentitasPasien.php?NOMR="+nomr);
    });
    jQuery(".btn_sep").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("print_sep.php?idx="+idxdaftar+"&poly="+poli+"&nomr="+nomr);
    });
    jQuery(".btn_tracer").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("print_tracer.php?idx="+idxdaftar+"&poly="+poli);
    });
	jQuery(".btn_tracer_kecil").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("tracer.php?idx="+idxdaftar+"&poly="+poli);
    });
	jQuery(".btn_bukti_daftar_kecil").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("bukti_daftar.php?idx="+idxdaftar+"&poly="+poli);
    });
    jQuery(".btn_tracer_sep").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
        window.open("print_tracer_sep.php?idx="+idxdaftar+"&poly="+poli);
    });
	jQuery(".btn_stiker").click(function(){
        var nama 	 = jQuery(this).attr("nama");
        var nomr     = jQuery(this).attr("nomr");
        var tgllahir = jQuery(this).attr("tgllahir");
        window.open("stiker.php?nomr="+nomr+"&nama="+nama+"&ttl="+tgllahir);
    });
    jQuery(".btn_batal").click(function(){
        var idxdaftar = jQuery(this).attr("idxdaftar");
        var nomr      = jQuery(this).attr("nomr");
        var poli      = jQuery(this).attr("poli");
		
		jQuery('#idxdaftar_batal').val(idxdaftar);
		jQuery('#nomr_batal').val(nomr);
		jQuery('#poli_batal').val(poli);
  
		jQuery("#dialog-form").dialog("open");
    });
	
	jQuery("#btn_batal_yes").click(function(){
		var idxdaftar = jQuery('#idxdaftar_batal').val();
		var nomr 	  = jQuery('#nomr_batal').val();
		var poli 	  = jQuery('#poli_batal').val();
		var alasan 	  = jQuery('#alasan_batal').val();
		if(alasan == ""){
			alert("Harap diisi dulu alasan pembatalan, untuk membatalkan transaksi ini...");
		} else{
			jQuery.ajax({
            url: "models/pembatalan_pasien.php",
            method: "post",
            data: {idxdaftar:idxdaftar,nomr:nomr,poli:poli,alasan:alasan},
            success: function(data){
                alert("Pasien sudah dibatalkan");
                location.reload();
            },
            error: function(jqXHR, textStatus, errorThrown){
                alert("Perubahan tidak gagal dilakukan!");
            }
        });
		}
	});
	
	jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 200,
        width: 700,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        close: function() {
            jQuery("#dialog-form").dialog('destroy');
        }
    });
	
	function show(){
        var Digital=new Date();
        var hours=Digital.getHours();
        var minutes=Digital.getMinutes();
        var seconds=Digital.getSeconds();
        var curTime =
            ((hours < 10) ? "0" : "") + hours + ":"
            + ((minutes < 10) ? "0" : "") + minutes + ":"
            + ((seconds < 10) ? "0" : "") + seconds;
        var dn="AM";

        if (hours>12){
            dn="PM";
            hours=hours-12
        }
        if (hours==0)
            hours=12;
        if (minutes<=9)
            minutes="0"+minutes;
        if (seconds<=9)
            seconds="0"+seconds;
		jQuery(".status_kembali").val(curTime);
        setTimeout("show()",1000)
    }
    show();
    //-->
    <!-- hide; from; old; browsers;
    var curDateTime = new Date();
    var curHour = curDateTime.getHours();
    var curMin = curDateTime.getMinutes();
    var curSec = curDateTime.getSeconds();
    var curTime =
        ((curHour < 10) ? "0" : "") + curHour + ":"
        + ((curMin < 10) ? "0" : "") + curMin + ":"
        + ((curSec < 10) ? "0" : "") + curSec;
    //-->
</script>