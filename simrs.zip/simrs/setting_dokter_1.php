<?php 
include("include/connect.php");
require_once('ps_pagebill.php');
?>
<script>
jQuery(document).ready(function(){
	jQuery('.loader').hide();
	jQuery('.button').click(function(){
		var kdpoly	= jQuery(this).attr('svn');
		var kddokter= jQuery('#dokter_'+kdpoly).val();
		var kddokter2= jQuery('#dokter2_'+kdpoly).val();
		jQuery('#loader_'+kdpoly).show();
		jQuery.post('<?php echo _BASE_; ?>include/ajaxload.php',{kdpoly:kdpoly,kddokter:kddokter,kddokter2:kddokter2,dokterjaga:'true'},function(data){
			//location.reload();
			jQuery('#btn_'+kdpoly).val('U P D A T E').css({'background':'#ff9900'});
			jQuery('#loader_'+kdpoly).hide();
		});
	});
});
</script>
<style type="text/css">
.loader{background:url(js/loading.gif) no-repeat; width:16px; height:16px; float:right; margin-right:30px;}
</style>
<div align="center">
    <div id="frame">
    	<div id="frame_title">
			<h3>Pengaturan Dokter Jaga TGL <?php echo date('d/m/Y'); ?></h3>
    	</div>
        <table width="70%">
        <tr><th>Nama Poly</th><th>Nama Dokter Jaga I</th><th>Nama Dokter Jaga II</th><th>Aksi</th></tr>
        <?php
		$sql	= mysql_query('select * from m_poly');
		while($dpoly = mysql_fetch_array($sql)){
			echo '<tr>';
				echo '<td>'.$dpoly['nama'].'</td>';
				echo '<td><select name="dokter" id="dokter_'.$dpoly['kode'].'">';
				$sql_3	= mysql_query('select * from m_dokter_jaga where kdpoly = '.$dpoly['kode'].'');
				$p		= mysql_fetch_array($sql_3);
				$sql_2	= mysql_query('SELECT DISTINCT NAMADOKTER, KDDOKTER FROM m_dokter GROUP BY NAMADOKTER ORDER BY NAMADOKTER ASC');
				while($ddok	= mysql_fetch_array($sql_2)){
					if($ddok['KDDOKTER'] == $p['kddokter']): $x = 'selected="selected"'; else: $x = ''; endif;
					echo'<option value="'.$ddok['KDDOKTER'].'" '.$x.'>'.$ddok['NAMADOKTER'].'</option>';
				}
				echo '</select><div class="loader" id="loader_'.$dpoly['kode'].'"></div></td>';
				
				echo '<td><select name="dokter" id="dokter2_'.$dpoly['kode'].'">';
				$sql_3	= mysql_query('select * from m_dokter_jaga where kdpoly = '.$dpoly['kode'].'');
				$p		= mysql_fetch_array($sql_3);
				$sql_2	= mysql_query('SELECT DISTINCT NAMADOKTER, KDDOKTER FROM m_dokter GROUP BY NAMADOKTER ORDER BY NAMADOKTER ASC');
				while($ddok	= mysql_fetch_array($sql_2)){
					if($ddok['KDDOKTER'] == $p['kddokter2']): $x = 'selected="selected"'; else: $x = ''; endif;
					echo'<option value="'.$ddok['KDDOKTER'].'" '.$x.'>'.$ddok['NAMADOKTER'].'</option>';
				}
				echo '</select><div class="loader" id="loader_'.$dpoly['kode'].'"></div></td>';
				if($p['kddokter'] == ''){
					echo '<td><input type="button" class="button text" value="S I M P A N" svn="'.$dpoly['kode'].'" id="btn_'.$dpoly['kode'].'"></td>';
				}else{
					echo '<td><input type="button" class="button text" value="U P D A T E" style="background:#ff9900;" svn="'.$dpoly['kode'].'" id="btn_'.$dpoly['kode'].'"></td>';
				}
			echo '</tr>';
		}
		?>
        </table>
	</div>
</div>
