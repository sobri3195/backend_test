<?php 
function Terbilang($x)
{
  $abil = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
  if ($x < 12)
    return " " . $abil[$x];
  elseif ($x < 20)
    return Terbilang($x - 10) . "belas";
  elseif ($x < 100)
    return Terbilang($x / 10) . " puluh" . Terbilang($x % 10);
  elseif ($x < 200)
    return " seratus" . Terbilang($x - 100);
  elseif ($x < 1000)
    return Terbilang($x / 100) . " ratus" . Terbilang($x % 100);
  elseif ($x < 2000)
    return " seribu" . Terbilang($x - 1000);
  elseif ($x < 1000000)
    return Terbilang($x / 1000) . " ribu" . Terbilang($x % 1000);
  elseif ($x < 1000000000)
    return Terbilang($x / 1000000) . " juta" . Terbilang($x % 1000000);
}

function nomr($p='0'){
	$sql="select LPAD(nomor,6,'0') as nomor from m_maxnomr";
	$query=mysql_query($sql);
	$data=mysql_fetch_assoc($query);
	$v = $data['nomor'] + $p;
	$vl=strlen($v);
	if($vl < 6){
		$x = 6 - $vl;
		$val	= '';
		for($i=1; $i<=$vl; $i++):
			$val = $val +0;
		endfor;
		echo "$val"."$v";
	}else{
		echo $v;
	}
}

//added 30062015
function getLastNoRak($p=0){
	$sql   = "SELECT no_rak AS nomor FROM m_maxnomr WHERE status=1";
	$query = mysql_query($sql);
	$data  = mysql_fetch_assoc($query);
	$v     = $data['nomor'];
	
	return $v;
}
//added 30062015

function getLastNoM($p=0){
	$sql="select last2 as nomor from m_maxnomr where status=1";
	$query=mysql_query($sql);
	$data=mysql_fetch_assoc($query);
	$v = $data['nomor'];
	$vl=strlen($v);
	if($v < 10){ $value = '0'.$v;
	}else if($v < 100){ $value =$v;
	
	}
	return $value;
}

function getLastMR($p=0){
	$sql="select last1 as nomor from m_maxnomr where status=1";
	$query=mysql_query($sql);
	$data=mysql_fetch_assoc($query);
	$v = $data['nomor'];
	$vl=strlen($v);
	if($v < 10){ $value = '0'.$v;
	}else if($v < 100){ $value =$v;
	
	}
	return $value;
}

function datediff3($d1, $d2){
	$d1 = str_replace("/", "-", $d1);
	$d2 = str_replace("/", "-", $d2);
	$sql = "SELECT DATEDIFF('".$d1."', '".$d2."') AS hari";
	$rs = mysql_query($sql);
	$row = mysql_fetch_array($rs);
	$a = array();
	$a['years'] 	= floor($row['hari'] / (365));
	$a['months'] = floor(($row['hari'] - $a['years'] * 365) / (30));
	$a['days'] 	= floor(($row['hari'] - $a['years'] * 365 - $a['months']*30)/ (60));
	echo $a['days'];
}

function datediff($d1, $d2){
	$diff 	= abs(strtotime($d2) - strtotime($d1));
	$a	= array();
	$a['years'] 	= floor($diff / (365*60*60*24));
	$a['months'] = floor(($diff - $a['years'] * 365*60*60*24) / (30*60*60*24));
	$a['days'] 	= floor(($diff - $a['years'] * 365*60*60*24 - $a['months']*30*60*60*24)/ (60*60*24));
	return $a;
	#printf("%d years, %d months, %d days\n", $years, $months, $days);
	/*
	$d1 = (is_string($d1) ? strtotime($d1) : $d1);
	$d2 = (is_string($d2) ? strtotime($d2) : $d2);
	$diff_secs = abs($d1 - $d2);
	$base_year = min(date("Y", $d1), date("Y", $d2));
	$diff = mktime(0, 0, $diff_secs, 1, 1, $base_year);
	return array(
	"years" => date("Y", $diff) - $base_year,
	"months_total" => (date("Y", $diff) - $base_year) * 12 + date("n", $diff) - 1,
	"months" => date("n", $diff) - 1,
	"days_total" => floor($diff_secs / (3600 * 24)),
	"days" => date("j", $diff) - 1,
	"hours_total" => floor($diff_secs / 3600),
	"hours" => date("G", $diff),
	"minutes_total" => floor($diff_secs / 60),
	"minutes" => (int) date("i", $diff),
	"seconds_total" => $diff_secs,
	"seconds" => (int) date("s", $diff)
	
	);*/
}

function CurFormat($value,$dec=0){
	$res = number_format ($value,$dec,",",".");
	return $res;
}

function getRealIpAddr() {
    if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
      $ip=$_SERVER['HTTP_CLIENT_IP']; // share internet
    } elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR']; // pass from proxy
    } else {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
  return $ip;
}
function jeniskelamin($P){
	if($P == 'P'){
		$v = "Perempuan (P)";
	}else{
		$v = "Laki - Laki (L)";
	}
	return $v;
}

function get_binary_jeniskelamin($P){
    if($P == 'P'){
        $v = 2;
    } else if($P == 'L'){
        $v = 1;
    } else{
        $v = 1;
    }
    return $v;
}
function getDokterName($kddokter){
	include("connect.php");
	$sql = mysql_query('select NAMADOKTER from m_dokter where KDDOKTER = '.$kddokter);
	if(mysql_num_rows($sql) > 0){
		$data = mysql_fetch_array($sql);
		$val = $data['NAMADOKTER'];
	}else{
		$val = '';
	}
	return $val;
}
function get_id_dokter($kddokter){
	include 'connect.php';
	$sql 	= mysql_query('select id_dokter from m_dokter where KDDOKTER = "'.$kddokter.'"');
	if(mysql_num_rows($sql) > 0){
		$data = mysql_fetch_array($sql);
		$val = $data['id_dokter'];
	}else{
		$val = '';
	}
	return $val;
}
function getJenisPoly($kdpoly){
	include("connect.php");
	$sql = mysql_query('select * from m_poly where kode = '.$kdpoly);
	if(mysql_num_rows($sql) > 0){
		$data = mysql_fetch_array($sql);
		$val = $data['jenispoly'];
	}else{
		$val = '';
	}
	return $val;
}
function getProfesiDoktor($kddokter){
	include("connect.php");
	$sql = mysql_query('select * from m_dokter where KDDOKTER = '.$kddokter);
	if(mysql_num_rows($sql) > 0){
		$data = mysql_fetch_array($sql);
		$val = $data['KDPROFESI'];
	}else{
		$val = '';
	}
	return $val;
}
function getKodePendaftaran($jenispoly,$kdprofesi){
	include("connect.php");
	#$sql = mysql_query('select * from m_tarifpendaftaran where jenispoly = "'.$jenispoly.'" and kdprofesi = "'.$kdprofesi.'"');
	#echo 'select * from m_tarifpendaftaran where jenispoly = "'.$jenispoly.'" and kdprofesi = "'.$kdprofesi.'"';
	$sql = 'select * from m_tarif2012 where kode_unit = "'.$jenispoly.'" and kode_profesi = "'.$kdprofesi.'"';
	$sql = mysql_query($sql);
	if(mysql_num_rows($sql) > 0){
		$data = mysql_fetch_array($sql);
		$val = $data['kode_tindakan'];
	}else{
		$val = '';
	}
	return $val;
}
function get_tarif_by_poly_profesi_carabayar($jenispoly,$kdprofesi,$kdcarabayar){
    include("connect.php");
    $sql = 'select * from m_tarif2012
            where kode_unit = "'.$jenispoly.'"
            and kode_profesi = "'.$kdprofesi.'"
            and kode_carabayar='.$kdcarabayar;
    $sql = mysql_query($sql);
    if(mysql_num_rows($sql) > 0){
        $data = mysql_fetch_array($sql);
        $val = $data['kode_tindakan'];
    }else{
        $val = getKodePendaftaran($jenispoly,$kdprofesi);
    }
    return $val;
}
function getTarifPendaftaran($kodetarif){
	include("connect.php");
	$sql = 'select * from m_tarif2012 where kode_tindakan = "'.$kodetarif.'"';
	$sql = mysql_query($sql);
	if(mysql_num_rows($sql) > 0){
		$data = mysql_fetch_array($sql);
		$val[] = $data['jasa_sarana'];
		$val[] = $data['jasa_pelayanan'];
		$val[] = $data['tarif'];
	}else{
		$val[] = '';
	}
	return $val;
}

function getLastNoBILL($p=0){
	include("connect.php");
	$sql = mysql_query('SELECT nomor FROM M_MAXNOBILL');
	if(mysql_num_rows($sql) > 0):
		$d	= mysql_fetch_array($sql);
		$no	= $d['nomor'] + $p;
	else:
		$no = 1;
	endif;
	return $no;
}
function getLastIDXDAFTAR($p=0){
	include("connect.php");
	$sql = mysql_query('select IDXDAFTAR from t_pendaftaran order by IDXDAFTAR desc limit 1');
	if(mysql_num_rows($sql) > 0):
		$d	= mysql_fetch_array($sql);
		$no	= $d['IDXDAFTAR'] + $p;
	else:
		$no = 1;
	endif;
	return $no;
}
function getLastIDXOBATtmp($p=0){
	include("connect.php");
	$sql = mysql_query('select IDXOBAT from tmp_cartresep order by IDXOBAT desc limit 1');
	if(mysql_num_rows($sql) > 0):
		$d	= mysql_fetch_array($sql);
		$no	= $d['IDXOBAT'] + $p;
	else:
		$no = 1;
	endif;
	return $no;
}

function getNamaPoly($kdpoly){
	include 'connect.php';
	$sql 	= mysql_query('select nama from m_poly where kode = '.$kdpoly);
	if(mysql_num_rows($sql)){
		$data	= mysql_fetch_array($sql);
		$v	= 'Daftar Tindakan Poliklinik '.$data['nama'];
	}else{
		$v	= 'Daftar Tindakan Lain Lain';
	}
	return $v;
}

function getPolyName($kdpoly){
    include 'connect.php';
    $sql 	= mysql_query('select nama from m_poly where kode = '.$kdpoly);
    if(mysql_num_rows($sql)){
        $data = mysql_fetch_array($sql);
        $v	  = $data['nama'];
    }else{
        $v	  = '';
    }
    return $v;
}

function getGroupUnit($val){
	include 'connect.php';
	$sql	= mysql_query('select * from m_unit where kode_unit = '.$val);
	if(mysql_num_rows($sql) > 0):
		$data	= mysql_fetch_array($sql);
		$v	= $data['grup_unit'];
	else:
		$v	= 1;
	endif;
	return $v;
}

function CheckLastLevel($kode_tindakan,$kelas=''){
	include 'connect.php';
	$kelas_q = '';
	if($kelas != ''){
		$kelas_q 	= 'and kelas = "'.$kelas.'"';
	}
	$sql = mysql_query('select * from m_tarif2012 where kode_tindakan like "'.$kode_tindakan.'.%" '.$kelas_q);
	$val = mysql_num_rows($sql);
	return $val;
}

function getLastLevel($kode_tindakan){
	include 'connect.php';
	$sql = mysql_query('select * from m_tarif2012 where kode_tindakan like "'.$kode_tindakan.'.%"');
	return $sql;
}

function getGroupName($kode){
	include 'connect.php';
	$sql = mysql_query('select * from m_tarif2012 where kode_tindakan like "'.$kode.'%" order by kode_tindakan asc limit 1');
	$data= mysql_fetch_array($sql);
	return $data;
}

function check_t_admission($nomr,$idxdaftar,$kondisi=''){
	include 'connect.php';
	if($kondisi != ''){
		$kondisi = 'and '.$kondisi;
	}
	$sql	= 'select * from t_admission where id_admission = "'.$idxdaftar.'" and nomr = "'.$nomr.'"';
	$sql 	= mysql_query($sql);
	$data	= mysql_fetch_array($sql);
	return $data;
}

function check_t_bayarrajal($nomr,$idxdaftar){
	include 'connect.php';
	$sql	= 'select * from t_bayarrajal where IDXDAFTAR = "'.$idxdaftar.'" and NOMR = "'.$nomr.'" ORDER BY NOBILL DESC LIMIT 1';
	$sql 	= mysql_query($sql);
	$data	= mysql_fetch_array($sql);
	return $data;
}

function check_t_bayarranap($nomr,$idxdaftar){
	include 'connect.php';
	$sql	= 'select * from t_bayarranap where IDXDAFTAR = "'.$idxdaftar.'" and NOMR = "'.$nomr.'"';
	$sql 	= mysql_query($sql);
	$data	= mysql_fetch_array($sql);
	return $data;
}

function check_rajal_ranap_status_operasi($select="*",$id){
	include 'connect.php';
	$sql	= mysql_query('select '.$select.' from t_operasi where id_operasi = '.$id);
	$data	= mysql_fetch_array($sql);
	return $data;
}

function getNamaDokter($kddokter){
	include 'connect.php';
	$sql 	= mysql_query('select * from m_dokter where KDDOKTER = "'.$kddokter.'"');
	$data	= mysql_fetch_array($sql);
	return $data;
}

function getTarif($kode){
	include 'connect.php';
	$sql = mysql_query('select jasa_sarana, jasa_pelayanan, tarif from m_tarif2012 where kode_tindakan ="'.$kode.'"');
	$data	= mysql_fetch_array($sql);
	return $data;
}
function TrimArray($Input){ 
	if (!is_array($Input))
		return trim($Input);
	return array_map('TrimArray', $Input);
}
function getKecamatanName($id){
	include("connect.php");
	$sql = mysql_query('select * from m_kecamatan where idkecamatan = '.$id);
	if(mysql_num_rows($sql) > 0){
		$data = mysql_fetch_array($sql);
		$val = $data['namakecamatan'];
	}else{
		$val = '';
	}
	return $val;
}

//added 08072015
function getbillobat($idxdaftar){
	include 'connect.php';
	$sql	  = mysql_query("SELECT COUNT(*) AS jml, nobill FROM t_billobat_rajal WHERE idxdaftar = ". $idxdaftar);
		//$data = mysql_fetch_array($sql);
		//$val  = $data['jml'];
	return $sql;
}

function getvalidasibillobat($nobill){
	include 'connect.php';
	$sql	= mysql_query("SELECT COUNT(*) AS jumlahnya FROM t_bayarrajal WHERE NOBILL = ". $nobill);
	$data	= mysql_fetch_array($sql);
	$val	= $data['jumlahnya'];
	return $val;
}

function getbillobatrajal($idxdaftar){
	include 'connect.php';
	$sql	= mysql_query("SELECT *, sum(harga) AS harga FROM t_billobat_rajal WHERE idxdaftar = ". $idxdaftar);
	return $sql;
}

function gettotalbayarobat($idxdaftar){
	include 'connect.php';
	$sql 	= mysql_query("SELECT harga, qty FROM t_billobat_rajal WHERE idxdaftar = ". $idxdaftar);
	
	$total 	= 0;
	while($row = mysql_fetch_array($sql, MYSQL_NUM)){
		$total = $total + ($row[0] * $row[1]);
		//echo $row[0] . " " . $row[1] . "<br/>";
	}
	
	return $total;
}

function getbayarobat($idxdaftar, $nobill){
	include "connect.php";
	$sql	= mysql_query("SELECT * FROM t_bayarrajal WHERE idxdaftar = ".$idxdaftar." AND nobill = ".$nobill);
	return $sql;
}

function deleteRedundanBill($nobill){
	include "connect.php";
	$sql	= mysql_query("DELETE FROM t_bayarrajal WHERE nobill = ".$nobill);
}

function getbayarrajalapotik($idxdaftar){
	include "connect.php";
	$sql    = mysql_query("SELECT * FROM t_bayarrajal WHERE idxdaftar = ".$idxdaftar." AND NIP='apotik'");
	return $sql;
}

function updatetotaltarif($total, $idxdaftar){
	include "connect.php";
	$sql    = mysql_query("UPDATE `t_bayarrajal` SET TOTTARIFRS = ".$total.", sisabayar = ".$total." WHERE NIP = 'apotik' AND IDXDAFTAR = ".$idxdaftar);
}

function updatetarifbillrajal($total, $idxdaftar){
	include "connect.php";
	$sql    = mysql_query("UPDATE t_billrajal SET TARIFRS = ".$total." WHERE NIP = 'apotik' AND IDXDAFTAR = ".$idxdaftar);
	
}
//added 08072015

//added 07082015
function cek_pasien($nomr){
	include "connect.php";
	$sql 	= mysql_query("SELECT * FROM m_pasien WHERE NOMR = '". $nomr ."'");
	return $sql;
}

function datenow(){
	include "connect.php";
	$sql	= mysql_query("SELECT DATE(NOW()) AS DATENOW");
	$sqldb	= mysql_fetch_array($sql);
	return $sqldb['DATENOW'];
}

function datenow2(){
    include "connect.php";
    $sql	= mysql_query("SELECT NOW() AS DATENOW");
    $sqldb	= mysql_fetch_array($sql);
    return $sqldb['DATENOW'];
}

function jmlbatal($datenow){
	include "connect.php";
	$sql	= mysql_query("SELECT TOTTARIFRS FROM `t_bayarrajal` WHERE STATUS='LUNAS' AND TGLBAYAR='".$datenow."%'");
	
	$total 	= 0;
	while($row = mysql_fetch_array($sql, MYSQL_NUM)){
		if($row[0]<0){
			$total	= $total + 1;
		}
	}
	
	return $total;
}

function jmlbatal2($datenow){
	include "connect.php";
	$sql	= mysql_query("SELECT count(*) AS jml FROM m_batal WHERE TGLBATAL LIKE '".$datenow."%' AND KODETARIF LIKE '01.01.%'");
	
	$data	= mysql_fetch_array($sql);
	return $data['jml'];
}

function jmlbatal3($start,$end){
	include 'connect.php';
	$sql	= mysql_query("SELECT count(*) AS jml FROM m_batal WHERE (TGLBATAL BETWEEN '".$start."%' AND '".$end."%') AND KODETARIF LIKE '01.01.%'");
	
	$data	= mysql_fetch_array($sql);
	return $data['jml'];
}
//added 07082015

//added 10082015
function ambildatapasein($nomr){
	include 'connect.php';
	$sql	= mysql_query("SELECT * FROM m_pasien WHERE NOMR=".$nomr);
	
	$data	= mysql_fetch_array($sql);
	return $data;
}

function getkelurahan($kel){
	include 'connect.php';
	$sql	= mysql_query("SELECT namakelurahan FROM m_kelurahan WHERE idkelurahan=".$kel);
	$data	= mysql_fetch_array($sql);
	
	return $data['namakelurahan'];
}

function getkecamatan($kec){
	include 'connect.php';
	$sql	= mysql_query("SELECT namakecamatan FROM m_kecamatan WHERE idkecamatan=".$kec);
	$data	= mysql_fetch_array($sql);
	
	return $data['namakecamatan'];
}

function getkota($kota){
	include 'connect.php';
	$sql	= mysql_query("SELECT namakota FROM m_kota WHERE idkota=".$kota);
	$data	= mysql_fetch_array($sql);
	
	return $data['namakota'];
}

function getprovinsi($prov){
	include 'connect.php';
	$sql	= mysql_query("SELECT namaprovinsi FROM m_provinsi WHERE idprovinsi=".$prov);
	$data	= mysql_fetch_array($sql);
	
	return $data['namaprovinsi'];
}
//added 10082015

//added 11082015
function getdatabayar($nobill){
	include 'connect.php';
	$sql	= mysql_query("SELECT * FROM t_bayarrajal WHERE NOMR=".$nobill);
	$data	= mysql_fetch_array($sql);
	
	return $data;
}

function getfirstbill($nomr, $idxdaftar){
	include 'connect.php';
	$sql	= mysql_query("SELECT NOBILL, UNIT FROM t_billrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxdaftar);
	$data	= mysql_fetch_array($sql);
	
	return $data;
}

function getallbayarrajalbynobill($nobill){
	include 'connect.php';
	$sql	= mysql_query("SELECT * FROM t_bayarrajal WHERE NOBILL=".$nobill);
	$data	= mysql_fetch_array($sql);
	
	return $data;
}

function getunit($unit){
	include 'connect.php';
	$sql	= mysql_query("SELECT nama_unit FROM m_unit WHERE kode_unit=".$unit);
	$data	= mysql_fetch_array($sql);
	
	return $data['nama_unit'];
}

function getallcarabayar($kode){
	include 'connect.php';
	$sql	= mysql_query("SELECT * FROM m_carabayar WHERE KODE=".$kode);
	$data 	= mysql_fetch_array($sql);
	
	return $data;
}

function getDokter($kddokter){
	include 'connect.php';
	$sql	= mysql_query("SELECT * FROM m_dokter WHERE KDDOKTER=".$kddokter);
	$data	= mysql_fetch_array($sql);
	
	return $data;
}
//added 11082015

//added 12082015
function jmlbayarawalpendaftaran($nomr){
	include 'connect.php';
	$sql	= mysql_query("SELECT count(*) JML
                            FROM t_billrajal
                            JOIN t_pendaftaran ON t_pendaftaran.NOMR = t_billrajal.NOMR
                            WHERE t_billrajal.KODETARIF = '10'
                            AND t_billrajal.NOMR='".$nomr."'
                            AND t_billrajal.TANGGAL=(SELECT DATE(NOW()))
                            AND t_pendaftaran.TGLREG=(SELECT DATE(NOW()))
                            AND t_pendaftaran.BATAL=0");
	$data	= mysql_fetch_array($sql);
	
	return $data['JML'];
}

function updatenobill($nobill){
	include 'connect.php';
	$sql	= mysql_query("UPDATE m_maxnobill SET nomor=".$nobill);
}

function getmaxnobyr(){
	include 'connect.php';
	$sql 	= mysql_query("SELECT NOMOR FROM M_MAXNOBYR INTO iNOBAYAR");
	$data 	= mysql_fetch_array($sql);
	
	return $data['NOMOR'];
}

function updatenobyr($nobyr){
	include 'connect.php';
	$sql	= mysql_query("UPDATE M_MAXNOBYR SET NOMOR=".$nobyr);
}

function getjasatindakan($kodetindakan){
	include 'connect.php';
	$sql	= mysql_query("SELECT * FROM m_tarif2012 WHERE kode_tindakan=".$kodetindakan);
	$data 	= mysql_fetch_array($sql);
	
	return $data;
}
//added 12082015

//added 26082015
function getAllBank(){
	include 'connect.php';
	$sql	= mysql_query("SELECT * FROM m_bank");
	
	return $sql;
}
//added 26082015

//added 28082015
function getsisabayarrajal($idxdaftar){
	include 'connect.php';
	$sql	= mysql_query("SELECT sisabayar FROM t_bayarrajal WHERE NIP = 'apotik' AND IDXDAFTAR = ".$idxdaftar);
	$data	= mysql_fetch_array($sql);
	
	return $data['sisabayar'];
}
//added 28082015

//added 02092015
function getsisapembayaran($idxd){
	$sql = mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.qty, b.TARIFRS,c.NAMADOKTER
						FROM m_tarif2012 a, t_billrajal b
						LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
						WHERE a.kode_tindakan=b.KODETARIF
						AND b.IDXDAFTAR='".$idxd."'");
	
	$total	= 0;
	while($data = mysql_fetch_array($sql)){
		$total	= $total + ( $data['TARIFRS'] * $data['qty']);
	}
	
	$sql2=mysql_query("SELECT SUM(TOTTARIFRS) as total from t_bayarrajal where IDXDAFTAR='".$idxd."' and STATUS='LUNAS'");
	$data2=mysql_fetch_array($sql2);
	$byr=$data2['total'];
	$kurang=$total-$data2['total'];
	if($kurang < 0){
		$byr=$byr+$kurang;
		$kurang=0;
	}
	
	return $kurang;
}

function getTottarifrsrajal($idxd){
	$sql = mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.qty, b.TARIFRS,c.NAMADOKTER
						FROM m_tarif2012 a, t_billrajal b
						LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
						WHERE a.kode_tindakan=b.KODETARIF
						AND b.IDXDAFTAR='".$idxd."'");
	
	$total	= 0;
	while($data = mysql_fetch_array($sql)){
		$total	= $total + ( $data['TARIFRS'] * $data['qty']);
	}
	
	return $total;
}

function getTottarifrsrajal2($idxd, $nomr){
    $sql = mysql_query("SELECT
                            a.kode_tindakan AS kode,
                            a.nama_tindakan AS nama_jasa,
                            b.qty,
                            b.TARIFRS,c.NAMADOKTER
						FROM m_tarif2012 a, t_billrajal b
						LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
						WHERE a.kode_tindakan=b.KODETARIF
						    AND b.IDXDAFTAR='".$idxd."'
						    AND b.NOMR='".$nomr."'");

    $total	= 0;
    while($data = mysql_fetch_array($sql)){
        $total	= $total + ( $data['TARIFRS'] * $data['qty']);
    }

    return $total;
}

function getsisatarifrajal($idxd){
	$sql 	= mysql_query("SELECT SUM(sisabayar) AS sisabayar FROM t_bayarrajal WHERE IDXDAFTAR=".$idxd);
	$data	= mysql_fetch_array($sql);
	
	return $data['sisabayar'];
}

function getsisatarifrajal2($idxd, $nomr){
    $sql 	= mysql_query("SELECT
                                SUM(sisabayar) AS sisabayar
                            FROM t_bayarrajal
                            WHERE IDXDAFTAR=".$idxd ."
                                AND NOMR='".$nomr."' AND APS=0");
    $data	= mysql_fetch_array($sql);

    return $data['sisabayar'];
}

function getsisatarifrajal3($idxd, $nomr){
    $sql 	= mysql_query("SELECT
                                SUM(sisabayar) AS sisabayar
                            FROM t_bayarrajal
                            WHERE IDXDAFTAR=".$idxd ."
                                AND NOMR='".$nomr."' AND APS=1");
    $data	= mysql_fetch_array($sql);

    return $data['sisabayar'];
}

function getMaxIdxangsuranbyperson($idxd){
	$sql	= mysql_query("SELECT max(idxangsuran) AS max FROM t_angsuranrajal WHERE idxdaftar=".$idxd);
	$data	= mysql_fetch_array($sql);
	
	return $data['max'];
}

function getMaxIdxangsuranbyperson2($idxd, $nomr){
    $sql	= mysql_query("SELECT max(idxangsuran) AS max FROM t_angsuranrajal WHERE idxdaftar=".$idxd." AND nomr='".$nomr."'");
    $data	= mysql_fetch_array($sql);

    return $data['max'];
}
//added 02092015
//added 30092015
function getTahun(){
	$sql 	= mysql_query("SELECT YEAR(NOW()) AS tahun");
	$data 	= mysql_fetch_array($sql);
	
	return $data['tahun'];
}
//added 30092015
//added 06102015
function getKodeRujukan(){
	$sql 	= mysql_query("SELECT KODE FROM m_rujukan");
	
	return $sql;
}
//added 06102015
//added 07102015
function getAllPoly(){
	$sql 	= mysql_query("SELECT * FROM m_poly");
	
	return $sql;
}
function getNamaRujukan(){
	$sql 	= mysql_query("SELECT NAMA FROM m_rujukan WHERE KODE <> 1 ORDER BY ORDERS");
	
	return $sql;
}
//added 07102015
//added 12102015
function getShift(){
	$sql	= mysql_query("SELECT DISTINCT SHIFT FROM t_pendaftaran");
	
	return $sql;
}
function getJenkel(){
	$sql	= mysql_query("SELECT DISTINCT JENISKELAMIN FROM m_pasien");
	
	return $sql;
}
function insertTbl_temp14(){
	$tmp_all 		= '';
	$poly 			= getAllPoly();
	$jmlRowPoly		= mysql_num_rows($poly);
	while($dataPoly = mysql_fetch_array($poly)){
		$kode[] = $dataPoly['kode'];
	}
	
	$shift 			= getShift();
	$jmlRowShift	= mysql_num_rows($shift);
	
	$jenkel 		= getJenkel();
	$jmlRowJenkel	= mysql_num_rows($jenkel);
	while($dataJenkel = mysql_fetch_array($jenkel)){
		$gender[] = $dataJenkel['JENISKELAMIN'];
	}
	
	for($i = 0; $i < 2; $i++){
		$tmp_pasienbaru	= "SUM( IF(pasienbaru=".$i;
		if($i == 0){
			$status_pasienbaru	= "Lama";
		}
		else{
			$status_pasienbaru 	= "Baru";
		}
		
		for($j = 0; $j < $jmlRowShift; $j++){
			$tmp = $j+1;
			$tmp_shift 	= ",IF(shif=".$tmp;
			if($j == 0){
				$status_shift 	= "I";
			}
			else if($j == 1){
				$status_shift 	= "II";
			}
			else{
				$status_shift 	= "III";
			}
			
			for($k = 0; $k < $jmlRowJenkel; $k++){
				$tmp_jenkel = ",IF(jeniskelamin=\'".$gender[$k]."\'";
				$status_jenkel 	= $gender[$k];
				
				for($l = 0; $l < $jmlRowPoly; $l++){
					if($l < ($jmlRowPoly-1)){
						$tmp_poly = ",".$kode[$l]."_1, NULL), NULL), NULL)) + ";
					}
					else{
						$tmp_poly = ",".$kode[$l]."_1, NULL), NULL), NULL)) AS ".$status_pasienbaru."_".$status_shift."_".$status_jenkel.", ";
					}
					$tmp_all  = $tmp_all . $tmp_pasienbaru . $tmp_shift . $tmp_jenkel . $tmp_poly;
				}
			}
		}
	}
	$i = 0;
	$i++;
	mysql_query("DROP TABLE IF EXISTS tbl_temp14_temp;");
	mysql_query("CREATE TABLE tbl_temp14_temp(id int,data TEXT);");
	mysql_query("INSERT INTO tbl_temp14_temp(id,data) VALUES(".$i.",'".$tmp_all."');");
}

function insertTbl_temp15(){
	$tmp_all 		= '';
	$poly 			= getAllPoly();
	$jmlRowPoly		= mysql_num_rows($poly);
	while($dataPoly = mysql_fetch_array($poly)){
		$kode[] = $dataPoly['kode'];
	}
	
	$rujukan 		= getKodeRujukan();
	$jmlRowRujukan	= mysql_num_rows($rujukan);
	while ($dataRujukan = mysql_fetch_array($rujukan)){
		$kode_rj[] 	= $dataRujukan['KODE'];
	}
	
	for($i = 0; $i < $jmlRowRujukan; $i++){
		$tmp_rujukan 	= "SUM( IF(kdrujuk=".$kode_rj[$i];
		
		for($j = 0; $j < 2; $j++){
			$tmp_pasienbaru = ",IF(pasienbaru=".$j;
			if($j == 0){
				$status_pasienbaru	= "L";
			}
			else{
				$status_pasienbaru 	= "B";
			}
			
			for($k = 0; $k < $jmlRowPoly; $k++){
				if($k < ($jmlRowPoly-1)){
					$tmp_poly  = ",".$kode[$k]."_1, NULL), NULL)) + ";
				}
				else{
					$tmp_poly = ",".$kode[$k]."_1, NULL), NULL)) AS ".$kode_rj[$i]."_".$status_pasienbaru.", ";
				}
				
				$tmp_all 	= $tmp_all . $tmp_rujukan . $tmp_pasienbaru . $tmp_poly;
			}
		}	
	}
	$i = 0;
	$i++;
	mysql_query("DROP TABLE IF EXISTS tbl_temp15_temp;");
	mysql_query("CREATE TABLE tbl_temp15_temp(id int,data TEXT);");
	mysql_query("INSERT INTO tbl_temp15_temp(id,data) VALUES(".$i.",'".$tmp_all."');");
}
//added 12102015
//added 13102015
function getCaraBayar(){
	$sql 	= mysql_query("SELECT * FROM m_carabayar ORDER BY ORDERS ASC");
	
	return $sql;
}
function getCaraBayarlab(){
	$sql 	= mysql_query("SELECT kode,nama FROM m_carabayar ORDER BY ORDERS ASC");

	return $sql;
}
function getCaraBayarEx1(){
	$sql 	= mysql_query("SELECT * FROM m_carabayar WHERE KODE <> 1 order by ORDERS ASC");
	
	return $sql;
}
function insertTbl_temp16(){
	$tmp_all 		= '';
	$poly 			= getAllPoly();
	$jmlRowPoly		= mysql_num_rows($poly);
	while($dataPoly = mysql_fetch_array($poly)){
		$kode[] = $dataPoly['kode'];
	}
	
	for($i = 0; $i < 2; $i++){
		$tmp_pasienbaru = " SUM( IF(pasienbaru=".$i;
		if($i == 0){
			$status_pasienbaru	= "L";
		}
		else{
			$status_pasienbaru 	= "B";
		}
		
		for($j = 0; $j < $jmlRowPoly; $j++){
			$tmp_poly	= ",".$kode[$j]."_1, NULL)) AS ".$kode[$j]."_".$status_pasienbaru."_poly, ";
			$tmp_all	= $tmp_all . $tmp_pasienbaru . $tmp_poly;
		}
	}
	$i = 0;
	$i++;
	mysql_query("DROP TABLE IF EXISTS tbl_temp16_temp;");
	mysql_query("CREATE TABLE tbl_temp16_temp(id int,data TEXT);");
	mysql_query("INSERT INTO tbl_temp16_temp(id,data) VALUES(".$i.",'".$tmp_all."');");
}
function insertTbl_temp17(){
	$tmp_all 		= '';
	$poly 			= getAllPoly();
	$jmlRowPoly		= mysql_num_rows($poly);
	while($dataPoly = mysql_fetch_array($poly)){
		$kode[] = $dataPoly['kode'];
	}
	
	$crbayar 		= getCaraBayar();
	$jmlRowCraBayar	= mysql_num_rows($crbayar);
	while($dataCrBayar 	= mysql_fetch_array($crbayar)){
		$kodeCrbayar[] 	= $dataCrBayar['KODE'];  
	}
	
	for($i = 0; $i < $jmlRowCraBayar; $i++){
		$tmp_crbayar	= "SUM( IF(kdcarabayar=".$kodeCrbayar[$i];
		
		for($j =0; $j < 2; $j++){
			$tmp_pasienbaru = ",IF(pasienbaru=".$j;
			if($j == 0){
				$status_pasienbaru	= "L";
			}
			else{
				$status_pasienbaru 	= "B";
			}
			
			for($k = 0; $k < $jmlRowPoly; $k++){
				if($k < ($jmlRowPoly-1)){
					$tmp_poly 	= ",".$kode[$k]."_1, NULL), NULL)) + ";
				}
				else if($i == $jmlRowCraBayar-1 && $j == 1){
					$tmp_poly 	= ",".$kode[$k]."_1, NULL), NULL)) AS ".$kodeCrbayar[$i]."_".$status_pasienbaru.'_crbyr';
				}
				else{
					$tmp_poly 	= ",".$kode[$k]."_1, NULL), NULL)) AS ".$kodeCrbayar[$i]."_".$status_pasienbaru."_crbyr, ";
				}
				
				$tmp_all 	= $tmp_all . $tmp_crbayar . $tmp_pasienbaru . $tmp_poly;
			}
		}
	}
	$i = 0;
	$i++;
	mysql_query("DROP TABLE IF EXISTS tbl_temp17_temp;");
	mysql_query("CREATE TABLE tbl_temp17_temp(id int,data MEDIUMTEXT);");
	mysql_query("INSERT INTO tbl_temp17_temp(id,data) VALUES(".$i.",'".$tmp_all."');");
}
//added 13102015
//added 15102015
function getPasienAusransi($asuransi,$nama){
	if($nama == ''){
		$sql 	= mysql_query("SELECT t.NOMR,t.KDCARABAYAR,p.NAMA,p.TEMPAT,p.TGLLAHIR,p.ALAMAT,p.JENISKELAMIN 
								FROM t_pendaftaran AS t INNER JOIN m_pasien AS p ON t.NOMR=p.NOMR 
								WHERE t.KDCARABAYAR = ".$asuransi);
	}
	else{
		$sql 	= mysql_query("SELECT t.NOMR,t.KDCARABAYAR,p.NAMA,p.TEMPAT,p.TGLLAHIR,p.ALAMAT,p.JENISKELAMIN
								FROM t_pendaftaran AS t INNER JOIN m_pasien AS p ON t.NOMR=p.NOMR
								WHERE  p.NAMA LIKE '%".$nama."%' AND t.KDCARABAYAR = ".$asuransi);
	}
	return $sql;
}

function getRujukan(){
	$sql	= mysql_query("SELECT KODE,NAMA FROM m_rujukan ORDER BY ORDERS ASC");
	
	return $sql;
}
//added 15102015
//added 19102015
function getDateAndTime(){
	$sql	= mysql_query("SELECT NOW() AS skr");
	$data	= mysql_fetch_array($sql);
	
	return $data['skr'];
}
//added 19102015
//added 21102015
function getKDCARABAYARAtPendafataranaps($idxdaftar){
	$sql	= mysql_query("SELECT KDCARABAYAR FROM t_pendaftaran_aps WHERE IDXDAFTAR=".$idxdaftar);
	$data	= mysql_fetch_array($sql);
	
	return $data['KDCARABAYAR'];
}

function getBillLab($nomr, $nama, $crbayar, $start, $end, $tp){
	
	$kondisi	= '';
	if($nomr != ''){
		$kondisi = $kondisi.' AND a.nomr="'.$nomr.'" ';
	}
	if($nama != ''){
		$kondisi = $kondisi.' AND b.NAMA like "%'.$nama.'%" ';
	}
	if($crbayar != ''){
		$kondisi = $kondisi.' AND a.carabayar='.$crbayar.' ';
	}

	if($start == ''){
		$start 	= 'CURDATE()';
	}
	else{
		$start	= '"'.$start.'"';
	}
	
	if($end == ''){
		$end	= 'CURDATE()';
	}
	else{
		$end 	= '"'.$end.'"';
	}
	
	
	$search		= ' AND (d.TANGGAL BETWEEN '. $start .' AND '.$end.')';
	
	if($tp == 1){
		$tp 	= ' AND e.tutup_pembayaran>=0';
	}
	else {
		$tp 	= ' AND e.tutup_pembayaran=0';
	}
	
	$sql	= mysql_query("SELECT DISTINCT a.nomr, a.carabayar, a.idxdaftar, b.NAMA, c.NAMA AS NAMACARABAYAR, d.TANGGAL, e.tutup_pembayaran 
							FROM t_bayarlab AS a 
							INNER JOIN m_pasien_aps AS b ON a.nomr=b.NOMR
							INNER JOIN m_carabayar AS c ON a.carabayar=c.KODE
							INNER JOIN t_orderlab AS d ON a.idxdaftar=d.IDXDAFTAR
							INNER JOIN t_pendaftaran_aps AS e ON e.IDXDAFTAR=a.idxdaftar
							WHERE 1=1 ".$tp." ".$search." ".$kondisi);
	
	return $sql;
}

function getJmlCartLabLunas($nomr, $idxdaftar){
	$sql 	= mysql_query("SELECT COUNT(*) AS tagihan FROM t_bayarlab WHERE nomr='".$nomr."' AND idxdaftar=".$idxdaftar." AND lunas=0");
	$data	= mysql_fetch_array($sql);
	
	return $data['tagihan'];
}

function getStatusBayarLab($nomr, $idxdaftar){
	$tagihan 	= getJmlCartLabLunas($nomr, $idxdaftar);
	
	$status = '';
	if($tagihan==0){
		$sql 	= mysql_query("SELECT COUNT(*) AS count FROM t_bayarlab WHERE nomr='".$nomr."' AND idxdaftar=".$idxdaftar." AND status!='BATAL'");
		$data 	= mysql_fetch_array($sql);
		if($data['count'] > 0){
			$status	= 'Lunas';
		}else{
			$status	= 'Batal';
		}
	}
	else{
		$sql 	= mysql_query("SELECT COUNT(*) AS count FROM t_bayarlab WHERE nomr='".$nomr."' AND idxdaftar=".$idxdaftar." AND status!='BATAL'");
		$data 	= mysql_fetch_array($sql);
		if($data['count'] > 0){
			$status	= '';
		}
		else{
			$status	= 'Batal';
		}
	}
	
	return $status;
}
//added 21102015
//added 22102015
function getPasienAPS($nomr){
	$sql 	= mysql_query("SELECT * FROM m_pasien_aps WHERE NOMR='".$nomr."'");
	
	return $sql;
}

function getJenkelDetail($jenkel){
	switch($jenkel){
		case 'L':
				$detail	= 'Laki-laki';
				break;
		case 'P':
				$detail	= 'Perempuan';
				break;
	}
	
	return $detail;
}

function getUmur($tgllahir){
	$now 	= date("Y-m-d");
	$umur 	= datediff($tgllahir, $now);
	
	return $umur[years]." tahun ".$umur[months]." bulan ".$umur[days]." hari";
}

function getPendaftaranAPS($idxdaftar){
	$sql 	= mysql_query("SELECT * FROM t_pendaftaran_aps WHERE IDXDAFTAR=".$idxdaftar);
	
	return $sql;
}

function getCartBillLab($nomr, $idxdaftar){
	$sql 	= mysql_query("SELECT DISTINCT a.nomr, b.NOLAB, c.nama_gruptindakan, c.kode_tindakan, c.nama_tindakan AS nama_jasa, 
							c.tarif AS harga, b.QTY, a.idxdaftar FROM t_bayarlab AS a 
							JOIN t_orderlab AS b ON a.idxdaftar=b.IDXDAFTAR 
							JOIN m_tarif2012 AS c ON c.kode_tindakan=b.KODE 
							WHERE b.NOMR='".$nomr."' AND a.status!='BATAL' AND b.IDXDAFTAR=".$idxdaftar);
	
	return $sql;
}
//added 22102015
//added 23102015
function getNow(){
	$sql 	= mysql_query("SELECT TIME(now()) as time");
	
	return $sql;
}

function get_idxbayarlab($kode,$idxdaftar){
	$sql 	= mysql_query("SELECT idxbayarlab FROM t_bayarlab WHERE kode_tindakan = '".$kode."' AND idxdaftar=".$idxdaftar);
	$data 	= mysql_fetch_array($sql);
	
	return $data['idxbayarlab'];
}

function getSumTottariflab($idxdaftar){
	$sql	= mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.QTY, b.tariflab
							FROM m_tarif2012 a, t_orderlab b
							WHERE a.kode_tindakan=b.KODE AND b.IDXDAFTAR=".$idxdaftar);
	
	$total	= 0;
	while($data = mysql_fetch_array($sql)){
		$total	= $total + ( $data['tariflab'] * $data['QTY']);
	}
	
	return $total;
}

function getsisapembayaranlab($idxdaftar){
	$sql	= mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.QTY, b.tariflab 
							FROM m_tarif2012 a, t_orderlab b 
							WHERE a.kode_tindakan=b.KODE AND b.IDXDAFTAR=".$idxdaftar);
	
	$total	= 0;
	while($data = mysql_fetch_array($sql)){
		$total	= $total + ( $data['tariflab'] * $data['QTY']);
	}
	
	$sql2	=mysql_query("SELECT SUM(jmbayar) as total from t_bayarlab where IDXDAFTAR=".$idxdaftar." AND status!='BATAL'");
	$jmldata=mysql_num_rows($sql2);	
	$data2	=mysql_fetch_array($sql2);
	$byr	=$data2['total'];
	$kurang	=$total-$data2['total'];
	if($kurang < 0){
		$byr=$byr+$kurang;
		$kurang=0;
	}
	
	if($data2['total'] == NULL){
		$kurang = 0;
	}
	
	return $kurang;
}

function getSudahBayarLab($idxdaftar){
	$sql2	=mysql_query("SELECT SUM(jmbayar) as total from t_bayarlab where IDXDAFTAR=".$idxdaftar);
	$data2	=mysql_fetch_array($sql2);
	
	return $data2['total'];
}

function get_t_bayarlab($nomr,$idxd){
	$sql 	= mysql_query("SELECT * FROM t_bayarlab WHERE nomr='".$nomr."' AND idxdaftar=".$idxd);
	
	return $sql;
}

function get_t_bayarlabbystatus($nomr,$idxd,$status){
	$sql 	= mysql_query("SELECT * FROM t_bayarlab WHERE nomr='".$nomr."' AND idxdaftar=".$idxd." AND status!='".$status."'");

	return $sql;
}
//added 23102015
//added 26102015
function create_t_angsuranlab(){
	mysql_query("CREATE TABLE IF NOT EXISTS `t_angsuranlab` (
				  `idxangsuranlab` int(11) NOT NULL AUTO_INCREMENT,
				  `nomr` varchar(8) NOT NULL,
				  `idxdaftar` int(11) NOT NULL,
				  `tglbayar` date NOT NULL,
				  `jambayar` time NOT NULL,
				  `jmbayar` decimal(15,2) NOT NULL,
				  `shift` int(11) NOT NULL,
				  `nip` varchar(50) NOT NULL,
				  `tottariflab` decimal(11,2) NOT NULL,
				  `sisabayar` decimal(11,2) NOT NULL,
				  PRIMARY KEY (`idxangsuranlab`)
				) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");
}

function getTottariflab($nomr,$idxdaftar,$kode_tindakan){
	$sql 	= mysql_query("SELECT tariflab, QTY FROM t_orderlab WHERE NOMR='".$nomr."' AND IDXDAFTAR=".$idxdaftar." AND KODE='".$kode_tindakan."'");
	$data	= mysql_fetch_array($sql);
	
	$total 	= 0;
	$total	= $data['tariflab'] * $data['QTY'];
	return $total;
}

function getAutomaticShift(){
	$sql3 = getNow();
	while($ds = mysql_fetch_array($sql3)){
		$now 	= $ds['time'];
		$jam 	= substr($now, 0, 2);
		$menit 	= substr($now, 3, 2);
		$detik 	= substr($now, 6, 2);
	}
	
	$jam_now 		= new DateTime($now);
	$jam_pagi_bawah = new DateTime("07:00:00");
	$jam_pagi_atas 	= new DateTime("14:15:00");
	$jam_sore_atas 	= new DateTime("21:15:00");
	
	if($jam_now > $jam_pagi_bawah && $jam_now < $jam_pagi_atas){
		$shift = 1;
	}
	else{
		$shift = 2;
	}
	
	return $shift;
}
//added 26102015
//added 27102015
function create_m_batal_penunjang(){
	mysql_query("CREATE TABLE IF NOT EXISTS `m_batal_penunjang` (
				  `idbatal` int(11) NOT NULL AUTO_INCREMENT,
				  `idxbayar` int(11) NOT NULL,
				  `idxdaftar` int(11) NOT NULL,
				  `nomr` varchar(6) NOT NULL,
				  `kode_tindakan` varchar(16) NOT NULL,
				  `tglbatal` datetime NOT NULL,
				  `shift` smallint(2) NOT NULL,
				  `nip` varchar(50) NOT NULL,
				  `carabayar` smallint(2) NOT NULL,
				  `qty` smallint(3) NOT NULL,
				  `tarif` decimal(11,2) NOT NULL,
				  `kdunit` smallint(6) NOT NULL,
				  PRIMARY KEY (`idbatal`)
				) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");
}

function get_t_orderlab($idxdaftar,$kode){
	$sql	= mysql_query("SELECT * FROM t_orderlab WHERE IDXDAFTAR=".$idxdaftar." AND KODE='".$kode."'");
	
	return $sql;
}

function getUnitByNama($nama){
	$sql 	= mysql_query("SELECT * FROM m_unit WHERE nama_unit LIKE '%".$nama."%'");
	
	return $sql;
}

function getsisatariflab($idxd){
	$sql 	= mysql_query("SELECT SUM(sisabayar) AS sisabayar FROM t_bayarlab WHERE IDXDAFTAR=".$idxd);
	$data	= mysql_fetch_array($sql);

	return $data['sisabayar'];
}

function getMaxIdxangsuranlabbyperson($idxd){
	$sql	= mysql_query("SELECT max(idxangsuranlab) AS max FROM t_angsuranlab WHERE idxdaftar=".$idxd);
	$data	= mysql_fetch_array($sql);

	return $data['max'];
}

function cek_pasienStatus($nomr, $idxdaftar){
	$sql 	= mysql_query("SELECT count(*) AS count FROM m_pasien AS a INNER JOIN t_pendaftaran AS b ON a.NOMR=b.NOMR WHERE a.NOMR='".$nomr."' AND b.IDXDAFTAR=".$idxdaftar);
	$data	= mysql_fetch_array($sql);
	
	return $data['count'];
}

function cek_pasienAPSStatus($nomr, $idxdaftar){
	$sql 	= mysql_query("SELECT count(*) AS count FROM m_pasien_aps AS a INNER JOIN t_pendaftaran_aps AS b ON a.NOMR=b.NOMR WHERE a.NOMR='".$nomr."' AND b.IDXDAFTAR=".$idxdaftar);
	$data 	= mysql_fetch_array($sql);
	
	return $data['count'];
}

function getStatusDetail($status){
	switch ($status){
		case 1: 
				$stts = 'Belum Kawin';
				break;
		case 2:
				$stts = 'Kawin';
				break;
		case 3:
				$stts = 'Janda / Duda';
				break;
	}
	
	return $stts;
}

function getAgamaDetail($agama){
	switch ($agama){
		case 1:
			$detail = 'Islam';
			break;
		case 2:
			$detail = 'Kristen Protestan';
			break;
		case 3:
			$detail = 'Khatolik';
			break;
		case 4:
			$detail = 'Hindu';
			break;
		case 5:
			$detail = 'Budha';
			break;
		case 6:
			$detail = 'Lain-lain';
			break;
	}
	
	return $detail;
}

function getPendidikanDetail($pend){
	switch ($pend){
		case 1:
			$detail = 'SD';
			break;
		case 2:
			$detail = 'SLTP';
			break;
		case 3:
			$detail = 'SMU';
			break;
		case 4:
			$detail = 'D3/Akademik';
			break;
		case 5:
			$detail = 'Universitas';
			break;
	}

	return $detail;
}

function getAllKelurahan(){
	$sql 	= mysql_query("SELECT * FROM m_kelurahan");
	
	return $sql;
}

function getRincianLab($nomr, $idxdaftar, $nolab){
	$sql 	= mysql_query("SELECT DISTINCT a.NOMR, 
								  a.IDXDAFTAR, 
								  a.NOLAB, 
								  a.DRPENGIRIM, 
								  a.KDPOLY, 
								  a.KODE, 
								  b.nama_tindakan, 
								  c.TARIFRS AS tottariflab
							FROM t_orderlab AS a 
							INNER JOIN m_tarif2012 AS b ON a.KODE=b.kode_tindakan 
							INNER JOIN t_billrajal AS c ON a.KODE=c.KODETARIF
							WHERE a.NOMR='".$nomr."' 
							  AND a.IDXDAFTAR=".$idxdaftar." 
							  AND c.IDXDAFTAR=".$idxdaftar."
							  AND a.NOLAB='".$nolab."'");
	
	return $sql;
}

function getRincianLabRanap($nomr, $idxdaftar, $nolab){
	$sql 	= mysql_query("SELECT DISTINCT t_orderlab.NOMR, 
								  t_orderlab.IDXDAFTAR, 
								  t_orderlab.NOLAB, 
								  t_orderlab.DRPENGIRIM, 
								  t_orderlab.KDPOLY, 
								  t_orderlab.KODE, 
								  m_tarif2012.nama_tindakan, 
								  ri_billing.tarif_rs
							FROM t_orderlab
							JOIN m_tarif2012 ON m_tarif2012.kode_tindakan = t_orderlab.KODE
							JOIN ri_billing ON ri_billing.id_tarif = t_orderlab.KODE
							WHERE t_orderlab.NOMR = '".$nomr."' 
							  AND t_orderlab.IDXDAFTAR = ".$idxdaftar." 
							  AND ri_billing.id_register = ".$idxdaftar."
							  AND t_orderlab.NOLAB = '".$nolab."'
							  AND t_orderlab.is_batal = 0 ;");
	
	return $sql;
}

function getRincianRad($nomr, $idxdaftar){
	$sql 	= mysql_query("SELECT DISTINCT a.NOMR, 
								  a.IDXDAFTAR, 
								  a.IDXORDERRAD, 
								  a.DRPENGIRIM, 
								  a.POLYPENGIRIM,
								  a.JENISPHOTO, 
								  b.nama_tindakan, 
								  c.TARIFRS
							FROM t_radiologi AS a
							INNER JOIN m_tarif2012 AS b ON a.JENISPHOTO=b.kode_tindakan
							INNER JOIN t_billrajal AS c ON a.JENISPHOTO=c.KODETARIF
							WHERE a.BATAL = 0 
							  AND a.NOMR='".$nomr."' 
							  AND a.IDXDAFTAR=".$idxdaftar." 
							  AND c.IDXDAFTAR=".$idxdaftar);

	return $sql;
}

function getRincianRadRanap($nomr, $idxdaftar, $no_rincian){
	$sql 	= "SELECT DISTINCT t_radiologi.NOMR,
					  t_radiologi.IDXDAFTAR,
					  t_radiologi.IDXORDERRAD,
					  t_radiologi.DRPENGIRIM,
					  t_radiologi.POLYPENGIRIM,
					  t_radiologi.JENISPHOTO,
					  m_tarif2012.nama_tindakan,
					  ri_billing.tarif_rs
			   FROM t_radiologi
			   INNER JOIN m_tarif2012 ON t_radiologi.JENISPHOTO = m_tarif2012.kode_tindakan
			   INNER JOIN ri_billing ON ri_billing.id_tarif = t_radiologi.JENISPHOTO
			   WHERE t_radiologi.BATAL = 0
			     AND t_radiologi.NOMR = '".$nomr."' 
	    		 AND t_radiologi.IDXDAFTAR=".$idxdaftar." 
				 AND ri_billing.id_register=".$idxdaftar."
				 AND t_radiologi.IDXORDERRAD = ".$no_rincian;
	
	$rs 	= mysql_query($sql);
				 
	return $rs;
}

function getRincianFisio($nomr, $idxdaftar){
	$sql 	= mysql_query("SELECT a.NOMR, a.IDXDAFTAR, a.IDXORDERFISIO, a.DRPENGIRIM, a.POLYPENGIRIM, a.KODE,
							b.nama_tindakan, c.TARIFRS
							FROM t_fisioterapi AS a
							INNER JOIN m_tarif2012 AS b ON a.KODE=b.kode_tindakan
							INNER JOIN t_billrajal AS c ON a.KODE=c.KODETARIF
							WHERE a.NOMR='".$nomr."' 
							  AND a.IDXDAFTAR=".$idxdaftar." 
							  AND c.IDXDAFTAR=".$idxdaftar." 
							  AND BATAL=0");

	return $sql;
}

function getRincianFisioRanap($nomr, $idxdaftar, $idxorderpa){
	$sql 	= mysql_query("SELECT t_fisioterapi.NOMR, 
								  t_fisioterapi.IDXDAFTAR, 
								  t_fisioterapi.IDXORDERFISIO, 
								  t_fisioterapi.DRPENGIRIM, 
								  t_fisioterapi.POLYPENGIRIM, 
								  t_fisioterapi.KODE,
								  m_tarif2012.nama_tindakan, 
								  ri_billing.tarif_rs
						   FROM t_fisioterapi
						   INNER JOIN m_tarif2012 ON t_fisioterapi.KODE=m_tarif2012.kode_tindakan
						   INNER JOIN ri_billing ON ri_billing.id_tarif = t_fisioterapi.KODE
						   WHERE t_fisioterapi.NOMR = '".$nomr."' 
						     AND t_fisioterapi.IDXDAFTAR = ".$idxdaftar." 
							 AND ri_billing.id_register = ".$idxdaftar."
							 AND t_fisioterapi.IDXORDERFISIO = '". $idxorderpa ."'
							 AND ri_billing.no_penunjang = '". $idxorderpa ."'
							 AND t_fisioterapi.BATAL = 0
							 AND ri_billing.is_batal = 0
							 group by IDXFISIO");

	return $sql;
}

function getRincianPA($nomr, $idxdaftar, $idxpa){
	$sql 	= mysql_query("SELECT a.NOMR, 
								  a.IDXDAFTAR, 
								  a.IDXPA AS IDXORDERPA, 
								  a.DRPENGIRIM, 
								  a.POLYPENGIRIM, 
								  a.KODE,
								  b.nama_tindakan, 
								  c.TARIFRS, 
								  a.no_register_manual
						   FROM t_patologi_anatomi AS a
						   INNER JOIN m_tarif2012 AS b ON a.KODE=b.kode_tindakan
						   INNER JOIN t_billrajal AS c ON a.KODE=c.KODETARIF
						   WHERE a.NOMR='".$nomr."' 
						     AND a.IDXDAFTAR=".$idxdaftar." 
							 AND c.IDXDAFTAR=".$idxdaftar." 
							 AND a.IDXPA=".$idxpa);

	return $sql;
}

function getRincianPARanap($nomr, $idxdaftar, $idxpa){
	$sql 	= "SELECT DISTINCT t_patologi_anatomi.NOMR, 
					  t_patologi_anatomi.IDXDAFTAR, 
					  t_patologi_anatomi.IDXPA AS IDXORDERPA, 
					  t_patologi_anatomi.DRPENGIRIM, 
					  t_patologi_anatomi.POLYPENGIRIM, 
					  t_patologi_anatomi.KODE,
					  m_tarif2012.nama_tindakan,
					  ri_billing.tarif_rs,
					  t_patologi_anatomi.no_register_manual
			   FROM t_patologi_anatomi
			   INNER JOIN m_tarif2012 ON t_patologi_anatomi.KODE=m_tarif2012.kode_tindakan
		       INNER JOIN ri_billing ON ri_billing.id_tarif = t_patologi_anatomi.KODE
			   WHERE t_patologi_anatomi.NOMR='".$nomr."' 
			     AND t_patologi_anatomi.IDXDAFTAR = ".$idxdaftar." 
				 AND ri_billing.id_register = ".$idxdaftar." 
				 AND t_patologi_anatomi.IDXPA = ".$idxpa;

	$rs 	= mysql_query($sql);
				 
	return $rs;
}

function getRincianLabKiriman($nomr, $idxdaftar, $nolab){
	$sql 	= mysql_query("SELECT DISTINCT a.NOMR, 
								  a.IDXDAFTAR, 
								  a.NOLAB, 
								  a.DRPENGIRIM, 
								  a.KDPOLY, 
								  a.KODE, 
								  b.nama_tindakan, 
								  b.tarif 
							FROM t_orderlab AS a 
							INNER JOIN m_tarif2012 AS b ON a.KODE=b.kode_tindakan 
							WHERE a.NOMR='".$nomr."' 
							  AND a.IDXDAFTAR=".$idxdaftar."
							  AND a.NOLAB='".$nolab."'");
	
	return $sql;
}

function getRincianRadKiriman($nomr, $idxdaftar){
	$sql 	= mysql_query("SELECT DISTINCT a.NOMR, a.IDXDAFTAR, a.IDXORDERRAD, a.DRPENGIRIM, a.POLYPENGIRIM, 
							a.JENISPHOTO, b.nama_tindakan, b.tarif
							FROM t_radiologi AS a
							INNER JOIN m_tarif2012 AS b ON a.JENISPHOTO=b.kode_tindakan
							WHERE a.BATAL = 0 AND a.NOMR='".$nomr."' AND a.IDXDAFTAR=".$idxdaftar );

	return $sql;
}

function getRincianRadKiriman2($nomr, $idxdaftar, $idxorder){
	$sql 	= mysql_query("SELECT DISTINCT a.NOMR, a.IDXDAFTAR, a.IDXORDERRAD, a.DRPENGIRIM, a.POLYPENGIRIM, 
							a.JENISPHOTO, b.nama_tindakan, b.tarif
							FROM t_radiologi AS a
							INNER JOIN m_tarif2012 AS b ON a.JENISPHOTO=b.kode_tindakan
							WHERE a.BATAL = 0 AND a.NOMR='".$nomr."' AND a.IDXDAFTAR=".$idxdaftar ." AND IDXORDERRAD = " . $idxorder );

	return $sql;
}

function getRincianFisioKiriman($nomr, $idxdaftar){
	$sql 	= mysql_query("SELECT a.NOMR, a.IDXDAFTAR, a.IDXORDERFISIO, a.DRPENGIRIM, a.POLYPENGIRIM,
							a.KODE, b.nama_tindakan, b.tarif
							FROM t_fisioterapi AS a
							INNER JOIN m_tarif2012 AS b ON a.KODE=b.kode_tindakan
							WHERE a.NOMR='".$nomr."' AND a.IDXDAFTAR=".$idxdaftar." AND BATAL=0");

	return $sql;
}

function getRincianPAKiriman($nomr, $idxdaftar, $idxpa){
	$sql 	= mysql_query("SELECT a.NOMR, a.IDXDAFTAR, a.IDXORDERPA, a.DRPENGIRIM, a.POLYPENGIRIM,
							a.KODE, b.nama_tindakan, b.tarif, a.no_register_manual
							FROM t_patologi_anatomi AS a
							INNER JOIN m_tarif2012 AS b ON a.KODE=b.kode_tindakan
							WHERE a.NOMR='".$nomr."' AND a.IDXDAFTAR=".$idxdaftar." AND a.IDXPA=".$idxpa);

	return $sql;
}

function getPolyByID($kode){
	$sql 	= mysql_query("SELECT * FROM m_poly WHERE kode=".$kode);
	
	return $sql;
}

function getRuangByID($kd_ruang){
	$sql = "SELECT NM_RUANG
			FROM ri_ruang
			WHERE KD_RUANG = '" . $kd_ruang . "'";
	$rs  = mysql_query($sql);
	$row = mysql_fetch_array($rs);
	
	return $row['NM_RUANG'];
}

function getRujukanByID($kode){
	$sql 	= mysql_query("SELECT * FROM m_rujukan WHERE KODE=".$kode);
	
	return $sql;
}

function detailTgl($tgl){
	$thn	= substr($tgl,0,4);
	$bln	= substr($tgl,5,2);
	$tgl 	= substr($tgl,8,2);
	
	switch ($bln){
		case '01' : 
					$bln = 'Januari';
					break;
		case '02' : 
					$bln = 'Februari';
					break;
		case '03' :
					$bln = 'Maret';
					break;
		case '04' :
					$bln = 'April';
					break;
		case '05' :
					$bln = 'Mei';
					break;
		case '06' : 
					$bln = 'Juni';
					break;
		case '07' :
					$bln = 'Juli';
					break;
		case '08' :
					$bln = 'Agustus';
					break;
		case '09' :
					$bln = 'September';
					break;
		case '10' :
					$bln = 'Oktober';
					break;
		case '11' :
					$bln = 'November';
					break;
		case '12' :
					$bln = 'Desember';
					break;
	}
	
	$tgl = $tgl." ".$bln." ".$thn;
	
	return $tgl;
}

function get_t_angsuranrajal($idxdaftar){
	$sql	= mysql_query("SELECT * FROM t_angsuranrajal WHERE idxdaftar=".$idxdaftar);
	
	return $sql;
}

function get_t_bill_rajal($idxdaftar){
	$sql 	= mysql_query("SELECT * FROM t_billrajal WHERE IDXDAFTAR=".$idxdaftar);
	
	return $sql;
}

function get_t_pendaftaran($idxdaftar, $nomr){
	$sql 	= mysql_query("SELECT * FROM t_pendaftaran WHERE IDXDAFTAR=".$idxdaftar." AND NOMR='".$nomr."'");
	$data 	= mysql_fetch_array($sql);
	
	return $data;
}
//added 27102015

function get_detail_shift($shift){
    if($shift == 1){
        return "Pagi";
    }
    else if($shift == 2){
        return "Sore";
    }
    else{
        return $shift;
    }
}

function set_penambahan_tarif($idxdaftar, $nomr, $tarif){
	$rs_pendaftaran  = mysql_query("SELECT total_tarifrs, total_sisa, total_bayar_sendiri 
                                        FROM t_pendaftaran 
                                        WHERE IDXDAFTAR = ".$idxdaftar." AND NOMR='".$nomr."'");
        $row_pendaftaran  = mysql_fetch_array($rs_pendaftaran);
        $total_tarifrs    = $row_pendaftaran['total_tarifrs'];
        $total_tanggungan = $row_pendaftaran['total_bayar_sendiri'];
        $total_sisa       = $row_pendaftaran['total_sisa'];
        $total_tarifrs    = $total_tarifrs + $tarif;
        $total_tanggungan = $total_tanggungan + $tarif;
        $total_sisa       = $total_sisa + $tarif;
        mysql_query("UPDATE t_pendaftaran SET total_tarifrs = ".$total_tarifrs.",
                                              total_bayar_sendiri = ".$total_tanggungan.",
                                              total_sisa = ".$total_sisa." 
                     WHERE IDXDAFTAR = ".$idxdaftar." AND NOMR = '".$nomr."'");
}

function set_penambahan_tarif_tindakan($idxdaftar, $nomr, $tarif){
	$sql_tindakan = "SELECT SUM(t_billrajal.QTY * t_billrajal.TARIFRS) AS jumlah, 
							t_bayarrajal.STATUS
					 FROM t_billrajal 
					 JOIN t_bayarrajal ON t_bayarrajal.NOBILL = t_billrajal.NOBILL
					 WHERE t_billrajal.KODETARIF LIKE '01.01.%' 
					   AND t_billrajal.IDXDAFTAR = " . $idxdaftar . "
					   AND t_billrajal.NOMR = '" . $nomr . "'";
	$rs_tindakan  = mysql_query($sql_tindakan);
	$row_tindakan = mysql_fetch_array($rs_tindakan);
	$tarif_tind   = $row_tindakan['jumlah'];
	$status_tind  = $row_tindakan['STATUS'];

	$rs_pendaftaran  = mysql_query("SELECT total_tarifrs, total_sisa, total_bayar_sendiri, total_sudah_bayar 
                                        FROM t_pendaftaran 
                                        WHERE IDXDAFTAR = ".$idxdaftar." AND NOMR='".$nomr."'");
    $row_pendaftaran  = mysql_fetch_array($rs_pendaftaran);
    $total_tarifrs    = $row_pendaftaran['total_tarifrs'];
    $total_tanggungan = $row_pendaftaran['total_bayar_sendiri'];
    $total_sisa       = $row_pendaftaran['total_sisa'];
    $total_sudah_byr  = $row_pendaftaran['total_sudah_bayar'];
    $total_tarifrs    = $total_tarifrs - $tarif_tind;
    $total_tanggungan = $total_tarifrs - $tarif_tind;
    $status_tind == 'LUNAS' ? $total_sudah_byr = $total_sudah_byr - $tarif_tind : $total_sisa = $total_sisa - $tarif_tind;

    mysql_query("UPDATE t_pendaftaran SET total_tarifrs = " . $total_tarifrs ." 
    									  total_sisa = " . $total_sisa . " 
    									  total_bayar_sendiri = " . $total_tanggungan . " 
    									  total_sudah_bayar = " . $total_sudah_byr . " 
    			 WHERE IDXDAFTAR = " . $idxdaftar . " AND NOMR = '" . $nomr . "'");
	$tarif = $tarif - $tarif_tind;
    set_penambahan_tarif($idxdaftar, $nomr, $tarif);
}

function get_tarif_tmp_cartbayar($ip, $poly, $dokter){
	$sql = "SELECT SUM(QTY * TARIF) AS jumlah
			FROM tmp_cartbayar 
			WHERE IP = '".$ip."' 
			  AND poly = '".$poly."'
			  AND KDDOKTER = '".$dokter."'";
	$rs  = mysql_query($sql);
	$row = mysql_fetch_array($rs);
	return $row['jumlah'];
}

function get_dt_replace($date){
    $replace = str_replace("-", "", $date);
    $replace = str_replace(" ", "", $replace);
    $replace = str_replace(":", "", $replace);
    $replace = substr($replace, 0, 14);
    return $replace;
}

function get_code_group_tindakan_by_kode_tindakan($kode_tindakan){
	return substr($kode_tindakan,0,5);
}

function map_kode_penunjang_radiologi_ri($kode_tindakan){
	$code_group 	= get_code_group_tindakan_by_kode_tindakan($kode_tindakan);
	$new_code_group = "";
	
	$new_code_group = $code_group == '06.04' ? 'E13' : $new_code_group;
	$new_code_group = $code_group == '06.05' ? 'E01' : $new_code_group;
	$new_code_group = $code_group == '06.07' ? 'E04' : $new_code_group;
	$new_code_group = $code_group == '06.08' ? 'E18' : $new_code_group;
	$new_code_group = $code_group == '06.09' ? 'E05' : $new_code_group;
	$new_code_group = $code_group == '06.10' ? 'E08' : $new_code_group;
	
	return $new_code_group;
}