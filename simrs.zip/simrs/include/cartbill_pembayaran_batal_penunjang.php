<?php 
	session_start();
	include 'connect.php';
	include 'function.php';
	
	extract($_POST);
	$shift 		= getAutomaticShift();
	
	//create_m_batal_penunjang();
	
	if($_REQUEST['opsi'] == 1){
		$t_bayarlab2 	= get_t_bayarlab($nomr, $idxdaftar);
		while($data3 = mysql_fetch_array($t_bayarlab2)){
			$idxbyrlab		= $data3['idxbayarlab'];
			$kode			= $data3['kode_tindakan'];
			$carabayar		= $data3['carabayar'];
			$tarif			= $data3['tottariflab'];
			$nip 			= $_SESSION['NIP'];
			
			$t_orderlab 	= get_t_orderlab($idxdaftar, $kode);
			$data_orderlab	= mysql_fetch_array($t_orderlab);
			$qty 			= $data_orderlab['QTY'];
		
			mysql_query("UPDATE t_bayarlab SET status='BATAL',
		 									 shif=".$shift.",
		 									 nip='".$nip."'  
										 WHERE idxbayarlab=".$idxbyrlab);
			
			mysql_query("INSERT INTO m_batal_penunjang(idxbayar,idxdaftar,nomr,kode_tindakan,tglbatal,shift,nip,carabayar,qty,tarif,kdunit)
						VALUE(".$idxbyrlab.",".$idxdaftar.",'".$nomr."','".$kode."',NOW(),".$shift.",'".$nip."',".$carabayar.",".$qty.",
								".$tarif.",".$kdunit.")");
		}
		echo 'ok';
	}
?>