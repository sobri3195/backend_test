<?php 
ini_set('display_errors',0);	
ini_set('memory_limit' , '128M');

/*
$hostname = '192.168.0.252';
$database = 'simrs';
$username = 'amril';
$password `	= '12345';

$hostname = '192.168.0.11';
$database = 'simrs';
$username = 'amril';
$password = 'simrs();';

$hostname = '192.168.0.172';
$database = 'simrs';
$username = 'amril';
$password = '12345';

$hostname = 'localhost';
$database = 'simrs';
$username = 'root';
$password = '';
*/

$hostname = '192.168.0.172';
$database = 'simrs';
$username = 'amril';
$password = '12345';

$connect = mysql_connect($hostname, $username, $password,true,65536) or die(mysql_error()); 
mysql_select_db($database,$connect)or die(mysql_error());
define ('_BASE_','http://'.$_SERVER['HTTP_HOST'].'/simrs/');
define ('_POPUPTIME_','50000');

//time setzone
date_default_timezone_set("Asia/Bangkok");

$rstitle = 'SIMRS GOS DITJEN BUK';
$singrstitl = 'RSUD Kota Bogor';
$singhead1 = '';
$singsurat = 'SIMRS GOS - RSUD Kota Bogor';
$header1 = 'RSUD Kota Bogor';
$header2 = '';
$header3 = '';
$header4 = '';
$KDRS = '3271104';
$KelasRS = 'B';
$NamaRS = 'RSUD Kota Bogor';
$KDTarifINACBG = 'B/ II / RSU';