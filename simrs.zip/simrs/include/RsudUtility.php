<?php
/**
 * Kelas utility yang digunakan untuk mengumpulkan fungsi-fungsi yang sering digunakan
 * User: ISYFALANA
 * Date: 30/08/2015
 * Time: 14:27
 */

class RsudUtility {
    /**
     * Digunakan untuk mengkonversi angka biasa menjadi angka berformat currency rupiah
     * @param $nilaiRupiah angka inputan yang akan dikonversi ke angka rupiah
     * @param $opt jika tidak diberi nilai, maka di depan nilai diberi kata Rp
     * @return string hasil konversi
     */
    public static final function toRupiah($nilaiRupiah, $opt = "Rp. "){
        return $opt . strrev(implode(str_split(strrev(strval($nilaiRupiah)),3),",")) ;
    }


    public static final function getAjaxBarang($params){
        include("../include/connect.php");
        $nama_barang = $optFarmasi = "";
        extract($params);
        if(isset($grpbarang)){
            $sql_barang = "SELECT DISTINCT(nama_barang),m_barang.kode_barang, no_batch, expiry FROM m_barang
                        WHERE LOWER(nama_barang) LIKE LOWER('" . addslashes($nama_barang) . "%') AND group_barang = '".trim($grpbarang)."'
                        AND farmasi= '".trim($optFarmasi)."'
                        ORDER BY nama_barang ASC";
        }else{
            $sql_barang = "SELECT DISTINCT(nama_barang),m_barang.kode_barang, no_batch, expiry FROM m_barang
                        WHERE LOWER(nama_barang) LIKE LOWER('" . addslashes($nama_barang) . "%')
                        ORDER BY nama_barang ASC";
        }

        $qry_barang = mysql_query($sql_barang);
        $matches = array();
        while($row = mysql_fetch_array($qry_barang)){
            $row['id']   = trim($row["kode_barang"]);
            $row['text'] = trim($row['nama_barang']);
            $matches[]   = $row;
        }
        $matches = array_slice($matches, 0, 10);
        print json_encode($matches);
    }

    
    /**
     * printOptionGroupBarang digunakan untuk mencetak select option html,
     * fungsi ini berguna saat akan menampilkan opsi group barang
     * @param $kode_unit: kode unit dari session
     * @param $id_field: id field yang digunakan untuk memberikan id ke tag select
     */
    public static final function printOptionGroupBarang($kode_unit, $id_field = "group", $name_field = "group", $selectedItem = ""){
        include_once("include/connect.php");
        $sql_unit = "SELECT DEPARTEMEN FROM m_login WHERE KDUNIT={$kode_unit} LIMIT 1";
        $qry_unit = mysql_query($sql_unit);
        $data     = mysql_fetch_array($qry_unit);
        $farmasi  = -1;
        if(trim($data['DEPARTEMEN']) == 'GUDANG'){
            $farmasi = 1;
        }else if(trim($data['DEPARTEMEN']) == 'LOGISTIK'){
            $farmasi = 0;
        }

        $sql_group_barang = "SELECT * FROM m_barang_group WHERE farmasi={$farmasi} ORDER BY nama_group;";
        $qry_group_barang = mysql_query($sql_group_barang);
        if(mysql_affected_rows() > 0){
            echo "<select name=\"{$name_field}\" id=\"{$id_field}\" style=\"100%\">\n";
            while($data = mysql_fetch_array($qry_group_barang)){
                echo "<option value=\"{$data['group_barang']}\" ";
                echo ($data['group_barang'] == $selectedItem) ? "selected" : "";
                echo " \">{$data['nama_group']}</option>\n";
            }
            echo "</select>\n";
        }
    }

    /**
     * Method ini digunakan untuk mencetak select option penerimaan barang pada Gudang farmasi dan Gudang Umum
     * @param string $id_field memberikan id pada tag select
     * @param string $name memberikan name pada tag select
     * @param string $style memberikan style-value pada tag select
     */
    public static final function printOptionPenerimaanBarang($id_field="jenis_penerimaan", $name="jenis_penerimaan", $style=""){
        $sql_jenis = "SELECT * FROM simrs.m_jenis_penerimaan_barang;";
        $qry_jenis = mysql_query($sql_jenis);
        if(mysql_affected_rows()>0){
            echo "<select id=\"{$id_field}\" name=\"$name\" style=\"$style\">\n";
            while($data = mysql_fetch_array($qry_jenis)){
                echo "<option value=\"{$data['id']}\">{$data['nama']}</option>\n";
            }
            echo "</select>\n";
        }
    }

    public static final function getNamaPenerimaanBarangById($idJnsPenerimaan){
        $sql_jenis = "SELECT * FROM simrs.m_jenis_penerimaan_barang WHERE id={$idJnsPenerimaan} LIMIT 1";
        $qry_jenis = mysql_query($sql_jenis);
        if(mysql_affected_rows() >0 ){
            $data = mysql_fetch_array($qry_jenis);
            return $data['nama'];
        }else{
            return "";
        }
    }

    /**
     * @param int $month Jika diberi nilai harus antara 1-12, jika tidak diberi nilai mengembalikan bulan sekarang
     * @return string Nama bulan dalam bahasa Indonesia
     */
    public static final function getMonthName($month=0){
        if($month == 0){
            $current_month = date("m");
        }else{
            $current_month = $month;
        }
        switch($current_month){
            case 1: return "Januari";
            case 2: return "Februari";
            case 3: return "Maret";
            case 4: return "April";
            case 5: return "Mei";
            case 6: return "Juni";
            case 7: return "Juli";
            case 8: return "Agustus";
            case 9: return "September";
            case 10: return "Oktober";
            case 11: return "Nopember";
            case 12: return "Desember";
            default: return "";
        }
    }
	
    /**
     * Method ini digunakan untuk mencetak select option Tarif
     */
 	public static final function getTarif($params){
            include("../include/connect.php");
            $n = "";
            extract($params);
            $sql_tarif 	= "SELECT DISTINCT kode_tindakan, nama_tindakan FROM m_tarif2012 WHERE nama_tindakan LIKE '%{$n}%' ORDER BY nama_tindakan;";
            $qry_tarif 	= mysql_query($sql_tarif);
            $matches  	= array();
            while($row = mysql_fetch_array($qry_tarif)){
                $row['id']   = trim($row["kode_tindakan"]);
                $row['text'] = trim($row['nama_tindakan']);
                $matches[]   = $row;
            }
            $matches = array_slice($matches, 0, 10);
            print json_encode($matches);
    }
    
    /**
     * Method ini digunakan untuk mencetak select option unit
     */
    public static final function getUnit($params){
        	include("../include/connect.php");
        	$n = "";
        	extract($params);
        	$sql 	= "SELECT KDUNIT as kode_unit, DEPARTEMEN nama_unit FROM m_login WHERE DEPARTEMEN LIKE '%{$n}%' ORDER BY DEPARTEMEN;";
        	$qry 	= mysql_query($sql);
        	$matches  	= array();
        	while($row = mysql_fetch_array($qry)){
        		$row['id']   = trim($row["kode_unit"]);
        		$row['text'] = trim($row['nama_unit']);
        		$matches[]   = $row;
        	}
        	$matches = array_slice($matches, 0, 10);
        	print json_encode($matches);
    }
    
    /**
     * Method ini digunakan untuk mencetak select option dokter
     */
    public static final function getDokter($params){
    	include("../include/connect.php");
    	$n = "";
    	extract($params);
    	$sql 	= "SELECT KDDOKTER, NAMADOKTER FROM m_dokter WHERE NAMADOKTER LIKE '%{$n}%' ORDER BY NAMADOKTER;";
    	$qry 	= mysql_query($sql);
    	$matches  	= array();
    	while($row = mysql_fetch_array($qry)){
    		$row['id']   = trim($row["KDDOKTER"]);
    		$row['text'] = trim($row['NAMADOKTER']);
    		$matches[]   = $row;
    	}
    	$matches = array_slice($matches, 0, 10);
    	print json_encode($matches);
    }
}


/**
 * Digunakan untuk menangani request ajax,
 *
 */
if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['function'])){
    RsudUtility::$_GET['function']($_GET);
}