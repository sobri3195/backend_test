//Define calendar(s): addCalendar ("Unique Calendar Name", "Window title", "Form element's name", Form name")
addCalendar("Calendar1", "Select Date", "TGLLAHIR", "myform");
addCalendar("theDate", "Select Date", "theDate", "myform");
addCalendar("Calendar2", "Select Date", "TGLREG", "cari");
addCalendar("Calendar15", "Select Date", "TGLREG2", "cari");
addCalendar("Calendar3", "Select Date", "tgl_pesan", "formsearch");
addCalendar("Calendar11", "Select Date", "tgl_pesan2", "formsearch");
addCalendar("Calendar4", "Select Date", "theDate", "tglkalender");
addCalendar("Calendar5", "Select Date", "tgl_keluar", "resume_medis");
addCalendar("Calendar6", "Select Date", "tgl_keluar", "rekam_asuhan_keperawatan");
addCalendar("Calendar7", "Select Date", "tgl_kembali", "rekam_asuhan_keperawatan");
addCalendar("Calendar9", "Select Date", "tgl_operasi", "daftar");
addCalendar("Calendar10", "Select Date", "tglsampai", "tglkalender");
addCalendar("tgl_kel", "Select Date", "tanggal", "catatan_keperawatan");
addCalendar("daricariadmission", "Select Date", "daricariadmission", "formcariadmission");
addCalendar("sampaicariadmission", "Select Date", "sampaicariadmission", "formcariadmission");
addCalendar("Calendar11", "Select Date", "TGLKELUAR", "resume_pulang");
addCalendar("tgl_pindah", "Select Date", "tgl_pindah", "form1");
addCalendar("darijamkesmas", "Select Date", "darijamkesmas", "formcarijamkesmas");
addCalendar("sampaijamkesmas", "Select Date", "sampaijamkesmas", "formcarijamkesmas");
addCalendar("caldpmp", "Select Date", "caldpmp", "cari");
addCalendar("caldpmp", "Select Date", "caldpmp", "cari");
addCalendar("TGLKELUAR", "Select Date", "TGLKELUAR", "resume_pulang");
addCalendar("Calendarx", "Select Date", "tgl_masuk", "form_admission");
addCalendar("Calendary", "Select Date", "tgl_masuk", "form1");
//addCalendar("Calendar2", "Select Date", "secondinput", "myform");

// default settings for English
// Uncomment desired lines and modify its values
// setFont("verdana", 9);
 setWidth(90, 1, 15, 1);
// setColor("#cccccc", "#cccccc", "#ffffff", "#ffffff", "#333333", "#cccccc", "#333333");
// setFontColor("#333333", "#333333", "#333333", "#ffffff", "#333333");
// setFormat("yyyy/mm/dd");
// setSize(200, 200, -200, 16);

// setWeekDay(0);
// setMonthNames("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
// setDayNames("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
// setLinkNames("[Close]", "[Clear]");
