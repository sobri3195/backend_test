<?php 
	session_start();
	
	include 'connect.php';
	
	if($_REQUEST['opsi'] == 1){
		echo "<div id='frame'></div>";
		echo "<script>
					jQuery.get('"._BASE_."pasien_v.php?nomr=".$_REQUEST['nomr']."&idx=".$_REQUEST['idx']."', function(data){
						jQuery('#frame').html(data);
					});
				</script>";
	}
	else if($_REQUEST['opsi'] == 2){
		echo "<div id='frame'></div>";
		echo "<script>
					jQuery.get('"._BASE_."edit_pasien_v.php?nomr=".$_REQUEST['nomr']."&idx=".$_REQUEST['idx']."', function(data){
						jQuery('#frame').html(data);
					});
				</script>";
	}
	else if($_REQUEST['opsi'] == 3){
		extract($_POST);
		if($statuspasien == 1){
			mysql_query("UPDATE m_pasien SET NAMA='".$nama."',
											TITLE='".$title."',
											TEMPAT='".$tempat."',
											TGLLAHIR='".$tgllhr."',
											JENISKELAMIN='".$jenkel."',
											ALAMAT='".$alamat."',
											NOTELP='".$telepon."',
											STATUS=".$status.",
											AGAMA=".$agama.",
											PENDIDIKAN=".$pendidikan." 
										WHERE NOMR='".$nomr."'");
			
			if($provinsi != ''){
				mysql_query("UPDATE m_pasien SET KDPROVINSI=".$provinsi." WHERE NOMR='".$nomr."'");
			}
			
			if($kota != ''){
				mysql_query("UPDATE m_pasien SET KOTA=".$kota." WHERE NOMR='".$nomr."'");
			}
			
			if($kecamatan != ''){
				mysql_query("UPDATE m_pasien SET KDKECAMATAN=".$kecamatan." WHERE NOMR='".$nomr."'");
			}
			
			if($kelurahan != ''){
				mysql_query("UPDATE m_pasien SET KELURAHAN=".$kelurahan." WHERE NOMR='".$nomr."'");
			}
		}
		else if($statuspasien == 2){
			mysql_query("UPDATE m_pasien_aps SET NAMA='".$nama."',
											TITLE='".$title."',
											TEMPAT='".$tempat."',
											TGLLAHIR='".$tgllhr."',
											JENISKELAMIN='".$jenkel."',
											ALAMAT='".$alamat."',
											NOTELP='".$telepon."',
											STATUS=".$status.",
											AGAMA=".$agama.",
											PENDIDIKAN=".$pendidikan."
										WHERE NOMR='".$nomr."'");
				
			if($provinsi != ''){
				mysql_query("UPDATE m_pasien_aps SET KDPROVINSI=".$provinsi." WHERE NOMR='".$nomr."'");
			}
				
			if($kota != ''){
				mysql_query("UPDATE m_pasien_aps SET KOTA=".$kota." WHERE NOMR='".$nomr."'");
			}
				
			if($kecamatan != ''){
				mysql_query("UPDATE m_pasien_aps SET KDKECAMATAN=".$kecamatan." WHERE NOMR='".$nomr."'");
			}
				
			if($kelurahan != ''){
				mysql_query("UPDATE m_pasien_aps SET KELURAHAN=".$kelurahan." WHERE NOMR='".$nomr."'");
			}
		}
		
		echo 'Update Berhasil';
	}
	else if($_REQUEST['opsi'] == 4){
		echo "<div id='frame'></div>";
		echo "<script>
					jQuery.get('"._BASE_."lab/list_pasien_mcu.php', function(data){
						jQuery('#frame').html(data);
					});
				</script>";
	}
	else if($_REQUEST['opsi'] == 5){
		$nomr 		= $_REQUEST['nomr'];
		$idxd 		= $_REQUEST['idxd'];
		$nobill		= $_REQUEST['nobill'];
		$tarif 		= $_REQUEST['tarif'];
		$kdpoly 	= $_REQUEST['kdpoly'];
		$jaminan	= $_REQUEST['jaminan'];
		$diskon 	= $_REQUEST['diskon'];
		
		$sql 		= mysql_query("SELECT count(*) AS jml FROM t_billrajal WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd);
		$data 		= mysql_fetch_array($sql);
		$jml 		= $data['jml'];
		
		if($jml == 1){
		mysql_query("UPDATE t_billrajal SET TARIFRS=".$tarif." 
										WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		}
		
		mysql_query("UPDATE t_bayarrajal SET TOTTARIFRS=".$tarif.",
											 sisabayar=".$tarif."  
										WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		
		if($jaminan != 0){
			$selisih = $tarif - $jaminan;
			mysql_query("UPDATE t_bayarrajal SET TGLBAYAR='0000-00-00',
												 LUNAS=0,
												 STATUS='TRX',
												 sisabayar=".$selisih.",
												 jaminan=".$jaminan.",
												 subcarabayar=4 
											 WHERE NOBILL=".$nobill);
		}
		
		if($diskon != 0){
			/*$getBillByBill 	= mysql_query("SELECT JASA_SARANA,JASA_PELAYANAN,TARIFRS
											FROM t_billrajal
											WHERE IDXDAFTAR=".$idxd." AND NOBILL=".$nobill);
			$data 			= mysql_fetch_array($getBillByBill);
			$jasa_sarana 	= $data['JASA_SARANA'];
			$jasa_pelayanan = $data['JASA_PELAYANAN'];
			$tarifrs 		= $data['TARIFRS'];
			
			$tempdiskon		= $diskon;
			$diskon 		= $diskon / 100;
			$potongan 		= $jasa_sarana * $diskon;
			$jasa_sarana 	= $jasa_sarana - $potongan;
			$potongan 		= $jasa_pelayanan * $diskon;
			$jasa_pelayanan = $jasa_pelayanan - $potongan;
			$tarif 			= $jasa_sarana + $jasa_pelayanan;
			
			mysql_query("UPDATE t_billrajal SET JASA_SARANA = ".$jasa_sarana.",
												JASA_PELAYANAN = ".$jasa_pelayanan.",
												TARIFRS = ".$tarif." 
											WHERE IDXDAFTAR=".$idxd." AND NOBILL=".$nobill);
			
			mysql_query("UPDATE t_bayarrajal SET TOTJASA_SARANA = ".$jasa_sarana.",
												 TOTJASA_PELAYANAN = ".$jasa_pelayanan.",
												 TOTTARIFRS = ".$tarif.",
												 sisabayar = ".$tarif.",
												 diskon = ".$tempdiskon." 
											WHERE IDXDAFTAR=".$idxd." AND NOBILL=".$nobill);*/
			
			$getBillByBill 	= mysql_query("SELECT sisabayar 
											FROM t_bayarrajal
											WHERE IDXDAFTAR=".$idxd." AND NOBILL=".$nobill);
			$data 			= mysql_fetch_array($getBillByBill);
			$sisabayar 		= $data['sisabayar'];
			$selisih 		= $sisabayar - $diskon;
			mysql_query("UPDATE t_bayarrajal SET TGLBAYAR='0000-00-00',
												 LUNAS=0,
												 STATUS='TRX',
												 sisabayar=".$selisih.",
												 diskon=".$diskon.",
												 subcarabayar=4
											 WHERE NOBILL=".$nobill);
		}

        header("location:../index.php?link=34&nomr=".$nomr."&poly=".$kdpoly."&idxdaftar=".$idxd."&success=1");
	}
	else if($_REQUEST['opsi'] == 6){
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
		$nobill	= $_REQUEST['nobill'];
		$kdpoly = $_REQUEST['kdpoly'];
		
		mysql_query("DELETE FROM t_billrajal WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd);
		mysql_query("DELETE FROM t_bayarrajal WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd);
		
		$_SESSION["success"] = 1;
		header("location:../index.php?link=34&nomr=".$nomr."&poly=".$kdpoly."&idxdaftar=".$idxd);
	}
	else if($_REQUEST['opsi'] == 7){
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
		
		if($_SESSION["ROLES"] == 23){
			mysql_query("UPDATE t_pendaftaran SET tutup_pembayaran=2
											WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		}
		else{
			mysql_query("UPDATE t_pendaftaran SET tutup_pembayaran=1  
											WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		}
		
		if($_SESSION["ROLES"] == 23){
			header("location:../index.php?link=2324kasir");
		}
		else{
			header("location:../index.php?link=33");
		}
	}
	else if($_REQUEST['opsi'] == 8){
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
		
		mysql_query("UPDATE t_pendaftaran_aps SET tutup_pembayaran=1
										WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		
		header("location:../index.php?link=billlab");
	}
	else if($_REQUEST['opsi'] == 9){
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
	
		mysql_query("UPDATE t_pendaftaran SET tutup_pembayaran=0
										WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
	
		header("location:../index.php?link=2324otoralan");
	}
	else if($_REQUEST['opsi'] == 10){
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
		$pb 	= $_REQUEST['pb'];
		
		if($pb > 0){
			$pb = 0;
		}
		else{
			$pb = 1;
		}
		
		mysql_query("UPDATE t_pendaftaran SET pasien_bermasalah=".$pb." 
										  WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
	}
	else if($_REQUEST['opsi'] == 11){
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
		$note 	= $_REQUEST['note'];
		
		mysql_query("UPDATE t_pendaftaran SET note_problem='".$note."' 
										  WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		
		header("location:../index.php?link=2324anggaranbaru01");
	}
	else if($_REQUEST['opsi'] == 12){
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
		
		mysql_query("UPDATE t_pendaftaran SET note_problem='' 
										  WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
	}
	else if($_REQUEST['opsi'] == 13){
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
		$pj 	= $_REQUEST['pj'];
		$hub 	= $_REQUEST['hub'];
		
		mysql_query("UPDATE t_pendaftaran SET PENANGGUNGJAWAB_NAMA='".$pj."',
											  PENANGGUNGJAWAB_HUBUNGAN='".$hub."' 
										  WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		
		mysql_query("UPDATE m_pasien SET PENANGGUNGJAWAB_NAMA='".$pj."',
									     PENANGGUNGJAWAB_HUBUNGAN='".$hub."'  
								     WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
	}
	else if($_REQUEST['opsi'] == 14){
		include 'function.php';
		
		$nomr 	= $_REQUEST['nomr'];
		$idxd 	= $_REQUEST['idxd'];
		$jnsp 	= $_REQUEST['jnsp'];
		
		mysql_query("UPDATE t_pendaftaran SET KDCARABAYAR=".$jnsp." 
										  WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		
		mysql_query("UPDATE m_pasien SET KDCARABAYAR=".$jnsp." 
								     WHERE NOMR='".$nomr."'");
		
		mysql_query("UPDATE t_billrajal SET CARABAYAR=".$jnsp." 
										WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		
		$query 	= mysql_query("SELECT JMKS FROM m_carabayar WHERE KODE=".$jnsp);
		$datum 	= mysql_fetch_array($query);
		$jmks 	= $datum['JMKS'];
		
		$shift 	= getAutomaticShift();
		
		$sql 	= mysql_query("SELECT TOTTARIFRS,NOBILL 
							   FROM t_bayarrajal 
							   WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		
		while($data = mysql_fetch_array($sql)){
			$tottarifrs 	= $data['TOTTARIFRS'];
			$nobill 		= $data['NOBILL'];
			
			if($jmks > 0){
				mysql_query("UPDATE t_bayarrajal SET TGLBAYAR=DATE(NOW()),
													 JAMBAYAR=TIME(NOW()),
													 JMBAYAR=".$tottarifrs.",
													 SHIFT=".$shift.",
													 NIP='".$_SESSION['NIP']."',
													 sisabayar=0,
													 LUNAS=1,
													 CARABAYAR=".$jnsp.", 
													 STATUS='LUNAS' 
												 WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."' AND NOBILL=".$nobill);
			}
			else{
				mysql_query("UPDATE t_bayarrajal SET CARABAYAR=".$jnsp." 
												 WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."' AND NOBILL=".$nobill);
			}
		}
	}
	else if($_REQUEST['opsi'] == 15){
		$nomr 		= $_REQUEST['nomr'];
		$idxd 		= $_REQUEST['idxd'];
		$nobill 	= $_REQUEST['nobill'];
		$kddokter	= $_REQUEST['kddokter'];
		
		$sql1 		= mysql_query("SELECT flag_pend 
								   FROM t_bayarrajal 
								   WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		$data1 		= mysql_fetch_array($sql1);
		$flag_pend 	= $data1['flag_pend'];
		
		if($flag_pend == 1){
			mysql_query("UPDATE t_pendaftaran SET KDDOKTER=".$kddokter." 
					      					  WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
		}
		
		mysql_query("UPDATE t_billrajal SET KDDOKTER=".$kddokter." 
										WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
	}
	else if($_REQUEST['opsi'] == 16){
		include 'function.php';
		
		$nomr 			= $_REQUEST['nomr'];
		$idxd 			= $_REQUEST['idxdaftar'];
		$kdpoly 		= $_REQUEST['kdpoly'];
		$kode_tindakan 	= $_REQUEST['jasa_tindakan'];
		$nobill 		= getLastNoBILL(1);
		//mysql_query("UPDATE m_maxnobill SET nomor=".$nobill);
		$shift			= getAutomaticShift();
		$nip 			= $_SESSION['NIP'];
		$jnsp 			= $_REQUEST['jnsp'];
		$kddokter 		= $_REQUEST['kddokter'];
		$unit 			= $_REQUEST['unit'];
		
		mysql_query("INSERT INTO t_billrajal(KODETARIF,NOMR,KDPOLY,TANGGAL,SHIFT,NIP,IDXDAFTAR,NOBILL,KDDOKTER,MULAI,SELESAI,STATUS,
								 CARABAYAR,UNIT,QTY)
								 VALUES('".$kode_tindakan."','".$nomr."',".$kdpoly.",DATE(NOW()),".$shift.",'".$nip."',".$idxd.",
								 ".$nobill.",".$kddokter.",NOW(),NOW(),'SELESAI',".$jnsp.",".$unit.",1)");
		
		mysql_query("INSERT INTO t_bayarrajal(NOMR,IDXDAFTAR,SHIFT,NIP,NOBILL,LUNAS,CARABAYAR,STATUS,UNIT)
								 VALUES('".$nomr."',".$idxd.",".$shift.",'".$nip."',".$nobill.",0,".$jnsp.",'TRX',".$unit.")");
		
		header("location:../index.php?link=34&nomr=$nomr&poly=$kdpoly&idxdaftar=$idxd");
	}
    else if($_REQUEST['opsi'] == 17){
        $nomr 	= $_REQUEST['nomr'];
        $idxd 	= $_REQUEST['idxd'];
        $pj 	= $_REQUEST['pj'];
        $hub 	= $_REQUEST['hub'];

        mysql_query("UPDATE t_pendaftaran_aps SET penanggungjawab_nama='".$pj."',
											  penanggungjawab_hubungan='".$hub."'
										  WHERE IDXDAFTAR=".$idxd." AND NOMR='".$nomr."'");
    }
    else if($_REQUEST['opsi'] == 18){
        extract($_POST);
        $nomr	= $NOMR;
        $idxd	= $IDXDAFTAR;

        $sql	= mysql_query("SELECT * FROM t_bayarrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
        $data	= mysql_fetch_array($sql);

        echo json_encode($data);
    }
    else if($_REQUEST['opsi'] == 19){
        extract($_POST);
        $nomr	= $NOMR;
        $idxd	= $IDXDAFTAR;

        $sql	= mysql_query("SELECT MAX(subcarabayar) AS subcarabayar FROM t_bayarrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
        $data	= mysql_fetch_array($sql);

        echo json_encode($data);
    }
    else if($_REQUEST['opsi'] == 20){
        $nomr 		= $_REQUEST['nomr'];
        $idxd 		= $_REQUEST['idxd'];
        $nobill		= $_REQUEST['nobill'];
        $jaminan	= $_REQUEST['jaminan'];
        $tarif      = $_REQUEST['tarif'];

        if(empty($jaminan)){
            $jaminan = 0;
        }

        $sql 		= mysql_query("SELECT count(*) AS jml FROM t_billrajal WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd);
        $data 		= mysql_fetch_array($sql);
        $jml 		= $data['jml'];

        if($jaminan != 0){
            $selisih = $tarif - $jaminan;
            mysql_query("UPDATE t_bayarrajal SET TGLBAYAR='0000-00-00',
												 LUNAS=0,
												 STATUS='TRX',
												 sisabayar=".$selisih.",
												 jaminan=".$jaminan.",
												 subcarabayar=4
											 WHERE NOBILL=".$nobill);
        }

        header("location:../index.php?link=cartbill_aps&nomr=".$nomr."&idxdaftar=".$idxd);
    }
?>