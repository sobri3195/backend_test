<?php 
	include 'connect.php';
    include 'function.php';
	
	extract($_POST);
	$idxd		= $idxdaftar;

	//$sql		= mysql_query("SELECT SUM(JMBAYAR) AS JMBAYAR, SUM(TOTTARIFRS) AS TOTTARIFRS FROM t_bayarrajal WHERE IDXDAFTAR=".$idxd);
	$sql = mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.qty, b.TARIFRS,c.NAMADOKTER
						FROM m_tarif2012 a, t_billrajal b
						LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
						WHERE a.kode_tindakan=b.KODETARIF
						AND b.IDXDAFTAR='".$idxd."'");

	//$data		= mysql_fetch_array($sql);
	$total	= 0;
	while($data = mysql_fetch_array($sql)){
		$total	= $total + ( $data['TARIFRS'] * $data['qty']);
	}

	$sql2=mysql_query("SELECT SUM(TOTTARIFRS) as total from t_bayarrajal where IDXDAFTAR='".$idxd."' and STATUS='LUNAS'");
	$data2=mysql_fetch_array($sql2);
	$byr=$data2['total'];
	$kurang=$total-$data2['total'];
	if($kurang < 0){
		$byr=$byr+$kurang;
		$kurang=0;
	}
	echo $kurang;

//    echo getsisapembayaran($idxd);
?>