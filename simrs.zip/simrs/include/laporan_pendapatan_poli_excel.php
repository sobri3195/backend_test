<?php
	session_start();
	include 'connect.php';
	include 'function.php';
	
	$tgl_kunjungan = "";
	if(!empty($_GET['tgl_kunjungan'])){
		$tgl_kunjungan = $_GET['tgl_kunjungan'];
	}else{
		$tgl_kunjungan = date('Y/m/d');
	}
	
	$tgl_kunjungan2 = "";
	if(!empty($_GET['tgl_kunjungan2'])){
		$tgl_kunjungan2 = $_GET['tgl_kunjungan2'];
	}else{
		$tgl_kunjungan2 = date('Y/m/d');
	}
	
	$kondisi 	= " AND a.TANGGAL BETWEEN '".$tgl_kunjungan."' AND '".$tgl_kunjungan2."'";
	
	$thn 	= substr($tgl_kunjungan, 0, 4);
	$bln 	= substr($tgl_kunjungan, 5, 2);
	
	header('Content-type: application/vnd.ms-excel');
	header('Content-Disposition: attachment; filename="RJ'.$bln.$thn.'.xls"');
	
?>
<center>
	<h2>TOTAL PENDAPATAN POLIKLINIK</h2>
	<h3>TANGGAL <?php echo detailTgl($tgl_kunjungan); ?> S/D <?php echo detailTgl($tgl_kunjungan2); ?></h3>
</center
		<table id="table" class="table" border="1">
			<thead>
				<tr>
					<th>TGL TRANSAKSI</th>
					<th>NOMR</th>
					<th>NAMA PASIEN</th>
					<th>POLI</th>
					<th>JENIS</th>
					<th>KETERANGAN</th>
					<th>BIAYA</th>
					<th>JAMINAN</th>
					<th>DISKON</th>
					<th>DOKTER</th>
					<th>KDPAS</th>
					<th>CARABAYAR</th>
					<th>JENIS PASIEN</th>
					<th>KODE PERUSAHAAN</th>
					<th>PENANGGUNG JAWAB</th>
					<th>TGL BAYAR</th>
					<th>NO RINCIAN/NOBILL</th>
					<th>KASIR</th>
					<th>SHIFT</th>
				</tr>
			</thead>
			<tbody>
				<?php
					$sql	= mysql_query("SELECT DISTINCT a.NOBILL, b.NOMR, a.TANGGAL
										   FROM `t_billrajal` AS a 
										   INNER JOIN t_bayarrajal AS b ON a.NOBILL=b.NOBILL  
										   WHERE 1=1 ".$kondisi);
					while ($data = mysql_fetch_array($sql)){
						/* *
						 * Data pasien
						 * @params NOMR
						 * */
						$sql2 	= mysql_query("SELECT NAMA, TITLE FROM m_pasien WHERE NOMR='".$data['NOMR']."'");
						$data2 	= mysql_fetch_array($sql2);
						
						/* *
						 * Data billrajal
						 * @params NOBILL
						 * */
						$biaya 	= 0;
						$subttal= 0;
						$sql3 	= mysql_query("SELECT * FROM t_billrajal WHERE NOBILL=".$data['NOBILL']);
						while($data3 	= mysql_fetch_array($sql3)){ 
							$idxd 	= $data3['IDXDAFTAR'];
							$tarifrs= $data3['TARIFRS'];
							$qty 	= $data3['QTY'];
							$subttal= $tarifrs * $qty;
							$biaya	= $biaya + $subttal;
							
							/* *
							 * Data Poly
							 * @params KDPOLY
							 * */
							$kdpoly = $data3['KDPOLY'];
							$sql4 	= getPolyByID($kdpoly);
							$data4 	= mysql_fetch_array($sql4);
							
							/* *
							 * Data m_tarif2012
							 * @params kdtarif
							 * */
							$kdtarif= $data3['KODETARIF'];
							$sql5 	= getGroupName($kdtarif);
							if($kdtarif == '02.03'){
								$data5 	= $sql5['nama_gruptindakan'];
							}else{
								$data5 	= $sql5['nama_tindakan'];
							}
							
							/* *
							 * Data m_dokter
							 * @params kddokter
							 * */
							$kddokter	= $data3['KDDOKTER'];
							$sql8 		= getNamaDokter($kddokter);
							$data8 		= $sql8['NAMADOKTER'];
						}
						
						/* *
						 * Data t_pendaftaran
						 * @params IDXDAFTAR
						 * @params NOMR
						 * */
						$sql6 	= mysql_query("SELECT * FROM t_pendaftaran WHERE NOMR='".$data['NOMR']."' AND IDXDAFTAR=".$idxd);
						$data6 	= mysql_fetch_array($sql6);
						
						/* *
						 * Data m_carabayar
						 * @params KODE
						 * */
						$jp 	= $data6['KDCARABAYAR'];
						$sql9 	= mysql_query("SELECT JMKS FROM m_carabayar WHERE KODE=".$jp);
						$data9 	= mysql_fetch_array($sql9);
						$jmks 	= $data9['JMKS'];
						if($jmks > 0){
							$jp = 'Perusahaan';
						}
						else{
							$jp	= 'Umum';
						}
						
						/* *
						 * Data t_bayarrajal
						 * @params NOBILL
						 * @params NOMR
						 * */
						$sql7 	= mysql_query("SELECT * FROM t_bayarrajal WHERE NOBILL=".$data['NOBILL']." AND NOMR='".$data['NOMR']."'");
						$data7 	= mysql_fetch_array($sql7);
						$crbayar= $data7['subcarabayar'];
						switch($crbayar){
							case 1:
								$crbayar = 'Tunai';
								break;
							case 2:
								$crbayar = 'Debet';
								break;
							case 3:
								$crbayar = 'Kredit';
								break;
							case 4:
								$crbayar = 'Angsuran';
								break;
							default:
								$crbayar = 'Tunai';
								break;
						}
				?>
				<tr>
					<td>
						<?php echo $data['TANGGAL']; ?>
					</td>
					<td>
						<?php echo $data['NOMR']; ?>
					</td>
					<td>
						<?php echo $data2['NAMA']; ?>
					</td>
					<td>
						<?php echo $data4['nama']; ?>
					</td>
					<td>
						<?php echo $kdtarif; ?>
					</td>
					<td>
						<?php echo $data5; ?>
					</td>
					<td>
						<?php echo CurFormat($biaya,2); ?>
					</td>
					<td>
						<?php echo CurFormat($data7['jaminan'],2); ?>
					</td>
					<td>
						<?php 
							/*if($data7['diskon'] != 0){
								echo $data7['diskon'] . "%";
							}
							else{
								echo "-";
							}*/
							echo CurFormat($data7['diskon'],2);
						?>
					</td>
					<td>
						<?php echo $data8; ?>
					</td>
					<td></td>
					<td>
						<?php echo $crbayar; ?>
					</td>
					<td>
						<?php echo $jp; ?>
					</td>
					<td>
						<?php echo  $data6['KDCARABAYAR']; ?>
					</td>
					<td>
						<?php echo $data6['PENANGGUNGJAWAB_NAMA']; ?>
					</td>
					<td>
						<?php echo $data7['TGLBAYAR']; ?>
					</td>
					<td>
						<?php echo $data['NOBILL']; ?>
					</td>
					<td>
						<?php echo $data7['NIP']; ?>
					</td>
					<td>
						<?php echo $data7['SHIFT']; ?>
					</td>
				</tr>
				<?php 
					}
				?>
			</tbody>
		</table> 