<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 26/01/2016
 * Time: 11:17
 */
?>
<div id="dialog-form" >
    <form method="post">
        <fieldset>
            <table id="table" class="hover">
                <thead>
                <tr>
                    <th>NOMR Lama</th>
                    <th>Nama Pasien</th>
                    <th>TGL Lahir</th>
                    <th>Alamat</th>
                </tr>
                </thead>
                <tbody>
                <?php
                while($data = mysql_fetch_array($sql)) {
                    ?>
                    <tr id="<?php echo $data['NOMEDIK']; ?>" class="tr_old">
                        <td><?php echo $data['NOMEDIK']; ?></td>
                        <td><?php echo $data['NAMAPAS']; ?></td>
                        <td><?php echo $data['TGLAHIR']; ?></td>
                        <td><?php echo $data['ALRUMPAS']; ?></td>
                    </tr>
                <?php
                }
                ?>
                </tbody>
            </table>
        </fieldset>
    </form>
</div>

<script>
    jQuery("#table").dataTable({
        'fnDrawCallback': function(){
            jQuery(".tr_old").click(function(){
                var nomr    = jQuery(this).attr('id');

                jQuery("#nomr_old").val(nomr);
                get_pasien_by_old_nomr(nomr);

                jQuery("#dialog-form").dialog("close");
            });
        }
    });

    jQuery("fieldset").css({padding:'0',border:'0', marginTop:'25px'});


    function get_pasien_by_old_nomr(nomr){
        jQuery.post('include/cari_pasien.php', {NOMR:nomr,pilihan:8}, function(data){
//                alert(data);
            var obj = JSON.parse(data);
            jQuery("#NAMA").val(obj.NAMAPAS);
            jQuery("#ALAMAT").val(obj.ALRUMPAS);
            jQuery("#notelp").val(obj.TLRUMPAS);
            jQuery("#TEMPAT").val(obj.TPLAHIR);

            var tglLahir    = obj.TGLAHIR;
            var thnLahir    = tglLahir.substr(0, 4);
            var blnLahir    = tglLahir.substr(5, 2);
            var tLhrnya     = tglLahir.substr(8, 2);
            var ttlnya      = tLhrnya + "/" + blnLahir + "/" + thnLahir;
            jQuery("#TGLLAHIR").val(ttlnya);

            var jenkel = obj.KELAMIN;
            if (jenkel == "L") {
                jQuery('#JENISKELAMIN_L').attr('checked', true);
            }
            else {
                jQuery('#JENISKELAMIN_P').attr('checked', true);
            }

            var agama = obj.AGAMA;
            switch (agama) {
                case "ISLAM":
                    jQuery('#AGAMA_1').attr('checked', true);
                    break;
                case "PROTESTAN":
                    jQuery('#AGAMA_2').attr('checked', true);
                    break;
                case "KATHOLIK":
                    jQuery('#AGAMA_3').attr('checked', true);
                    break;
                case "Hindu":
                    jQuery('#AGAMA_4').attr('checked', true);
                    break;
                case "BUDHA":
                    jQuery('#AGAMA_5').attr('checked', true);
                    break;
                default:
                    jQuery('#AGAMA_6').attr('checked', true);
                    break;
            }

            var pend = obj.PENDIDIK;
            var pendnow = pend.substring(4);
            switch (pendnow) {
                case "SD":
                    jQuery('#PENDIDIKAN_1').attr('checked', true);
                    break;
                case "SMP":
                    jQuery('#PENDIDIKAN_2').attr('checked', true);
                    break;
                case "SLTP":
                    jQuery('#PENDIDIKAN_2').attr('checked', true);
                    break;
                case "SMA":
                    jQuery('#PENDIDIKAN_3').attr('checked', true);
                    break;
                case "SMU":
                    jQuery('#PENDIDIKAN_3').attr('checked', true);
                    break;
                case "SLTA":
                    jQuery('#PENDIDIKAN_3').attr('checked', true);
                    break;
                case "STM":
                    jQuery('#PENDIDIKAN_3').attr('checked', true);
                    break;
                case "SMK":
                    jQuery('#PENDIDIKAN_3').attr('checked', true);
                    break;
                case "SMEA":
                    jQuery('#PENDIDIKAN_3').attr('checked', true);
                    break;
                case "SMKK":
                    jQuery('#PENDIDIKAN_3').attr('checked', true);
                    break;
                default:
                    jQuery('#PENDIDIKAN_5').attr('checked', true);
                    break;
            }

            var ketstatus = obj.KAWIN;
            switch (ketstatus) {
                case "K":
                    jQuery('#status_2').attr('checked', true);
                    break;
                case "T":
                    jQuery('#status_1').attr('checked', true);
                    break;
                case "J":
                    jQuery('#status_3').attr('checked', true);
                    break;
                case "D":
                    jQuery('#status_3').attr('checked', true);
                    break;
                default:
                    jQuery('#status_1').attr('checked', true);
                    break;
            }

            jQuery("#PEKERJAAN").val(obj.PEKPASIEN);
            jQuery("#SUAMI_ORTU").val(obj.NAMAWALI);
			
			var kdwil = obj.KDWIL;
                switch(kdwil){
                    case "B":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1698);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "T":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1701);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "G":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1700);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "U":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1702);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "S":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1699);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "H":
                        jQuery("#KOTAHIDDEN").val(144);
                        jQuery("#KECAMATANHIDDEN").val(1703);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(144).change();
                        break;
                    case "D":
                        jQuery("#KOTAHIDDEN").val(127);
                        jQuery("#KECAMATANHIDDEN").val(1267);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(127).change();
                        break;
                    case "L":
                        jQuery("#KOTAHIDDEN").val(142);
                        jQuery("#KECAMATANHIDDEN").val(1667);
                        jQuery('#KDPROVINSI').val(12).change();
                        jQuery('#KOTA').val(142).change();
                        break;
                }
        });
    }

    jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 550,
        width: 700,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        buttons: {
            Tutup: function() {
                jQuery(this).dialog("close");
            }
        },
        close: function() {
            jQuery(".validateTips").html("Harap isi semua field yang dibutuhkan..");
            jQuery("#dialog-form").dialog('destroy');
            jQuery("#list_pasien").html('');
        }
    }).dialog("open");
</script>