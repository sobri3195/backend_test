<style type="text/css" media="screen">
	#global_print{width:500px;}
	#header{ height:30px; width:100%;}
	#logo_cetak{float:left;}
	#title{float:left; width:400px;}
	#kepada{float:left; width:700px; font-size:7pt;}
	#kepada .headfield{float:left; width:150px;}
	#kepada .childhead{float:left; width:10px;}
	#kepada .field{float:left; width:100px;}
	#kepada .value{float:left; width:200px;}
	#kuitansi{text-align:center; font-size:7pt; font-weight:bold;}
	#no_kuitansi{text-align:left; font-size:7pt;}
	table#table_list{width:100%; font-size:7pt; border-collapse:0; border-spacing:0px;}
	tr th{border-bottom:1px dashed #000; border-top:1px dashed #000;}
	#footer{width:100%; font-size:7pt;}
	#last_line{font-size:7pt; font-style:inherit; width:100%;}
</style>
<style type="text/css" media="print">
	#global_print{width:500px;}
	#header{ height:30px; width:100%;}
	#logo_cetak{float:left;}
	#title{float:left; width:400px;}
	#kepada{float:left; width:700px; font-size:7pt;}
	#kepada .headfield{float:left; width:150px;}
	#kepada .childhead{float:left; width:10px;}
	#kepada .field{float:left; width:100px;}
	#kepada .value{float:left; width:200px;}
	#kuitansi{text-align:center; font-size:7pt; font-weight:bold;}
	#no_kuitansi{text-align:left; font-size:7pt;}
	table#table_list{width:100%; font-size:7pt; border-collapse:0; border-spacing:0px;}
	tr th{border-bottom:1px dashed #000; border-top:1px dashed #000;}
	#footer{width:100%; font-size:7pt;}
	#last_line{font-size:7pt; font-style:inherit; width:100%;}
</style>

<?php 
	session_start();
	include 'connect.php';
	include 'function.php';
	
	$cnama 	= $_REQUEST['cnama'];
	$cnomr 	= $_REQUEST['cnomr'];
	$cpoly 	= $_REQUEST['cpoly'];
	$crbayar= $_REQUEST['crbayar'];
	$cstart	= $_REQUEST['cstart'];
	$cend	= $_REQUEST['cend'];
	$i 		= -1;
	
	$sql 	= mysql_query("SELECT * FROM `t_pendaftaran` 
						   WHERE NOMR='".$cnomr."' AND KDPOLY=".$cpoly." AND TGLREG BETWEEN '".$cstart."' AND '".$cend."' 
						   ORDER BY IDXDAFTAR ASC");
	while ($data = mysql_fetch_array($sql)) {
		$idxdaftar[] = $data['IDXDAFTAR'];
		$i++;
	}
	
	$sql5 	= mysql_query("SELECT NOBILL FROM t_billrajal WHERE IDXDAFTAR=".$idxdaftar[$i]);
	$data5 	= mysql_fetch_array($sql5);
	
	$myquery = 'SELECT a.nomr AS NOMR, a.NOBILL, b.NAMA as pasien, a.TGLBAYAR, a.JAMBAYAR, a.TOTCOSTSHARING,a.JMBAYAR, a.UNIT, c.nama_unit,d.NAMA as carabayar
				FROM t_bayarrajal a
				JOIN m_pasien b ON b.NOMR = a.NOMR
				JOIN m_unit c ON c.kode_unit = a.UNIT
				JOIN m_carabayar d ON d.KODE = a.CARABAYAR
				WHERE a.NOMR = "'.$cnomr.'"
				AND a.IDXDAFTAR = "'.$idxdaftar[$i].'"';
	$get = mysql_query ($myquery)or die(mysql_error());
	$userdata = mysql_fetch_assoc($get);
?>
<div style="font-family: 'Lucida Console', Monaco, monospace; font-size: 7pt;">
	<div id="global_print" style="height:550px; width:580px; padding-left:100px;">
	    <div id="header">
	    	<br/>
	        <div id="logo_cetak">
	        	<!--<img src="img/logokotabogor.PNG" width="50px" />-->
	        </div>
	        <div id="title">
	        	<br/>
	        	<div id="title1"><?=strtoupper($header1)?></div>
	            <div id="title2"><?=strtoupper($header2)?></div>
				<div id="title3" style="font-size:11px;"><?=$header3?></div>
				<div id="title4" style="font-size:11px;"><?=$header4?></div>
	        </div>
	        <div id="kepada" style="padding-top:10px; font-size:7pt;">
	        	
	        	<div class="headfield">Sudah terima dari</div>
	        	<span class="childhead">:</span>
	        	<div class="value">
	        		<?php 
		        		$sql3 	= mysql_query("SELECT PENANGGUNGJAWAB_NAMA
	        								   FROM t_pendaftaran
	        								   WHERE NOMR='".$cnomr."' AND IDXDAFTAR=".$idxdaftar[$i]);
		        		$data3 	= mysql_fetch_array($sql3);
		        		echo strtoupper($data3['PENANGGUNGJAWAB_NAMA']);
	        		?>
	        	</div>
	        	<br clear="all" />
	           	<div id="kepada2">
		            <div class="headfield">Untuk Pembayaran</div>
		            <span class="childhead">:</span>
		            <div style="float: left;">Biaya Periksa/pengobatan dari pasien:</div>
		       	</div>
		        <br clear="all" />
		        <div id="kepada2">
		            <div class="headfield">&nbsp;</div>
		            <span class="childhead">&nbsp;</span>
		            <div class="field">Nama</div>
		            <span class="childhead">:</span>
		            <div class="value"><?php echo strtoupper($userdata['pasien']);?></div>
		        </div>
	            <br clear="all" />
	            <div id="kepada3">
	            	<div class="headfield">&nbsp;</div>
	            	<span class="childhead">&nbsp;</span>
	            	<div class="field">No.DM</div>
	            	<span class="childhead">:</span>
	            	<div class="value"><?php echo $cnomr;?></div>
	            </div>
	            <br clear="all" />
	            <div id="kepada4">
	            	<div class="headfield">&nbsp;</div>
	            	<span class="childhead">&nbsp;</span>
	            	<div class="field">Tanggal Bayar</div>
	            	<span class="childhead">:</span>
	            	<div class="value"><?php echo $userdata['TGLBAYAR'].' '.$userdata['JAMBAYAR'];?></div>
	            </div>
	            <br clear="all" />
	            <div id="kepada4">
	            	<div class="headfield">&nbsp;</div>
	            	<span class="childhead">&nbsp;</span>
	            	<div class="field">Poli</div>
	            	<span class="childhead">:</span>
	            	<div class="value"><?php echo $userdata['nama_unit'];?></div>
	            </div>
	            <br clear="all" />
	       </div>
	    </div>
	    <br clear="all" />
	    <br/>
	    <div id="kuitansi"></div>
	    <div id="no_kuitansi"> No Transaksi : <?php echo $data5['NOBILL']; ?></div>
	    <table id="table_list">
	    <tr id="header_table"><th style="text-align:left;">Nama Jasa</th><th style="width:40px;">Qty</th><th style="width:80px;">Harga</th><th style="width:100px;">Total</th><th style="width:20px;">&nbsp;</th></tr>
	    <tbody style="height:200px;">
	    <?php
	    $byr1 	= 0;
	    $total 	= 0;
	    $sisa 	= 0;
	    for($j=0; $j <= $i; $j++){
			$sql = mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.qty, b.TARIFRS,c.NAMADOKTER
								FROM m_tarif2012 a, t_billrajal b
								LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
								WHERE a.kode_tindakan=b.KODETARIF 
								AND b.IDXDAFTAR='".$idxdaftar[$j]."'");
			$total1 = 0;
			while($data = mysql_fetch_array($sql)){
				$sql1=mysql_query("select b.STATUS from t_billrajal a left join t_bayarrajal b ON b.NOBILL=a.NOBILL where a.KODETARIF='".$data['kode']."'");
				$data1=mysql_fetch_array($sql1);
				if ($data1['STATUS']=='LUNAS'){
					$st="L";
				}
				else if ($data1['STATUS']=='TRX'){
					$st="-";
				}
					echo '<tr style="height:10px;"><td>'.$data['nama_jasa'].'</td><td align="center">'.$data['qty'].'</td><td align="right">Rp. '.curformat($data['TARIFRS'],0).'</td><td align="right">Rp. '.curformat($data['TARIFRS'] * $data['qty']).'</td><td align="right">'.$st.'</td></tr>';
					$total	= $total + ( $data['TARIFRS'] * $data['qty']);
					$total1 = $total1 + ( $data['TARIFRS'] * $data['qty']);;
			}
			$sql2	= mysql_query("SELECT SUM(TOTTARIFRS) as total from t_bayarrajal where IDXDAFTAR='".$idxdaftar[$j]."' and STATUS='LUNAS'");
			$data2	= mysql_fetch_array($sql2);
			$byr	= $data2['total'];
			$kurang	= $total1 - $data2['total'];
			if($kurang < 0){
				$byr	= $byr + $kurang;
				$kurang	= 0;
			}
			
			$sql4 	= mysql_query("SELECT SUM(jaminan) AS jaminan FROM t_bayarrajal WHERE IDXDAFTAR=".$idxdaftar[$j]." AND STATUS='LUNAS'");
			$data4 	= mysql_fetch_array($sql4);
			$jaminan= $data4['jaminan'];
			
			if($_REQUEST['subcrbyr'] == 4){
				$total_bayar 	= 0;
				$getangsuran 	= get_t_angsuranrajal($idxdaftar[$j]);
				while($dataangsuran = mysql_fetch_array($getangsuran)){
					$total_bayar	= $total_bayar + $dataangsuran['jmbayar'];
				}
				$byr1 	= $total_bayar;
			}
			else{
				$byr1 	= $byr;
			}
			$byr1	= $byr1 + $byr1;
			
			if($_REQUEST['subcrbyr'] == 4){
				$sisa 	= getsisatarifrajal($idxdaftar[$j]);
			}else{
				$sisa 	= $kurang;
			}
			$sisa 	= $sisa + $sisa;
	    ?>
		
	    <tr style="height:auto;"><td colspan="4"></td></tr>
	    </tbody>
	    <?php }?>
		  <tr>
		  	<td style="text-align:left; padding-right:10px; border-top:1px dashed #000;">&nbsp;</td>
		  	<td colspan="2" style="text-align:right; padding-right:0px; border-top:1px dashed #000; font-size:7pt;">Total Biaya</td>
		  	<td style="border-top:1px dashed #000; text-align:right;">Rp. <?php echo curformat($total); ?></td>
		  </tr>
	   	  <tr>
	   	  	<td colspan="3" style="text-align:right; padding-right:0px; font-size:7pt;">Total Yang Sudah dibayarkan</td>
	   	  	<td style="text-align:right;">
	   	  		Rp. <?php 
	   	  				echo curformat($byr1);
	   	  			?>
	   	  	</td>
	   	  </tr>
	      <tr>
	      	<td rowspan="3" style="text-align:left; padding-right:10px; border-bottom:1px dashed #000;"><em>Terbilang: <?php echo strtoupper(Terbilang($total));?> Rupiah</em></td>
	      	<td colspan="2" style="text-align:right; font-size:7pt;">Sisa Pembayaran</td>
	      	<td style="text-align:right;">
	      		Rp. <?php 
	      				echo CurFormat($sisa);
	      			?>
	      	</td>
	      </tr>
	      <tr>
	      	<td colspan="2" style="text-align:right; font-size:7pt;">Jumlah Tanggungan</td>
	      	<td style="text-align:right; font-size:7pt;"><?php echo "Rp. " . CurFormat($jaminan); ?></td>
	      </tr>
	      <tr>
	      	<td colspan="2" style="text-align:right; padding-right:0px; border-bottom:1px dashed #000; font-size:7pt;">Selisih</td>
	      	<td style="text-align:right; padding-right:0px; border-bottom:1px dashed #000; font-size:7pt;"><?php echo "Rp. " . CurFormat($total - $jaminan); ?></td>
	      </tr>
	    <?php if(!empty($userdata['TOTASKES']) > 0){ ?>
	    <?php } ?>
	    <?php if(!empty($userdata['TOTCOSTSHARING']) > 0){ ?>
	    <?php } ?>
	    <?php if( (!empty($userdata['TOTASKES']) > 0) or (!empty($userdata['TOTCOSTSHARING']) > 0) ): ?>
	    <?php endif; ?>
	    </table>
	    <div id="footer">
	    	<br/>
	    	<div id="last_line" style="padding-top: 0px; margin: 0px;"> Dicetak : <?php echo date('d/m/Y H:i:s'); ?></div>
	    	<div id="footer1" style="float:left; width:300px; height:100px;">
	        	<br />
			</div>
	        <div id="footer2" style="float:left; width:280px;">
				<div style="text-align:center; width:100%;">Bagian Keuangan</div>
				<br/><br/><br/>
	            <div style="text-align:center; width:100%;">( Gunadi, SE.AK, M.Si )</div>
	        </div>
	    	<br clear="all" />
	   </div>
	</div>
</div>

<script type="text/javascript">
	window.print();
</script>