<?php
    class RsudAddressUtility{
        public static final function getNegara(){
            include_once("../include/connect.php");
            $sql = "SELECT * FROM m_negara ORDER BY negara; ";
            return mysql_query($sql);
        }

        public static final function getJsonKota($params){
            include("../include/connect.php");
            $nama_kota = "";
            extract($params);
            $sql_kota = "SELECT idkota, namakota FROM m_kota WHERE namakota LIKE '%{$nama_kota}%' ORDER BY namakota;";
            $qry_kota = mysql_query($sql_kota);
            $matches  = array();
            while($row = mysql_fetch_array($qry_kota)){
                $row['id']   = trim($row["idkota"]);
                $row['text'] = trim($row['namakota']);
                $matches[]   = $row;
            }
            $matches = array_slice($matches, 0, 10);
            print json_encode($matches);
        }
        
        public static final function getProvinsi($params){
        	include("../include/connect.php");
        	$n = "";
        	extract($params);
        	$sql = "SELECT * FROM m_provinsi WHERE namaprovinsi LIKE '%{$n}%';";
        
        	$rs_prov = mysql_query($sql);
        	$matches = array();
        	while($row = mysql_fetch_array($rs_prov)){
        		$row['id']   = trim($row["idprovinsi"]);
        		$row['text'] = trim($row['namaprovinsi']);
        		$matches[]   = $row;
        	}
        	$matches = array_slice($matches, 0, 10);
        	print json_encode($matches);
        }
        
        public static final function getKota($params){
        	include("../include/connect.php");
        	$n = "";
        	$idprov = "";
        	extract($params);
        	$sql = "SELECT * FROM m_kota WHERE namakota LIKE '%{$n}%' AND idprovinsi=".$idprov.";";
        
        	$rs_prov = mysql_query($sql);
        	$matches = array();
        	while($row = mysql_fetch_array($rs_prov)){
        		$row['id']   = trim($row["idkota"]);
        		$row['text'] = trim($row['namakota']);
        		$matches[]   = $row;
        	}
        	$matches = array_slice($matches, 0, 10);
        	print json_encode($matches);
        }
        
        public static final function getKecamatan($params){
        	include("../include/connect.php");
        	$n = "";
        	$idkota = "";
        	extract($params);
        	$sql = "SELECT * FROM m_kecamatan WHERE namakecamatan LIKE '%{$n}%' AND idkota=".$idkota.";";
        
        	$rs_prov = mysql_query($sql);
        	$matches = array();
        	while($row = mysql_fetch_array($rs_prov)){
        		$row['id']   = trim($row["idkecamatan"]);
        		$row['text'] = trim($row['namakecamatan']);
        		$matches[]   = $row;
        	}
        	$matches = array_slice($matches, 0, 10);
        	print json_encode($matches);
        }
        
        public static final function getKelurahan($params){
        	include("../include/connect.php");
        	$n = "";
        	$idkec = "";
        	extract($params);
        	$sql = "SELECT * FROM m_kelurahan WHERE namakelurahan LIKE '%{$n}%' AND idkecamatan=".$idkec.";";
        
        	$rs_prov = mysql_query($sql);
        	$matches = array();
        	while($row = mysql_fetch_array($rs_prov)){
        		$row['id']   = trim($row["idkelurahan"]);
        		$row['text'] = trim($row['namakelurahan']);
        		$matches[]   = $row;
        	}
        	$matches = array_slice($matches, 0, 10);
        	print json_encode($matches);
        }
        
    }
    
    /**
     * Digunakan untuk menangani request ajax,
     *
     */
    if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['function'])){
    	RsudAddressUtility::$_GET['function']($_GET);
    }