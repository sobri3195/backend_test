<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 02/03/2016
 * Time: 14:30
 */

    ini_set('display_errors',0);
    ini_set('memory_limit' , '128M');
    $hostname = '192.168.0.251';
    $database = 'simrskb';
    $username = 'admin';
    $password = 'rskb292929';
    $connect = mysql_connect($hostname, $username, $password,true,65536) or die(mysql_error());
    mysql_select_db($database,$connect)or die(mysql_error());