<?php
/**
 * Created by Fernalia.
 * Contact : fernalia.h@gmail.com
 * User: Ferna
 * Date: 08/06/2016
 * Time: 13:20
 */

require_once "TCPDF/tcpdf.php";

class PDF extends TCPDF{
    function __construct() {
        parent::__construct();
    }
}