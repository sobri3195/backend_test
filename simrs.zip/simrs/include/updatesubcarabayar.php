<?php
    session_start();
	include 'connect.php';
	
	extract($_POST);
	$nomr		= $NOMR;
	$idxd		= $IDXDAFTAR;
	$kdsubcb	= $kdsubcarabayar;
	$presenan	= $presentase;
	$idb		= $idbank;
	$user		= $_SESSION['NIP'];
	$opsi 		= $pilihan;
	
	$persenan	= $presenan/100;
	
	//update nilai subcarabayar dan presentase
	$t_pendaftaran	= mysql_query("UPDATE t_pendaftaran SET subcarabayar=".$kdsubcb." WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
	$t_billrajal	= mysql_query("UPDATE t_billrajal SET subcarabayar=".$kdsubcb." WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
	$t_bayarrajal	= mysql_query("UPDATE t_bayarrajal SET subcarabayar=".$kdsubcb.", presentase=".$presenan.", idbank=".$idb." WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
		
	//update nilai
	/*ambil semua total bayar*/
	$t_billrajalsel	= mysql_query("SELECT IDXBILL,JASA_SARANA,JASA_PELAYANAN,TARIFRS,NOBILL FROM t_billrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
	while($row1 = mysql_fetch_array($t_billrajalsel)){
        $idxbill        = $row1['IDXBILL'];
        $jasa_sarana	= $row1['JASA_SARANA'];
		$jasa_pelayanan	= $row1['JASA_PELAYANAN'];
		$tarifrs		= $row1['TARIFRS'];
		$nobill			= $row1['NOBILL'];
			
		$tempsarana		= $jasa_sarana * $persenan;
		$temppelayanan	= $jasa_pelayanan * $persenan;
		
		$jasa_sarana	= $jasa_sarana + $tempsarana;
		$jasa_pelayanan	= $jasa_pelayanan + $temppelayanan;

        $tarifrs_temp   = $tarifrs * $persenan;
		$tarifrs		= $tarifrs + $tarifrs_temp;

        mysql_query("UPDATE t_billrajal SET JASA_SARANA=".$jasa_sarana.", JASA_PELAYANAN=".$jasa_pelayanan.",
                        TARIFRS=".$tarifrs." WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd." AND IDXBILL=".$idxbill);

        $total          = 0;
        $tot_sarana     = 0;
        $tot_pelayanan  = 0;
        $sql            = mysql_query("SELECT * FROM t_billrajal WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd);
        while($data = mysql_fetch_array($sql)){
            $jsarana    = $data['JASA_SARANA'];
            $jpelayanan = $data['JASA_PELAYANAN'];
            $billtarif  = $data['TARIFRS'];
            $qty        = $data['QTY'];
            $temp_s     = $jsarana * qty;
            $temp_p     = $jpelayanan * $qty;
            $temp_total = $billtarif * $qty;

            $tot_sarana     = $tot_sarana + $temp_s;
            $tot_pelayanan  = $tot_pelayanan + $temp_p;
            $total          = $total + $temp_total;
        }
        mysql_query("UPDATE t_bayarrajal SET TOTJASA_SARANA=".$tot_sarana.", TOTJASA_PELAYANAN=".$tot_pelayanan.",
                        TOTTARIFRS=".$total.", sisabayar=".$total." WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd);
	}
		
	if($kdsubcb == 3){
		$t_bayarrajalsel	= mysql_query("SELECT TOTTARIFRS,NOBILL FROM t_bayarrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
		while($row2 = mysql_fetch_array($t_bayarrajalsel)){
			$tottarifrs		= $row2['TOTTARIFRS'];
			$nobillbayar	= $row2['NOBILL'];
				
			mysql_query("UPDATE t_bayarrajal SET TGLBAYAR=DATE(NOW()), JAMBAYAR=TIME(NOW()), JMBAYAR=".$tottarifrs.", NIP='".$user."', LUNAS=1, STATUS='LUNAS' WHERE NOBILL=".$nobillbayar);
		}
	}
	elseif ($kdsubcb == 4){
		$sql = mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.qty, b.TARIFRS,c.NAMADOKTER
							FROM m_tarif2012 a, t_billrajal b
							LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
							WHERE a.kode_tindakan=b.KODETARIF
							AND b.IDXDAFTAR='".$idxd."'");
		$total	= 0;
		while($data = mysql_fetch_array($sql)){
			$total	= $total + ( $data['TARIFRS'] * $data['qty']);
		}
			
		$sql2=mysql_query("SELECT SUM(TOTTARIFRS) as total from t_bayarrajal where IDXDAFTAR='".$idxd."' and STATUS='LUNAS'");
		$data2=mysql_fetch_array($sql2);
		$byr=$data2['total'];
		$kurang=$total-$data2['total'];
		if($kurang < 0){
			$byr=$byr+$kurang;
			$kurang=0;
		}
			
		$sql3 = mysql_query("SELECT TIME(now()) as time");
		while($ds = mysql_fetch_array($sql3)){
			$now 	= $ds['time'];
			$jam 	= substr($now, 0, 2);
			$menit 	= substr($now, 3, 2);
			$detik 	= substr($now, 6, 2);
		}
				
		$jam_now 		= new DateTime($now);
		$jam_pagi_bawah = new DateTime("07:00:00");
		$jam_pagi_atas 	= new DateTime("14:15:00");
		$jam_sore_atas 	= new DateTime("21:15:00");
			
		if($jam_now > $jam_pagi_bawah && $jam_now < $jam_pagi_atas){
			$shift = 1;
		}
		else{
			$shift = 2;
		}
			
		$sql4 = mysql_query("INSERT INTO t_angsuranrajal(nomr,idxdaftar,tglbayar,jambayar,shift,nip,tottarifrs,sisabayar) VALUES(".$nomr.",".$idxd.",DATE(NOW()),TIME(NOW()),".$shift.",'".$user."',".$total.",".$kurang.")");
	}
?>