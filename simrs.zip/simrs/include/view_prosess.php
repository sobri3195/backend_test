<SCRIPT LANGUAGE="JavaScript">
/*
function stopjam(){
var d = new Date();
var curr_hour = d.getHours();
var curr_min = d.getMinutes();
var curr_sec = d.getSeconds();
document.getElementById('stop_daftar').value=(curr_hour + ":" + curr_min+ ":" + curr_sec);
}
*/
jQuery(document).ready(function(){
	jQuery("#KDPROVINSI").change(function(){
		var selectValues = jQuery("#KDPROVINSI").val();
		var kotaHidden = jQuery("#KOTAHIDDEN").val();
		var kecHidden = jQuery("#KECAMATANHIDDEN").val();
		jQuery.post('<?php echo _BASE_;?>include/ajaxload.php',{kdprov:selectValues, kdkota:kotaHidden, kdkec:kecHidden, load_kota:'true'},function(data){
			jQuery('#kotapilih').html(data);
			jQuery('#KOTA').val(kotaHidden).change();
			jQuery('#kecamatanpilih').html("<select name=\"KDKECAMATAN\" class=\"text required select2\" title=\"*\" id=\"KDKECAMATAN\"><option value=\"0\"> --pilih-- </option></select>");
			jQuery('#kelurahanpilih').html("<select name=\"KELURAHAN\" class=\"text required select2\" title=\"*\" id=\"KELURAHAN\"><option value=\"0\"> --pilih-- </option></select>");
		});
	});
});
</SCRIPT>
     
 
    <!--<fieldset class="fieldset" style="background:#D7F5A1;">-->
<!--        <legend>Data Pasien</legend>-->
      

	 
	  
        <tr>
          <td>Tempat Tanggal Lahir</td>
          <td>Tempat
            <input type="hidden" name="kartu1" id="kartu1" size="30" value="<? if(!empty($_GET['NO_KARTU'])){ echo $_GET['NO_KARTU']; } ?>"  />
			<input type="text" value="<? if(!empty($_GET['TEMPAT'])){ echo $_GET['TEMPAT']; }else{ echo $m_pasien->TEMPAT;} ?>" class="text required" title="*" name="TEMPAT" size="15" id="TEMPAT" />
            <input onblur="calage1(this.value,'umur');" type="text" class="text datepicker2 required" title="*" value="<? if(!empty($_GET['TGLLAHIR'])){ echo date('d/m/Y', strtotime($_GET['TGLLAHIR'])); }else{ echo date('d/m/Y', strtotime($m_pasien->TGLLAHIR));} ?>" name="TGLLAHIR" id="TGLLAHIR" size="10" />
<!--            <a href="javascript:showCal1('Calendar1')"><img align="top" src="img/date.png" border="0" /></a> ex : 29/09/1999</td>-->
<!--        <a href="javascript:showCal1('Calendar1')"><img align="top" src="img/date.png" border="0" /></a></td>  -->
        </tr>
 
 <tr>
          <td>Umur </td>
          <td>
          <?php 
		  if ($m_pasien->TGLLAHIR==""){
			  $a = datediff(date("Y/m/d"), date("Y/m/d"));
		  }
		  else {
			   $a = datediff($m_pasien->TGLLAHIR, date("Y/m/d"));
		  }
		  ?>
          <span id="umurc"><input class="text" type="text" value="<?php echo 'umur '.$a[years].' tahun '.$a[months].' bulan '.$a[days].' hari'; ?>" name="umur" id="umur" size="45" /></span></td>
          </tr>
        <tr>
          <td valign="top">Alamat Sekarang</td>
          <td colspan="1"><input name="ALAMAT" id="ALAMAT"  type="text" value="<? if(!empty($_GET['ALAMAT'])){ echo $_GET['ALAMAT']; } ?>" title="*" size="45" /></td>
          </tr>
        <tr>
          <td>Alamat KTP</td>
          <td><input name="ALAMAT_KTP"  type="text" value="<? if(!empty($_GET['ALAMAT_KTP'])){ echo $_GET['ALAMAT_KTP']; } ?>" title="*" size="45" id="ALAMAT_KTP" /></td>
        </tr>
		<tr>
          <td>Provinsi</td>
          <td><select name="KDPROVINSI"  title="*" id="KDPROVINSI" class="select2">
            <option value="0"> --pilih-- </option>
			<?php
			  $ss	= mysql_query('select * from m_provinsi order by idprovinsi ASC');
			  while($ds = mysql_fetch_array($ss)){
				if($_GET['KDPROVINSI'] == $ds['idprovinsi']): $sel = "selected=Selected"; else: $sel = ''; endif;
				echo '<option value="'.$ds['idprovinsi'].'" '.$sel.' > '.$ds['namaprovinsi'].'</option>';
			  }
			?>
          </select>
		  <input class="text" value="<?=$_GET['KOTA']?>" type="hidden" name="KOTAHIDDEN" id="KOTAHIDDEN" >
		  <input class="text" value="<?=$_GET['KECAMATAN']?>" type="hidden" name="KECAMATANHIDDEN" id="KECAMATANHIDDEN" >
		  <input class="text" value="<?=$_GET['KELURAHAN']?>" type="hidden" name="KELURAHANHIDDEN" id="KELURAHANHIDDEN" ></td>
        </tr>
        <tr>
          <td>Kota</td>
          <td><div id="kotapilih"><select name="KOTA"  title="*" id="KOTA" class="select2">
            <option value="0"> --pilih-- </option>
			<?php
			  $ss	= mysql_query('select * from m_kota where idprovinsi = "'.$_GET['KDPROVINSI'].'" order by idkota ASC');
			  while($ds = mysql_fetch_array($ss)){
				if($_GET['KOTA'] == $ds['idkota']): $sel = "selected=Selected"; else: $sel = ''; endif;
				echo '<option value="'.$ds['idkota'].'" '.$sel.' > '.$ds['namakota'].'</option>';
			  }
			?>
          </select></div></td>
        </tr>
        <tr>
          <td>Kecamatan</td>
          <td><div id="kecamatanpilih"><select name="KDKECAMATAN" title="*" id="KDKECAMATAN" class="select2">
            <option value="0"> --pilih-- </option>
			<?php
			  $ss	= mysql_query('select * from m_kecamatan where idkota = "'.$_GET['KOTA'].'" order by idkecamatan ASC');
			  while($ds = mysql_fetch_array($ss)){
				if($_GET['KDKECAMATAN'] == $ds['idkecamatan']): $sel = "selected=Selected"; else: $sel = ''; endif;
				echo '<option value="'.$ds['idkecamatan'].'" '.$sel.' /> '.$ds['namakecamatan'].'</option>&nbsp;';
			  }
			?>
          </select></div></td>
        </tr>
        <tr>
          <td>Kelurahan</td>
          <td><div id="kelurahanpilih"><select name="KELURAHAN"  title="*" id="KELURAHAN" class="select2">
            <option value="0"> --pilih-- </option>
			<?php
			  $ss	= mysql_query('select * from m_kelurahan where idkecamatan = "'.$_GET['KDKECAMATAN'].'" order by idkelurahan ASC');
			  while($ds = mysql_fetch_array($ss)){
				if($_GET['KELURAHAN'] == $ds['idkelurahan']): $sel = "selected=Selected"; else: $sel = ''; endif;
				echo '<option value="'.$ds['idkelurahan'].'" '.$sel.' /> '.$ds['namakelurahan'].'</option>&nbsp;';
			  }
			?>
			</select></div></td>
        </tr>
        <tr>

          <td>No Telepon / HP</td>
          <td><input  value="<? if(!empty($_GET['NOTELP'])){ echo $_GET['NOTELP']; }else{ echo $m_pasien->NOTELP;} ?>" title="*" type="text" name="NOTELP" size="25" id="notelp" /></td>
        </tr>
        <tr>
        	<td valign="top">&nbsp;</td>
          <td>No KTP </td>
          <td><input  value="<? if(!empty($_GET['NOKTP'])){ echo $_GET['NOKTP']; }else{ echo $m_pasien->NOKTP;} ?>" title="*" type="text" name="NOKTP" id="NOKTP" size="25" /></td>
        </tr>
<!--        <tr>
          <td>Nama Ayah </td>
          <td><input class="text" type="text" value="<? if(!empty($_GET['SUAMI_ORTU'])){ echo $_GET['SUAMI_ORTU']; }else{ echo $m_pasien->SUAMI_ORTU;} ?>" name="SUAMI_ORTU" id="SUAMI_ORTU" size="25" /></td>
          </tr>-->
        <!--<tr valign="top">-->
		<tr>
			<td valign="top">&nbsp;</td>
<!--			<td valign="top">&nbsp;</td>-->
          <!--<td height="22" valign="top">--><td>Pekerjaan Pasien</td>
          <!--<td><input  type="text" value="<? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN']; }else{ echo $m_pasien->PEKERJAAN;} ?>" title="*" name="PEKERJAAN" size="25" id="PEKERJAAN" /></td>-->
		  <td>
			<select name="PEKERJAAN" id="PEKERJAAN" class="required">
				<option value="" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "" ? "selected" : ""; }; ?>>-- Pilih Pekerjaan --</option>
				<option value="TIDAK_BEKERJA" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "TIDAK_BEKERJA" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "TIDAK_BEKERJA" ? "selected" : ""; }; ?>>TIDAK BEKERJA</option>
				<option value="SWASTA" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "SWASTA" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "SWASTA" ? "selected" : ""; }; ?>>SWASTA</option>
				<option value="NEGERI" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "NEGERI" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "NEGERI" ? "selected" : ""; }; ?>>NEGERI</option>
				<option value="BUMN" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "BUMN" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "BUMN" ? "selected" : "BUMN"; }; ?>>BUMN</option>
				<option value="TANI_BURUH" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "TANI_BURUH" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "TANI_BURUH" ? "selected" : ""; }; ?>>TANI/BURUH</option>
				<option value="WIRASWASTA" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "WIRASWASTA" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "WIRASWASTA" ? "selected" : ""; }; ?>>WIRASWASTA</option>
				<option value="MAHASISWA" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "MAHASISWA" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "MAHASISWA" ? "selected" : ""; }; ?>>MAHASISWA</option>
				<option value="IRT" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "IRT" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "IRT" ? "selected" : ""; }; ?>>IRT</option>
				<option value="GURU_DOSEN" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "GURU_DOSEN" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "GURU_DOSEN" ? "selected" : ""; }; ?>>GURU/DOSEN</option>
				<option value="PENGEMUDI" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "PENGEMUDI" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "PENGEMUDI" ? "selected" : ""; }; ?>>PENGEMUDI</option>
				<option value="ABRI_POLISI" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "POLISI" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "POLISI" ? "selected" : ""; }; ?>>POLISI</option>
				<option value="ABRI_POLISI" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "ABRI" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "ABRI" ? "selected" : ""; }; ?>>ABRI</option>
				<option value="PELAJAR" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "PELAJAR" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "PELAJAR" ? "selected" : ""; }; ?>>PELAJAR</option>
				<option value="LAINNYA" <? if(!empty($_GET['PEKERJAAN'])){ echo $_GET['PEKERJAAN'] == "LAINNYA" ? "selected" : ""; }else{ echo $m_pasien->PEKERJAAN == "LAINNYA" ? "selected" : ""; }; ?>>LAINNYA</option>
			</select>
		  </td>
		</tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td valign="top">&nbsp;</td>
          <td valign="top">&nbsp;</td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td valign="top">
          					<label id="label_namapj">Nama Penanggung Jawab</label>
          </td>
          <td valign="top"><input  type="text" name="nama_penanggungjawab" size="30" value="<? if(!empty($_GET['nama_penanggungjawab'])){ echo $_GET['nama_penanggungjawab']; } ?>" title="*" id="nama_penanggungjawab"  /></td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td valign="top">Hubungan Dengan Pasien</td>
          <td valign="top"><input type="text" name="hubungan_penanggungjawab" size="30" value="<? if(!empty($_GET['hubungan_penanggungjawab'])){ echo $_GET['hubungan_penanggungjawab']; } ?>" title="*" id="hubungan_penanggungjawab" /></td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td valign="top">Alamat</td>
          <td valign="top"><input name="alamat_penanggungjawab"  type="text" size="45" value="<? if(!empty($_GET['alamat_penanggungjawab'])){ echo $_GET['alamat_penanggungjawab']; } ?>" title="*" id="alamat_penanggungjawab" /></td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td valign="top">No Telepon / HP</td>
          <td valign="top"><input  type="text" name="phone_penanggungjawab" size="25" value="<? if(!empty($_GET['phone_penanggungjawab'])){ echo $_GET['phone_penanggungjawab']; } ?>" title="*" id="phone_penanggungjawab" /></td>
        </tr>
        <tr>
            <td valign="top">&nbsp;</td>
            <td>
                Jam Selesai Pendaftaran
            </td>
            <td>
                <input type="text" class="text required" name="keluar" title="*" value="" id="keluar" size="25"/>
                <input type="button" class="text" name="save2" onclick="jQuery('#keluar').val(js_yyyy_mm_dd_hh_mm_ss()); jQuery(this).hide();" value=" K e l u a r " />
            </td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td valign="top">&nbsp;</td>
          <td valign="top">&nbsp;</td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td valign="top">&nbsp;</td>
          <td valign="top">&nbsp;</td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td valign="top">&nbsp;</td>
          <td colspan="2"><input type='hidden' name='stop_daftar' id='stop_daftar' /></td>
        </tr>
      </table>
		<table width="25%" style="float:right;">
        	<tr><td width="20%" rowspan="19" valign="top"> Jenis Kelamin :<br />
            <input type="radio" name="JENISKELAMIN" id="JENISKELAMIN_L" title="*" class="required" value="L" <? if(strtoupper($_GET['JENISKELAMIN'])=="L") echo "Checked";?>/>
            Laki-laki<br />
            <input type="radio" name="JENISKELAMIN" id="JENISKELAMIN_P" title="*" class="required" title="*" value="P" <? if(strtoupper($_GET['JENISKELAMIN'])=="P") echo "Checked";?>/>
            Perempuan<br />
            <br />
            Status Perkawinan :<br />
            
            <input type="radio" title="*" class="required" name="STATUS" id="status_1" value="1" <? if($m_pasien->STATUS=="1" || $_GET['STATUS']=="1") echo "Checked";?>/>
            Belum Kawin<br />
            <input type="radio" title="*" class="required" name="STATUS" id="status_2" value="2" <? if($m_pasien->STATUS=="2" || $_GET['STATUS']=="2") echo "Checked";?> />
            Kawin<br />
            <input type="radio" title="*" class="required" name="STATUS" id="status_3" value="3" <? if($m_pasien->STATUS=="3" || $_GET['STATUS']=="3") echo "Checked";?>/>
            Janda / Duda<br /><br />
            
            Pendidikan Terakhir :<br />
			<input type="radio" title="*" class="required" name="PENDIDIKAN" id="PENDIDIKAN_6" value="6" <? if($m_pasien->PENDIDIKAN=="6" || $_GET['PENDIDIKAN']=="6") echo "Checked";?> />
            Belum Sekolah<br />
            <input type="radio" title="*" class="required" name="PENDIDIKAN" id="PENDIDIKAN_1" value="1" <? if($m_pasien->PENDIDIKAN=="1" || $_GET['PENDIDIKAN']=="1") echo "Checked";?> />
            SD<br />
            <input type="radio" title="*" class="required" name="PENDIDIKAN" id="PENDIDIKAN_2" value="2" <? if($m_pasien->PENDIDIKAN=="2" || $_GET['PENDIDIKAN']=="2") echo "Checked";?> />
            SLTP<br />
            <input type="radio" title="*" class="required" name="PENDIDIKAN" id="PENDIDIKAN_3" value="3" <? if($m_pasien->PENDIDIKAN=="3" || $_GET['PENDIDIKAN']=="3") echo "Checked";?> />
            SMU<br />
            <input type="radio" title="*" class="required" name="PENDIDIKAN" id="PENDIDIKAN_4" value="4" <? if($m_pasien->PENDIDIKAN=="4" || $_GET['PENDIDIKAN']=="4") echo "Checked";?> />
            D3/Akademik<br />
            <input type="radio" title="*" class="required" name="PENDIDIKAN" id="PENDIDIKAN_5" value="5" <? if($m_pasien->PENDIDIKAN=="5" || $_GET['PENDIDIKAN']=="5") echo "Checked";?> />
            Universitas<br /><br />
           
            Agama :<br />
             <input type="radio" title="*" class="required" name="AGAMA" id="AGAMA_1" value="1" <? if($m_pasien->AGAMA=="1" || $_GET['AGAMA']=="1") echo "Checked";?> />
Islam<br />

<input type="radio" name="AGAMA" title="*" class="required" id="AGAMA_2" value="2" <? if($m_pasien->AGAMA=="2" || $_GET['AGAMA']=="2") echo "Checked";?>/>
Kristen Protestan<br />

<input type="radio" name="AGAMA" title="*" class="required" id="AGAMA_3" value="3" <? if($m_pasien->AGAMA=="3" || $_GET['AGAMA']=="3") echo "Checked";?>/>
Katholik<br />

<input type="radio" name="AGAMA" title="*" class="required" id="AGAMA_4" value="4" <? if($m_pasien->AGAMA=="4" || $_GET['AGAMA']=="4") echo "Checked";?>/>
Hindu<br />

<input type="radio" name="AGAMA" title="*" class="required" id="AGAMA_5" value="5" <? if($m_pasien->AGAMA=="5" || $_GET['AGAMA']=="5") echo "Checked";?>/>
Budha<br />

<input type="radio" name="AGAMA" title="*" class="required" id="AGAMA_6" value="6" <? if($m_pasien->AGAMA=="6" || $_GET['AGAMA']=="6") echo "Checked";?>/>
Lain - lain </td></tr>
        </table>
        <br clear="all" />
        <table width="100%">
        <tr>
          <td colspan="4" align="right">
          <input type="button" name="daftar" class="text btn_simpan" value="  Simpan  "
           />
          <a href="#" onclick="cetak();" >
          <input type="button" name="print" class="text" value=" Print Kartu Pasien " />
          </a>
          </td>
        </tr>
        </table>
      <input type="text" id="msgid" name="msgid" style="border:1px #FFF solid; width:0px; height:0px;">
      <br>
    <!--</fieldset>-->
<? if(!empty($_GET['TGLLAHIR'])){ ?>    
<script language="javascript" >
calage1('<?=$_GET['TGLLAHIR']?>','umur');
</script>
<? } ?>

<script language="javascript" type="text/javascript">
function cetak(){
var nomr = document.getElementById('NOMR').value;
var nama = document.getElementById('NAMA').value;
var cal = document.getElementById('CALLER').value;
var alamat = document.getElementById('ALAMAT').value;
//window.open("pdfb/kartupasien.php?NOMR="+ nomr +"&NAMA="+ nama +"&ALAMAT="+ alamat,"mywindow");
window.open("pdfb/kartupasien.php?NOMR="+ nomr +"&NAMA="+ nama + ", " + cal +"&ALAMAT="+ alamat,"mywindow");
return false;
}

	jQuery(".btn_simpan").click(function(){
		var carbar = jQuery(".carabayar").val();
		//alert(carbar);
		if(carbar == 5){
			var sep = jQuery("#NK").val();
			if(sep.substring(0,5) == "0133R" && sep.length == 19){
				jQuery("#myform").submit();
			} else{
				alert("Maaf SEP tidak sesuai! harap cek kembali...");
			}
		} else{
			var dokter = jQuery('#kddokter').val();
			var nomr   = jQuery('#NOMR').val();
			jQuery.ajax({
				url: "<?= _BASE_;?>models/pendaftaran/cek_pendaftaran_by_dokter.php",
				method: "post",
				data: {dokter:dokter,nomr:nomr},
				success: function (data) {
					if(data > 0){
						alert("Pasien sudah terdaftar pada dokter tersebut. Harap cek kembali di list kunjungan pasien.");
					} else{
						jQuery("#myform").submit();
					}
				},
				error: function (jqXHR, textStatus, errorThrown) {

				}
			});
		}
	});
</script>
  