<?php 
	session_start();
	include 'connect.php';
	include 'function.php';
	
	extract($_POST);
	$nomr	= $NOMR;
	$idxd	= $IDXDAFTAR;
	$opsi	= $pilihan;
	
	if($opsi == 0){
		$sql	= mysql_query("SELECT MAX(subcarabayar) AS subcarabayar FROM t_bayarrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
		$data	= mysql_fetch_array($sql);
		
		echo json_encode($data);	
	}
	else if($opsi == 1){
		$sql	= mysql_query("SELECT * FROM t_bayarrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
		$data	= mysql_fetch_array($sql);
		
		echo json_encode($data);
	}
	else if($opsi == 2){
		$shift		= getAutomaticShift();
		
		$sql		= mysql_query("SELECT * FROM t_bayarrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
		$totalbayar	= $totalygdibayarkan;
		$tempttl	= $totalbayar;
		$user 		= $_SESSION['NIP'];
		
		$tottarif	= getTottarifrsrajal2($idxd,$nomr);
		
		while($data = mysql_fetch_array($sql)){
			if($totalbayar > 0){
				$nobill		= $data['NOBILL'];
				$jmbayar	= $data['JMBAYAR'];
				$jmtarif	= $data['TOTTARIFRS'];
				$tempsisa	= $data['sisabayar'];
				$sisa		= $data['sisabayar'];
				$carabayar	= $data['CARABAYAR'];
				$totalbayar	= $totalbayar - $sisa;
				
				
				if($totalbayar >= 0){
					$sisa 			= $tempsisa - $sisa;
					$tempjmbayar	= $jmbayar + $sisa;
					mysql_query("UPDATE t_bayarrajal SET TGLBAYAR=DATE(NOW()), 
														JAMBAYAR=TIME(NOW()), 
														SHIFT=".$shift.", 
														NIP='".$_SESSION['NIP']."', 
														JMBAYAR=".$tempjmbayar.", 
														LUNAS=1, sisabayar=".$sisa.", 
														STATUS='LUNAS' 
													WHERE NOBILL=".$nobill);
				}
				else{
					$temptotalbyr 	= $totalbayar * -1;
					$tempjmbayar	= $jmbayar + $tempttl;
					mysql_query("UPDATE t_bayarrajal SET sisabayar=".$temptotalbyr.", 
														JMBAYAR=".$tempjmbayar." 
													WHERE NOBILL=".$nobill);
				} 
			}
		}
		
		if($carabayar == 5){
			mysql_query("INSERT INTO t_angsuranrajal(nomr,idxdaftar,tglbayar,jambayar,jmbayar,shift,nip,tottarifrs) VALUES(".$nomr.",".$idxd.",DATE(NOW()),TIME(NOW()),".$tempttl.",".$shift.",'".$user."',".$tempsisa.")");
		}
		else{
			mysql_query("INSERT INTO t_angsuranrajal(nomr,idxdaftar,tglbayar,jambayar,jmbayar,shift,nip,tottarifrs) VALUES(".$nomr.",".$idxd.",DATE(NOW()),TIME(NOW()),".$tempttl.",".$shift.",'".$user."',".$tottarif.")");
		}
		
		$sisatarif	= getsisatarifrajal2($idxd, $nomr);
		$maxidangsr	= getMaxIdxangsuranbyperson2($idxd, $nomr);
		mysql_query("UPDATE t_angsuranrajal SET sisabayar=".$sisatarif." WHERE idxangsuran=".$maxidangsr);
	}
	else if ($opsi == 3){
		$sisatarif	= getsisatarifrajal2($idxd,$nomr);
		echo curformat($sisatarif,2);
	}
	else if($opsi == 4){
		$sql	= mysql_query("SELECT * FROM t_bayarlab WHERE nomr=".$nomr." AND idxdaftar=".$idxd);
		$data	= mysql_fetch_array($sql);
		
		echo json_encode($data);
	}
	else if($opsi == 5){
		$sisatarif	= getsisatariflab($idxd);
		echo CurFormat($sisatarif,2);
	}
	else if($opsi == 6){
		$shift		= getAutomaticShift();
		
		$sql		= get_t_bayarlab($nomr, $idxd);
		$totalbayar	= $totalygdibayarkan;
		$tempttl	= $totalbayar;
		
		//$tottarif	= getTottarifrsrajal($idxd);
		$tottarif	= getSumTottariflab($idxd);
		
		while($data = mysql_fetch_array($sql)){
			if($totalbayar > 0){
				$idxbyrlab	= $data['idxbayarlab'];
				$nobill		= $data['nobilllab'];
				$jmbayar	= $data['jmbayar'];
				$jmtarif	= $data['tottariflab'];
				$tempsisa	= $data['sisabayar'];
				$sisa		= $data['sisabayar'];
				$totalbayar	= $totalbayar - $sisa;
			
				if($totalbayar >= 0){
					$sisa 			= $tempsisa - $sisa;
					$tempjmbayar	= $jmbayar + $sisa;
					mysql_query("UPDATE t_bayarlab SET tglbayar=DATE(NOW()),
														jambayar=TIME(NOW()),
														shif=".$shift.",
														nip='".$_SESSION['NIP']."',
														jmbayar=".$tempjmbayar.",
														lunas=1,
														sisabayar=".$sisa.",
														status='LUNAS'
													WHERE idxbayarlab=".$idxbyrlab);
				}
				else{
					$temptotalbyr 	= $totalbayar * -1;
					$tempjmbayar	= $jmbayar + $tempttl;
					mysql_query("UPDATE t_bayarlab SET sisabayar=".$temptotalbyr.",
														jmbayar=".$tempjmbayar."
													WHERE idxbayarlab=".$idxbyrlab);
				}
			}
		}
		
		mysql_query("INSERT INTO t_angsuranlab(nomr,idxdaftar,tglbayar,jambayar,jmbayar,shift,nip,tottariflab)
					VALUES('".$nomr."',".$idxd.",DATE(NOW()),TIME(NOW()),".$tempttl.",".$shift.",'".$_SESSION['NIP']."',".$tottarif.")");
		
		$sisatarif	= getsisatariflab($idxd);
		$maxidangsr	= getMaxIdxangsuranlabbyperson($idxd);
		mysql_query("UPDATE t_angsuranlab SET sisabayar=".$sisatarif." WHERE idxangsuranlab=".$maxidangsr);
	}
    else if($opsi == 7){
        $sisatarif	= getsisatarifrajal3($idxd,$nomr);
        echo curformat($sisatarif,2);
    }
    else if($opsi == 8){
        $sql    = mysql_query("SELECT * FROM idpasien WHERE NOMEDIK='".$nomr."'");
        $data   = mysql_fetch_array($sql);

        echo json_encode($data);
    }
?>