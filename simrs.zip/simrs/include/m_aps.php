<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 05/01/2016
 * Time: 14:55
 */

    session_start();
    include 'connect.php';

    extract($_POST);
    $nomr		= $NOMR;
    $idxd		= $IDXDAFTAR;
    $kdsubcb	= $kdsubcarabayar;
    $presenan	= $presentase;
    $idb		= $idbank;
    $user		= $_SESSION['NIP'];

    $persenan	= $presenan/100;

    //update nilai subcarabayar dan presentase
    $t_pendaftaran	= mysql_query("UPDATE t_pendaftaran_aps SET subcarabayar=".$kdsubcb." WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
    $t_billrajal	= mysql_query("UPDATE t_billrajal SET subcarabayar=".$kdsubcb." WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
    $t_bayarrajal	= mysql_query("UPDATE t_bayarrajal SET subcarabayar=".$kdsubcb.", presentase=".$presenan.", idbank=".$idb." WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);

    //update nilai
    /*ambil semua total bayar*/
    $t_billrajalsel	= mysql_query("SELECT IDXBILL,JASA_SARANA,JASA_PELAYANAN,TARIFRS,NOBILL FROM t_billrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
    while($row1 = mysql_fetch_array($t_billrajalsel)){
        $idxbill        = $row1['IDXBILL'];
        $jasa_sarana	= $row1['JASA_SARANA'];
        $jasa_pelayanan	= $row1['JASA_PELAYANAN'];
        $tarifrs		= $row1['TARIFRS'];
        $nobill			= $row1['NOBILL'];

        $tempsarana		= $jasa_sarana * $persenan;
        $temppelayanan	= $jasa_pelayanan * $persenan;

        $jasa_sarana	= $jasa_sarana + $tempsarana;
        $jasa_pelayanan	= $jasa_pelayanan + $temppelayanan;

        $tarifrs_temp   = $tarifrs * $persenan;
        $tarifrs		= $tarifrs + $tarifrs_temp;

        mysql_query("UPDATE t_billrajal SET JASA_SARANA=".$jasa_sarana.", JASA_PELAYANAN=".$jasa_pelayanan.",
                        TARIFRS=".$tarifrs." WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd." AND IDXBILL=".$idxbill);

        $total          = 0;
        $tot_sarana     = 0;
        $tot_pelayanan  = 0;
        $sql            = mysql_query("SELECT * FROM t_billrajal WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd);
        while($data = mysql_fetch_array($sql)){
            $jsarana    = $data['JASA_SARANA'];
            $jpelayanan = $data['JASA_PELAYANAN'];
            $billtarif  = $data['TARIFRS'];
            $qty        = $data['QTY'];
            $temp_s     = $jsarana * qty;
            $temp_p     = $jpelayanan * $qty;
            $temp_total = $billtarif * $qty;

            $tot_sarana     = $tot_sarana + $temp_s;
            $tot_pelayanan  = $tot_pelayanan + $temp_p;
            $total          = $total + $temp_total;
        }
        mysql_query("UPDATE t_bayarrajal SET TOTJASA_SARANA=".$tot_sarana.", TOTJASA_PELAYANAN=".$tot_pelayanan.",
                        TOTTARIFRS=".$total.", sisabayar=".$total." WHERE NOBILL=".$nobill." AND IDXDAFTAR=".$idxd);
    }

    if($kdsubcb == 3){
        $t_bayarrajalsel	= mysql_query("SELECT TOTTARIFRS,NOBILL FROM t_bayarrajal WHERE NOMR=".$nomr." AND IDXDAFTAR=".$idxd);
        while($row2 = mysql_fetch_array($t_bayarrajalsel)){
            $tottarifrs		= $row2['TOTTARIFRS'];
            $nobillbayar	= $row2['NOBILL'];

            mysql_query("UPDATE t_bayarrajal SET TGLBAYAR=DATE(NOW()), sisabayar=0, JAMBAYAR=TIME(NOW()), JMBAYAR=".$tottarifrs.", NIP='".$user."', LUNAS=1, STATUS='LUNAS' WHERE NOBILL=".$nobillbayar);
        }
    }