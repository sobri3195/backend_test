<?php 
	session_start();
	include 'connect.php';
	include 'function.php';
	
	if($_REQUEST['opsi'] == 1){
		$nama	= $_REQUEST['nama'];
		$jmks 	= $_REQUEST['jmks'];
		
		$get_kdmax 	= mysql_query("SELECT MAX(KODE) AS KODE FROM m_carabayar");
		$data_kdmax	= mysql_fetch_array($get_kdmax);
		$kd_max 	= $data_kdmax['KODE'] + 1;
		
		$get_odrmax	= mysql_query("SELECT MAX(ORDERS) AS ORDERS FROM m_carabayar");
		$data_odrmax= mysql_fetch_array($get_odrmax);
		$odr_max 	= $data_odrmax['ORDERS'];
		$new_odrmax	= $odr_max + 1;
		
		mysql_query("UPDATE m_carabayar SET ORDERS=".$new_odrmax." 
										WHERE ORDERS=".$odr_max);
		
		mysql_query("INSERT INTO m_carabayar(KODE,NAMA,ORDERS,JMKS) VALUES(".$kd_max.",'".$nama."',".$odr_max.",'".$jmks."')");
		$_SESSION["success"]	= 1;
		header("location:../index.php?link=2324anggaranbaru");
	}
	else if($_REQUEST['opsi'] == 2){
		$kode 	= $_REQUEST['kode'];
		$nama	= $_REQUEST['nama'];
		$jmks 	= $_REQUEST['jmks'];
		
		mysql_query("UPDATE m_carabayar SET NAMA='".$nama."',
											JMKS='".$jmks."' 
										WHERE KODE=".$kode);
		$_SESSION["success"]	= 1;
		header("location:../index.php?link=2324anggaranbaru");
	}
	else if($_REQUEST['opsi'] == 3){
		$kode 	= $_REQUEST['kode'];
		
		mysql_query("DELETE FROM m_carabayar WHERE KODE=".$kode);
		$_SESSION["success"]	= 1;
		header("location:../index.php?link=2324anggaranbaru");
	}
?>