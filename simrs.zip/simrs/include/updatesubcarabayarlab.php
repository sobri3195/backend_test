<?php 
	session_start();
	include 'connect.php';
	include 'function.php';
	
	extract($_POST);
	$nomr		= $NOMR;
	$idxd		= $IDXDAFTAR;
	$kdsubcb	= $kdsubcarabayar;
	$presenan	= $presentase;
	$idb		= $idbank;
	$user		= $_SESSION['NIP'];
	
	$persenan		= $presenan/100;
	$tempsarana		= 0;
	$temppelayanan	= 0;
	
	$shift 		= getAutomaticShift();

	//update nilai subcarabayar dan persentase
	$t_bayarlab 	= mysql_query("UPDATE t_bayarlab SET subcarabayar=".$kdsubcb.",
														 presentase=".$presenan.",
														 idbank=".$idb."
													 WHERE nomr='".$nomr."' AND idxdaftar=".$idxd);
	
	//ambil semua total bayar laboratorium
	$t_bayarlab 	= get_t_bayarlab($nomr, $idxd);
	while ($dataBayarlab = mysql_fetch_array($t_bayarlab)){
		$jasa_sarana 	= $dataBayarlab['totjasa_sarana'];
		$jasa_pelayanan	= $dataBayarlab['totjasa_pelayanan'];
		$tariflab		= $dataBayarlab['tottariflab'];
		$idxbayarlab 	= $dataBayarlab['idxbayarlab'];
		$kode_tindakan	= $dataBayarlab['kode_tindakan'];
			
		$tempsarana		= $jasa_sarana * $persenan;
		$temppelayanan	= $jasa_pelayanan * $persenan;
			
		$jasa_sarana 	= $jasa_sarana + $tempsarana;
		$jasa_pelayanan	= $jasa_pelayanan + $temppelayanan;
			
		$tariflab		= $jasa_sarana + $jasa_pelayanan;
			
		mysql_query("UPDATE t_bayarlab SET totjasa_sarana=".$jasa_sarana.",
										   totjasa_pelayanan=".$jasa_pelayanan.",
										   tottariflab=".$tariflab."
									   WHERE idxbayarlab=".$idxbayarlab);
		
		mysql_query("UPDATE t_orderlab SET Jasa_sarana=".$jasa_sarana.",
										   jasa_pelayanan=".$jasa_pelayanan.",
										   tariflab=".$tariflab." 
									   WHERE IDXDAFTAR=".$idxd." AND KODE='".$kode_tindakan."'");
	}
	
	if($kdsubcb == 3){
		 $t_bayarlab2 	= get_t_bayarlab($nomr, $idxd);
		 while($data3 = mysql_fetch_array($t_bayarlab2)){
		 $tottariflab 	= $data3['tottariflab'];
		 $idxbyrlab		= $data3['idxbayarlab'];
		
		 mysql_query("UPDATE t_bayarlab SET tglbayar=DATE(NOW()),
											 jambayar=TIME(NOW()),
											 jmbayar=".$tottariflab.",
											 nip='".$user."',
											 lunas=1,
											 status='LUNAS',
											 sisabayar=0,
		 									 shif=".$shift."  
										 WHERE idxbayarlab=".$idxbyrlab);
		 }
	}
	elseif ($kdsubcb == 4){
		 $sql	= mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.QTY, b.tariflab
		 FROM m_tarif2012 a, t_orderlab b
		 WHERE a.kode_tindakan=b.KODE AND b.IDXDAFTAR=".$idxd);
		 	
		 $total	= 0;
		 while($data = mysql_fetch_array($sql)){
		 $total	= $total + ( $data['tariflab'] * $data['QTY']);
		 }
		 	
		 $sql2=mysql_query("SELECT SUM(tottariflab) as total from t_bayarlab where IDXDAFTAR='".$idxd."' and status='LUNAS'");
		 $data2=mysql_fetch_array($sql2);
		 $byr=$data2['total'];
		 $kurang=$total-$data2['total'];
		 if($kurang < 0){
		 $byr=$byr+$kurang;
		 $kurang=0;
		 }
		 
		 //create t_angsuranlab
		 create_t_angsuranlab();
		 	
		 //insert into t_angsuranlab
		 mysql_query("INSERT INTO t_angsuranlab(nomr,idxdaftar,tglbayar,jambayar,shift,nip,tottariflab,sisabayar)
		 VALUES('".$nomr."',".$idxd.",DATE(NOW()),TIME(NOW()),".$shift.",'".$user."',".$total.",".$kurang.")");
	}
?>