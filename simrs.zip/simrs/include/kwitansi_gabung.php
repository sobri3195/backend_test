<style type="text/css" media="screen">
	#global_print{width:500px;}
	#header{ height:30px; width:100%;}
	#logo_cetak{float:left;}
	#title{float:left; width:400px;}
	#kepada{float:left; width:700px; font-size:7pt;}
	#kepada .headfield{float:left; width:150px;}
	#kepada .childhead{float:left; width:10px;}
	#kepada .field{float:left; width:100px;}
	#kepada .value{float:left; width:200px;}
	#kuitansi{text-align:center; font-size:7pt; font-weight:bold;}
	#no_kuitansi{text-align:left; font-size:7pt;}
	table#table_list{width:100%; font-size:7pt; border-collapse:0; border-spacing:0px;}
	tr th{border-bottom:1px dashed #000; border-top:1px dashed #000;}
	#footer{width:100%; font-size:7pt;}
	#last_line{font-size:7pt; font-style:inherit; width:100%;}
</style>
<style type="text/css" media="print">
	#global_print{width:500px;}
	#header{ height:30px; width:100%;}
	#logo_cetak{float:left;}
	#title{float:left; width:400px;}
	#kepada{float:left; width:700px; font-size:7pt;}
	#kepada .headfield{float:left; width:150px;}
	#kepada .childhead{float:left; width:10px;}
	#kepada .field{float:left; width:100px;}
	#kepada .value{float:left; width:200px;}
	#kuitansi{text-align:center; font-size:7pt; font-weight:bold;}
	#no_kuitansi{text-align:left; font-size:7pt;}
	table#table_list{width:100%; font-size:7pt; border-collapse:0; border-spacing:0px;}
	tr th{border-bottom:1px dashed #000; border-top:1px dashed #000;}
	#footer{width:100%; font-size:7pt;}
	#last_line{font-size:7pt; font-style:inherit; width:100%;}
</style>
<?php 
	session_start();
	include("connect.php");
	include("function.php");
	
	$nomr 	= $_REQUEST['nomr'];
	$start	= $_REQUEST['start'];
	$end 	= $_REQUEST['end'];

    if($start == ""){
        $start  = date('Y/m/d');
    }

    if($end == ""){
        $end    = date('Y/m/d');
    }
	
	$kondisi= " AND a.TANGGAL BETWEEN '".$start."' AND '".$end."'";
	
	$temp_idxd	= '';
	$j 			= 0;
	$totalbiaya	= 0;
	$sql 		= mysql_query("SELECT DISTINCT a.NOBILL, b.NOMR, b.IDXDAFTAR, a.TANGGAL
						   FROM `t_billrajal` AS a 
						   INNER JOIN t_bayarrajal AS b ON a.NOBILL=b.NOBILL  
						   WHERE 1=1 AND b.NOMR='".$nomr."'".$kondisi);
	
	while($data = mysql_fetch_array($sql)){
		if($j == 0){
			$temp_idxd	 	= $data['IDXDAFTAR'];
			$idxdaftar[]	= $data['IDXDAFTAR'];
		}
		else{
			if($temp_idxd != $data['IDXDAFTAR']){
				$temp_idxd 	= $data['IDXDAFTAR'];
				$idxdaftar[]= $data['IDXDAFTAR'];
			}
		}
		$j++;
	}
	
	$sql4 	= mysql_query("SELECT COUNT(*) AS jml 
						   FROM t_pendaftaran 
						   WHERE NOMR='".$_REQUEST['nomr']."' AND TGLREG BETWEEN '".$start."' AND '".$end."'");
	$data4 	= mysql_fetch_array($sql4);
	$jml 	= $data4['jml'];
	
	for($i = 0; $i < $jml; $i++){
		$sql6 	= mysql_query("SELECT NOBILL FROM t_billrajal WHERE NOMR='".$nomr."' AND IDXDAFTAR=".$idxdaftar[$i]);
		$data6 	= mysql_fetch_array($sql6);
		$nobill = $data6['NOBILL'];
		$get 	= mysql_query('SELECT a.nomr AS NOMR, b.NAMA as pasien, a.TGLBAYAR, a.JAMBAYAR, a.TOTCOSTSHARING,a.JMBAYAR, a.UNIT, 
							   c.nama_unit,d.NAMA as carabayar
							   FROM t_bayarrajal a 
							   JOIN m_pasien b ON b.NOMR = a.NOMR 
						       JOIN m_unit c ON c.kode_unit = a.UNIT
							   JOIN m_carabayar d ON d.KODE = a.CARABAYAR 
							   WHERE a.NOMR = "'.$nomr.'" AND a.NOBILL = "'.$nobill.'"');
		$userdata = mysql_fetch_assoc($get);
	
?>
<div style="font-family: 'Lucida Console', Monaco, monospace; font-size: 7pt;">
	<div id="global_print" style="width:580px; padding-left:100px;">
	    <div id="header">
	        <div id="kepada" style="padding-top:10px; font-size:7pt;">
	        	<div class="headfield">Sudah terima dari</div>
	        	<span class="childhead">:</span>
	        	<div class="value">
	        		<?php 
	        			$sql3 	= mysql_query("SELECT PENANGGUNGJAWAB_NAMA 
	        								   FROM t_pendaftaran 
	        								   WHERE NOMR='".$nomr."' AND IDXDAFTAR=".$idxdaftar[$i]);
	        			$data3 	= mysql_fetch_array($sql3);
	        			echo $data3['PENANGGUNGJAWAB_NAMA'];
	        		?>
	        	</div>
	        	<br clear="all" />
	            <div id="kepada2">
	            	<div class="headfield">Untuk Pembayaran</div>
	            	<span class="childhead">:</span>
	            	<div style="float: left;">Biaya Periksa/pengobatan dari pasien:</div>
	            </div>
	            <br clear="all" />
	            <div id="kepada2">
	            	<div class="headfield">&nbsp;</div>
	            	<span class="childhead">&nbsp;</span>
	            	<div class="field">Nama</div>
	            	<span class="childhead">:</span>
	            	<div class="value"><?php echo $userdata['pasien'];?></div>
	            </div>
	            <br clear="all" />
	            <div id="kepada3">
	            	<div class="headfield">&nbsp;</div>
	            	<span class="childhead">&nbsp;</span>
	            	<div class="field">No.DM</div>
	            	<span class="childhead">:</span>
	            	<div class="value"><?php echo $_REQUEST['nomr'];?></div>
	            </div>
	            <br clear="all" />
	            <div id="kepada4">
	            	<div class="headfield">&nbsp;</div>
	            	<span class="childhead">&nbsp;</span>
	            	<div class="field">Tanggal Bayar</div>
	            	<span class="childhead">:</span>
	            	<div class="value"><?php echo $userdata['TGLBAYAR'].' '.$userdata['JAMBAYAR'];?></div>
	            </div>
	            <br clear="all" />
	            <div id="kepada4">
	            	<div class="headfield">&nbsp;</div>
	            	<span class="childhead">&nbsp;</span>
	            	<div class="field">Poli</div>
	            	<span class="childhead">:</span>
	            	<div class="value"><?php echo $userdata['nama_unit'];?></div>
	            </div>
	            <br clear="all" />
	       </div>
	    </div>
	    <br clear="all" />
	    <br/>
	    <div id="kuitansi"></div>
	    <div id="no_kuitansi"> No Transaksi : <?php echo $nobill; ?></div>
	    <table id="table_list">
	    <tr id="header_table"><th style="text-align:left;">Nama Jasa</th><th style="width:40px;">Qty</th><th style="width:80px;">Harga</th><th style="width:100px;">Total</th><th style="width:20px;">&nbsp;</th></tr>
	    <tbody style="height:200px;">
	    <?php
		$sql = mysql_query("SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.qty, b.TARIFRS,c.NAMADOKTER
							FROM m_tarif2012 a, t_billrajal b
							LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
							WHERE a.kode_tindakan=b.KODETARIF 
							AND b.IDXDAFTAR='".$idxdaftar[$i]."'");
		$total	= 0;
		while($data = mysql_fetch_array($sql)){
		$sql1=mysql_query("select b.STATUS from t_billrajal a left join t_bayarrajal b ON b.NOBILL=a.NOBILL where a.KODETARIF='".$data['kode']."'");
		$data1=mysql_fetch_array($sql1);
		if ($data1['STATUS']=='LUNAS'){
		$st="L";}
		else if ($data1['STATUS']=='TRX'){
		$st="-";}
			echo '<tr style="height:10px;"><td>'.$data['nama_jasa'].'</td><td align="center">'.$data['qty'].'</td><td align="right">Rp. '.curformat($data['TARIFRS'],0).'</td><td align="right">Rp. '.curformat($data['TARIFRS'] * $data['qty']).'</td><td align="right">'.$st.'</td></tr>';
			$total	= $total + ( $data['TARIFRS'] * $data['qty']);
		}
		$sql2=mysql_query("SELECT SUM(TOTTARIFRS) as total from t_bayarrajal where IDXDAFTAR='".$_REQUEST['idxdaftar']."' and STATUS='LUNAS'");
		$data2=mysql_fetch_array($sql2);
		$byr=$data2['total'];
		$kurang=$total-$data2['total'];
		if($kurang < 0){
			$byr=$byr+$kurang;
			$kurang=0;
		}
	    ?>
		
	    <tr style="height:auto;"><td colspan="4"></td></tr>
	    </tbody>
		  <tr>
		  	<td style="text-align:left; padding-right:10px; border-top:1px dashed #000;">&nbsp;</td>
		  	<td colspan="2" style="text-align:right; padding-right:0px; border-top:1px dashed #000; font-size:7pt;">Sub Total</td>
		  	<td style="border-top:1px dashed #000; text-align:right;">
		  		Rp. <?php 
		  				echo curformat($total); 
		  				$totalbiaya 	= $totalbiaya + $total;
		  			?>
		  	</td>
		  </tr>
	    <?php if(!empty($userdata['TOTASKES']) > 0){ ?>
	    <?php } ?>
	    <?php if(!empty($userdata['TOTCOSTSHARING']) > 0){ ?>
	    <?php } ?>
	    <?php if( (!empty($userdata['TOTASKES']) > 0) or (!empty($userdata['TOTCOSTSHARING']) > 0) ): ?>
	    <?php endif; ?>
	    <?php 
	    	if($i == ($jml-1)){
	    ?>
	    <tr>
	    	<td colspan="2" style="border-top:1px solid #000;">
	    		Terbilang : <?php echo strtoupper(Terbilang($totalbiaya)); ?>
	    	</td>
	    	<td align="right" style="border-top:1px solid #000;">
	    		TOTAL
	    	</td>
	    	<td align="right" style="border-top:1px solid #000;">
	    		<?php echo "Rp. " . CurFormat($totalbiaya); ?>
	    	</td>
	    	<td style="border-top:1px solid #000;"></td>
	    </tr>
	    <?php
	    	}
	    ?>
	    </table>
	</div>
<?php
	}
?>
	<div id="global_print" style="width:580px; padding-left:100px;">
		<div id="footer">
	    	<br/>
	    	<div id="last_line" style="padding-top: 0px; margin: 0px;"> Dicetak : <?php echo date('d/m/Y H:i:s'); ?></div>
	    	<div id="footer1" style="float:left; width:300px; height:100px;">
	        	<br />
			</div>
	        <div id="footer2" style="float:left; width:280px;">
				<div style="text-align:center; width:100%;">Bagian Keuangan</div>
				<br/><br/><br/>
	            <div style="text-align:center; width:100%;">( Gunadi, SE.AK, M.Si )</div>
	        </div>
	    	<br clear="all" />
	   </div>
	</div>
</div>

<script type="text/javascript">
	window.print();
</script>
