<div align="center">
	<div id="frame">
		<div id="frame_title"><h3>Introduction</h3></div>
			<img src="img/index.png" />
		</div>
	</div>
</div>