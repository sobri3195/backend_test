<?php
/**
 * Created by PhpStorm.
 * User: ISYFALANA
 * Date: 26/08/2015
 * Time: 14:40
 */

include("../include/connect.php");
$sql_ruangan = "SELECT * FROM m_unit ORDER BY nama_unit;" ;
$qry_ruangan = mysql_query($sql_ruangan);

?>

<fieldset class='fieldset' style="width:100%">
    <legend>Obat Ruangan</legend>
    <form action="gudang/obat_ruangan_proses.php" method="post" id="form_barang_ruangan">
        <table>
            <tr>
                <td><label for="ruangan">Ruangan</label></td>
                <td>
                    <select id="ruangan" name="ruangan" style="width: 250px" >
                    <?php
                        while($data = mysql_fetch_array($qry_ruangan)){
                            echo "<option value=\"{$data['kode_unit']}\"> {$data['nama_unit']} </option>";
                        }
                    ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="obat">Obat</label></td>
                <td>
                    <select id="obat"  style="width: 250px">
                        <option></option>
                    </select>
                    <input  id="obat_hidden" type="hidden" name="kode_barang">
                    &nbsp;&nbsp;
                </td>
            </tr>
            <tr>
                <td><label for="harga">Harga</label></td>
                <td>
                    <input type="text" id="harga" name='harga' class="inputku" readonly style="padding-left: 6px; height: 26px; width: 250px" />
                </td>
            </tr>
            <tr>
                <td><label for="persen_untung">Persen Keuntungan</label></td>
                <td>
                    <input type="number" max="100" step="any" id="persen_untung" name='persen_untung' class="inputku"  style="padding-left: 6px; height: 26px; width: 250px"/>
                </td>
            </tr>
            <tr>
                <td><label for="harga_jual">Harga Jual</label></td>
                <td>
                    <input type="number" step="any" id="harga_jual" name='harga_jual' class="inputku"  style="padding-left: 6px; height: 26px; width: 250px"/>
                </td>
            </tr>
            <tr>
                <td><label for="stok_min">Stok Minimal</label></td>
                <td>
                    <input type="number" id="stok_min" name='stok_min' class="inputku"  style="padding-left: 6px; height: 26px; width: 250px"/>
                </td>
            </tr>
            <tr>
                <td><label for="stok_max">Stok Maximal</label></td>
                <td>
                    <input type="number" id="stok_max" name='stok_max' class="inputku"  style="padding-left: 6px; height: 26px; width: 250px"/>
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <br/><input type="submit" id="submitButton"  class="text" value="Simpan"  style="margin-right: 12px; height: 26px; width: 100px; "/>
                    <input type="reset"   class="text" value="Batal"  style="margin-right: 12px; height: 26px; width: 100px; "/>
                </td>
            </tr>
        </table>
    </form>
</fieldset>

<script type="text/javascript">

    jQuery.getScript('include/select2-4.0.0/js/select2.min.js',function(){

        var harga_jual = function(){
            var harga_awal    = jQuery("#harga").val();
            var persen_untung = jQuery("#persen_untung").val();
            var untung        = parseFloat(harga_awal) + parseFloat((persen_untung / 100) * harga_awal);
            jQuery("#harga_jual").val(untung);

        }

        jQuery("#ruangan").select2({
            placeholderOption : "Pilih ruangan"
        });

        jQuery("#ruangan").on("change", function(e){
            jQuery("#obat").val(null).trigger("change");
            jQuery("#harga").val(null);
        });

        jQuery("#obat").select2({
            allowClear: true,
            placeholder: "Pilih Obat",
            ajax: {
                delay: 250,
                url: "gudang/obat_ruangan_proses.php?opt=obat",
                dataType: 'json',
                data: function(params){
                    return {
                        term: params.term,
                        kode_unit: jQuery("#ruangan option:selected").val()
                    };
                },
                processResults: function (data) {
                    return {
                        results: data
                    };
                },
                cache: true
            },
            minimumInputLength: 1
        });

        jQuery("#obat").on("select2:select", function (e) {
            if(e){
                jQuery("#harga").val(e.params.data.harga);
                jQuery("#persen_untung").val(e.params.data.persen_surplus);
                jQuery("#stok_min").val(e.params.data.stok_min);
                jQuery("#stok_max").val(e.params.data.stok_max);
                jQuery("#obat_hidden").val(e.params.data.kode_barang);
                harga_jual();
            }
        });

        jQuery("#obat").on("select2:unselect", function (e) {
            if(e){
                jQuery("#harga").val("");
                jQuery("#persen_untung").val("");
                jQuery("#stok_min").val("");
                jQuery("#stok_max").val("");
            }
        });

        jQuery("#persen_untung").keyup(function(){
            harga_jual();
        });

//        jQuery("#reset_obat").click(function(e){
//            jQuery("#obat").val(null).trigger("change");
//        });


        jQuery("#form_barang_ruangan").submit(function(e){
//            alert("diklik");
            e.preventDefault();
            console.log(e, "Apakah default ", e.isDefaultPrevented());
            jQuery.ajax({
                url: e.currentTarget.action + "?opt=save",
                type: 'post',
                data: jQuery("#form_barang_ruangan").serialize(),
                beforeSend:function(){
                    //alert("Kiiriiim");
                },
                complete: function(){
                    //alert("Compleete");
                },
                success: function(response){
                    jQuery("#addbarang").html(response);
                    console.log(response);
                }
            });
        });


    }); // End of getScript

</script>