<?php
include('settings_farmasi.php');
include('../include/RsudAddressUtility.php');
?>


<div id="supplier_tab">
    <table class="tb">
        <thead>
        <tr align="center">
            <th>ID</th>
            <th>Supplier</th>
            <th>Kontak Person</th>
            <th>Nomor HP</th>
            <th>Alamat</th>
            <th>Kota</th>
            <th>Nomor Telepon</th>
            <th>Nomor Fax</th>
            <th>Term</th>
            <th>Edit</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $i = 1;
        $qry = Settings_Farmasi::get_supplier();
        while($data = mysql_fetch_array($qry)){
            ?>
            <tr class="<?= $i++ % 2 ? 'tr1' : 'tr2'?>">
                <td>
                    <?=$data['id_supplier']?>
                    <input type="hidden" id="id_sup_<?=$data['id_supplier']?>" value="<?=$data['id_supplier']?>" />
                </td>
                <td>
                    <?=$data['supplier'] ?>
                    <input type="hidden" id="sup_<?=$data['id_supplier']?>" value="<?=$data['supplier']?>" />
                </td>
                <td>
                    <?=$data['kontak_person'] ?>
                    <input type="hidden" id="kp_<?=$data['id_supplier']?>" value="<?=$data['kontak_person']?>" />
                </td>
                <td>
                    <?=$data['nomor_kontak_person'] ?>
                    <input type="hidden" id="no_kp_<?=$data['id_supplier']?>" value="<?=$data['nomor_kontak_person']?>" />
                </td>
                <td>
                    <?=$data['alamat'] ?>
                    <input type="hidden" id="almt_sup_<?=$data['id_supplier']?>" value="<?=$data['alamat']?>" />
                </td>
                <td>
                    <?=$data['namakota'] ?>
                    <input type="hidden" id="kota_sup_<?=$data['id_supplier']?>" value="<?=$data['kota']?>" data-kota="<?=$data['namakota'] ?>" />
                </td>
                <td>
                    <?=$data['no_telp'] ?>
                    <input type="hidden" id="no_tlp_sup_<?=$data['id_supplier']?>" value="<?=$data['no_telp']?>" />
                </td>
                <td>
                    <?=$data['no_fax'] ?>
                    <input type="hidden" id="no_fax_sup_<?=$data['id_supplier']?>" value="<?=$data['no_fax']?>" />
                </td>
                <td>
                    <?=$data['term'] ?>
                    <input type="hidden" id="term_<?=$data['id_supplier']?>" value="<?=$data['term']?>" />
                </td>

                <td>
                    <button class="button edit-supplier"   id="edit_<?=$data['id_supplier']?>"   >Edit</button>
                    <button class="button delete-supplier" id="delete_<?=$data['id_supplier']?>" >Hapus</button>
                </td>
            </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
    <br/>
    <button class="add-supplier" data-kategori="supplier">Tambah Supplier</button>
</div>

<!--Modal supplier -->
<div id="dialog-form-supplier" >
    <p class="validateTipsSupplier">Harap isi semua field yang dibutuhkan..</p>

    <form method="post">
        <fieldset>
            <label for="id_supplier">Id supplier</label>
            <input type="text" name="id" id="id_supplier" placeholder="Terisi otomatis..." class="text ui-widget-content ui-corner-all">

            <label for="supplier" id="lbl_supplier">Supplier</label>
            <input type="text" name="supplier" id="supplier" placeholder="Nama supplier" autofocus class="text ui-widget-content ui-corner-all">

            <label for="kontak" id="lbl_kontak">Kontak Person</label>
            <input type="text" name="kontak" id="kontak" placeholder="Kontak person" class="text ui-widget-content ui-corner-all">

            <label for="no_hp" id="lbl_no_hp">Nomor HP</label>
            <input type="text" name="no_hp" id="no_hp" placeholder="Nomor HP" class="text ui-widget-content ui-corner-all">

            <label for="alamat_sup" id="lbl_alamat">Alamat</label>
            <textarea id="alamat_sup" name="alamat" placeholder="Alamat" class="text ui-widget-content ui-corner-all"></textarea>

            <label for="kota" id="lbl_kota">Kota</label>
<!--            <input type="text" name="kota" id="kota" placeholder="Kota" class="text ui-widget-content ui-corner-all">-->
            <select name="kota" id="kota" placeholder="Kota" class="select2 text ui-widget-content ui-corner-all">
            </select>

            <label for="nomor_telepon" id="lbl_nomor_telepon" style="margin-top: 12px">Nomor Telepon</label>
            <input type="text" name="nomor_telepon" id="nomor_telepon" placeholder="Nomor telepon" class="text ui-widget-content ui-corner-all">

            <label for="fax" id="lbl_fax">Nomor Fax</label>
            <input type="text" name="fax" id="fax" placeholder="Nomor fax" class="text ui-widget-content ui-corner-all">

            <label for="term" id="lbl_term">Term</label>
            <input type="text" name="term" id="term" placeholder="Term" class="text ui-widget-content ui-corner-all">

        </fieldset>
    </form>
</div>

<!--Modal confirm delete supplier-->
<div id="dialog-delete-confirm-supplier" title="Yakin untuk menghapus data ini?">
    <p>
        <span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        Data yang akan Anda hapus yaitu: [<span id="del_id_supplier"></span>] <span id="del_supplier"></span>.
    </p>
    <form method="post">
        <input type="hidden" name="id" id="id_supplier_to_del" />
    </form>
</div>


<script type="text/javascript">
    var url = "gudang/settings_farmasi.php?m=" ;
    // CSS
    jQuery("input, label").css({display: 'block'});
    jQuery("input.text").css({marginBottom:'12px',width: '95%',padding: '.4em'});
    jQuery("textarea").css({marginBottom:'12px',width: '95%',padding: '.4em'});
    jQuery("fieldset").css({padding:'0',border:'0', marginTop:'25px'});
    jQuery(".select2").css({marginBottom:'12px',width:"97%",padding: '.4em'});

//    jQuery("#kota").select2();

    jQuery(".add-supplier").button({icons: {primary: "ui-icon-circle-plus"}}).click(function(){
        setDialogSupplierFields("","","","","","","","","");
        jQuery("#kota").html("").trigger("change");
        jQuery("#dialog-form-supplier").find("form").attr("action", url + "insert_supplier");
        jQuery("#dialog-form-supplier").dialog({title: "Edit Data Supplier"}).dialog("open");
    });

    jQuery(".edit-supplier").button({icons: {primary: "ui-icon-pencil"}}).click(function(){
        var id = this.id.substr(5);
        setDialogSupplierFields(
            id,
            jQuery("#sup_"+id).val(),
            jQuery("#kp_"+id).val(),
            jQuery("#no_kp_"+id).val(),
            jQuery("#almt_sup_"+id).val(),
            jQuery("#no_tlp_sup_"+id).val(),
            jQuery("#no_fax_sup_"+id).val(),
            jQuery("#term_"+id).val()
        );
        var nama_kota = jQuery("#kota_sup_"+id).attr("data-kota");
        jQuery("#kota").html("<option value='"+jQuery("#kota_sup_"+id).val()+"'>" + nama_kota + "</option>").trigger("change");

        jQuery("#dialog-form-supplier").find("form").attr("action", url + "update_supplier");
        jQuery("#dialog-form-supplier").dialog({title: "Edit Data Supplier"}).dialog("open");
    });

    jQuery(".delete-supplier").button({icons: {primary: "ui-icon-trash"}}).click(function(){
        var id = this.id.substr(7);
        jQuery("#del_id_supplier").html(id);
        jQuery("#del_supplier").html(jQuery("#sup_"+id).val());
        jQuery("#id_supplier_to_del").val(id);
        jQuery("#dialog-delete-confirm-supplier").find("form").attr("action", url + "delete_supplier");
        jQuery("#dialog-delete-confirm-supplier").dialog("open");
    });

    jQuery("#dialog-form-supplier").dialog({
        autoOpen: false,
        height  : 620,
        width   : 600,
        modal   : true,
        show: {
            effect: "clip",
            duration: 140
        },
        buttons: {
            Simpan: function(){
                // Send form
                clearError();
                sendFormDataSupplier();
            },
            Batal: function() {
                jQuery(this).dialog("close");
            }
        },
        close: function() {
            jQuery(".validateTipsSupplier").html("Harap isi semua field yang dibutuhkan..");
        },
        open: function(event, ui){
            var input  = jQuery("#supplier");
            var length = jQuery("#supplier").val().length;
            input[0].focus();
            input[0].setSelectionRange(length, length);
        }
    });

    jQuery("#dialog-delete-confirm-supplier").dialog({
        autoOpen: false,
        height: 140,
        width: 350,
        modal: true,
        buttons: {
            Hapus: function() {
                jQuery("#dialog-delete-confirm-supplier").find("form").submit();
            },
            Batal: function() {
                jQuery( this ).dialog( "close" );
            }
        }
    });

    function setDialogSupplierFields(id, sup, kp, no_hp, alamat, nomor_telepon, fax, term){
        jQuery("#id_supplier").val(id).removeClass("ui-state-error");
        jQuery("#supplier").val(sup).removeClass("ui-state-error");
        jQuery("#kontak").val(kp).removeClass("ui-state-error");
        jQuery("#no_hp").val(no_hp).removeClass("ui-state-error");
        jQuery("#alamat_sup").val(alamat).removeClass("ui-state-error");
        jQuery("#nomor_telepon").val(nomor_telepon).removeClass("ui-state-error");
        jQuery("#fax").val(fax).removeClass("ui-state-error");
        jQuery("#term").val(term).removeClass("ui-state-error");
        jQuery("#id_supplier").attr("readonly", "readonly");
    }

    function clearError(){
        jQuery("#id_supplier").removeClass("ui-state-error");
        jQuery("#supplier").removeClass("ui-state-error");
        jQuery("#kontak").removeClass("ui-state-error");
        jQuery("#no_hp").removeClass("ui-state-error");
        jQuery("#alamat_sup").removeClass("ui-state-error");
        jQuery("#nomor_telepon").removeClass("ui-state-error");
        jQuery("#fax").removeClass("ui-state-error");
        jQuery("#term").removeClass("ui-state-error");
    }

    jQuery("#kota").select2({
        allowClear: true,
        placeholder: "Ketikkan nama kota..",
        ajax: {
            type: 'post',
            url: url + "getJsonKota",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    nama_kota: params.term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });

    function updateTipsSupplier( t ){
        jQuery(".validateTipsSupplier").text( t ).addClass( "ui-state-highlight" );
        setTimeout(function(){
            jQuery(".validateTipsSupplier").removeClass( "ui-state-highlight", 1500 );
        }, 500 );
    }

    function checkLengthSupplier( o, n, min, max ) {
        if ( o.val().length > max || o.val().length < min ) {
            o.addClass( "ui-state-error" );
            updateTipsSupplier( "Panjang dari " + n.toLowerCase() + " harus diantara " + min + " dan " + max + "." );
            return false;
        } else {
            return true;
        }
    }

    function validateFormSupplier(){
        var valid = true;
        valid = valid && checkLengthSupplier(jQuery("#supplier"), jQuery("#lbl_supplier").html(), 3, 22);
        valid = valid && checkLengthSupplier(jQuery("#kontak"), jQuery("#lbl_kontak").html(), 3, 12);
        valid = valid && checkLengthSupplier(jQuery("#no_hp"), jQuery("#lbl_no_hp").html(), 12, 12);
        valid = valid && checkLengthSupplier(jQuery("#alamat_sup"), jQuery("#lbl_alamat").html(), 3, 1200);
        valid = valid && checkLengthSupplier(jQuery("#nomor_telepon"), jQuery("#lbl_nomor_telepon").html(), 12, 12);
        valid = valid && checkLengthSupplier(jQuery("#fax"), jQuery("#lbl_fax").html(), 12, 12);
        valid = valid && checkLengthSupplier(jQuery("#term"), jQuery("#lbl_term").html(), 1, 3);
        return valid;
    }

    function sendFormDataSupplier(){
        if(validateFormSupplier()){
            console.log("->form valid");
            jQuery("#dialog-form-supplier").find("form").submit();
        }
    }

</script>