<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>REKAP TAHUNAN</h3></div>
        <div align="left" style="margin:5px;">
            <fieldset >
                <form name="filterlap" id="filterlap" method="get" >
                    <input type="hidden" name="link" value="g05" />
                    <table class="tb" align="left">
                        <tr>
                            <?php  $akhtahun = date('Y') - 20; $c = date('Y'); ?>
                            <td>Tahun</td>
                            <td><select name="tahun" id="tahun" class="text" >
                                    <? while($akhtahun <= $c) { ?>
                                        <option value="<?=$akhtahun?>" <?= ($akhtahun == $c) ?"selected=selected" :""; ?>><?=$akhtahun++?></option>
                                    <? } ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Group Barang</td>
                            <td>
                                <?php include('include/RsudUtility.php'); RsudUtility::printOptionGroupBarang($_SESSION['KDUNIT']);?>
                                <input type="hidden" name="farmasi" id="farmasi" value="<?= $_SESSION['KDUNIT']=="12" ? '1' : '0'?>" />
                            </td>
                        </tr>
                        <tr>
                            <td>Nama Barang</td>
                            <td>
<!--                                <input type="text" name="nm_barang" class="text" />-->
                                <select id="nm_barang" name="nm_barang" >
                                    <option></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td><input type="submit" value="Open" class="text" /></td>
                        </tr>
                    </table>
                </form>
            </fieldset >
        </div>
    </div>
</div>


<script>
    jQuery(document).ready(function(){
        // Atur tampilan
        jQuery("#nm_barang").css({paddingLeft: '6px', height: '18px', width: '250px'});
        jQuery("#tahun").css(    {paddingLeft: '6px', height: '21px', width: '250px'}).select2();
        jQuery("#group").css(    {paddingLeft: '6px', height: '21px', width: '250px'}).select2();

        // Autcomplete nama barang
        jQuery("#nm_barang").select2({
            ajax: {
                url     : 'include/RsudUtility.php',
                dataType: 'json',
                delay   : 250,
                cache: true,
                data: function(params){
                    return {
                        nama_barang: params.term,
                        grpbarang  : jQuery("#group option:selected").val(),
                        optFarmasi: jQuery("#farmasi").val(),
                        function   : 'getAjaxBarang'
                    };
                },
                processResults: function(data){
                    return {
                        results: jQuery.map(data, function(item){
                            item.id = item.text;
                            return item;
                        })
                    };
                }
            },
            minimumInputLength: 1,
            allowClear: true,
            placeholder: 'Masukan nama barang. (Optional)'
        });
    });
</script>