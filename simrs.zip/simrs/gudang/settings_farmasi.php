<?php

    class Settings_Farmasi{
        public static final function index(){
            session_start();
            include('setting_farmasi_view.php');
            if(isset($_SESSION['settings_farmasi_notif'])){
                unset($_SESSION['settings_farmasi_notif']);
            }
        }

        // Group Barang
        public static final function get_group_barang(){
            include_once("../include/connect.php");
            $sql = "SELECT * FROM simrs.m_barang_group WHERE farmasi=1;";
            return mysql_query($sql);
        }
        public static final function insert_group_barang($params){
            include_once("../include/connect.php");
            $jenis    = "";
            extract($params);
            $jenis   = mysql_real_escape_string($jenis);
            $sql     = "SELECT (MAX(group_barang) + 1) as id FROM m_barang_group WHERE farmasi=1";
            $rs      = mysql_query($sql);
            $next_id = mysql_fetch_array($rs);
            $sql = "INSERT INTO m_barang_group(group_barang, farmasi, nama_group, nama_farmasi) " .
                   "VALUES('{$next_id['id']}', 1, '{$jenis}', 'Gudang Farmasi');";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah disimpan.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal disimpan.";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#group_barang") ;
        }
        public static final function update_group_barang($params){
            include_once("../include/connect.php");
            $id    = "";
            $jenis = "";
            extract($params);
            $id    = mysql_real_escape_string($id);
            $jenis = mysql_real_escape_string($jenis);
            $sql   = "UPDATE m_barang_group SET nama_group='{$jenis}' WHERE group_barang='{$id}' AND farmasi=1;";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah diubah.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal diubah";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#group_barang") ;
        }
        public static final function delete_group_barang($params){
            include_once("../include/connect.php");
            $id  = "";
            extract($params);
            $id  = mysql_real_escape_string($id);
            $sql = "DELETE FROM m_barang_group WHERE group_barang='{$id}' AND farmasi=1;";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah dihapus.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal dihapus";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#group_barang") ;
        }

        // Jenis Obat
        public static final function get_jenis_obat(){
            include_once("../include/connect.php");
            $sql = "SELECT * FROM simrs.m_far_jenis_barang;";
            return mysql_query($sql);
        }
        public static final function insert_jenis_obat($params){
            include_once("../include/connect.php");
            $jenis    = "";
            extract($params);

            $jenis    = mysql_real_escape_string($jenis);

            $sql = "INSERT INTO m_far_jenis_barang(jenis) VALUE ('{$jenis}') ;";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah disimpan.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal disimpan.";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#jenis_obat");
        }
        public static final function update_jenis_obat($params){
            include_once("../include/connect.php");
            $id     = "";
            $jenis  = "";
            extract($params);
            $id     = mysql_real_escape_string($id);
            $jenis  = mysql_real_escape_string($jenis);
            $sql    = "UPDATE m_far_jenis_barang SET jenis='{$jenis}' WHERE id_jenis='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah diubah.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal diubah";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#jenis_obat");
        }
        public static final function delete_jenis_obat($params){
            include_once("../include/connect.php");
            $id  = "";
            extract($params);
            $id  = mysql_real_escape_string($id);
            $sql = "DELETE FROM m_far_jenis_barang WHERE id_jenis='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah dihapus.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal dihapus";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#jenis_obat");
        }

        //Satuan Barang
        public static final function get_satuan_barang(){
            include_once("../include/connect.php");
            $sql_satuan_barang = "SELECT * FROM m_far_satuan_barang;" ;
            $query_satuan_barang = mysql_query($sql_satuan_barang) or die(mysql_error());
            return $query_satuan_barang;
        }
        public static final function insert_satuan_barang($params){
            include_once("../include/connect.php");
            $jenis    = "";
            extract($params);
            $jenis    = mysql_real_escape_string($jenis);
            $sql = "INSERT INTO m_far_satuan_barang(satuan) VALUE ('{$jenis}') ;";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah disimpan.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal disimpan.";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#satuan_barang");
        }
        public static final function update_satuan_barang($params){
            include_once("../include/connect.php");
            $id     = "";
            $jenis  = "";
            extract($params);
            $id     = mysql_real_escape_string($id);
            $jenis  = mysql_real_escape_string($jenis);
            $sql    = "UPDATE m_far_satuan_barang SET satuan='{$jenis}' WHERE id_satuan='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah diubah.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal diubah";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#satuan_barang");
        }
        public static final function delete_satuan_barang($params){
            include_once("../include/connect.php");
            $id  = "";
            extract($params);
            $id  = mysql_real_escape_string($id);
            $sql = "DELETE FROM m_far_satuan_barang WHERE id_satuan='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah dihapus.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal dihapus";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#satuan_barang");
        }

        // Golongan Barang
        public static final function get_golongan_barang(){
            include_once("../include/connect.php");
            $sql = "SELECT * FROM simrs.m_far_golongan_barang;";
            return mysql_query($sql);
        }
        public static final function insert_golongan_barang($params){
            include_once("../include/connect.php");
            $jenis    = "";
            extract($params);
            $jenis    = mysql_real_escape_string($jenis);
            $sql = "INSERT INTO m_far_golongan_barang(golongan) VALUE ('{$jenis}') ;";
            mysql_query($sql);
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#golongan_obat");
        }
        public static final function update_golongan_barang($params){
            include_once("../include/connect.php");
            $id = "";
            $jenis    = "";
            extract($params);
            $id = mysql_real_escape_string($id);
            $jenis    = mysql_real_escape_string($jenis);
            $sql = "UPDATE m_far_golongan_barang SET golongan='{$jenis}' WHERE id_golongan='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah diubah.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal diubah";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#golongan_obat");
        }
        public static final function delete_golongan_barang($params){
            include_once("../include/connect.php");
            $id   = "";
            extract($params);
            $id   = mysql_real_escape_string($id);
            $sql  = "DELETE FROM m_far_golongan_barang WHERE id_golongan='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah dihapus.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal dihapus";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#golongan_obat");
        }

        // Kemasan Obat
        public static final function get_kemasan_obat(){
            include_once("../include/connect.php");
            $sql = "SELECT * FROM simrs.m_far_kemasan_barang;";
            return mysql_query($sql);
        }
        public static final function insert_kemasan_obat($params){
            include_once("../include/connect.php");
            $jenis  = "";
            extract($params);
            $jenis  = mysql_real_escape_string($jenis);
            $sql    = "INSERT INTO m_far_kemasan_barang(kemasan) VALUE ('{$jenis}') ;";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah disimpan.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal disimpan.";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#kemasan_barang");
        }
        public static final function update_kemasan_obat($params){
            include_once("../include/connect.php");
            $id     = "";
            $jenis  = "";
            extract($params);
            $id     = mysql_real_escape_string($id);
            $jenis  = mysql_real_escape_string($jenis);
            $sql    = "UPDATE m_far_kemasan_barang SET kemasan='{$jenis}' WHERE id_kemasan='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah diubah.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal diubah";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#kemasan_barang");
        }
        public static final function delete_kemasan_obat($params){
            include_once("../include/connect.php");
            $id   = "";
            extract($params);
            $id   = mysql_real_escape_string($id);
            $sql  = "DELETE FROM m_far_kemasan_barang WHERE id_kemasan='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah dihapus.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal dihapus";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#kemasan_barang");
        }

        // Kelas Theraphy
        public static final function get_kelas_therapy(){
            include_once("../include/connect.php");
            $sql = "SELECT * FROM simrs.m_far_kelas_therapy;";
            return mysql_query($sql);
        }
        public static final function insert_kelas_therapy($params){
            include_once("../include/connect.php");
            $jenis  = "";
            extract($params);
            $jenis  = mysql_real_escape_string($jenis);
            $sql    = "INSERT INTO m_far_kelas_therapy(kelas_therapy) VALUE ('{$jenis}') ;";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data kelas terapi baru telah ditambahkan";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal tersimpan";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#kelas_therapy");
        }
        public static final function update_kelas_therapy($params){
            include_once("../include/connect.php");
            $id     = "";
            $jenis  = "";
            extract($params);
            $id     = mysql_real_escape_string($id);
            $jenis  = mysql_real_escape_string($jenis);
            $sql    = "UPDATE m_far_kelas_therapy SET kelas_therapy='{$jenis}' WHERE id_kelas_therapy='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah diubah.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal diubah";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#kelas_therapy");
        }
        public static final function delete_kelas_therapy($params){
            include_once("../include/connect.php");
            $id   = "";
            extract($params);
            $id   = mysql_real_escape_string($id);
            $sql  = "DELETE FROM m_far_kelas_therapy WHERE id_kelas_therapy='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah dihapus";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal dihapus";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#kelas_therapy");
        }

        // Principal
        public static final function get_principal(){
            include_once("../include/connect.php");
            $sql = "SELECT m_far_principal.*, m_negara.negara as nama_negara FROM simrs.m_far_principal INNER JOIN m_negara ON m_far_principal.negara=m_negara.id_negara;";
            return mysql_query($sql);
        }
        public static final function insert_principal($params){
            include_once("../include/connect.php");
            $id        = "";
            $principal = "";
            $alamat    = "";
            $negara    = "";
            extract($params);
            $id        = mysql_real_escape_string($id);
            $principal = mysql_real_escape_string($principal);
            $alamat    = mysql_real_escape_string($alamat);
            $negara    = mysql_real_escape_string($negara);
            $sql       = "INSERT INTO m_far_principal(principal, alamat, negara) " .
                         "VALUES('{$principal}', '{$alamat}', '{$negara}');";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah disimpan.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal disimpan.";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#principal");
        }
        public static final function update_principal($params){
            include_once("../include/connect.php");
            $str_update= "";
            $id        = "";
            $principal = "";
            $alamat    = "";
            $negara    = "";
            extract($params);

            $id        = mysql_real_escape_string($id);
            $principal = mysql_real_escape_string($principal);
            $alamat    = mysql_real_escape_string($alamat);
            $negara    = mysql_real_escape_string($negara);

            if(!empty($principal)){
                $str_update .= " principal='{$principal}' ";
            }
            if(!empty($alamat)){
                if(!empty($str_update)){
                    $str_update .= ", alamat='{$alamat}' ";
                }else{
                    $str_update .= " alamat='{$alamat}' ";
                }
            }
            if(!empty($negara)){
                if(!empty($str_update)){
                    $str_update .= ", negara='{$negara}' ";
                }else{
                    $str_update .= " negara='{$negara}' ";
                }
            }

            $sql       = "UPDATE m_far_principal SET " .$str_update ." WHERE id_principal='{$id}'";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah diubah.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal diubah";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#principal");
        }
        public static final function delete_principal($params){
            include_once("../include/connect.php");
            $id   = "";
            extract($params);
            $id   = mysql_real_escape_string($id);
            $sql  = "DELETE FROM m_far_principal WHERE id_principal='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah dihapus";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal dihapus";
            }
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#principal");
        }

        // Supplier
        public static final function get_supplier(){
            include_once("../include/connect.php");
            $sql = "SELECT m_far_supplier.*, m_kota.namakota FROM m_far_supplier LEFT JOIN m_kota ON m_far_supplier.kota = m_kota.idkota;";
            return mysql_query($sql);
        }
        public static final function insert_supplier($params){
            include_once("../include/connect.php");
            $id        = "";
            $supplier  = "";
            $kontak    = "";
            $no_hp     = "";
            $alamat    = "";
            $kota      = "";
            $nomor_telepon = "";
            $fax       = "";
            $term      = "";
            extract($params);
            $id        = mysql_real_escape_string($id);
            $supplier  = mysql_real_escape_string($supplier);
            $kontak    = mysql_real_escape_string($kontak);
            $no_hp     = mysql_real_escape_string($no_hp);
            $alamat    = mysql_real_escape_string($alamat);
            $kota      = mysql_real_escape_string($kota);
            $nomor_telepon = mysql_real_escape_string($nomor_telepon);
            $fax       = mysql_real_escape_string($fax);
            $term      = mysql_real_escape_string($term);

            $sql       = "INSERT INTO m_far_supplier(supplier, kontak_person, nomor_kontak_person, alamat, kota, no_telp, no_fax, term) " .
                         " VALUES('{$supplier}', '{$kontak}', '{$no_hp}', '{$alamat}', '{$kota}', '{$nomor_telepon}', '{$fax}', '{$term}'); ";

            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah disimpan.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal disimpan.";
            }
            $_SESSION['tab_active'] = 7;
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#supplier");
        }
        public static final function update_supplier($params){
            include_once("../include/connect.php");
            $id        = "";
            $supplier  = "";
            $kontak    = "";
            $no_hp     = "";
            $alamat    = "";
            $kota      = "";
            $nomor_telepon = "";
            $fax       = "";
            $term      = "";
            extract($params);
            $id        = mysql_real_escape_string($id);
            $supplier  = mysql_real_escape_string($supplier);
            $kontak    = mysql_real_escape_string($kontak);
            $no_hp     = mysql_real_escape_string($no_hp);
            $alamat    = mysql_real_escape_string($alamat);
            $kota      = mysql_real_escape_string($kota);
            $nomor_telepon = mysql_real_escape_string($nomor_telepon);
            $fax       = mysql_real_escape_string($fax);
            $term      = mysql_real_escape_string($term);

            $sql       = "UPDATE m_far_supplier SET supplier='{$supplier}', kontak_person='{$kontak}', nomor_kontak_person='{$no_hp}',
                          alamat='{$alamat}', kota='{$kota}', no_telp='{$nomor_telepon}', no_fax='{$fax}', term='{$term}'
                          WHERE id_supplier='{$id}'; ";

            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah disimpan.";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal disimpan.";
            }
//            echo $sql;
            $_SESSION['tab_active'] = 7;
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#supplier");
        }
        public static final function delete_supplier($params){
            include_once("../include/connect.php");
            $id   = "";
            extract($params);
            $id   = mysql_real_escape_string($id);
            $sql  = "DELETE FROM m_far_supplier WHERE id_supplier='{$id}';";
            mysql_query($sql);
            session_start();
            if(mysql_affected_rows() > 0){
                $_SESSION['settings_farmasi_notif'] = "Data telah dihapus";
            }else{
                $_SESSION['settings_farmasi_notif'] = "Data gagal dihapus";
            }
            $_SESSION['tab_active'] = 7;
            header('Location: ' . $_SERVER['HTTP_REFERER'] . "#supplier");
        }

        //JSON
        public static final function getJsonKota($params){
            include_once('../include/RsudAddressUtility.php');
            RsudAddressUtility::getJsonKota($params);
        }

    }

if($_SERVER['REQUEST_METHOD'] == 'GET' && !isset($_GET['m'])){
    Settings_Farmasi::index();
}else if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['m'])){
    Settings_Farmasi::$_GET['m']($_POST);
}
