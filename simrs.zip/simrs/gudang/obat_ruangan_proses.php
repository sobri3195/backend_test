<?php
/**
 * Created by PhpStorm.
 * User: ISYFALANA
 * Date: 26/08/2015
 * Time: 14:51
 */

include("../include/connect.php");

if($_GET["opt"] == "obat"){
    if(isset($_GET['term'])){
        $kode_unit   = $_GET['kode_unit'];
        $sql_obat    = "SELECT m_barang_unit.KDUNIT, m_barang_unit.kode_barang, m_barang.nama_barang, m_barang.harga,
                                m_barang_ruangan.persen_surplus, m_barang_ruangan.stok_min, m_barang_ruangan.stok_max
                        FROM m_barang_unit INNER JOIN m_barang ON (m_barang_unit.kode_barang = m_barang.kode_barang)
                             LEFT JOIN m_barang_ruangan
                             ON (m_barang_unit.KDUNIT = m_barang_ruangan.kode_unit AND m_barang_unit.kode_barang = m_barang_ruangan.kode_barang)
                        WHERE m_barang.farmasi=1 AND m_barang_unit.KDUNIT = ". $kode_unit." AND m_barang.nama_barang LIKE '".
                        trim(strip_tags($_GET['term']))."%'";
        $qry_obat   = mysql_query($sql_obat);
        $matches = array();
        while($row = mysql_fetch_array($qry_obat)){
            $row['id']   = $row["nama_barang"];
            $row['text'] = "{$row['nama_barang']} [{$row['kode_barang']}] " . $row['harga'];
            $matches[] = $row;
        }
        $matches = array_slice($matches, 0, 10);
        print json_encode($matches);
    }
}

if($_GET['opt'] == "save"){
//    var_dump($_POST);
    $sql_barang_ruangan = "REPLACE INTO m_barang_ruangan( kode_unit, kode_barang, persen_surplus, stok_min, stok_max)
                           VALUES ( {$_POST['ruangan']}, {$_POST['kode_barang']}, {$_POST['persen_untung']},
                           {$_POST['stok_min']}, {$_POST['stok_max']})";
    $result = mysql_query($sql_barang_ruangan);
    if(mysql_affected_rows() > 0 ){
        echo "<fieldset class='fieldset' style=\"width:100%; height: 50%;\">" ;
        echo "<legend>Obat Ruangan</legend>";
        echo "<p ><h3 style=\"color: #000000;\">Data berhasil disimpan..</h3></p>";
        echo "</fieldset>";
    }else{
        echo "<fieldset class='fieldset' style=\"width:100%; height: 50%;\">" ;
        echo "<legend>Obat Ruangan</legend>";
        echo "<p ><h3 style=\"color: red;\">Data GAGAL disimpan..</h3></p>";
        echo "</fieldset>";
    }
//    echo "<br/>" .$sql_barang_ruangan;
}

