<?php
$sqlunit = "SELECT 
  			distinct m_login.DEPARTEMEN,
  			m_login.KDUNIT
			FROM m_login
			WHERE KDUNIT <> 0 ORDER BY DEPARTEMEN ";
$qry_unit = mysql_query($sqlunit);			
?>
<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>LAPORAN STOK UNIT</h3></div>
        <div align="left" style="margin:5px;">
<fieldset >
<form name="filterlap" id="filterlap" method="get" >
<input type="hidden" name="link" value="g06" />
<input type="hidden" name="farmasi" id="farmasi" value="<?= $_SESSION['KDUNIT']=="12" ? '1' : '0'?>" />
<table class="tb" align="left">
  </tr>
       <tr>
          <td>Unit&nbsp;</td>
          <td>
          <select name="unit" id="unit" class="text" style="width: 260px" >
          <? while($unitx = mysql_fetch_array($qry_unit)) {?>
            <option value="<?=$unitx['KDUNIT']?>" ><?=ucwords(strtolower($unitx['DEPARTEMEN']))?></option>
		  <? } ?>
          </select>
          </td>
       </tr>

 <tr>
<?php
 $m = date('m');
?>
  
   <td>Bulan</td>
   <td><select name="bulan" id="bulan" class="text" style="width: 100%" >
   <option value="1"  <?= ($m == "1")? "selected" : "";?> >Januari</option>
   <option value="2"  <?= ($m == "2")? "selected" : "";?> >Pebruari</option>
   <option value="3"  <?= ($m == "3")? "selected" : "";?> >Maret</option>
   <option value="4"  <?= ($m == "4")? "selected" : "";?> >April</option>
   <option value="5"  <?= ($m == "5")? "selected" : "";?> >Mei</option>
   <option value="6"  <?= ($m == "6")? "selected" : "";?> >Juni</option>
   <option value="7"  <?= ($m == "7")? "selected" : "";?> >Juli</option>
   <option value="8"  <?= ($m == "8")? "selected" : "";?> >Agustus</option>
   <option value="9"  <?= ($m == "9")? "selected" : "";?> >September</option>
   <option value="10" <?= ($m == "10")? "selected": "";?> >Oktober</option>
   <option value="11" <?= ($m == "11")? "selected": "";?> >Nopember</option>
   <option value="12" <?= ($m == "12")? "selected": "";?> >Desember</option>
   </select></td>
 </tr>
  <tr>
 <?php
  $akhtahun = date('Y') - 20;
  $c        = date('Y');
 ?>
   <td><label for="tahun">Tahun</td>
   <td><select name="tahun" id="tahun" class="text" style="width: 100%" >
 <? while(++$akhtahun <= $c){ ?>
   <option value="<?=$akhtahun?>" <? echo ($akhtahun == $c)? "selected" : ""; ?> ><?=$akhtahun?></option>
 <? } ?>
   </select></td>
 </tr>
 <tr>
   <td><label for="group">Group Barang<label></label></td>
   <td><?php include('include/RsudUtility.php'); RsudUtility::printOptionGroupBarang($_SESSION['KDUNIT']);?></td>
 </tr>
 <tr>
   <td><label for="nm_barang">Nama Barang</label></td>
   <td>
<!--       <input type="text" name="nm_barang" id="nm_barang" class="text" style="width: 95%; height: 18px; padding-left: 6px;" />-->
       <select id="nm_barang" name="nm_barang" style="width: 260px; height: 18px; padding-left: 6px;" >
           <option></option>
       </select>
   </td>
 </tr>
  <tr>
   <td>&nbsp;</td>
   <td><br/><input type="submit" value="Open" class="text" /></td>
 </tr>
</table>
</form>
</fieldset >
</div></div>
</div>
<script>
    jQuery("#unit").select2();
    jQuery("#tahun").select2();
    jQuery("#bulan").select2();
    jQuery("#group").select2();
    jQuery("#nm_barang").select2({
        ajax: {
            url     : 'include/RsudUtility.php',
            dataType: 'json',
            delay   : 250,
            cache: true,
            data: function(params){
                return {
                    nama_barang: params.term,
                    grpbarang  : jQuery("#group option:selected").val(),
                    optFarmasi: jQuery("#farmasi").val(),
                    function   : 'getAjaxBarang'
                };
            },
            processResults: function(data){
                return {
                    results: jQuery.map(data, function(item){
                        item.id = item.text;
                        return item;
                    })
                };
            }
        },
        minimumInputLength: 1,
        allowClear: true,
        placeholder: 'Masukan nama barang. (Optional)'
    });
</script>