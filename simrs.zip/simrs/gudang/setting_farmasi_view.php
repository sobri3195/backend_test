<?php //include('settings_farmasi.php'); ?>

<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>PENGATURAN</h3></div>
        <div align="left" style="margin:5px;">

            <div id="settings_tabs" >
                <ul>
                    <li><a href="#group_barang">Kelompok / Group Barang</a></li>
                    <li><a href="#jenis_obat">Jenis Obat</a></li>
                    <li><a href="#golongan_obat">Golongan Obat</a></li>
                    <li><a href="#satuan_barang">Satuan Barang</a></li>
                    <li><a href="#kemasan_barang">Kemasan Obat</a></li>
                    <li><a href="#kelas_therapy">Kelas Therapy</a></li>
                    <li><a href="gudang/settings_farmasi_view_principal.php?m=get_principal">Principal</a></li>
                    <li><a href="gudang/settings_farmasi_view_supplier.php?m=get_supplier">Supplier</a></li>
                </ul>

                <div id="group_barang" >
                    <table class="tb">
                        <thead>
                        <tr align="center">
                            <th>ID Group</th>
                            <th width="180px">Group Barang</th>
                            <th>Edit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 1;
                        $qry = Settings_Farmasi::get_group_barang();
                        while($data = mysql_fetch_array($qry)){
                            ?>
                            <tr class="<?= $i++ % 2 ? 'tr1' : 'tr2'?>">
                                <td><?=$data['group_barang']?></td>
                                <td><?=$data['nama_group'] ?> </td>
                                <td>
                                    <div class="ui-widget-header ui-corner-all">
                                        <button class="button edit"   data-kategori="group" id="edit_<?=$data['group_barang']?>"   data-nya="<?=$data['nama_group']?>">Edit</button>
                                        <button class="button delete" data-kategori="group" id="delete_<?=$data['group_barang']?>" data-nya="<?=$data['nama_group']?>">Hapus</button>
                                    </div>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                    </table>
                    <br/>
                    <button class="add" data-kategori="group">Tambah Group Barang</button>
                </div>

                <div id="jenis_obat" >
                    <table class="tb">
                        <thead>
                            <tr align="center">
                                <th>ID</th>
                                <th width="180px">Jenis Obat</th>
                                <th>Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $i = 1;
                            $qry = Settings_Farmasi::get_jenis_obat();
                            while($data = mysql_fetch_array($qry)){
                        ?>
                                <tr class="<?= $i++ % 2 ? 'tr1' : 'tr2'?>">
                                    <td><?=$data['id_jenis']?></td>
                                    <td><?=$data['jenis'] ?> </td>
                                    <td>
                                        <div class="ui-widget-header ui-corner-all">
                                            <button class="button edit"   data-kategori="jenis" id="edit_<?=$data['id_jenis']?>"   data-nya="<?=$data['jenis']?>">Edit</button>
                                            <button class="button delete" data-kategori="jenis" id="delete_<?=$data['id_jenis']?>" data-nya="<?=$data['jenis']?>">Hapus</button>
                                        </div>
                                    </td>
                                </tr>
                        <?php
                            }
                        ?>
                        </tbody>
                    </table>
                    <br/>
                    <button class="add" data-kategori="jenis">Tambah Jenis Obat </button>
                </div>

                <div id="golongan_obat">
                    <table class="tb">
                        <thead>
                        <tr align="center">
                            <th>ID</th>
                            <th width="180px">Golongan Obat</th>
                            <th>Edit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 1;
                        $qry = Settings_Farmasi::get_golongan_barang();
                        while($data = mysql_fetch_array($qry)){
                            ?>
                            <tr class="<?= $i++ % 2 ? 'tr1' : 'tr2'?>">
                                <td><?=$data['id_golongan']?></td>
                                <td><?=$data['golongan'] ?> </td>
                                <td>
                                    <div class="ui-widget-header ui-corner-all">
                                        <button class="button edit"   data-kategori="golongan" id="edit_<?=$data['id_golongan']?>"   data-nya="<?=$data['golongan']?>">Edit</button>
                                        <button class="button delete" data-kategori="golongan" id="delete_<?=$data['id_golongan']?>" data-nya="<?=$data['golongan']?>">Hapus</button>
                                    </div>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                    </table>
                    <br/>
                    <button class="add" data-kategori="golongan">Tambah Golongan Obat </button>
                </div>

                <div id="satuan_barang">
                    <table class="tb">
                        <thead>
                        <tr align="center">
                            <th>ID</th>
                            <th width="180px">Satuan</th>
                            <th>Edit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 1;
                        $qry = Settings_Farmasi::get_satuan_barang();
                        while($data = mysql_fetch_array($qry)){
                            ?>
                            <tr class="<?= $i++ % 2 ? 'tr1' : 'tr2'?>">
                                <td><?=$data['id_satuan']?></td>
                                <td><?=$data['satuan'] ?> </td>
                                <td>
                                    <button class="button edit"   data-kategori="satuan" id="edit_<?=$data['id_satuan']?>"   data-nya="<?=$data['satuan']?>">Edit</button>
                                    <button class="button delete" data-kategori="satuan" id="delete_<?=$data['id_satuan']?>" data-nya="<?=$data['satuan']?>">Hapus</button>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                    </table>
                    <br/>
                    <button class="add" data-kategori="satuan">Tambah Satuan </button>
                </div>

                <div id="kemasan_barang">
                    <table class="tb">
                        <thead>
                        <tr align="center">
                            <th>ID</th>
                            <th width="180px">Kemasan</th>
                            <th>Edit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 1;
                        $qry = Settings_Farmasi::get_kemasan_obat();
                        while($data = mysql_fetch_array($qry)){
                            ?>
                            <tr class="<?= $i++ % 2 ? 'tr1' : 'tr2'?>">
                                <td><?=$data['id_kemasan']?></td>
                                <td><?=$data['kemasan'] ?> </td>
                                <td>
                                    <button class="button edit"   data-kategori="kemasan" id="edit_<?=$data['id_kemasan']?>"   data-nya="<?=$data['kemasan']?>">Edit</button>
                                    <button class="button delete" data-kategori="kemasan" id="delete_<?=$data['id_kemasan']?>" data-nya="<?=$data['kemasan']?>">Hapus</button>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                    </table>
                    <br/>
                    <button class="add" data-kategori="kemasan">Tambah Kemasan</button>
                </div>

                <div id="kelas_therapy">
                    <table class="tb">
                        <thead>
                        <tr align="center">
                            <th>ID</th>
                            <th width="180px">Kelas Therapy</th>
                            <th>Edit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 1;
                        $qry = Settings_Farmasi::get_kelas_therapy();
                        while($data = mysql_fetch_array($qry)){
                            ?>
                            <tr class="<?= $i++ % 2 ? 'tr1' : 'tr2'?>">
                                <td><?=$data['id_kelas_therapy']?></td>
                                <td><?=$data['kelas_therapy'] ?> </td>
                                <td>
                                    <button class="button edit"   data-kategori="kelas_therapy" id="edit_<?=$data['id_kelas_therapy']?>"   data-nya="<?=$data['kelas_therapy']?>">Edit</button>
                                    <button class="button delete" data-kategori="kelas_therapy" id="delete_<?=$data['id_kelas_therapy']?>" data-nya="<?=$data['kelas_therapy']?>">Hapus</button>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                    </table>
                    <br/>
                    <button class="add" data-kategori="kelas_therapy">Tambah Kelas Therapy</button>
                </div>

            </div> <!-- Akhir settings_tabs -->

        </div>
    </div>
</div>

<!--Modal Jenis Obat-->
<div id="dialog-form" >
    <p class="validateTips">Harap isi semua field yang dibutuhkan..</p>

    <form method="post">
        <fieldset>
            <label for="id">Id</label>
            <input type="text" name="id" id="id" placeholder="Terisi otomatis..." class="text ui-widget-content ui-corner-all">

            <label for="jenis" id="label_jenis">Nama Jenis Obat</label>
            <input type="text" name="jenis" id="jenis" autofocus  class="text ui-widget-content ui-corner-all">

<!--            <input type="submit" tabindex="-1" style="position:absolute; top:-1000px">-->
        </fieldset>
    </form>
</div>

<!--Modal confirm delete-->
<div id="dialog-delete-confirm" title="Yakin untuk menghapus data ini?">
    <p>
        <span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        Data yang akan Anda hapus yaitu: <span id="del_id_data"></span> <span id="del_data"></span>.
    </p>
    <form method="post">
        <input type="hidden" name="id" id="id_jenis_to_del" />
    </form>
</div>

<!-- Modal diaolog Info-->
<div id="dialog-message" title="Heeey :D">
    <p>
        <span class="ui-icon ui-icon-circle-check" style="float:left; margin:0 7px 50px 0;"></span>
        <?php
            if(isset($_SESSION['settings_farmasi_notif'])){
                echo $_SESSION['settings_farmasi_notif'];
            }
        ?>
    </p>
</div>

<script>
    var allFields = jQuery([]).add(jQuery("#id")).add(jQuery("#jenis"));
    var url       = "gudang/settings_farmasi.php?m=" ;
    var urlInsert = "gudang/settings_farmasi.php?m=insert_jenis_obat" ;
    var urlUpdate = "gudang/settings_farmasi.php?m=update_jenis_obat" ;
    var urlDelete = "gudang/settings_farmasi.php?m=delete_jenis_obat" ;

    jQuery(".ui-widget-header").css({padding: '2px'});
    jQuery("input, label").css({display: 'block'});
    jQuery("input.text").css({marginBottom:'12px',width: '95%',padding: '.4em'});
    jQuery("fieldset").css({ padding:'0',border:'0', marginTop:'25px'});
    var active_tab = <?= isset($_SESSION['tab_active']) ? $_SESSION['tab_active'] : 0; ?>;
    <?php if(isset($_SESSION['tab_active'])) unset($_SESSION['tab_active']);?>
    active_tab != 0 ? jQuery("#settings_tabs").tabs({active: active_tab}) : jQuery("#settings_tabs").tabs();

    jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 300,
        width: 350,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        buttons: {
            Simpan: function(){
                //validai
                console.log("-->sendFormData()");
                sendFormData();
            },
            Batal: function() {
                jQuery(this).dialog("close");
            }
        },
        close: function() {
            jQuery(".validateTips").html("Harap isi semua field yang dibutuhkan..");
            allFields.val("");
            allFields.removeClass("ui-state-error");
        },
        open: function(event, ui){
            var input  = jQuery("#jenis");
            var length = jQuery("#jenis").val().length;
            input[0].focus();
            input[0].setSelectionRange(length, length);
        }
    });

    jQuery("#dialog-delete-confirm").dialog({
        autoOpen: false,
        height: 140,
        width: 350,
        modal: true,
        buttons: {
            Hapus: function() {
                jQuery("#dialog-delete-confirm").find("form").submit();
            },
            Batal: function() {
                jQuery( this ).dialog( "close" );
            }
        }
    });

    jQuery( "#dialog-message" ).dialog({
        modal   : true,
        autoOpen: <?= isset($_SESSION['settings_farmasi_notif']) ? "true" : "false"; ?> ,
        buttons : {Ok: function(){jQuery( this ).dialog( "close" );}}
    });

    jQuery(".add").button({icons: {primary: "ui-icon-circle-plus"}}).on("click", function(){
        var title = "";
        var kategori = jQuery(this).attr("data-kategori");
        console.log("-->kategori : " + kategori);
        jQuery("#jenis").focus();
        allFields.val("");
        jQuery("#id").attr("readonly", "readonly");
        if(kategori == "group"){
            jQuery("#label_jenis").html("Nama group barang");
            jQuery("#dialog-form").find("form").attr("action", url + "insert_group_barang");
            title = "Tambah Group Barang";
        }else if(kategori == "jenis"){
            jQuery("#label_jenis").html("Nama jenis barang");
            jQuery("#dialog-form").find("form").attr("action", urlInsert);
            title = "Tambah Jenis Obat";
        }else if(kategori == "satuan"){
            jQuery("#label_jenis").html("Nama satuan barang");
            jQuery("#dialog-form").find("form").attr("action", url + "insert_satuan_barang");
            title = "Tambah Satuan";
        }else if(kategori == "golongan"){
            jQuery("#label_jenis").html("Nama golongan barang");
            jQuery("#dialog-form").find("form").attr("action", url + "insert_golongan_barang");
            title = "Tambah Satuan";
        }else if(kategori == "kemasan"){
            jQuery("#label_jenis").html("Nama kemasan barang");
            jQuery("#dialog-form").find("form").attr("action", url + "insert_kemasan_obat");
            title = "Tambah Kemasan Obat";
        }else if(kategori == "kelas_therapy"){
            jQuery("#label_jenis").html("Nama kelas therapy");
            jQuery("#dialog-form").find("form").attr("action", url + "insert_kelas_therapy");
            title = "Tambah Kelas Therapy";
            console.log("-->masuke ke : " + kategori);
        }
        jQuery("#dialog-form").dialog({title: title}).dialog("open");
    });

    jQuery(".edit").button({icons: {primary: "ui-icon-pencil"}}).click(function() {
        var id = this.id.substr(5);
        // Ubah nilai di field berdasarkan tombol yang dipilih
        jQuery("#id").attr("readonly", "readonly");
        jQuery("#id").val(id);
        console.log("id -> " + id);
        jQuery("#jenis").val(jQuery(this).attr("data-nya"));
        console.log("nya : " + jQuery("#jenis").val());
        // menentukan url form
        var kategori = jQuery(this).attr("data-kategori");
        if(kategori== "group"){
            jQuery("#label_jenis").html("Nama jenis barang");
            jQuery("#dialog-form").find("form").attr("action", url + "update_group_barang");
            jQuery("#dialog-form").dialog({
                title: "Edit Group Barang"
            }).dialog("open");
        }else if(kategori== "jenis"){
            jQuery("#label_jenis").html("Nama jenis barang");
            jQuery("#dialog-form").find("form").attr("action", urlUpdate);
            jQuery("#dialog-form").dialog({
                title: "Edit Jenis Obat"
            }).dialog("open");
        }else if(kategori == "satuan"){
            jQuery("#label_jenis").html("Nama satuan barang");
            jQuery("#dialog-form").find("form").attr("action", url + "update_satuan_barang");
            jQuery("#dialog-form").dialog({
                title: "Edit Satuan Barang"
            }).dialog("open");
        }else if(kategori == "golongan"){
            jQuery("#label_jenis").html("Nama golongan barang");
            jQuery("#dialog-form").find("form").attr("action", url + "update_golongan_barang");
            jQuery("#dialog-form").dialog({
                title: "Edit Golongan Barang"
            }).dialog("open");
        }else if(kategori == "kemasan"){
            jQuery("#label_jenis").html("Nama kemasan obat");
            jQuery("#dialog-form").find("form").attr("action", url + "update_kemasan_obat");
            jQuery("#dialog-form").dialog({
                title: "Edit Kemasan Obat"
            }).dialog("open");
        }else if(kategori == "kelas_therapy"){
            jQuery("#label_jenis").html("Nama kelas therapy");
            jQuery("#dialog-form").find("form").attr("action", url + "update_kelas_therapy");
            jQuery("#dialog-form").dialog({
                title: "Edit Kelas Therapy"
            }).dialog("open");
        }
    });

    jQuery(".delete").button({icons: {primary: "ui-icon-trash"}}).click(function(){
        var id = this.id.substr(7);
        var kategori = jQuery(this).attr("data-kategori");
        if(kategori == "group"){
            jQuery("#dialog-delete-confirm").find("form").attr("action", url + "delete_group_barang");
        }else if(kategori == "jenis"){
            jQuery("#dialog-delete-confirm").find("form").attr("action", urlDelete);
        }else if(kategori == "satuan"){
            jQuery("#dialog-delete-confirm").find("form").attr("action", url + "delete_satuan_barang");
        }else if(kategori == "golongan"){
            jQuery("#dialog-delete-confirm").find("form").attr("action", url + "delete_golongan_barang");
        }else if(kategori == "kemasan"){
            jQuery("#dialog-delete-confirm").find("form").attr("action", url + "delete_kemasan_obat");
        }else if(kategori == "kelas_therapy"){
            jQuery("#dialog-delete-confirm").find("form").attr("action", url + "delete_kelas_therapy");
        }
        jQuery("#del_id_data").html(id);
        jQuery("#del_data").html(jQuery(this).attr("data-nya"));
        jQuery("#id_jenis_to_del").val(this.id.substr(7));
        jQuery("#dialog-delete-confirm").dialog("open");

    });

//    jQuery("#dialog-form").find("form").on("submit", function(event){
//        event.preventDefault();
//        sendFormData();
//    });

    function updateTips( t ){
        jQuery(".validateTips").text( t ).addClass( "ui-state-highlight" );
        setTimeout(function(){
            jQuery(".validateTips").removeClass( "ui-state-highlight", 1500 );
        }, 500 );
    }
    function checkLength( o, n, min, max ) {
        if ( o.val().length > max || o.val().length < min ) {
            o.addClass( "ui-state-error" );
            updateTips( "Panjang dari " + n + " harus diantara " +
            min + " dan " + max + "." );
            return false;
        } else {
            return true;
        }
    }

    function validateForm(){
        var valid = true;
        valid = valid && checkLength(jQuery("#jenis"), jQuery("#label_jenis").html(), 3, 100);
        return valid;
    }
    function sendFormData(){
        if(validateForm()){
            jQuery("#dialog-form").find("form").submit();
        }
    }


</script>
