<?php session_start();
include("../include/connect.php");

$kdbarang = $_POST['kdbarang'];
$stok     = $_POST['stok'];

$sql_unit = "INSERT INTO t_barang_stok(kode_barang, tanggal, saldo, KDUNIT)
			VALUES('".$kdbarang."', now(), '".$stok."',". $_SESSION['KDUNIT'] . " )";
@mysql_query($sql_unit);

//echo "<fieldset class='fieldset'>";
//echo "<legend>Informasi</legend>";
//echo "Simpan Data Stok Berhasil." ;

?>

<script >
    alert("Perubahan Stok Berhasil.");
    window.location="../index.php?link=82";
</script>