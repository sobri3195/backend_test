<?php
session_start();
/**
 * Created by PhpStorm.
 * User: ISYFALANA
 * Date: 19/08/2015
 * Time: 9:32
 */
    include("../include/connect.php");
    $sql_satuan_barang = "SELECT * FROM m_barang_satuan;" ;
    $query_satuan_barang = mysql_query($sql_satuan_barang) or die(mysql_error());
?>

<?php
    /*  opt 1 = lihat
    /*  opt 2 = Edit
    /*  opt 3 = Hapus
    /*  opt 4 = tambah
     */
    if($_GET['opt'] == 1) {
?>
        <fieldset class='fieldset' style="width:80%">
            <legend>Satuan Barang</legend>
            <table style="width:80%; margin: 2px auto;">
                <thead>
                <tr>
                    <th style="width: 10%">ID</th>
                    <th style="width: 60%">Satuan</th>
                    <th style="width: 30%">Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i = 0;
                while ($satuan_barang = mysql_fetch_array($query_satuan_barang)) {
                    echo "<tr class=\"".(($i++ % 2 == 0)?'tr1':'tr2')."\">";
                    echo "<td>" . $satuan_barang['id_satuan'] . "</td>";
                    echo "<td>" . $satuan_barang['satuan'] . "</td>";
                    echo "<td>";
                    echo "<a href=\"#\" class=\"text\" onclick=\"javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=2&amp;id=".$satuan_barang['id_satuan']."&amp;satuan=".$satuan_barang['satuan'] ."');\" >Edit </a>&nbsp;";
                    echo "<a href=\"#\" class=\"text\" onclick=\"javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=4&amp;id=".$satuan_barang['id_satuan']."&amp;satuan=".$satuan_barang['satuan'] ."');\" >Hapus</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
                </tbody>
            </table>
            <br/>
            <a href="#" class="text"
               onclick="javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=3');">Tambah Satuan</a>
        </fieldset>

    <?php
    }else if($_GET['opt'] == 2){
    ?>
        <fieldset class='fieldset' style="width:80%">
            <legend>Edit Satuan Barang</legend>
            <form name="xform" id="xform" action="gudang/add_barang_satuan.php" method="post" >
                <table>
                    <tr>
                        <td>ID</td>
                        <td>:</td>
                        <td><input type="text" value="<?=$_GET['id']; ?>" readonly></td>
                    </tr>
                    <tr>
                        <td>Satuan</td>
                        <td>:</td>
                        <td>
                            <input type="hidden" name="id" value="<?=$_GET['id']; ?>">
                            <input type="hidden" name="opt" value="4">
                            <input type="text"   name="satuan" value="<?=$_GET['satuan']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="submit" class="text" value="Simpan" onclick="newsubmitform(document.getElementById('xform'),'gudang/add_barang_satuan.php','addbarang',validatetask);  return false;" />
                            <a href="#" class="text" onclick="javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=1');" >Batal</a>
                        </td>
                    </tr>
                </table>
            </form>
        </fieldset>
    <?php
    }else if($_GET['opt'] == 3) {
    ?>
        <fieldset class='fieldset' style="width:80%">
            <legend>Tambah Satuan Barang</legend>
            <form name="xform" id="xform" action="gudang/add_barang_satuan.php" method="post">
                <table>
                    <tr>
                        <td>Nama satuan</td>
                        <td>:</td>
                        <td>
                            <input type="hidden" name="opt" value="5">
                            <input type="text" name="satuan"/>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="submit" class="text" value="Simpan"
                                   onclick="newsubmitform(document.getElementById('xform'),'gudang/add_barang_satuan.php','addbarang',validatetask);  return false;"/>
                            <a href="#" class="text"
                               onclick="javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=1');">Batal</a>
                        </td>
                    </tr>
                </table>
            </form>
        </fieldset>
    <?php
    }else if($_GET['opt'] == 4){
    ?>
        <fieldset class='fieldset' style="width:80%">
            <legend>Konfirmasi</legend>

            <h3  style="margin: 0 auto; color: #000000;">Apakah Anda yakin akan menghapus data ini?</h3>
            <span style="margin: 0 auto; color: #000000; font-size: 12px;">Satuan : <?= $_GET['satuan'];?></span>
            <br/>
            <br/>
            <br/>
            <form name="xform" id="xform" action="gudang/add_barang_satuan.php" method="post">
                <div style="margin: 0 auto;">
                <input type="hidden" name="id" value="<?= $_GET['id'];?>">
                <input type="hidden" name="opt" value="6">
                <input type="submit" class="text" value="Hapus"
                       onclick="newsubmitform(document.getElementById('xform'),'gudang/add_barang_satuan.php','addbarang',validatetask);  return false;"/>
                <a href="#" class="text"
                   onclick="javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=6');">Batal</a>
                </div>
            </form>
        </fieldset>
    <?php
    }else if($_POST['opt'] == 4){
        $sql_update = "UPDATE m_barang_satuan
                        SET m_barang_satuan.satuan='".mysql_real_escape_string($_POST['satuan'])."'
                        WHERE m_barang_satuan.id_satuan='".mysql_real_escape_string($_POST['id'])."' ;";
        mysql_query($sql_update) ;
        $info = "";
        if( mysql_affected_rows() ){
            $info = "Perubahan berhasil disimpan";
        }else{
            $info = "Perubahan GAGAL disimpan";
        }
        echo "<fieldset class='fieldset' style='width:80%'>";
        echo "<legend>Info</legend>";
        echo "<h3 style='color: #000000'>".$info."</h3>";
        echo "<br/><br/>";
        echo "<a href=\"#\" class=\"text\" onclick=\"javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=1');\" >Kembali</a>";
        echo "</fieldset>";
    }else if($_POST['opt'] == 5){
        $sql_insert = "INSERT INTO m_barang_satuan(satuan) VALUES ('".mysql_real_escape_string($_POST['satuan'])."');";
        mysql_query($sql_insert) ;
        $info = "";
        if( mysql_affected_rows() ){
            $info = "Data berhasil disimpan";
        }else{
            $info = "Data GAGAL disimpan";
        }
        echo "<fieldset class='fieldset' style='width:80%'>";
        echo "<legend>Info</legend>";
        echo "<h3 style='color: #000000'>".$info."</h3>";
        echo "<br/><br/>";
        echo "<a href=\"#\" class=\"text\" onclick=\"javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=1');\" >Kembali</a>";
        echo "</fieldset>";
    }else if($_POST['opt'] == 6){
        $sql_insert = "DELETE FROM m_barang_satuan WHERE id_satuan=".mysql_real_escape_string($_POST['id']).";";
        mysql_query($sql_insert) ;
        $info = "";
        if( mysql_affected_rows() ){
            $info = "Data berhasil dihapus";
        }else{
            $info = "Data GAGAL dihapus";
        }
        echo "<fieldset class='fieldset' style='width:80%'>";
        echo "<legend>Info</legend>";
        echo "<h3 style='color: #000000'>".$info."</h3>";
        echo "<br/><br/>";
        echo "<a href=\"#\" class=\"text\" onclick=\"javascript: MyAjaxRequest('addbarang','gudang/add_barang_satuan.php?opt=1');\" >Kembali</a>";
        echo "</fieldset>";
    }
    ?>