<div align="center">
    <div id="frame">
    <div id="frame_title"><h3>Laporan Harian</h3></div>

<fieldset >
<legend>Filter Laporan Harian</legend>
<form name="formsearch" id="filterlap" method="get" >
<input type="hidden" name="link" value="g01" />
<table class="tb" align="left">
<tr>
<td>Tanggal</td>
<td>
    <input type="text" name="tgl_pesan" id="tgl_pesan" class="text datepicker" />
</td>
</tr>

 <tr>
   <td>Group Barang</td>
   <td><?php include('include/RsudUtility.php'); RsudUtility::printOptionGroupBarang($_SESSION['KDUNIT']);?></td>
 </tr>
 <tr>
   <td>Nama Barang</td>
   <td><input type="text" name="nm_barang" id="nm_barang" class="text" /></td>
 </tr>
  <tr>
   <td>&nbsp;</td>
   <td><input type="submit" value="Open" class="text" /></td>
 </tr>
</table>
</form>
</fieldset >
</div></div>
<script>
    jQuery(document).ready(function() {
    // Atur tampilan
        jQuery("#tgl_pesan").css({paddingLeft: '6px', height: '18px', width: '250px'});
        jQuery("#group").css({paddingLeft: '6px', height: '21px', width: '260px'}).select2();
        jQuery("#nm_barang").css({paddingLeft: '6px', height: '21px', width: '250px'});
    });
</script>