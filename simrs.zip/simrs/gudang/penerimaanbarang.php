<div align="center">
    <div id="frame" style="width:100%;">
    <div id="frame_title"><h3>PENERIMAAN BARANG</h3></div>
        <div align="left" style="margin:5px;">
            <?php
                include('../include/function.php');
                include('include/RsudUtility.php');
                $ip = getRealIpAddr();
                mysql_query('delete from temp_cartbarang_penerimaan where IP = "'.$ip.'"');
            ?>
            <form name="terimabarang" id="terimabarang" action="gudang/addbarangpenerimaan.php" method="post" >
                <fieldset class="fieldset">
                    <table class="tb" align="left">
                        <tr>
                            <td>Terima Dari</td>
                            <td><input type="text" name="nmsuplier" autofocus required class="text" style="width:96%; height:16px; padding-left: 6px"/></td>
                        </tr>
                        <tr>
                            <td>Jenis Penerimaan</td>
                            <td>
                                <?php
                                    RsudUtility::printOptionPenerimaanBarang("jns","jns", "width: 100%");
                                ?>
<!--                                <select name="jns" id="jns" class="text select2" style="width: 100%">-->
<!--                                    <option value="1" >APBN</option>-->
<!--                                    <option value="2" >APBD I</option>-->
<!--                                    <option value="3" >APBD II</option>-->
<!--                                    <option value="4" >LAIN-LAIN</option>-->
<!--                                </select>-->
                            </td>
                        </tr>
                        <tr>
                            <td>Keterangan</td>
                            <td><input type="text" name="ket" class="text" style="width:96%; height:16px; padding-left: 6px" /></td>
                        </tr>
                        <tr>
                            <td>Tanggal</td>
                            <?php $tgl =  date("Y-m-d");?>
                            <td>
                                <input type="text" name="tglterima" value="<?=$tgl?>" readonly="readonly" class="text" style="width:96%; height:16px; padding-left: 6px"/>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td>Group Barang</td>
                            <td>
                                <? if($_SESSION['KDUNIT']=="12"){ ?>
                                        <input type="hidden" name="farmasi" id="farmasi" value="1"  />
                                <? }else if($_SESSION['KDUNIT']=="13"){ ?>
                                        <input type="hidden" name="farmasi" id="farmasi" value="0"  />
                                <? } ?>
                                <?php
                                    RsudUtility::printOptionGroupBarang($_SESSION['KDUNIT'], "grpbarang", "grpbarang");
                                ?>
                            </td>
                        </tr>
                        <tr>
                        <td>Nama Barang</td>
                            <td>
                                <!--     <input name="nm_barang" type="text" class="text" id="nm_barang" size="50" onkeypress="autocomplete_gudang(this.value, event)" onblur="document.getElementById('autocompletediv'); Efect.appear('autocompletediv');" style="width:96%; height:16px; padding-left: 6px"/>-->
                                <!--     <input name="nm_barang" type="text" class="text" id="nm_barang" size="50" style="width:96%; height:16px; padding-left: 6px"/>-->
                                <select id="nm_barang" name="nm_barang" style="width: 250px" class="select2">
                                    <option></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Kode Barang</td>
                            <td><input type="text" name="kd_barang"  id="kd_barang" class="text" readonly="readonly" style="width:96%; height:16px; padding-left: 6px" /></td>
                        </tr>
                        <tr>
                            <td>No Batch</td>
                            <td><input type="text" name="no_batch"  id="no_batch" class="text" readonly="readonly" style="width:96%; height:16px; padding-left: 6px" /></td>
                        </tr>
                        <tr>
                            <td>Tgl Kadaluarsa</td>
                            <td><input type="text" name="tgl_kadaluarsa"  id="tgl_kadaluarsa" class="text" readonly="readonly" style="width:96%; height:16px; padding-left: 6px" /></td>
                        </tr>
                        <tr>
                            <td>Jumlah</td>
                            <td>
                                <input type="text" name="jml_barang" id="jml_barang" class="text" style="width:96%; height:16px; padding-left: 6px" />
                            </td>
                        </tr>
                        <tr>
                            <td height="26"></td>
                            <td><input type="submit" class="text" value="Add" onclick="submitform (document.getElementById('terimabarang'),'gudang/addbarangpenerimaan.php','validbarang',validatetask);
                                document.getElementById('kd_barang').value = ''; document.getElementById('nm_barang').value = '';
                                document.getElementById('jml_barang').value = ''; document.getElementById('tgl_kadaluarsa').value = '';
                                document.getElementById('no_batch').value = ''; return false;"/></td>
                        </tr>
                    </table>
                </fieldset>
            </form>
            <div id="autocompletediv" class="autocomp" align="left"></div>
            <div id="validbarang"></div>
        </div>
    </div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
    // style
    jQuery("#grpbarang").css({width: '100%', height:'16px', paddingLeft: '6px'});
    jQuery("#jns").select2();
    jQuery("#grpbarang").select2();
    jQuery("#grpbarang").on("change", function(e){
        jQuery("#nm_barang").val(null).trigger("change");
        jQuery("#kd_barang").val('');
        jQuery("#no_batch").val('');
        jQuery("#tgl_kadaluarsa").val('');
    });
    jQuery("#nm_barang").select2({
        allowClear: true,
        placeholder: "Ketikkan nama barang..",
        ajax: {
            url: "include/RsudUtility.php",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    nama_barang: params.term, // search term
                    optFarmasi : jQuery("#farmasi").val(),
                    grpbarang  : jQuery("#grpbarang option:selected").val(),
                    function: 'getAjaxBarang'
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });

    jQuery("#nm_barang").on("select2:select", function (e) {
        if(e){
            jQuery("#kd_barang").val(e.params.data.kode_barang);
            jQuery("#no_batch").val(e.params.data.no_batch);
            jQuery("#tgl_kadaluarsa").val(e.params.data.expiry);
            jQuery("#jml_barang").focus();
        }
    });

    jQuery("#nm_barang").on("select2:unselect", function (e) {
        if(e){
            jQuery("#harga").val("");
        }
    });
});
</script>
