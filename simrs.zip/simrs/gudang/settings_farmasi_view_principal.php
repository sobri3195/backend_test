<?php
    include('settings_farmasi.php');
    include('../include/RsudAddressUtility.php');
?>


<div id="principal_tab">
    <table class="tb">
        <thead>
        <tr align="center">
            <th>ID</th>
            <th width="180px">Principal</th>
            <th width="180px">Alamat</th>
            <th width="180px">Negara</th>
            <th>Edit</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $i = 1;
        $qry = Settings_Farmasi::get_principal();
        while($data = mysql_fetch_array($qry)){
            ?>
            <tr class="<?= $i++ % 2 ? 'tr1' : 'tr2'?>">
                <td>
                    <?=$data['id_principal']?>
                    <input type="hidden" id="id_<?=$data['id_principal']?>" value="<?=$data['id_principal']?>" />
                </td>
                <td>
                    <?=$data['principal'] ?>
                    <input type="hidden" id="principal_<?=$data['id_principal']?>" value="<?=$data['principal']?>" />
                </td>
                <td>
                    <?=$data['alamat'] ?>
                    <input type="hidden" id="alamat_<?=$data['id_principal']?>" value="<?=$data['alamat']?>" />
                </td>
                <td>
                    <?=$data['nama_negara'] ?>
                    <input type="hidden" id="negara_<?=$data['id_principal']?>" value="<?=$data['negara']?>" />
                </td>
                <td>
                    <button class="button edit-principal"   data-kategori="kelas_therapy" id="edit_<?=$data['id_principal']?>"   data-nya="<?=$data['principal']?>">Edit</button>
                    <button class="button delete-principal" data-kategori="kelas_therapy" id="delete_<?=$data['id_principal']?>" data-nya="<?=$data['principal']?>">Hapus</button>
                </td>
            </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
    <br/>
    <button class="add-principal" data-kategori="principal">Tambah Principal</button>
</div>

<!--Modal Principal -->
<div id="dialog-form-principal" >
    <p class="validateTipsPrincipal">Harap isi semua field yang dibutuhkan..</p>

    <form method="post">
        <fieldset>
            <label for="id_principal">Id Principal</label>
            <input type="text" name="id" id="id_principal" placeholder="Terisi otomatis..." class="text ui-widget-content ui-corner-all">

            <label for="principal" id="lbl_principal">Principal</label>
            <input type="text" name="principal" id="principal"  class="text ui-widget-content ui-corner-all">

            <label for="alamat" id="lbl_alamat">Alamat</label>
            <textarea name="alamat" id="alamat"  class="text ui-widget-content ui-corner-all"></textarea>

            <label for="negara" id="lbl_negara">Negara</label>
            <select id="negara" name="negara" class="select2">
            <?php
                $rs_negara = RsudAddressUtility::getNegara();
                while($data = mysql_fetch_array($rs_negara)){
            ?>
                    <option value="<?=$data['id_negara']?>"><?=$data['negara']?></option>
            <?php
                }
            ?>
            </select>

            <!--            <input type="submit" tabindex="-1" style="position:absolute; top:-1000px">-->
        </fieldset>
    </form>
</div>

<!--Modal confirm delete principal-->
<div id="dialog-delete-confirm-principal" title="Yakin untuk menghapus data ini?">
    <p>
        <span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        Data yang akan Anda hapus yaitu: <span id="del_id_principal"></span> <span id="del_principal"></span>.
    </p>
    <form method="post">
        <input type="hidden" name="id" id="id_principal_to_del" />
    </form>
</div>


<script type="text/javascript">
    var url = "gudang/settings_farmasi.php?m=" ;
    jQuery(".ui-widget-header").css({padding: '2px'});
    jQuery("input, label").css({display: 'block'});
    jQuery("input.text").css({marginBottom:'12px',width: '95%',padding: '.4em'});
    jQuery("textarea").css({marginBottom:'12px',width: '95%',padding: '.4em'});
    jQuery("fieldset").css({ padding:'0',border:'0', marginTop:'25px'});
    jQuery(".select2").css({marginBottom:'12px',width:"97%",padding: '.4em'});

    function setFields(id, principal, alamat, negara){
        jQuery("#id_principal").val(id).removeClass("ui-state-error");
        jQuery("#principal").val(principal).removeClass("ui-state-error");
        jQuery("#alamat").val(alamat).removeClass("ui-state-error");
        jQuery("#negara").val(negara).trigger("change").removeClass("ui-state-error");
    }


    jQuery(".add-principal").button({icons: {primary: "ui-icon-circle-plus"}}).on("click", function(){
        setFields("","","","");
        jQuery("#id_principal").attr("readonly", "readonly");
        jQuery("#dialog-form-principal").find("form").attr("action", url + "insert_principal");
        jQuery("#dialog-form-principal").dialog({
            title: "Tambah Data Principal"
        }).dialog("open");
    });

    jQuery(".edit-principal").button({icons: {primary: "ui-icon-pencil"}}).click(function(){
        var id = this.id.substr(5);
        setFields(id, jQuery("#principal_"+id).val(), jQuery("#alamat_"+id).val(), jQuery("#negara_"+id).val());
        jQuery("#id_principal").attr("readonly", "readonly");
        jQuery("#dialog-form-principal").find("form").attr("action", url + "update_principal");
        jQuery("#dialog-form-principal").dialog({
            title: "Edit Data Principal"
        }).dialog("open");
    });

    jQuery(".delete-principal").button({icons: {primary: "ui-icon-trash"}}).click(function(){
        var id = this.id.substr(7);
        jQuery("#del_id_principal").html(id);
        jQuery("#del_principal").html(jQuery("#principal_"+id).val());
        jQuery("#id_principal_to_del").val(id);
        jQuery("#dialog-delete-confirm-principal").find("form").attr("action", url + "delete_principal");
        jQuery("#dialog-delete-confirm-principal").dialog("open");
    });

    jQuery("#dialog-form-principal").dialog({
        autoOpen: false,
        height: 400,
        width: 450,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        buttons: {
            Simpan: function(){
                //validai
                console.log("-->sendFormData()");
                sendFormDataPrincipal();
            },
            Batal: function() {
                jQuery(this).dialog("close");
            }
        },
        close: function() {
            jQuery(".validateTipsPrincipal").html("Harap isi semua field yang dibutuhkan..");
        }
    });

    jQuery("#dialog-delete-confirm-principal").dialog({
        autoOpen: false,
        height: 140,
        width: 350,
        modal: true,
        buttons: {
            Hapus: function() {
                jQuery("#dialog-delete-confirm-principal").find("form").submit();
            },
            Batal: function() {
                jQuery( this ).dialog( "close" );
            }
        }
    });

    jQuery("#negara").select2();
    function checkLengthPrincipal( o, n, min, max ) {
        if ( o.val().length > max || o.val().length < min ) {
            o.addClass( "ui-state-error" );
            updateTipsPrincipal( "Panjang dari " + n + " harus diantara " + min + " dan " + max + "." );
            return false;
        } else {
            return true;
        }
    }

    function validateFormPrincipal(){
        var valid = true;
        valid = valid && checkLengthPrincipal(jQuery("#principal"), jQuery("#lbl_principal").html(), 3, 22);
        valid = valid && checkLengthPrincipal(jQuery("#alamat"), jQuery("#lbl_alamat").html(), 6, 22);
        return valid;
    }

    function updateTipsPrincipal( t ){
        jQuery(".validateTipsPrincipal").text( t ).addClass( "ui-state-highlight" );
        setTimeout(function(){
            jQuery(".validateTipsPrincipal").removeClass( "ui-state-highlight", 1500 );
        }, 500 );
    }

    function sendFormDataPrincipal(){
        if(validateFormPrincipal()){
            jQuery("#dialog-form-principal").find("form").submit();
        }
    }

</script>
