<?
include("signature.php");
#error_reporting("E_ALL");
include('include/connect.php');
#include('lib/function.php');
if ($_POST) {
	extract($_POST);
if($reqdata=="sep"){
	$tgl=date("Y-m-d H:i:s");
$scml.="
<request>";
 $scml.="<data>";
  $scml.="<t_sep>";
   $scml.="<noKartu>$nopeserta</noKartu>
   <tglSep>$tgl</tglSep>
   <tglRujukan>$tgl</tglRujukan>
   <noRujukan>$norujukan</noRujukan>
   <ppkRujukan>$noppk</ppkRujukan>
   <ppkPelayanan>0133R018</ppkPelayanan>
   <jnsPelayanan>2</jnsPelayanan>
   <catatan>$catatan</catatan>
   <diagAwal>$diagnosa</diagAwal>
   <poliTujuan>$politujuan</poliTujuan>
   <klsRawat>$klsrawat</klsRawat>
   <user>$user</user>
   <noMr>$nomr</noMr>";
  $scml.="</t_sep>";
 $scml.="</data>";
$scml.="</request>
";
$url= "http://192.168.0.228:8082/SepLokalRest/sep/";
$process = curl_init($url); 
curl_setopt($process, CURLOPT_HTTPHEADER,
        array("Content-Type: application/xml\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
curl_setopt($process, CURLOPT_HEADER, false); 
curl_setopt($process, CURLOPT_TIMEOUT, 30); 
curl_setopt($process, CURLOPT_POST, true); 
curl_setopt($process, CURLOPT_POSTFIELDS, $scml); 
curl_setopt($process, CURLOPT_RETURNTRANSFER, TRUE); 
$return = curl_exec($process); 
curl_close($process);
$response = json_decode($return, true);
$no_sep=$response[response];
echo $no_sep;
}
if($reqdata=="rujukan"){
	$tgl=date("Y-m-d H:i:s");

$ip= "http://192.168.0.228:8082/SepLokalRest/peserta";
$nilai1=$nopeserta;
$url= "".$ip."/$nilai1";
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER,
        array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
curl_setopt($curl, CURLOPT_GET, true);
#curl_setopt($curl, CURLOPT_POSTFIELDS, $content);

$json_response = curl_exec($curl);

#$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

curl_close($curl);

$response = json_decode($json_response, true);
$rest=$response[metaData]['message']; 
//if($rest==200){
echo $json_response;
//}
//else{
//echo"Error";
//}
}
if($reqdata=="norujukan"){
	$tgl=date("Y-m-d H:i:s");

$ip= "http://192.168.0.228:8082/SepLokalRest/rujukan/";
$nilai1=$norujuk;
$url= "".$ip."/$nilai1";
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER,
        array("Accept: application/json\r\n" . "X-cons-id: $consID\r\n" . "X-Timestamp: $timestamp\r\n" . "X-Signature: $encodedSignature"));
curl_setopt($curl, CURLOPT_GET, true);
#curl_setopt($curl, CURLOPT_POSTFIELDS, $content);

$json_response = curl_exec($curl);

#$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

curl_close($curl);

$response = json_decode($json_response, true);
$rest=$response[metaData]['message']; 
if($rest==200){
$diagnosa=$response[response]['item']['diagnosa']['kdDiag'];
echo $diagnosa;
}
else{
echo "error";
}
}
}
?>