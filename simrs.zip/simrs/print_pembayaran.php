 <?php
session_start ();
include 'include/connect.php';
include 'include/function.php';

$myquery = 'SELECT a.nomr AS NOMR, b.NAMA as pasien, a.TGLBAYAR, a.JAMBAYAR, a.TOTCOSTSHARING,a.JMBAYAR, a.UNIT, c.DEPARTEMEN AS nama_unit,d.NAMA as carabayar
			FROM t_bayarrajal a
			JOIN m_pasien b ON b.NOMR = a.NOMR
			JOIN m_login c ON c.KDUNIT = a.UNIT
			JOIN m_carabayar d ON d.KODE = a.CARABAYAR 
			WHERE a.NOMR = "' . $_REQUEST ['nomr'] . '"
			AND a.NOBILL = "' . $_REQUEST ['idxb'] . '"';
$get = mysql_query ( $myquery ) or die ( mysql_error () );
$userdata = mysql_fetch_assoc ( $get );
?>
<style type="text/css" media="screen">
#global_print {
	width: 500px;
}

#header {
	height: 30px;
	width: 100%;
}

#logo_cetak {
	float: left;
}

#title {
	float: left;
	width: 400px;
}

#kepada {
	float: left;
	width: 700px;
	font-size: 7pt;
}

#kepada .headfield {
	float: left;
	width: 150px;
}

#kepada .childhead {
	float: left;
	width: 10px;
}

#kepada .field {
	float: left;
	width: 100px;
}

#kepada .value {
	float: left;
	width: 200px;
}

#kuitansi {
	text-align: center;
	font-size: 7pt;
	font-weight: bold;
}

#no_kuitansi {
	text-align: left;
	font-size: 7pt;
}

table#table_list {
	width: 100%;
	font-size: 7pt;
	border-collapse: 0;
	border-spacing: 0px;
}

tr th {
	border-bottom: 1px dashed #000;
	border-top: 1px dashed #000;
}

#footer {
	width: 100%;
	font-size: 7pt;
}

#last_line {
	font-size: 7pt;
	font-style: inherit;
	width: 100%;
}
</style>
<style type="text/css" media="print">
#global_print {
	width: 500px;
}

#header {
	height: 30px;
	width: 100%;
}

#logo_cetak {
	float: left;
}

#title {
	float: left;
	width: 400px;
}

#kepada {
	float: left;
	width: 700px;
	font-size: 7pt;
}

#kepada .headfield {
	float: left;
	width: 150px;
}

#kepada .childhead {
	float: left;
	width: 10px;
}

#kepada .field {
	float: left;
	width: 100px;
}

#kepada .value {
	float: left;
	width: 200px;
}

#kuitansi {
	text-align: center;
	font-size: 7pt;
	font-weight: bold;
}

#no_kuitansi {
	text-align: left;
	font-size: 7pt;
}

table#table_list {
	width: 100%;
	font-size: 7pt;
	border-collapse: 0;
	border-spacing: 0px;
}

tr th {
	border-bottom: 1px dashed #000;
	border-top: 1px dashed #000;
}

#footer {
	width: 100%;
	font-size: 7pt;
}

#last_line {
	font-size: 7pt;
	font-style: inherit;
	width: 100%;
}
</style>
<div
	style="font-family: 'Lucida Console', Monaco, monospace; font-size: 7pt;">
	<div id="global_print"
		style="height: 550px; width: 580px; padding-left: 100px;">
		<div id="header">
			<br />
			<div id="logo_cetak">
				<!--<img src="img/logokotabogor.PNG" width="50px" />-->
			</div>
			<div id="title">
				<br />
				<div id="title1"><?=strtoupper($header1)?></div>
				<div id="title2"><?=strtoupper($header2)?></div>
				<div id="title3" style="font-size: 11px;"><?=$header3?></div>
				<div id="title4" style="font-size: 11px;"><?=$header4?></div>
			</div>
			<div id="kepada" style="padding-top: 10px; font-size: 7pt;">

				<div class="headfield">Sudah terima dari</div>
				<span class="childhead">:</span>
				<div class="value">
        		<?php
										$sql3 = mysql_query ( "SELECT PENANGGUNGJAWAB_NAMA 
        								   FROM t_pendaftaran 
        								   WHERE NOMR='" . $_REQUEST ['nomr'] . "' AND IDXDAFTAR=" . $_REQUEST ['idxdaftar'] );
										$data3 = mysql_fetch_array ( $sql3 );
										echo strtoupper ( $data3 ['PENANGGUNGJAWAB_NAMA'] );
										?>
        	</div>
				<br clear="all" />
				<div id="kepada2">
					<div class="headfield">Untuk Pembayaran</div>
					<span class="childhead">:</span>
					<div style="float: left;">Biaya Periksa/pengobatan dari pasien:</div>
				</div>
				<br clear="all" />
				<div id="kepada2">
					<div class="headfield">&nbsp;</div>
					<span class="childhead">&nbsp;</span>
					<div class="field">Nama</div>
					<span class="childhead">:</span>
					<div class="value"><?php echo strtoupper($userdata['pasien']);?></div>
				</div>
				<br clear="all" />
				<div id="kepada3">
					<div class="headfield">&nbsp;</div>
					<span class="childhead">&nbsp;</span>
					<div class="field">No.DM</div>
					<span class="childhead">:</span>
					<div class="value"><?php echo $_REQUEST['nomr'];?></div>
				</div>
				<br clear="all" />
				<div id="kepada4">
					<div class="headfield">&nbsp;</div>
					<span class="childhead">&nbsp;</span>
					<div class="field">Tanggal Bayar</div>
					<span class="childhead">:</span>
					<div class="value"><?php echo $userdata['TGLBAYAR'].' '.$userdata['JAMBAYAR'];?></div>
				</div>
				<br clear="all" />
				<div id="kepada4">
					<div class="headfield">&nbsp;</div>
					<span class="childhead">&nbsp;</span>
					<div class="field">Poli</div>
					<span class="childhead">:</span>
					<div class="value"><?php echo $userdata['nama_unit'];?></div>
				</div>
				<br clear="all" />
			</div>
		</div>
		<br clear="all" /> <br />
		<div id="kuitansi"></div>
		<div id="no_kuitansi"> No Transaksi : <?php echo $_REQUEST['idxb']; ?></div>
		<table id="table_list">
			<tr id="header_table">
				<th style="text-align: left; width: 100px;">Nama Jasa</th>
				<th style="width: 10px;">Qty</th>
				<th style="width: 70px;">Harga</th>
				<th style="width: 70px;">Diskon</th>
				<th style="width: 80px;">Total</th>
				<th style="width: 20px;">&nbsp;</th>
			</tr>
			<tbody style="height: 200px;">
	    <?php
//					$sql = mysql_query ( "SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.qty, b.TARIFRS, b.NOBILL, c.NAMADOKTER
//							FROM m_tarif2012 a, t_billrajal b
//							LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
//							WHERE a.kode_tindakan=b.KODETARIF
//							AND b.IDXDAFTAR='" . $_REQUEST ['idxdaftar'] . "' AND b.NOMR='".$_REQUEST['nomr']."'" );
                    $sql = mysql_query("SELECT DISTINCT b.NOBILL, b.qty,
                            a.TOTTARIFRS AS TARIFRS, c.NAMADOKTER, (SELECT KODETARIF FROM t_billrajal
                            WHERE NOBILL=a.NOBILL LIMIT 1) AS kode
							FROM t_bayarrajal a,t_billrajal b
							LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
							WHERE a.NOBILL=b.NOBILL
							AND b.IDXDAFTAR='" . $_REQUEST ['idxdaftar'] . "' AND b.NOMR='".$_REQUEST['nomr']."'" );
					$total = 0;
					while ( $data = mysql_fetch_array ( $sql ) ) {
                        $sql1 = mysql_query("select b.STATUS from t_billrajal a left join t_bayarrajal b ON b.NOBILL=a.NOBILL where a.KODETARIF='" . $data ['kode'] . "'");
                        $data1 = mysql_fetch_array($sql1);
                        if ($data1 ['STATUS'] == 'LUNAS') {
                            $st = "L";
                        } else if ($data1 ['STATUS'] == 'TRX') {
                            $st = "-";
                        }
                        $j = substr($data ['kode'], 0, 5);
                        $js = getGroupName($j);

                        if ($j == '02.03') {
                            $jasa = $js ['nama_gruptindakan'];
                        } elseif($j == '01.02'){
                            $js = getGroupName($data ['kode']);
                            $jasa = $js ['nama_tindakan'];
                        } else {
							$jasa = $js ['nama_tindakan'];
						}
						
						$sql5 = mysql_query ( "SELECT diskon FROM t_bayarrajal WHERE IDXDAFTAR=" . $_REQUEST ['idxdaftar'] . " AND NOBILL=" . $data ['NOBILL'] );
						$data5 = mysql_fetch_array ( $sql5 );
						
						echo '<tr style="height:10px;"><td>' . $jasa . '</td><td align="center">' . curformat($data ['qty']) . '</td><td align="right">Rp. ' . curformat ( $data ['TARIFRS'], 0 ) . '</td><td align="right">Rp.' . CurFormat ( $data5 ['diskon'] ) . ' </td><td align="right">Rp. ' . curformat ( ($data ['TARIFRS'] * $data ['qty']) - $data5 ['diskon'] ) . '</td><td align="right">' . $st . '</td></tr>';
						$total = $total + ($data ['TARIFRS'] * $data ['qty']) - $data5 ['diskon'];
					}
					$sql2 = mysql_query ( "SELECT SUM(TOTTARIFRS) as total from t_bayarrajal where IDXDAFTAR='" . $_REQUEST ['idxdaftar'] . "' and STATUS='LUNAS'" );
					$data2 = mysql_fetch_array ( $sql2 );
					$byr = $data2 ['total'];
					$kurang = $total - $data2 ['total'];
					if ($kurang < 0) {
						$byr = $byr + $kurang;
						$kurang = 0;
					}
					
					$sql4 = mysql_query ( "SELECT SUM(jaminan) AS jaminan FROM t_bayarrajal WHERE IDXDAFTAR=" . $_REQUEST ['idxdaftar'] . " AND STATUS='LUNAS'" );
					$data4 = mysql_fetch_array ( $sql4 );
					$jaminan = $data4 ['jaminan'];
					?>
		
	    <tr style="height: auto;">
					<td colspan="6"></td>
				</tr>
			</tbody>
			<tr>
				<td
					style="text-align: left; padding-right: 10px; border-top: 1px dashed #000;">&nbsp;</td>
				<td colspan="3"
					style="text-align: right; padding-right: 0px; border-top: 1px dashed #000; font-size: 7pt;">Total
					Biaya</td>
				<td style="border-top: 1px dashed #000; text-align: right;">Rp. <?php echo curformat($total); ?></td>
			</tr>
			<tr>
				<td colspan="4"
					style="text-align: right; padding-right: 0px; font-size: 7pt;">Total
					Yang Sudah dibayarkan</td>
				<td style="text-align: right;">
	   	  		Rp. <?php
									if ($_REQUEST ['subcrbyr'] == 4) {
										$total_bayar = 0;
										$getangsuran = get_t_angsuranrajal ( $_REQUEST ['idxdaftar'] );
										while ( $dataangsuran = mysql_fetch_array ( $getangsuran ) ) {
											$total_bayar = $total_bayar + $dataangsuran ['jmbayar'];
										}
										
										echo CurFormat ( $total_bayar );
									} else {
										echo curformat ( $byr );
									}
									?>
	   	  	</td>
			</tr>
			<tr>
				<td rowspan="4"
					style="text-align: left; padding-right: 10px; border-bottom: 1px dashed #000;"><em>Terbilang: <?php echo Terbilang($total);?> rupiah</em></td>
				<td colspan="3" style="text-align: right; font-size: 7pt;">Sisa
					Pembayaran</td>
				<td style="text-align: right;">
	      		Rp. <?php
									if ($_REQUEST ['subcrbyr'] == 4) {
										echo CurFormat ( getsisatarifrajal ( $_REQUEST ['idxdaftar'] ) );
									} else {
										echo curformat ( $kurang );
									}
									?>
	      	</td>
			</tr>
			<tr>
				<td colspan="3" style="text-align: right; font-size: 7pt;">Jumlah
					Tanggungan</td>
				<td style="text-align: right; font-size: 7pt;"><?php echo "Rp. " . CurFormat($jaminan); ?></td>
			</tr>
			<tr>
				<td colspan="3"
					style="text-align: right; padding-right: 0px; border-bottom: 1px dashed #000; font-size: 7pt;">Selisih</td>
				<td
					style="text-align: right; padding-right: 0px; border-bottom: 1px dashed #000; font-size: 7pt;"><?php echo "Rp. " . CurFormat($total - $jaminan); ?></td>
			</tr>
	    <?php if(!empty($userdata['TOTASKES']) > 0){ ?>
	    <!--<tr><td colspan="3" style="text-align:right; padding-right:10px;">Di Bayarkan Asuransi</td><td style="text-align:right;">Rp. <?php echo curformat($userdata['TOTASKES']); ?></td></tr>-->
	    <?php } ?>
	    <?php if(!empty($userdata['TOTCOSTSHARING']) > 0){ ?>
	    <!--<tr><td colspan="3" style="text-align:right; padding-right:10px;">Keringanan Biaya</td><td style="text-align:right;">Rp. <?php echo curformat($userdata['TOTCOSTSHARING']); ?></td></tr>-->
	    <?php } ?>
	    <?php if( (!empty($userdata['TOTASKES']) > 0) or (!empty($userdata['TOTCOSTSHARING']) > 0) ): ?>
	    <!--<tr><td colspan="3" style="text-align:right; padding-right:10px;">Sisa Yang Harus dibayarkan</td><td style="text-align:right;">Rp. <?php echo curformat($userdata['JMBAYAR']); ?></td></tr>-->
	    <?php endif; ?>
    </table>
		<div id="footer">
			<br />
			<div id="last_line" style="padding-top: 0px; margin: 0px;"> Dicetak : <?php echo datenow2(); ?></div>
			<div id="footer1" style="float: left; width: 300px; height: 100px;">
				<br />
			</div>
			<div id="footer2" style="float: left; width: 280px;">
				<div style="text-align: center; width: 100%;">Kasir</div>
				<br /> <br />
				<div style="text-align: center; width: 100%;">( <?php echo $_SESSION['NIP'];?> )</div>
			</div>
			<br clear="all" />
		</div>
	</div>
</div>
<?php
require_once ("dompdf/dompdf_config.inc.php");
$namafile = date ( 'Y-m-d' ) . '-' . $_REQUEST ['idxb'] . '-' . $userdata ['NOMR'];
$report = '
<table style="font-family:"Arial", Gadget, sans-serif;">
<tr><td>
    	<table id="header" style="height:100px; width:100%;">
		<tr>
		<td style="height:100px; width:100px;"></td>
		<td style="width:400px;">
        	<div id="title1">' . strtoupper ( $header1 ) . '</div>
            <div id="title2">' . strtoupper ( $header2 ) . '</div>
			<div id="title3" style="font-size:12px;">' . $header3 . '</div>
			<div id="title4" style="font-size:12px;">' . $header4 . '</div>
		</td><td style="padding-top:25px; font-size:12px; width:350px;">
        	<table width="100%">
            <tr><td colspan="2">Kepada Yth.</td></tr>
            <tr><td style="width:100px;">Nama Pasien</td><td>: ' . $userdata ['NAMA'] . '</td></tr>
            <tr><td style="width:100px;">No RM</td><td>: ' . $userdata ['NOMR'] . '</td></tr>
            <tr><td style="width:100px;">Tanggal Bayar</td><td>: ' . $userdata ['TGLBAYAR'] . ' ' . $userdata ['JAMBAYAR'] . '</td></tr>
			<tr><td style="width:100px;">Pembayaran</td><td>: ' . $userdata ['carabayar'] . '</td></tr>
            </table>
		</td></tr>
    	</table>
</td></tr>
<tr><td style="text-align:center; font-size:13px; font-weight:bold;">Kuitansi Pembayaran</td></tr>
<tr><td style="text-align:left; font-size:12px; font-weight:bold;">No Transaksi : ' . $_REQUEST ['idxb'] . '</td></tr>
<tr><td>
    	<table id="table_list" style="width:100%; font-size:12px; border-collapse:0; border-spacing:0px;" >
    	<tr id="header_table">
			<th style="border-bottom:1px dashed #000; border-top:1px dashed #000;">Nama Jasa</th>
			<th style="width:50px; border-bottom:1px dashed #000; border-top:1px dashed #000;">Qty</th>
			<th style="width:200px; border-bottom:1px dashed #000; border-top:1px dashed #000;">Tarif</th>
			<th style="width:100px; border-bottom:1px dashed #000; border-top:1px dashed #000;">Total</th>
		</tr>';
$sql = mysql_query ( "SELECT a.kode_tindakan AS kode, a.nama_tindakan AS nama_jasa, b.qty, b.TARIFRS,c.NAMADOKTER
FROM m_tarif2012 a, t_billrajal b 
LEFT JOIN m_dokter c ON c.KDDOKTER = b.KDDOKTER
WHERE a.kode_tindakan=b.KODETARIF 
AND b.NOBILL='" . $_REQUEST ['idxb'] . "'" );

$total = 0;
while ( $data = mysql_fetch_array ( $sql ) ) {
	$report .= '<tr style="height:20px;">
						<td>' . $data ['nama_jasa'] . ' &nbsp; &nbsp;( ' . $data ['NAMADOKTER'] . ' )</td>
						<td align="center">' . $data ['qty'] . '</td>
						<td align="right">Rp. ' . curformat ( $data ['TARIFRS'], 0 ) . '</td>
						<td align="right">Rp. ' . curformat ( $data ['TARIFRS'] * $data ['qty'] ) . '</td>
					</tr>';
	$total = $total + $data ['TARIFRS'] * $data ['qty'];
}
$report .= '<tr><td style="text-align:left; padding-right:10px; border-top:1px dashed #000;"><em>Terbilang: ' . Terbilang ( $total ) . ' rupiah</em></td><td colspan="2" style="text-align:right; padding-right:10px; border-top:1px dashed #000;">Total Yang Harus dibayarkan</td><td style="border-top:1px dashed #000; text-align:right;">Rp. ' . curformat ( $total ) . '</td></tr>';
// if($userdata['TOTCOSTSHARING'] > 0):
// $report .= '<tr><td colspan="3" style="text-align:right; padding-right:10px;">Keringanan Biaya</td><td style="text-align:right;">Rp. '.curformat($userdata['TOTCOSTSHARING']).'</td></tr>
// <tr><td colspan="3" style="text-align:right; padding-right:10px;">Sisa Yang Harus dibayarkan</td><td style="text-align:right;">Rp. '.curformat($userdata['JMBAYAR']).'</td></tr>';
// endif;

$report .= '</table>
		</td></tr>
<tr><td>
    	<table style="width:100%; font-size:12px; border-collapse:0; border-spacing:0px;">
        <tr><td style="width:400px; height:100px;">
        	<br />
		</td><td style="width:200px;">
			<div style="text-align:center; width:100%;">Kasir</div>
            <div style="text-align:center; width:100%; padding-top:70px;">( ' . $_SESSION ['NIP'] . ' )</div>
        </td></tr>
        </table>
    </td></tr>
    <tr><td style="font-size:12px; font-style:italic;">Dicetak oleh : ' . $_SESSION ['NIP'] . ' sebanyak [ 4 ] tanggal ' . date ( 'd/m/Y H:i:s' ) . '</td></tr>
</table>
';
$base = './pdf_pembayaran/';
$folder = date ( 'Ymd' );
$ext = '.pdf';
if (file_exists ( $base . $folder )) {
	$folder_simpan = $base . $folder;
	if (file_exists ( $folder_simpan . '/' . $namafile . $ext )) {
		$uniq = date ( 'His' );
		$filesave = $folder_simpan . '/' . $namafile . '_(' . $uniq . ')' . $ext;
	} else {
		$filesave = $folder_simpan . '/' . $namafile . $ext;
	}
} else {
	mkdir ( $base . $folder, 0777 );
	$folder_simpan = $base . $folder;
	$filesave = $folder_simpan . '/' . $namafile . $ext;
}
$dompdf = new DOMPDF ();
$dompdf->load_html ( $report );
$dompdf->set_paper ( "A5", "landscape" );
$dompdf->render ();
$pdf = $dompdf->output ();
file_put_contents ( $filesave, $pdf );
?>

<!-- added 03072015 -->
<script type="text/javascript">
	window.print();
</script>
<!-- added 03072015 -->