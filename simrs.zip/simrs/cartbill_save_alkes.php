<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 30/12/2015
 * Time: 9:54
 */

include 'include/connect.php';
include 'include/function.php';
#if(!empty($_REQUEST['kddokter'])){
if( ($_SESSION['KDUNIT'] != 19) and ($_SESSION['KDUNIT'] != 15) and ($_SESSION['KDUNIT'] != 27) ){
    //if($_SESSION['KDUNIT'] == 32){
    //	$u = $_REQUEST['poly'];
    //}else{
    $u = $_REQUEST['poly'];
    //}
    $nip = $_REQUEST['nip'] == "" ? $_SESSION['NIP'] : $_REQUEST['nip'];

    $sql2		= mysql_query("SELECT flag_pend FROM t_bayarrajal WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']." ORDER BY IDXBAYAR DESC");
    $data2		= mysql_fetch_array($sql2);
    $flagpend	= $data2['flag_pend'];

    /**
    pengurangan stok untuk alkes
     */
    $sql6       = mysql_query("SELECT * FROM tmp_cartbayar WHERE IP='".getRealIpAddr()."'");
    while($data6 = mysql_fetch_array($sql6)){
        $last_saldo     = $data6['saldo']-$data6['QTY'];
        mysql_query("INSERT INTO t_barang_stok(kode_barang,tanggal,keluar,saldo,KDUNIT)
                      VALUES(".$data6['kd_barang'].",NOW(),".$data6['QTY'].",".$last_saldo.",".$_SESSION['KDUNIT'].")");

        mysql_query("INSERT INTO t_pengeluaran_barang(NIP,KDUNIT,kodebarang,tglkeluar,jmlkeluar)
                      VALUES('".$nip."',".$_SESSION['KDUNIT'].",".$data6['kd_barang'].",NOW(),".$data6['QTY'].")");
    }

    $tarif = get_tarif_tmp_cartbayar(getRealIpAddr(), $_REQUEST['poly'], $_REQUEST['kddokter']);
    set_penambahan_tarif($_REQUEST['idxdaftar'], $_REQUEST['nomr'], $tarif);

//    mysql_query('CALL pr_savebill_tindakanrajal_tmpdokter("'.$_REQUEST['nomr'].'",1,"'.$_SESSION['NIP'].'","'.$_REQUEST['idxdaftar'].'","'.date("Y-m-d").'",0,0,"'.getRealIpAddr().'",'.$_REQUEST['carabayar'].','.$_REQUEST['poly'].',0,'.$u.')');
    mysql_query('CALL pr_savebill_lab("'.$_REQUEST['nomr'].'",1,"'.$nip.'","'.$_REQUEST['idxdaftar'].'","'.date("Y-m-d").'",0,0,"'.getRealIpAddr().'",'.$_REQUEST['carabayar'].','.$_REQUEST['poly'].',0,'.$u.')');

    //added and edited 10092015
    $sql1		= mysql_query("SELECT MAX(NOBILL) AS NOBILL, CARABAYAR, subcarabayar, idbank FROM t_bayarrajal WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']);
    $data1		= mysql_fetch_array($sql1);
    $nobill		= $data1['NOBILL'];
    $carabyr	= $data1['CARABAYAR'];
    $subcrbyr	= $data1['subcarabayar'];
    $idbank		= $data1['idbank'];

    if($carabyr == 11){
        $subsql1		= mysql_query("SELECT JASA_SARANA, JASA_PELAYANAN, TARIFRS FROM t_billrajal WHERE NOBILL=".$nobill);
        $datasql1		= mysql_fetch_array($subsql1);
        $tar_sarana		= $datasql1['JASA_SARANA'];
        $tar_pelayanan	= $datasql1['JASA_PELAYANAN'];
        $tarif			= $datasql1['TARIFRS'];

        $diskon				= 50 / 100;
        $tar_saranatemp		= $tar_sarana * $diskon;
        $tar_pelayanantemp	= $tar_pelayanan * $diskon;
        $tarif_temp			= $tar_saranatemp + $tar_pelayanantemp;

        mysql_query("UPDATE t_billrajal SET JASA_SARANA=".$tar_saranatemp.", JASA_PELAYANAN=".$tar_pelayanantemp.", TARIFRS=".$tarif_temp." WHERE NOBILL=".$nobill);
        mysql_query("UPDATE t_bayarrajal SET TOTTARIFRS=".$tarif_temp.", sisabayar=".$tarif_temp.", TOTJASA_SARANA=".$tar_saranatemp.", TOTJASA_PELAYANAN=".$tar_pelayanantemp." WHERE NOBILL=".$nobill);
    }

    if($subcrbyr == 2){
        $subsql1 	= mysql_query("SELECT MIN(IDXBAYAR) AS IDXBAYAR FROM t_bayarrajal WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']);
        $datasql1 	= mysql_fetch_array($subsql1);
        $IDXBAYAR 	= $datasql1['IDXBAYAR'];

        $subsql2 	= mysql_query("SELECT presentase FROM t_bayarrajal WHERE IDXBAYAR=".$IDXBAYAR);
        $datasql2 	= mysql_fetch_array($subsql2);
        $presentase	= $datasql2['presentase'];

        $subsql3 		= mysql_query("SELECT JASA_SARANA, JASA_PELAYANAN, TARIFRS, QTY FROM t_billrajal WHERE NOBILL=".$nobill);
        $datasql3 		= mysql_fetch_array($subsql3);
        $TOT_SARANA		= $datasql3['JASA_SARANA'];
        $TOT_PELAYANAN	= $datasql3['JASA_PELAYANAN'];
        $TOT_TARIFRS    = $datasql3['TARIFRS'];
        $qty            = $datasql3['QTY'];
        $TOTTARIFRS		= $TOT_TARIFRS * $qty;

        $presentase			= $presentase / 100;
        $TOT_SARANA_temp	= $TOT_SARANA * $presentase;
        $TOT_SARANA			= $TOT_SARANA + $TOT_SARANA_temp;
        $TOT_PELAYANAN_temp	= $TOT_PELAYANAN * $presentase;
        $TOT_PELAYANAN		= $TOT_PELAYANAN + $TOT_PELAYANAN_temp;
        $TOT_TARIFRS_temp   = $TOT_TARIFRS * $presentase;
        $TOT_TARIFRS        = $TOT_TARIFRS + $TOT_TARIFRS_temp;
        $TOTTARIFRS_temp    = $TOTTARIFRS * $presentase;
        $TOTTARIFRS         = $TOTTARIFRS + $TOTTARIFRS_temp;

        mysql_query("UPDATE t_billrajal SET JASA_SARANA=".$TOT_SARANA.", JASA_PELAYANAN=".$TOT_PELAYANAN.", TARIFRS=".$TOT_TARIFRS." WHERE NOBILL=".$nobill);
        mysql_query("UPDATE t_bayarrajal SET TOTTARIFRS=".$TOTTARIFRS.", sisabayar=".$TOTTARIFRS.", TOTJASA_SARANA=".$TOT_SARANA.", TOTJASA_PELAYANAN=".$TOT_PELAYANAN.", idbank=".$idbank." WHERE NOBILL=".$nobill);
    }
    else if($subcrbyr == 3){
        $subsql1 	= mysql_query("SELECT MIN(IDXBAYAR) AS IDXBAYAR FROM t_bayarrajal WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']);
        $datasql1 	= mysql_fetch_array($subsql1);
        $IDXBAYAR 	= $datasql1['IDXBAYAR'];

        $subsql2 	= mysql_query("SELECT presentase FROM t_bayarrajal WHERE IDXBAYAR=".$IDXBAYAR);
        $datasql2 	= mysql_fetch_array($subsql2);
        $presentase	= $datasql2['presentase'];

        $subsql3 		= mysql_query("SELECT JASA_SARANA, JASA_PELAYANAN, TARIFRS, QTY FROM t_billrajal WHERE NOBILL=".$nobill);
        $datasql3 		= mysql_fetch_array($subsql3);
        $TOT_SARANA		= $datasql3['JASA_SARANA'];
        $TOT_PELAYANAN	= $datasql3['JASA_PELAYANAN'];
        $TOT_SARANA		= $datasql3['JASA_SARANA'];
        $TOT_PELAYANAN	= $datasql3['TOTJASA_PELAYANAN'];
        $TOT_TARIFRS    = $datasql3['TARIFRS'];
        $qty            = $datasql3['QTY'];
        $TOTTARIFRS		= $TOT_TARIFRS * $qty;

        $presentase			= $presentase / 100;
        $TOT_SARANA_temp	= $TOT_SARANA * $presentase;
        $TOT_SARANA			= $TOT_SARANA + $TOT_SARANA_temp;
        $TOT_PELAYANAN_temp	= $TOT_PELAYANAN * $presentase;
        $TOT_PELAYANAN		= $TOT_PELAYANAN + $TOT_PELAYANAN_temp;
        $TOT_TARIFRS_temp   = $TOT_TARIFRS * $presentase;
        $TOT_TARIFRS        = $TOT_TARIFRS + $TOT_TARIFRS_temp;
        $TOTTARIFRS_temp    = $TOTTARIFRS * $presentase;
        $TOTTARIFRS         = $TOTTARIFRS + $TOTTARIFRS_temp;

        mysql_query("UPDATE t_billrajal SET JASA_SARANA=".$TOT_SARANA.", JASA_PELAYANAN=".$TOT_PELAYANAN.", TARIFRS=".$TOT_TARIFRS." WHERE NOBILL=".$nobill);
        mysql_query("UPDATE t_bayarrajal SET TOTTARIFRS=".$TOTTARIFRS.", sisabayar=".$TOTTARIFRS.", TOTJASA_SARANA=".$TOT_SARANA.", TOTJASA_PELAYANAN=".$TOT_PELAYANAN.", idbank=".$idbank." WHERE NOBILL=".$nobill);

        $subsql1	= mysql_query("SELECT TOTTARIFRS FROM t_bayarrajal WHERE NOBILL=".$nobill);
        $datasql1	= mysql_fetch_array($subsql1);
        $TOTTARIFRS	= $datasql1['TOTTARIFRS'];

        mysql_query("UPDATE t_bayarrajal SET TGLBAYAR=DATE(NOW()), JAMBAYAR=TIME(NOW()) , JMBAYAR=".$TOTTARIFRS.", sisabayar=".$TOTTARIFRS." , LUNAS=1, STATUS='LUNAS', idbank=".$idbank." WHERE NOBILL=".$nobill);
    }
    else if($subcrbyr == 4){
        if($flagpend == 1){
            $subsql2	= mysql_query("SELECT TOTTARIFRS FROM t_bayarrajal WHERE flag_pend=1 AND IDXDAFTAR=".$_REQUEST['idxdaftar']);
            $datasql2	= mysql_fetch_array($subsql2);
            $sisa 		= $datasql2['TOTTARIFRS'];
            $subsql3	= mysql_query("SELECT sisabayar FROM t_bayarrajal WHERE NOBILL=". $nobill);
            $datasql3	= mysql_fetch_array($subsql3);
            $sisabayar	= $datasql3['sisabayar'];

            $sisabayar	= $sisabayar - $sisa;

            mysql_query("UPDATE t_bayarrajal SET sisabayar=".$sisabayar." WHERE NOBILL=".$nobill);
        }
    }

    //added and edited 21092015
    $sql3 		= mysql_query("SELECT KODETARIF FROM t_billrajal WHERE IDXDAFTAR = ".$_REQUEST['idxdaftar']." AND NOBILL=".$nobill);
    $data3 		= mysql_fetch_array($sql3);
    $kodetarif	= $data3['KODETARIF'];

    $sql4 		= mysql_query("SELECT nama_tindakan FROM `m_tarif2012` WHERE kode_tindakan ='".$kodetarif."'");
    $data4 		= mysql_fetch_array($sql4);
    $tindakan	= $data4['nama_tindakan'];

    $sql5 		= mysql_query("SELECT * FROM t_diagnosadanterapi WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']);
    $data5 		= mysql_fetch_array($sql5);
    $icd_9 		= $data5['ICD_9'];

    if($icd_9 == ""){
        mysql_query("UPDATE t_diagnosadanterapi SET ICD_9='".$tindakan."' WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']);
    }
    else{
        for($i=2; $i<=30; $i++){
            if($data5['ICD_9'.$i] == ""){
                $ubah = mysql_query("UPDATE t_diagnosadanterapi SET ICD_9".$i."='".$tindakan."' WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']);
                if($ubah > 0){
                    $i = 30;
                }
            }
        }
    }
}else{
    $sql = 'select * from t_bayarranap where NOMR = "'.$_REQUEST['nomr'].'"	and IDXDAFTAR = "'.$_REQUEST['idxdaftar'].'"';
    $sql = mysql_query($sql);
    if(mysql_num_rows($sql) > 0){
        $data = mysql_fetch_array($sql);
        if($data['LUNAS'] == 0){
            $sql='CALL pr_savebill_ranap_add("'.$_REQUEST['nomr'].'",1,"'.$nip.'","'.$_REQUEST['idxdaftar'].'","'.date("Y-m-d").'",0,0,"'.getRealIpAddr().'",'.$_REQUEST['carabayar'].','.$_REQUEST['noruang'].',0,"'.$data['NOBILL'].'")';
            mysql_query($sql);
        }else{
            $sql='CALL pr_savebill_ranap("'.$_REQUEST['nomr'].'",1,"'.$nip.'","'.$_REQUEST['idxdaftar'].'","'.date("Y-m-d").'",0,0,"'.getRealIpAddr().'",'.$_REQUEST['carabayar'].','.$_REQUEST['noruang'].',"0")';
            mysql_query($sql);
        }
    }else{
        $sql='CALL pr_savebill_ranap("'.$_REQUEST['nomr'].'",1,"'.$nip.'","'.$_REQUEST['idxdaftar'].'","'.date("Y-m-d").'",0,0,"'.getRealIpAddr().'",'.$_REQUEST['carabayar'].','.$_REQUEST['noruang'].',"0")';
        mysql_query($sql);
    }
}