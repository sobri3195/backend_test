<?php
	//include('tcpdf.php');
	include "include/PDF.php";
	
	if(isset($_REQUEST['idx']) && isset($_REQUEST['poly'])){
		include("include/connect.php");
		
		$idx	= $_REQUEST['idx'];
		$poly	= $_REQUEST['poly'];
		$sql	= 	'select t_pendaftaran.NOMR, 
						m_pasien.nama as pasien, 
						m_poly.nama as poly, 
						m_carabayar.nama as carabayar,
						t_pendaftaran.NIP, 
						t_pendaftaran.PASIENBARU, 
						t_pendaftaran.KDDOKTER, 
						t_pendaftaran.KDPOLY,
						m_dokter.NAMADOKTER, 
						NOW() AS now,
						t_pendaftaran.KETBAYAR,
						m_pasien.nomr_old,
						t_pendaftaran.kode_p,
						t_pendaftaran.kode_t,
						t_pendaftaran.TGLREG,
						t_pendaftaran.NIP AS user
					from t_pendaftaran
					join m_pasien on t_pendaftaran.NOMR = m_pasien.NOMR
					join m_poly on m_poly.kode = t_pendaftaran.KDPOLY
					join m_carabayar on m_carabayar.KODE = t_pendaftaran.KDCARABAYAR
					JOIN m_dokter on m_dokter.KDDOKTER=t_pendaftaran.KDDOKTER
					where t_pendaftaran.KDPOLY ='.$poly.' and t_pendaftaran.IDXDAFTAR="'.$idx.'"';
		$res	= mysql_query($sql) or die(mysql_error());
		$a		= mysql_num_rows($res);
		$data	= mysql_fetch_array($res);
		
		if($data['KDPOLY'] == 53){
			$sql_nourut = 'SELECT * FROM 
					(SELECT (@row:=@row+1) AS row,
									NOMR
					FROM `t_pendaftaran`, (SELECT @row := 0) r 
					WHERE KDPOLY = "'.$data['KDPOLY'].'"
						AND TGLREG = "'.$data['TGLREG'].'"
						AND kode_p = 0
					ORDER BY IDXDAFTAR) AS EMP
					WHERE NOMR = "'.$data['NOMR'].'";';
		} else if($data['KDPOLY'] == 47){
			$sql_nourut = 'SELECT * FROM 
					(SELECT (@row:=@row+1) AS row,
									NOMR
					FROM `t_pendaftaran`, (SELECT @row := 0) r 
					WHERE KDPOLY = "'.$data['KDPOLY'].'"
						AND TGLREG = "'.$data['TGLREG'].'"
						AND kode_p = 0
					ORDER BY IDXDAFTAR) AS EMP
					WHERE NOMR = "'.$data['NOMR'].'";';
		} else if($data['KDPOLY'] == 52){
			$sql_nourut = 'SELECT * FROM 
					(SELECT (@row:=@row+1) AS row,
									NOMR
					FROM `t_pendaftaran`, (SELECT @row := 0) r 
					WHERE KDPOLY = "'.$data['KDPOLY'].'"
						AND TGLREG = "'.$data['TGLREG'].'"
						AND kode_p = 0
					ORDER BY IDXDAFTAR) AS EMP
					WHERE NOMR = "'.$data['NOMR'].'";';
		} else if($data['KDPOLY'] == 31){
			$sql_nourut = 'SELECT * FROM 
					(SELECT (@row:=@row+1) AS row,
									NOMR
					FROM `t_pendaftaran`, (SELECT @row := 0) r 
					WHERE KDPOLY = "'.$data['KDPOLY'].'"
						AND TGLREG = "'.$data['TGLREG'].'"
						AND kode_p = 0
					ORDER BY IDXDAFTAR) AS EMP
					WHERE NOMR = "'.$data['NOMR'].'";';
		} else{
			$sql_nourut = 'SELECT * FROM 
					(SELECT (@row:=@row+1) AS row,
									NOMR
					FROM `t_pendaftaran`, (SELECT @row := 0) r 
					WHERE KDPOLY = "'.$data['KDPOLY'].'"
						AND KDDOKTER = "'.$data['KDDOKTER'].'"
						AND TGLREG = "'.$data['TGLREG'].'"
						AND kode_p = 0
					ORDER BY IDXDAFTAR) AS EMP
					WHERE NOMR = "'.$data['NOMR'].'";';
		}
		$rs_nourut  = mysql_query($sql_nourut);
		$row_nourut = mysql_fetch_array($rs_nourut);
		$nourut	    = $row_nourut['row'];
		
		$kode   = "";
		$kode  .= $data['kode_p'] > 0 ? "KODE P" : '';
		$kode  .= $data['kode_t'] > 0 ? "KODE T" : '';
		
		if($data['PASIENBARU'] == 0){
			$tpbtemp = 'L';
		}else{
			$tpbtemp = 'B';
		}
		
		$params = array(
			'nama'       => $data['pasien'],
			'tanggal'    => date('d-m-Y', strtotime(str_replace('/','-',$data['now'])))." ".substr($data['now'],11),
			'no_mr_baru' => $data['NOMR'],
			'cara_bayar' => $data['carabayar'],
			'tujuan'     => $data['poly'],
			'no_mr_lama' => $data['nomr_old'],
			'dokter'     => $data['NAMADOKTER'],
			'kode'       => $kode,
			'nourut'	 => $nourut,
			'tbp'		 => $tpbtemp,
			'nip'		 => $data['user'],
			'register'	 => $_REQUEST['idx']
		);
	}else{
		die('IDXDAFTAR && POLY TIDAK ADA!!!');
	}
	
		
    class Tracer_PDF extends TCPDF{
        function print_tracer($nama, $tanggal, $no_mr_baru, $cara_bayar, $tujuan, $no_mr_lama, $dokter, $kode, $nourut, $tbp, $nip, $register){
            $border = 0;          

            //MultiCell($w, $h, $txt, $border=0, $align='J', $fill=false, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0, $valign='T', $fitcell=false)
            $this->MultiCell(5, 0, '<strong>T R A C E R</strong>', $border, 'C', false, 0, '', '', true, 0, true, true, 0, 'T', false );
            $this->MultiCell(3, 0, '<strong>(' . $tbp . ')</strong>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
            $this->MultiCell(8, 0, '<font style="font-size:20pt;"><b>'.$no_mr_baru.'</b></font>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
            // Tabel
			// w,h,text,border,ln,align,fill,link,strecth,ignoremin_high, calign,valign
            $this->Cell(1.8, 0, 'No Urut', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $nourut, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'NAMA', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $nama, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'TANGGAL', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $tanggal, $border, 1, 'L', 0, '', 0);

			$this->Cell(1.8, 0, 'CARA BAYAR', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $cara_bayar, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'TUJUAN', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $tujuan, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'NOMR LAMA', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $no_mr_lama, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'DOKTER', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $dokter, $border, 1, 'L', 0, '', 0);
			
			if(!empty($kode)){
				$this->Cell(1.8, 0, 'KODE', $border, 0, 'L', 0, '', 0);
				$this->Cell(3, 0, " : " . $kode, $border, 1, 'L', 0, '', 0);
			}

			$this->MultiCell(7.4, 0, '<b>--- '. $nip . ' ---</b>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
		
			// set style for barcode
			$style = array(
//				'border' => false,
//				'padding' => 0,
//				'fgcolor' => array(0,0,0),
//				'bgcolor' => false
                'position' => '',
                'align' => 'C',
                'stretch' => false,
                'fitwidth' => true,
                'cellfitalign' => '',
                'border' => true,
                'hpadding' => 'auto',
                'vpadding' => 'auto',
                'fgcolor' => array(0,0,0),
                'bgcolor' => false, //array(255,255,255),
                'text' => true,
                'font' => 'helvetica',
                'fontsize' => 8,
                'stretchtext' => 4
			);

			// write RAW 2D Barcode
//			$this->write2DBarcode($register."\x0D", 'QRCODE,H', 2.8, 9.8, 2, 2, $style, 'N');
//			$this->MultiCell(0, 0, '<b>'. $register . '</b>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );

            // Write RAW 1D Barcode
            $this->write1DBarcode($register, 'C39', 1.1, 9.8, 5.5, 2.5, 0.4, $style, 'N');
        }
		
		function print_bukti_daftar($nama, $tanggal, $no_mr_baru, $cara_bayar, $tujuan, $no_mr_lama, $dokter, $kode, $nourut, $tbp, $nip){
            $border = 0;          

            //MultiCell($w, $h, $txt, $border=0, $align='J', $fill=false, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0, $valign='T', $fitcell=false)
            $this->MultiCell(5, 0, '<strong>BUKTI DAFTAR</strong>', $border, 'C', false, 0, '', '', true, 0, true, true, 0, 'T', false );
            $this->MultiCell(3, 0, '<strong>( B )</strong>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
            $this->MultiCell(8, 0, '<font style="font-size:20pt;"><b>'.$no_mr_baru.'</b></font>', $border, 'C', false, 1, '', '', true, 0, true, 0, 0, 'T', false );
            // Tabel
			// w,h,text,border,ln,align,fill,link,strecth,ignoremin_high, calign,valign
            $this->Cell(1.8, 0, 'No Urut', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $nourut, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'NAMA', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $nama, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'TANGGAL', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $tanggal, $border, 1, 'L', 0, '', 0);

			$this->Cell(1.8, 0, 'CARA BAYAR', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $cara_bayar, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'TUJUAN', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $tujuan, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'NOMR LAMA', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $no_mr_lama, $border, 1, 'L', 0, '', 0);
			
			$this->Cell(1.8, 0, 'DOKTER', $border, 0, 'L', 0, '', 0);
            $this->Cell(3, 0, " : " . $dokter, $border, 1, 'L', 0, '', 0);
			
			if(!empty($kode)){
				$this->Cell(1.8, 0, 'KODE', $border, 0, 'L', 0, '', 0);
				$this->Cell(3, 0, " : " . $kode, $border, 1, 'L', 0, '', 0);
			}
			
			$this->MultiCell(7.4, 0, '<b>--- '. $nip . ' ---</b>', $border, 'C', false, 1, '', '', true, 0, true, true, 0, 'T', false );
        }
    }

	// Ukuran kertas (panjang x lebar)
	$STICKER_3x10_SIZE = array(7.7, 13.5);

	// Create new PDF document
	$pdf = new Tracer_PDF('P', 'cm', $STICKER_3x10_SIZE, true, 'UTF-8', false);

	// set document information
	$PDF_CREATOR  = "SIMRS RSUD Kota Bogor";
	$PDF_AUTHOR   = "Ahmad Isyfalana Amin & Fernalia";
	$TITLE        = 'Tracer Pasien';
	$SUBJECT      = "Pendaftaran RSUD Kota Bogor";
	$PDF_KEYWORDS = "SIMRS Tracer";

    $pdf->SetCreator($PDF_CREATOR);
    $pdf->SetAuthor($PDF_AUTHOR);
    $pdf->SetTitle($TITLE);
    $pdf->SetSubject($SUBJECT);
    $pdf->SetKeywords($PDF_KEYWORDS);

    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

	// set font
	$pdf->SetFont('courier', '', 9.5);
	$pdf->setFontSpacing(0);
	$pdf->SetMargins(0.25,0,0,false);
	$pdf->SetAutoPageBreak(true, 1);
	$pdf->SetCellPadding(0.25);

	$pdf->AddPage();
	$pdf->print_tracer(
		$params['nama'],
		$params['tanggal'],
		$params['no_mr_baru'],
		$params['cara_bayar'],
		$params['tujuan'],
		$params['no_mr_lama'],
		$params['dokter'],
		$params['kode'],
		$params['nourut'],
		$params['tbp'],
		$params['nip'],
		$params['register']
	);

    $pdf->AddPage();
    $pdf->print_tracer(
        $params['nama'],
        $params['tanggal'],
        $params['no_mr_baru'],
        $params['cara_bayar'],
        $params['tujuan'],
        $params['no_mr_lama'],
        $params['dokter'],
        $params['kode'],
        $params['nourut'],
        $params['tbp'],
        $params['nip'],
        $params['register']
    );
	/*$pdf->AddPage();
	$pdf->print_bukti_daftar(
		$params['nama'],
		$params['tanggal'],
		$params['no_mr_baru'],
		$params['cara_bayar'],
		$params['tujuan'],
		$params['no_mr_lama'],
		$params['dokter'],
		$params['kode'],
		$params['nourut']
	);*/
	
	$pdf->lastPage();
	//Close and output PDF document
	$nama_file = "tracer_" . $params['no_mr_baru'] . '_' .date('Ymd') . '.pdf';
	$pdf->Output($nama_file, 'I');
	
	