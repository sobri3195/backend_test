<script language="javascript" type="text/javascript" src="js/jquery.PrintArea.js"></script>
<script language="javascript">
    include("include/function.php");
//    parent.window.location.reload();
    function printIt()
    {
        content=document.getElementById('print_selection');
        w=window.open('about:blank');
        w.document.writeln("<? session_start(); ?>");
        w.document.writeln("<link href='dq_sirs.css' type='text/css' rel='stylesheet' />");
        w.document.write( content.innerHTML );
        w.document.writeln("<? $var = $_SESSION['cetak']; ?>");
        w.document.writeln("<script>");
        w.document.writeln("window.print()");
        w.document.writeln("</"+"script>");
    }
</script>
<script language="javascript" type="text/javascript">
    function jumpTo (link)
    {
        var new_url=link;
        if (  (new_url != "")  &&  (new_url != null)  )
            window.location=new_url;
    }
    function terbilangnya(bilangan) {
        bilangan    = String(bilangan);
        var angka   = ['0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'];
        var kata    = ['','Satu','Dua','Tiga','Empat','Lima','Enam','Tujuh','Delapan','Sembilan'];
        var tingkat = ['','Ribu','Juta','Milyar','Triliun'];

        var panjang_bilangan = bilangan.length;

        /* pengujian panjang bilangan */
        if (panjang_bilangan > 15) {
            kaLimat = "Diluar Batas";
            return kaLimat;
        }

        /* mengambil angka-angka yang ada dalam bilangan, dimasukkan ke dalam array */
        for (i = 1; i <= panjang_bilangan; i++) {
            angka[i] = bilangan.substr(-(i),1);
        }

        i = 1;
        j = 0;
        kaLimat = "";


        /* mulai proses iterasi terhadap array angka */
        while (i <= panjang_bilangan) {

            subkaLimat = "";
            kata1 = "";
            kata2 = "";
            kata3 = "";

            /* untuk Ratusan */
            if (angka[i+2] != "0") {
                if (angka[i+2] == "1") {
                    kata1 = "Seratus";
                } else {
                    kata1 = kata[angka[i+2]] + " Ratus";
                }
            }

            /* untuk Puluhan atau Belasan */
            if (angka[i+1] != "0") {
                if (angka[i+1] == "1") {
                    if (angka[i] == "0") {
                        kata2 = "Sepuluh";
                    } else if (angka[i] == "1") {
                        kata2 = "Sebelas";
                    } else {
                        kata2 = kata[angka[i]] + " Belas";
                    }
                } else {
                    kata2 = kata[angka[i+1]] + " Puluh";
                }
            }

            /* untuk Satuan */
            if (angka[i] != "0") {
                if (angka[i+1] != "1") {
                    kata3 = kata[angka[i]];
                }
            }

            /* pengujian angka apakah tidak nol semua, lalu ditambahkan tingkat */
            if ((angka[i] != "0") || (angka[i+1] != "0") || (angka[i+2] != "0")) {
                subkaLimat = kata1+" "+kata2+" "+kata3+" "+tingkat[j]+" ";
            }

            /* gabungkan variabe sub kaLimat (untuk Satu blok 3 angka) ke variabel kaLimat */
            kaLimat = subkaLimat + kaLimat;
            i = i + 3;
            j = j + 1;

        }

        /* mengganti Satu Ribu jadi Seribu jika diperlukan */
        if ((angka[5] == "0") && (angka[6] == "0")) {
            kaLimat = kaLimat.replace("Satu Ribu","Seribu");
        }

        return kaLimat + "Rupiah";
    }

    function isibayar(kondisi){
        if (kondisi) {
            document.getElementById("jumlah_dibayar").value=document.getElementById("tanda_terimah").value;
            document.getElementById('terbilang').value=terbilangnya(document.getElementById("tanda_terimah").value);
        }
        else {
            document.getElementById("jumlah_dibayar").value="";
            document.getElementById('terbilang').value="";
        }
    }
    function isiterbilangnya(s){
        document.getElementById('terbilang').value=terbilangnya(s);
    }
</script>

<script type="text/javascript">
    function popUp(URL) {
        day = new Date();
        id = 'keringanan';
        eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=1000,height=400,left=50,top=50');");
    }

    jQuery(document).ready(function(){
        jQuery('#label_bayar').hide();
        jQuery('#bayarsisa').hide();
        jQuery('#btn_bayarsisa').hide();
        jQuery('#bayarsisa').attr('disabled','disabled');
        jQuery('#btn_bayarsisa').attr('disabled','disabled');
        jQuery('#subcarabayar').hide();
        jQuery('#label_subcarabayar').hide();
        jQuery('#btnSubcarabayar').show();
        jQuery('#subcarabayar').val(0);
        jQuery('#label_keterangan').hide();
        jQuery('#idbank').hide();
        jQuery('#idbank').val(0);
        start();

        function start(){
            var nomr		= jQuery('#nomr').val();
            var idxdaftar	= jQuery('#idxdaftar').val();
            jQuery.post('<?php echo _BASE_; ?>include/cari_pasien.php',{NOMR:nomr,IDXDAFTAR:idxdaftar,pilihan:1},function(data){
                var json	= JSON.parse(data);
                if(json.CARABAYAR == 1){
                    jQuery.post('<?php echo _BASE_; ?>include/cari_pasien.php',{NOMR:nomr,IDXDAFTAR:idxdaftar,pilihan:0},function(data){
                        var json2	= JSON.parse(data);
                        if(json2.subcarabayar > 0){
                            jQuery('#subcarabayar').val(json.presentase);
                            jQuery('.carabayarumum').val(json.subcarabayar);
                            jQuery('#idbank').val(json.idbank);
                            restart();
                            if(json2.subcarabayar == 2){
                                jQuery('#subcarabayar').show();
                                jQuery('#idbank').show();
                                jQuery('#label_subcarabayar').show();
                                jQuery('#label_keterangan').show();
                            }
                            else if(json2.subcarabayar == 3){
                                jQuery('#subcarabayar').show();
                                jQuery('#idbank').show();
                                jQuery('#label_subcarabayar').show();
                                jQuery('#label_keterangan').show();
                            }
                            else if(json2.subcarabayar == 4){
                                jQuery('#bayarsisa').removeAttr('disabled');
                                jQuery('#btn_bayarsisa').removeAttr('disabled');
                                jQuery('#label_bayar').show();
                                jQuery('#bayarsisa').show();
                                jQuery('#btn_bayarsisa').show();
//                                jQuery.post('<?php //echo _BASE_;?>//include/cari_pasien.php',{NOMR:nomr,IDXDAFTAR:idxdaftar,pilihan:3},function(data){
//                                    jQuery('#totbelumbayar').val("Rp. "+ data);
//                                });
                            }
                            jQuery('#btnSubcarabayar').hide();
                        }
                        else{
                            jQuery('.bayar').attr('disabled','disabled');
                            jQuery('.cancel').attr('disabled','disabled');
                            jQuery('.printpertindakan').attr('disabled','disabled');
                            jQuery('.print').attr('disabled','disabled');
                            jQuery('.shift').attr('disabled','disabled');
                        }
                    });
                }

//                jQuery.post('<?php //echo _BASE_; ?>//include/cari_pasien.php',{NOMR:nomr,IDXDAFTAR:idxdaftar,pilihan:0},function(data){
//                    var json2	= JSON.parse(data);
//
//                    if(json2.subcarabayar == 4){
//                        jQuery('#bayarsisa').removeAttr('disabled');
//                        jQuery('#btn_bayarsisa').removeAttr('disabled');
//                        jQuery('#label_bayar').show();
//                        jQuery('#bayarsisa').show();
//                        jQuery('#btn_bayarsisa').show();
//                        jQuery.post('<?php //echo _BASE_;?>//include/cari_pasien.php',{NOMR:nomr,IDXDAFTAR:idxdaftar,pilihan:3},function(data){
//                            jQuery('#totbelumbayar').val("Rp. "+ data);
//                        });
//                    }
//                });
            });
        }

        function restart(){
            jQuery('.bayar').removeAttr('disabled');
            jQuery('.cancel').removeAttr('disabled');
            jQuery('.printpertindakan').removeAttr('disabled');
            jQuery('.print').removeAttr('disabled');
            jQuery('.shift').removeAttr('disabled');
        }

        jQuery('.bayar').click(function(){
            var nomr		= jQuery('#nomr').val();
            var idxdaftar	= jQuery(this).attr('rel');
            var idxbayar	= jQuery(this).attr('svn');
            var idxdft		= jQuery(this).attr('idxd');
            var shif		= jQuery('#shift_'+idxdaftar).val();
            var tbp			= jQuery('#tbp_'+idxdaftar).val();
            var total		= jQuery('#hiden_total_bayar_'+idxdaftar).val();
            var carabayar	= jQuery('#carabayar').val();
            var keringanan	= jQuery('#hiden_keringanan_'+idxdaftar).val();
            var alasan		= jQuery('#hiden_alasan_'+idxdaftar).val();
            var shif_ket    = "";
            var crbyr		= jQuery('.carabayarumum').val();
            /*
             if(tbp == ''){
             alert('No TBP belum diisi');
             return false;
             }
             */
            //alert(idxdft);

            if(shif == ''){
                alert('Shift belum dipilih');
                return false;
            }

            jQuery.post('<?php echo _BASE_; ?>include/process.php?idxb='+idxbayar+'&idxdaftar='+idxdaftar,{SHIFT:shif,tbp:tbp,total:total,carabayar:carabayar,alasan:alasan,keringanan:keringanan,crbyr:crbyr},function(data){
                if(data == 'ok'){
                    //var btn	= '<input type="button" name="Print" value="Print" class="text print" id="'+idxdaftar+'" svn="'+idxbayar+'"/>';
                    //jQuery('#bayar_'+idxdaftar).attr('disabled','disabled');
                    jQuery('#bayar_'+idxdaftar).hide();
                    jQuery('#print_'+idxdaftar).css({'display':'inline','float':'right'});
                    jQuery('#shift_'+idxdaftar).hide();
                    jQuery('#cancel_'+idxdaftar).hide();
                    jQuery('#tbp_'+idxdaftar).hide();

                    /* added 08072015 */
                    if(shif == 1){
                        shif_ket = "Pagi";
                    }
                    else{
                        shif_ket = "Sore";
                    }

                    jQuery('#text_shift_'+idxdaftar).empty().append(shif_ket);
                    /* added 08072015 */

                    jQuery('#text_tbp_'+idxdaftar).empty().append(tbp);

                }else{
                    alert('Lost Connection');
                    return false;
                }

//                if(crbyr == 4){
                    jQuery.post('<?php echo _BASE_;?>include/cari_pasien.php',{NOMR:nomr,IDXDAFTAR:idxdft,pilihan:3},function(data){
                        jQuery('#totbelumbayar').val("Rp. "+ data);
                    });
//                }
//                else{
//                    //jQuery('#callback_'+idxdaftar).empty().html(data);
//                    jQuery.post('<?php //echo _BASE_ ?>//include/pembayaranpasien.php',{idxdaftar:idxdft}, function(data){
//                        jQuery('#totbelumbayar').val("Rp. "+ data +",00");
//                    });
//                }
            });
        });
        /*jQuery('.print').click(function(){
         var idxdaftar	= jQuery(this).attr('rel');
         var idxbayar	= jQuery(this).attr('svn');
         jQuery.get('<?php echo _BASE_; ?>print_pembayaran.php?idxb='+idxbayar+'&idxdaftar='+idxdaftar+'&nomr=<?php echo $_REQUEST['nomr']; ?>',function(data){
         jQuery('#tmp_print').empty().html(data);
         w=window.open();
         //w.document.write(jQuery('#show_print').html());
         w.document.write(jQuery('#tmp_print').html());
         w.print();
         //w.close();
         //jQuery('#show_print').empty();
         });
         });*/
        jQuery('#retribusi').change(function(){
            if(jQuery(this).val() != ''){
                var nomr		= jQuery('#nomr').val();
                var idxdaftar	= jQuery('#idxdaftar').val();
                var carabayar	= jQuery('#carabayar').val();
                var poly		= jQuery('#poly').val();
                popUp('daftar_tindakan_poly.php?nomr='+nomr+'&idx='+idxdaftar+'&carabayar='+carabayar+'&poly='+poly);
            }
        });
        jQuery('.tindakan').click(function(){
            var nomr		= jQuery('#nomr').val();
            var idxdaftar	= jQuery('#idxdaftar').val();
            var carabayar	= jQuery('#carabayar').val();
            var poly		= jQuery(this).attr('id');

            /* added 06072015 */
//            var poly        = document.getElementById('poly_id').value;
//            console.log(poly);
            /* added 06072015 */

            popUp('daftar_tindakan_poly.php?nomr='+nomr+'&idx='+idxdaftar+'&carabayar='+carabayar+'&poly='+poly);
        });
        jQuery('.cancel').click(function(){
            var nobill = jQuery(this).attr('svn');
            var nomr		= jQuery('#nomr').val();
            var kode	= jQuery(this).attr('kode');
            var idxdaftar = jQuery(this).attr('idxdaftar');
            //cancel
            jQuery.post('<?php echo _BASE_;?>cartbill_pembayaran_batal.php',{nobill:nobill,nomr:nomr,kode:kode,idxdaftar:idxdaftar},function(data){
                jQuery('#tmp_print').empty().html(data);
                w=window.open();
                w.document.write(jQuery('#tmp_print').html());
                w.print();
                w.close();
                location.reload();
            });
        });

        //added 11082015
        jQuery('.printpertindakan').click(function(){
            var nobill		= jQuery(this).attr('nobill');
            var nomr		= jQuery('#nomr').val();
            var kode		= jQuery(this).attr('kode');
            var idxdaftar	= jQuery(this).attr('idxdaftar');
            var pilih		= jQuery(this).attr('pilih');

            window.open('print_pembayaran_pertindakan.php?idxdaftar='+idxdaftar+'&nomr='+nomr+'&kode='+kode+'&nobill='+nobill+'&pilihan='+pilih);
        });
        //added 11082015

        jQuery('.link_detail').click(function(){
            var bill = jQuery(this).attr('id');
            var tarif = jQuery(this).attr('detail');
            var active = jQuery('#d'+bill).attr('show');
            if(active == 'show'){
                jQuery('#d'+bill).empty().attr('show','hide');
            }else{
                jQuery.post('<?php echo _BASE_;?>include/ajaxload.php',{nobill:bill,view_detail_bill:true,kode_tarif:tarif},function(data){
                    jQuery('#d'+bill).empty().html(data).attr('show','show');
                });
            }
        });
        jQuery('.form_keringanan').click(function(){
            var nobill = jQuery(this).attr('id');
            popUp('form_keringanan_rajal.php?nobill='+nobill);
        });

        jQuery('#masuk').click(function(){
            var nomr = jQuery('#nomr').val();
            var idxdaftar = jQuery('#idxdaftar').val();
            var dokter	= jQuery('#dokterpelaksana').val();
            jQuery.post('<?php echo _BASE_;?>rajal/valid_keluar-masuk.php',{Masuk:'Masuk', NOMR:nomr, IDXDAFTAR2:idxdaftar, dokter:dokter},function(data){
                alert(data);																																			});
        });

        //added 21082015
        jQuery('.carabayarumum').click(function(){
            var val	= jQuery('.carabayarumum').val();
            if(val == 2){
                jQuery('#label_bayar').hide();
                jQuery('#bayarsisa').hide();
                jQuery('#btn_bayarsisa').hide();
                jQuery('#subcarabayar').show();
                jQuery('#idbank').show();
                jQuery('#label_subcarabayar').show();
                jQuery('#btnSubcarabayar').show();
                jQuery('#subcarabayar').val(0);
                jQuery('#label_keterangan').show();
            }
            else if(val == 3){
                jQuery('#label_bayar').hide();
                jQuery('#bayarsisa').hide();
                jQuery('#btn_bayarsisa').hide();
                jQuery('#idbank').show();
                jQuery('#subcarabayar').show();
                jQuery('#label_subcarabayar').show();
                jQuery('#btnSubcarabayar').show();
                jQuery('#label_keterangan').show();
            }
            else if(val == 4){
                jQuery('#label_bayar').show();
                jQuery('#bayarsisa').show();
                jQuery('#btn_bayarsisa').show();
                jQuery('#subcarabayar').hide();
                jQuery('#label_subcarabayar').hide();
                jQuery('#btnSubcarabayar').show();
                jQuery('#label_keterangan').hide();
                jQuery('#idbank').hide();
            }
            else{
                jQuery('#label_bayar').hide();
                jQuery('#bayarsisa').hide();
                jQuery('#btn_bayarsisa').hide();
                jQuery('#subcarabayar').hide();
                jQuery('#label_subcarabayar').hide();
                jQuery('#btnSubcarabayar').show();
                jQuery('#label_keterangan').hide();
                jQuery('#idbank').hide();
            }
        });

        jQuery('#btnSubcarabayar').click(function(){
            var nomr 			= jQuery('#nomr').val();
            var idxdaftar 		= jQuery('#idxdaftar').val();
            var carabayarumum	= jQuery('.carabayarumum').val();
            var subcarabayar	= jQuery('#subcarabayar').val();
            var pengguna		= "pembayaran";

            if(carabayarumum == 2 || carabayarumum == 3){
                var idbank		= jQuery('#idbank').val();
            }
            else{
                var idbank		= 0;
            }

            //alert(idbank);
            jQuery.post('<?php echo _BASE_; ?>include/updatesubcarabayar.php',{NOMR:nomr, IDXDAFTAR:idxdaftar, kdsubcarabayar:carabayarumum, presentase:subcarabayar, idbank:idbank, pengguna:pengguna}, function(data){
                alert("Berhasil di update");
                location.reload();
                restart();
            });
        });
        //added 21082015

        //added 28082015
        jQuery('#btn_bayarsisa').click(function(){
            var nomr 				= jQuery('#nomr').val();
            var idxdaftar 			= jQuery('#idxdaftar').val();
            var totalygdibayarkan	= jQuery('#bayarsisa').val();
            var pengguna		= "pembayaran";

            jQuery.post('<?php echo _BASE_; ?>include/cari_pasien.php',{NOMR:nomr, IDXDAFTAR:idxdaftar, totalygdibayarkan:totalygdibayarkan, pengguna:pengguna, pilihan:2}, function(data){
                alert('Transaksi Pembayaran Berhasil');
                location.reload();
            });
        });
        //added 28082015
    });
</script>

<style>
    .detail_billing ul{
        list-style:none; padding-left:10px;
    }
    .detail_billing li{padding:3px;}
    .link_detail{ color:#000; font-weight:bold; cursor:pointer;}
</style>
<div align="center">
    <div id="frame">
        <div id="frame_title"><h3>Cart Bayar Rawat Jalan</h3></div>
        <fieldset class="fieldset">
            <legend>Identitas </legend>
            <?php
            $q_pasien	= "select a.NOMR, b.NAMA, b.ALAMAT, b.JENISKELAMIN, b.TGLLAHIR, c.NAMA as CARABAYAR, a.KDCARABAYAR,
						a.IDXDAFTAR, a.KDPOLY, d.nama as nama_poly,a.KDDOKTER, a.PENANGGUNGJAWAB_NAMA, a.PENANGGUNGJAWAB_HUBUNGAN 
						from t_pendaftaran a, 
						m_pasien b, 
						m_carabayar c, 
						m_poly d 
						where a.NOMR = b.NOMR 
						and a.KDCARABAYAR = c.KODE 
						and a.KDPOLY = d.kode 
						and a.NOMR = '".$_REQUEST['nomr']."' 
						and a.IDXDAFTAR = '".$_REQUEST['idxdaftar']."'";
            $get = mysql_query ($q_pasien)or die(mysql_error());
            $userdata = mysql_fetch_assoc($get);
            ?>

            <table width="60%" border="0" cellpadding="0" cellspacing="0" style="float:left;">
                <tr>
                    <td>No MR</td>
                    <td>
                        <label id="nomormedrek">
                            <?php echo $userdata['NOMR'];?>
<!--                            <input type="hidden" id="nomr" value="--><?php //echo $userdata['NOMR'];?><!--"/>-->
                        </label>
                    </td>
                </tr>
                <tr><td width="21%">Nama Lengkap Pasien</td><td width="79%"><?php echo $userdata['NAMA'];?></td></tr>
                <tr><td valign="top">Alamat Pasien</td><td><?php echo $userdata['ALAMAT'];?></td></tr>
                <tr><td valign="top">Jenis Kelamin</td><td colspan="2"><? if($userdata['JENISKELAMIN']=="l" || $userdata['JENISKELAMIN']=="L"){echo"Laki-Laki";}elseif($userdata['JENISKELAMIN']=="p" || $userdata['JENISKELAMIN']=="P"){echo"Perempuan";} ?> <?php echo"( ". $userdata['JENISKELAMIN']." )";?></td></tr>
                <tr><td valign="top">Tanggal Lahir</td><td><?php echo $userdata['TGLLAHIR'];?>          </td></tr>
                <tr><td valign="top">Umur</td><td><?php $a = datediff($userdata['TGLLAHIR'], date("Y-m-d")); echo $a[years]." tahun ".$a[months]." bulan ".$a[days]." hari"; ?></td></tr>
                <tr>
                    <td valign="top">Penangggung Jawab</td>
                    <td>
                        <input type="text" name="pj_pasien" id="pj_pasien" value="<?php echo $userdata['PENANGGUNGJAWAB_NAMA']; ?>" style="font-size: 9pt;" placeholder="Nama" />
                        <input type="text" name="hub_pasien" id="hub_pasien" value="<?php echo $userdata['PENANGGUNGJAWAB_HUBUNGAN']; ?>" style="font-size: 9pt;" placeholder="Hubungan" />
                        <input type="button" name="btn_ubahpj" id="btn_ubahpj" class="text button" value="Ubah" />
                    </td>
                </tr>
                <tr><td valign="top">Nama Poly</td><td><?php echo $userdata['nama_poly']; ?></td></tr>
                <tr>
                    <td valign="top">Jenis Pasien</td>
                    <td>
                        <!--<input type="text" id="jenis_pasien" name="jenis_pasien" value="<?php echo $userdata['CARABAYAR'];?>" style="font-size: 9pt;" placeholder="Jenis Pasien" />-->
                        <select id="jenis_pasien" name="jenis_pasien" class="select2">
                            <?php
                            $sql5 	= getCaraBayar();
                            while($data3 = mysql_fetch_array($sql5)){
                                if($data3['KODE'] == $userdata['KDCARABAYAR']){
                                    $sel	= 'selected';
                                }
                                else{
                                    $sel 	= '';
                                }
                                ?>
                                <option value="<?php echo $data3['KODE']; ?>" <?php echo $sel; ?>><?php echo $data3['NAMA']; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                        <input type="button" name="btn_jenispasien" id="btn_jenispasien" class="text button" value="Ubah" />
                </tr>
                <tr>
                    <td>Cara Bayar</td>
                    <td>
                        <?php
                        if($userdata['KDCARABAYAR'] == 1){
                            ?>
                            <select name="carabayarumum" class="carabayarumum" style="font-size:8pt;">
                                <option value="1">Cash</option>
                                <option value="2">Debet</option>
                                <option value="3">Credit</option>
                                <option value="4">Angsuran</option>
                            </select>
                            &nbsp;
                            <select name="idbank" id="idbank" class="idbank text" style="font-size: 8pt;">
                                <?php
                                $sql4	= getAllBank();
                                while ($data = mysql_fetch_array($sql4, MYSQL_NUM)){

                                    ?>
                                    <option value="<?php echo $data[0]; ?>"><?php echo $data[1]; ?></option>
                                <?php
                                }
                                ?>
                            </select>
                            &nbsp;
                            <input type="text" id="subcarabayar" class="subcarabayar text" style="font-size: 8pt; text-align: right;" size="5" /><label id="label_subcarabayar">%</label>
                            &nbsp;
                            <input type="button" id="btnSubcarabayar" value="Pilih" class="btnSubcarabayar text" style="font-size: 8pt;" />
                            &nbsp;
                            <label id="label_keterangan" style="color: #FF0000">*Untuk koma menggunakan titik (.)</label>
                        <?php
                        }
                        else{
                            echo 'Perusahaan';
                        }
                        ?>
                    </td>
                    </td>
                </tr>
            </table>

            <?php
            if($_SESSION['ROLES'] == 26){
                $sqll = 'SELECT STATUS FROM t_pendaftaran WHERE NOMR = "'.$_REQUEST['nomr'].'" AND IDXDAFTAR = "'.$_REQUEST['idxdaftar'].'"';
                $sqll = mysql_query($sqll);
                $qrtl = mysql_fetch_array($sqll);
                if($qrtl['STATUS'] < 1){
                    ?>
                    <table width="15%" style="float:right;">
                        <tr><th colspan="2">Jasa Tindakan</th></tr>
                        <tr>
                            <!-- /* added 06072015 */ -->
                            <td>
                                <input type="button" name="tindakan_poly" class="tindakan text" id="<?php echo $_REQUEST['poly'];?>" value="Jasa Tindakan Poly" />
                                <input type="hidden" name="poly_id" id="poly_id" value="<?php echo $_REQUEST['poly']; ?>" />
                            </td>
                            <td>
                                <input type="button" name="tindakan_poly" class="tindakan text" id="0" value="Jasa Tindakan Lain Lain" />
                                <input type="hidden" name="poly_id" id="poly_id" value="0" />
                            </td>
                            <!-- /* added 06072015 */ -->
                        </tr>
                    </table>
                <?php
                }else{
                    ?>
                    <table width="15%" style="float:right;">
                        <tr><th colspan="2">Status pasien sudah pulang.</th></tr>
                    </table>
                <?php
                }
                ?>
                <!--
    <table width="55%" style="float:right;">
    <tr><td><input type="button" name="masuk" class="text" value="Masuk" /></td>
    	<td><select name="dokter" class="text" id="dokterpelaksana">
			<?php
                $sql_dokter = "SELECT a.kdpoly,a.kddokter, b.NAMADOKTER,b.KDDOKTER FROM m_dokter_jaga a join m_dokter b on a.kddokter = b.KDDOKTER WHERE a.kdpoly = ".$userdata['KDPOLY'];
                $get_dokter = mysql_query($sql_dokter);
                while($dat_dokter = mysql_fetch_array($get_dokter)) {
                    if($dat_dokter['KDDOKTER']==$userdata['KDDOKTER']): $sel = "selected=selected"; else: $sel = ''; endif;
                    echo '<option value="'.$dat_dokter['KDDOKTER'].'" '.$sel.'>'.$dat_dokter['NAMADOKTER'].'</option>';
                }
                ?>
            </select></td>
	</tr>
    <tr><td><input type="button" name="masuk" class="text" value="Keluar" /></td>
    	<td><select name="Status" class="text" onchange="javascript: MyAjaxRequest('rujuk','rujukan/alasan_rujuk.php?rujuk=' + this.value); return false;">
                                <option selected="selected">- Pilih Status -</option>
                                <?
                $qey = mysql_query("SELECT * FROM m_statuskeluar Where `status` <> 11");
                while ($show = mysql_fetch_array($qey)) {
                    echo '<option value="'.$show['status'].'">'.$show['keterangan'].'</option>';
                }
                ?>
                            </select>
                            </td>
	<tr><td colspan="2"><div id="rujuk"></div></td></tr>
    </tr>
    </table>-->
            <?php
            }else{
                ?>
                <table width="15%" style="float:right;">
                    <tr><th colspan="2">Jasa Tindakan</th></tr>
                    <tr>
                        <td>
                            <input type="button" name="tindakan_poly" class="tindakan text" id="<?php echo $_REQUEST['poly'];?>" value="Jasa Tindakan Poly" />
                            <input type="hidden" name="poly_id" id="poly_id" value="<?php echo $_REQUEST['poly']; ?>" />
                        </td>
                        <!-- /* added 06072015 */ -->
                        <td>
                            <input type="button" name="tindakan_poly" class="tindakan text" id="0" value="Jasa Tindakan Lain Lain" />
                            <input type="hidden" name="poly_id" id="poly_id" value="0" />
                        </td>
                        <!-- /* added 06072015 */ -->
                    </tr>
                    <tr><td>&nbsp;</td></tr>
                    <tr><th colspan="2">Alat Kesehatan & Obat Ruangan</th></tr>
                    <tr>
                        <td>
                            <input type="button" name="alkes" class="alkes text" id="<?php echo $_REQUEST['poly'];?>" value="Alat Kesehatan" />
                        </td>
                        <td>
                            <input type="button" name="obat_ruangan" class="obat_ruangan text" id="<?php echo $_REQUEST['poly'];?>" value="Obat Ruangan" />
                        </td>
                    </tr>
                    <tr><td>&nbsp;</td></tr>
                    <tr><th colspan="2">Penarikan Tarif Apotik</th></tr>
                    <tr>
                        <td>
                            <input type="text" class="text register_apo" name="resiter_apo" />
                        </td>
                        <td>
                            <button class="text btn_tarik_tarif_apo">Tarif Apotik</button>
                        </td>
                    </tr>
                </table>
            <?php
            }
            ?>
            <input type="hidden" name="nomr" id="nomr" value="<?php echo $userdata['NOMR']; ?>" />
            <input type="hidden" name="idxdaftar" id="idxdaftar" value="<?php echo $userdata['IDXDAFTAR']; ?>" />
            <input type="hidden" name="carabayar" id="carabayar" value="<?php echo $userdata['KDCARABAYAR']; ?>" />
            <br clear="all" />
        </fieldset>

    </div>



    <style type="text/css" media="screen">
        #tmp_print{display:none;}
    </style>
    <style type="text/css" media="print">
        #tmp_print{display:block;}
    </style>

    <div id="tmp_print"></div>

    <div id="frame">
        <div id="frame_title"><h3>List Pembayaran</h3></div>
        <form name="byr1" action="include/process.php" method="post" id="byr1">
            <fieldset>
                <legend>Cart List Bayar</legend>
                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="tb">
                    <tr>
                        <!--<th style="width:150px;">Jenis Retribusi</th>-->
                        <th style="width:200px;">Nama Jasa</th>
                        <?php if($_SESSION['ROLES'] == 2 || $_SESSION['ROLES'] == 23) : ?>
                            <th style="width:10px; text-align:center;"> Keringanan </th>
                        <?php endif;?>
                        <th style="width:100px; text-align:center;">Nama Dokter</th>
                        <th style="width:100px; text-align:center;">Tarif</th>
                        <th style="width:100px; text-align: center;">Jaminan</th>
                        <th style="width:50px; text-align: center;">Diskon</th>
                        <th style="width:50px;">Shift</th>
                        <?php if($_SESSION['ROLES'] == 2 || $_SESSION['ROLES'] == 23): ?>
                            <th style="width:150px; text-align:center;">Aksi</th>
                        <?php endif;?>
                        <?php if($_SESSION['ROLES'] == 26): ?>
                            <th style="width:150px; text-align:center;">Status</th>
                        <?php endif; ?>
                    </tr>
                    <tbody class="list_billrajal">
                    <?php
                    $datapend 	= get_t_pendaftaran($_REQUEST['idxdaftar'], $_REQUEST['nomr']);
                    $tutup_pend = $datapend['tutup_pembayaran'];

                    $totalygbelumdibayar = 0;

                    $sql	= 'SELECT a.NOMR, b.NOBILL, c.nama_gruptindakan,c.kode_tindakan, c.nama_tindakan AS nama_jasa, c.tarif AS harga, b.QTY,a.TBP,a.SHIFT, SUM(b.tarifrs * b.QTY) AS subtotal,
                                a.TGLBAYAR, a.sisabayar AS sisa, b.IDXDAFTAR, a.jaminan, a.diskon, b.KDDOKTER
                                FROM t_bayarrajal a
                                JOIN t_billrajal b ON a.NOBILL = b.NOBILL
                                JOIN m_tarif2012 c ON c.kode_tindakan  = b.KODETARIF
                                WHERE a.NOMR = "'.$_REQUEST['nomr'].'" AND a.STATUS !="BATAL" AND b.IDXDAFTAR = "'.$_REQUEST['idxdaftar'].'"
                                AND b.KODETARIF not like "01.01.18%" AND a.APS=0
                                GROUP BY
                                a.NOMR, b.NOBILL,
                                a.TGLBAYAR , b.IDXDAFTAR';
                    $qry = mysql_query($sql)or die(mysql_error());
                    while($data = mysql_fetch_array($qry)){
                        $dokter = $data['KDDOKTER'];
                        $j 		= substr($data['kode_tindakan'],0,5);
                        $js		= getGroupName($j);

                        if($j == '02.03'){
                            $jasa = $js['nama_gruptindakan'];
                        }else{
                            $jasa = $js['nama_tindakan'];
                        }

                        if(($data['TGLBAYAR'] == '') or ($data['TGLBAYAR'] == '0000-00-00')){
                            ?>
                            <tr>
                                <td style="padding-top:7px;" valign="top">
                                    <span class="link_detail" detail="<?php echo $data['kode_tindakan']?>" id="<?php echo $data['NOBILL']?>">
                                        <?php echo $jasa;?>
                                    </span>
                                    <div class="detail_billing" id="d<?php echo $data['NOBILL']; ?>"></div>
                                </td>
                                <?php if($_SESSION['ROLES'] == 2 || $_SESSION['ROLES'] == 23) : ?>
                                    <td style="text-align:center;">
                                        <span class="form_keringanan" style="cursor:pointer; font-weight:bold;" id="<?php echo $data['NOBILL']?>">
                                            Form Keringanan
                                        </span>
                                    </td>
                                <?php endif;?>
                                <td>
                                    <select name="dokter" id="dokter_<?php echo $data['NOBILL']; ?>" class="select2 dokter">
                                        <?php
                                        $sql6	= mysql_query("SELECT * FROM m_dokter");
                                        while($data6 = mysql_fetch_array($sql6)){
                                            if($data['KDDOKTER'] == $data6['KDDOKTER']){
                                                $sel	= 'selected';
                                            }
                                            else{
                                                $sel 	= '';
                                            }
                                            ?>
                                            <option value="<?php echo $data6['KDDOKTER']; ?>" <?php echo $sel; ?>><?php echo $data6['NAMADOKTER']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </td>
                                <td align="right" valign="top" style="padding-top:7px;">
                                    <span id="tarif_<?php echo $data['NOBILL']?>">
                                        <span class="tarif">
                                            <? echo "Rp. ".curformat($data['subtotal'],2); $totalygbelumdibayar=$totalygbelumdibayar+$data['sisa']; ?>
                                        </span>
                                        <span class="label_rp">
                                            Rp.
                                        </span>
                                        <input type="text" class="input_tarif" id="input_tarif_<?php echo $data['NOBILL']; ?>" name="input_tarif_<?php echo $data['NOBILL']; ?>" value="<?php echo $data['subtotal'];?>" style="width: 80px;"/>
                                    </span>
                                </td>
                                <td align="center">
                                    <span>
                                        Rp. <input type="text" class="jaminan" id="jaminan_<?php echo $data['NOBILL']; ?>" value="<?php echo $data['jaminan']; ?>" name="jaminan<?php echo $data['NOBILL']; ?>" placeholder="Jaminan" style="Width: 100px;" />
                                    </span>
                                </td>
                                <td align="center">
                                    <span>
                                        Rp. <input type="text" class="diskon" id="diskon_<?php echo $data['NOBILL']; ?>" value="<?php echo $data['diskon']; ?>" name="diskon<?php echo $data['NOBILL']; ?>" placeholder="Diskon" style="Width: 100px;" />
                                    </span>
                                </td>
                                <td valign="top" style="padding-top:7px;">
                                    <?php if($_SESSION['ROLES'] == 2  || $_SESSION['ROLES'] == 23): ?>
                                        <select name="shift" id="shift_<?php echo $data['NOBILL']; ?>" class="text shift">

                                            <!-- /* edited 08072015 */ -->
                                            <?php
                                            //added by ferna 25062015
                                            //waktu sekarang pada database
                                            $sql = mysql_query("SELECT TIME(now()) as time");
                                            while($ds = mysql_fetch_array($sql)){
                                                $now = $ds['time'];
                                                $jam = substr($now, 0, 2);
                                                $menit = substr($now, 3, 2);
                                                $detik = substr($now, 6, 2);
                                            }

                                            $jam_now = new DateTime($now);
                                            $jam_pagi_bawah = new DateTime("07:00:00");
                                            $jam_pagi_atas = new DateTime("14:15:00");
                                            $jam_sore_atas = new DateTime("21:15:00");
                                            ?>

                                            <option value=""> Pilih Shift </option>
                                            <option value="1" <? if($jam_now > $jam_pagi_bawah && $jam_now < $jam_pagi_atas) echo "Selected";?>> Pagi </option>
                                            <option value="2" <? if($jam_now > $jam_pagi_atas && $jam_now < $jam_sore_atas) echo "Selected";?>> Sore </option>
                                            <option value="3" hidden="true"> 3 </option>
                                            <!-- /* edited 08072015 */ -->

                                        </select>
                                        <input type="hidden" name="total" id="hiden_total_bayar_<?php echo $data['NOBILL']; ?>" value="<?php echo $data['subtotal']; ?>" />
                                        <input type="hidden" name="keringanan" id="hiden_keringanan_<?php echo $data['NOBILL']; ?>" value="0" />
                                        <input type="hidden" name="alasan" id="hiden_alasan_<?php echo $data['NOBILL']; ?>" value="" />
                                        <span id="text_shift_<?php echo $data['NOBILL'];?>"></span>
                                    <?php endif; ?>
                                </td>
                                <?php if($_SESSION['ROLES'] == 2  || $_SESSION['ROLES'] == 23): ?>
                                    <td valign="top" style="padding-top:7px;">
                                        <?php
                                        if($tutup_pend == 0){
                                            ?>
                                            <input type="button" name="Submit" value="Bayar"  class="text bayar" id="bayar_<?php echo $data['NOBILL']; ?>" rel="<?php echo $data['NOBILL']; ?>" svn="<?php echo $data['NOBILL']; ?>" idxd="<?php  echo $_GET['idxdaftar']; ?>" />
                                            <?php
                                            if($_SESSION['ROLES'] == 23){
                                                ?>
                                                <input type="button" name="Cancel" value="Batal" class="text cancel" idxdaftar="<?php echo $userdata['IDXDAFTAR'];?>" kode="<?php echo $data['kode_tindakan'];?>" id="cancel_<?php echo $data['NOBILL']; ?>" rel="<?php echo $data['NOBILL']; ?>" svn="<?php echo $data['NOBILL']; ?>" />
                                            <?php
                                            }
                                            ?>
                                            <input type="button" name="simpan" value="Simpan" class="text simpan" id="simpan_<?php echo $data['NOBILL']; ?>" rel="<?php echo $_REQUEST['nomr']; ?>" svn="<?php echo $data['NOBILL']; ?>" idxd="<?php  echo $_GET['idxdaftar']; ?>"/>
                                            <input type="button" name="hapus" value="Hapus" class="text hapus" id="hapus_<?php echo $data['NOBILL']?>" rel="<?php echo $_REQUEST['nomr']; ?>" svn="<?php echo $data['NOBILL']; ?>" idxd="<?php  echo $_GET['idxdaftar']; ?>"/>
                                        <?php
                                        }
                                        ?>
                                    </td>
                                <?php endif; ?>
                                <?php if($_SESSION['ROLES'] == 26): ?>
                                    <td style="width:150px; text-align:center; padding-top:7px;" valign="top">Belum di Bayar</td>
                                <?php endif; ?>
                            </tr>
                        <?php
                        }else{
                            ?>
                            <tr>
                                <td>
        	<span class="link_detail" detail="<?php echo $data['kode_tindakan']?>" id="<?php echo $data['NOBILL']?>">
        		<?php echo $jasa;?>
        	</span><div class="detail_billing" show="hide" id="d<?php echo $data['NOBILL']; ?>"></div>
                                </td>
                                <td> - </td>
                                <td>
                                    <select name="dokter" id="dokter_<?php echo $data['NOBILL']; ?>" class="select2 dokter">
                                        <?php
                                        $sql6	= mysql_query("SELECT * FROM m_dokter");
                                        while($data6 = mysql_fetch_array($sql6)){
                                            if($data['KDDOKTER'] == $data6['KDDOKTER']){
                                                $sel	= 'selected';
                                            }
                                            else{
                                                $sel 	= '';
                                            }
                                            ?>
                                            <option value="<?php echo $data6['KDDOKTER']; ?>" <?php echo $sel; ?>><?php echo $data6['NAMADOKTER']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </td>
                                <td align="right" valign="top">
                                    <?php if($_SESSION['ROLES'] == 23){ ?>
                                    <span class="tarif">
        	<?php } ?>
            <? echo "Rp. ".curformat($data['subtotal'],2); ?>
            <?php if($_SESSION['ROLES'] == 23){ ?>
        	</span>
                                    <span class="label_rp">Rp.</span>
                                <input type="text" class="input_tarif" id="input_tarif_<?php echo $data['NOBILL']; ?>" name="input_tarif_<?php echo $data['NOBILL']; ?>" value="<?php echo $data['subtotal'];?>" style="width: 80px;"/>
                                <?php } ?>
                                </td>
                                <td align="center">
        	<span>
        		Rp. <input type="text" class="jaminan" id="jaminan_<?php echo $data['NOBILL']; ?>" value="<?php echo $data['jaminan']; ?>" name="jaminan<?php echo $data['NOBILL']; ?>" placeholder="Jaminan" style="Width: 100px;" />
        	</span>
                                </td>
                                <td align="center">
        	<span>
        		Rp. <input type="text" class="diskon" id="diskon_<?php echo $data['NOBILL']; ?>" value="<?php echo $data['diskon']; ?>" name="diskon<?php echo $data['NOBILL']; ?>" placeholder="Diskon" style="Width: 100px;" />
        	</span>
                                </td>
                                <td valign="top" style="text-aligncenter;">

                                    <!-- /* edited 08072015 */ -->
                                    <?php

                                    if($data['SHIFT'] == 1){
                                        echo "Pagi";
                                    }
                                    else{
                                        echo "Sore";
                                    }
                                    ?>
                                    <!-- /* edited 08072015 */ -->

                                </td>
                                <?php if( ($_SESSION['ROLES'] == 2)  || ($_SESSION['ROLES'] == 23)): ?>
                                    <td valign="top">
                                        <?php
                                        if($_SESSION['ROLES'] == 23 and $tutup_pend == 0){
                                            ?>
                                            <input type="button" name="Cancel" value="Batal" class="text cancel" idxdaftar="<?php echo $userdata['IDXDAFTAR'];?>" kode="<?php echo $data['kode_tindakan'];?>" id="cancel_<?php echo $data['NOBILL']; ?>" rel="<?php echo $data['NOBILL']; ?>" svn="<?php echo $data['NOBILL']; ?>" />
<!--                                            <input type="button" name="simpan" value="Simpan" class="text simpan" id="simpan_--><?php //echo $data['NOBILL']; ?><!--" rel="--><?php //echo $_REQUEST['nomr']; ?><!--" svn="--><?php //echo $data['NOBILL']; ?><!--" idxd="--><?php // echo $_GET['idxdaftar']; ?><!--"/>-->
                                            <input type="button" name="hapus" value="Hapus" class="text hapus" id="hapus_<?php echo $data['NOBILL']?>" rel="<?php echo $_REQUEST['nomr']; ?>" svn="<?php echo $data['NOBILL']; ?>" idxd="<?php  echo $_GET['idxdaftar']; ?>"/>
                                        <?php
                                        }
                                        if($tutup_pend == 0){
                                            ?>
                                            <input type="button" name="simpan" value="Simpan" class="text simpan" id="simpan_<?php echo $data['NOBILL']; ?>" rel="<?php echo $_REQUEST['nomr']; ?>" svn="<?php echo $data['NOBILL']; ?>" idxd="<?php  echo $_GET['idxdaftar']; ?>"/>
                                            <input type="button" name="printpertindakan" value="Print" class="text printpertindakan" idxdaftar="<?php echo $userdata['IDXDAFTAR']; ?>" kode="<?php echo $data['kode_tindakan'];?>" nobill="<?php echo $data['NOBILL'] ?>" pilih="2" />
                                        <?php
                                        }
                                        ?>
                                    </td>
                                <?php endif; ?>
                                <?php if($_SESSION['ROLES'] == 26): ?>
                                    <td style="width:150px; text-align:center;">Lunas : <?php echo $data['NOBILL']; ?></td>
                                <?php endif; ?>
                            </tr>

                        <?php
                        }?>

                    <?php
                    }

                    ?>

                    <!-- /*added 08072015*/ -->
                    <?php/*
		$jml_obat    = getbillobat($_REQUEST['idxdaftar']); 
		$jml_obat_db = mysql_fetch_array($jml_obat);
		$jml1		 = $jml_obat_db['jml']; 
		$nobilldb  	 = $jml_obat_db['nobill']; 
		
		$jml2 = getvalidasibillobat($nobilldb);

		$bayarrajalapotik 		= getbayarrajalapotik($_REQUEST['idxdaftar']);
		$databayarrajalapotik	= mysql_fetch_array($bayarrajalapotik);
		$statusbayar			= $databayarrajalapotik['LUNAS'];
		$jmlbayarrajalapotik	= mysql_num_rows($bayarrajalapotik);
		//echo $jmlbayarrajalapotik;
		
		//if($jml2 > 0){
			//deleteRedundanBill($nobilldb);
		//}
		
		//echo $jml_obat;
		
		if($jml1 > 0){
			//if($jml2 < 2){
			if($jmlbayarrajalapotik!=0){
			$getbillobatrajal 	= getbillobatrajal($_REQUEST['idxdaftar']);
			$jmltotalbayar		= gettotalbayarobat($_REQUEST['idxdaftar']);
			while($getobat = mysql_fetch_array($getbillobatrajal)){
				
				//update pembayaran pada bayarrajal
				//echo $getobat['harga'];
				$updatebayarrajal 		= updatetotaltarif($jmltotalbayar, $_REQUEST['idxdaftar']);
				$updatetarifbillrajal 	= updatetarifbillrajal($jmltotalbayar, $_REQUEST['idxdaftar']);
				
				$sisabayarobat			= getsisabayarrajal($_REQUEST['idxdaftar']);
	?>
	<tr>
		<td style="padding-top:7px;" valign="top"><span class="link_detail" detail="Pembelian Obat" id="<?php echo $getobat['nobill']?>">Pembelian Obat</span><div class="detail_billing" id="d<?php echo $getobat['nobill']; ?>"></div></td>
        <?php if($_SESSION['ROLES'] == 2  || $_SESSION['ROLES'] == 23) : ?>
        <td style="text-align:center;"><span class="form_keringanan" style="cursor:pointer; font-weight:bold;" id="<?php echo $getobat['nobill']?>">Form Keringanan</span></td>
        <?php endif;?>
        <td align="right" valign="top" style="padding-top:7px;"><span id="tarif_<?php echo $getobat['nobill']?>"><? echo "Rp. ".curformat($sisabayarobat,2); $totalygbelumdibayar=$totalygbelumdibayar+$sisabayarobat; ?></span></td>
        <td valign="top" style="padding-top:7px;">
        <?php if($_SESSION['ROLES'] == 2  || $_SESSION['ROLES'] == 23): ?>
        <select name="shift" id="shift_<?php echo $getobat['nobill']; ?>" class="text">
        
        		<?php
					//added by ferna 25062015
					//waktu sekarang pada database
					$sql = mysql_query("SELECT TIME(now()) as time");
					while($ds = mysql_fetch_array($sql)){
						$now = $ds['time'];
						$jam = substr($now, 0, 2);
						$menit = substr($now, 3, 2);
						$detik = substr($now, 6, 2);
					}
					
					$jam_now = new DateTime($now);
					$jam_pagi_bawah = new DateTime("07:00:00");
					$jam_pagi_atas = new DateTime("14:15:00");
					$jam_sore_atas = new DateTime("21:15:00");
				?>
        		
                <option value=""> Pilih Shift </option>
                <option value="1" <? if($jam_now > $jam_pagi_bawah && $jam_now < $jam_pagi_atas) echo "Selected";?>> Pagi </option>
                <option value="2" <? if($jam_now > $jam_pagi_atas && $jam_now < $jam_sore_atas) echo "Selected";?>> Sore </option>
                <option value="3" hidden="true"> 3 </option>
            
            </select>
            <input type="hidden" name="total" id="hiden_total_bayar_<?php echo $getobat['nobill']; ?>" value="<?php echo $jmltotalbayar; ?>" />
            <input type="hidden" name="keringanan" id="hiden_keringanan_<?php echo $getobat['nobill']; ?>" value="0" />
            <input type="hidden" name="alasan" id="hiden_alasan_<?php echo $getobat['nobill']; ?>" value="" />
            <span id="text_shift_<?php echo $getobat['nobill'];?>"></span>
		<?php endif; ?>
        </td>
        <?php if($_SESSION['ROLES'] == 2  || $_SESSION['ROLES'] == 23): ?>
        <td valign="top" style="padding-top:7px;">
        <?php 
        	if($tutup_pend == 0){
        ?>
        <input type="button" name="Submit" value="Bayar"  class="text bayar" id="bayar_<?php echo $getobat['nobill']; ?>" rel="<?php echo $getobat['nobill']; ?>" svn="<?php echo $getobat['nobill']; ?>" idxd="<?php  echo $_GET['idxdaftar']; ?>" />
        <?php
        	if($_SESSION['ROLES'] == 23){
        ?>
        <input type="button" name="Cancel" value="Batal" class="text cancel" idxdaftar="<?php echo $userdata['IDXDAFTAR'];?>" kode="<?php echo $data['kode_tindakan'];?>" id="cancel_<?php echo $getobat['nobill']; ?>" rel="<?php echo $getobat['nobill']; ?>" svn="<?php echo $getobat['nobill']; ?>" />
        <?php 
        	}
        	}
        ?>
    </div>
        </td>
        <?php endif; ?>
        <?php if($_SESSION['ROLES'] == 26): ?>
        <td style="width:150px; text-align:center; padding-top:7px;" valign="top">Belum di Bayar</td>
        <?php endif; ?>
	</tr>
	<?php	} 
			}
			else{
				$getbayarobat  = getbayarobat($_REQUEST['idxdaftar'], $nobilldb);
				$databayarobat = mysql_fetch_array($getbayarobat); 
	?>
						<tr>
						<td><span class="link_detail" detail="Pembelian Obat" id="<?php echo $databayarobat['NOBILL']?>">Pelayanan Farmasi</span><div class="detail_billing" show="hide" id="d<?php echo $databayarobat['NOBILL']; ?>"></div></td>
						        <td> - </td>
						        <td align="right" valign="top"><? echo "Rp. ".curformat($databayarobat['JMBAYAR'],2); ?></td>
						        <td valign="top" style="text-aligncenter;">

						        	<?php 
						        		//echo $data['SHIFT'];
						        		
						        		if($databayarobat['SHIFT'] == 1){
						        			echo "Pagi";
						        		}
						        		else{
						        			echo "Sore";
						        		}
						        	?>

						        	
						        </td>
						        <?php if( ($_SESSION['ROLES'] == 2)  || ($_SESSION['ROLES'] == 23)): ?>
						        <td valign="top">
						            <?php 
						        		if($tutup_pend == 0){
						        		if($_SESSION['ROLES'] == 23){
						        	?>
						        	<input type="button" name="Cancel" value="Batal" class="text cancel" idxdaftar="<?php echo $userdata['IDXDAFTAR'];?>" kode="<?php echo $data['kode_tindakan'];?>" id="cancel_<?php echo $databayarobat['NOBILL']; ?>" rel="<?php echo $data['NOBILL']; ?>" svn="<?php echo $data['NOBILL']; ?>" />
						            <?php 
						        		}
						            ?>
						            <input type="button" name="printpertindakan" value="Print" class="text printpertindakan" idxdaftar="<?php echo $userdata['IDXDAFTAR']; ?>" kode="07" nobill="<?php echo $databayarobat['NOBILL'] ?>" pilih="1" />
						           	<?php 
						        		}
						            ?>
								</td>
						        <?php endif; ?>
						        <?php if($_SESSION['ROLES'] == 26): ?>
						        <td style="width:150px; text-align:center;">Lunas : <?php echo $databayarobat['NOBILL']; ?></td>
						        <?php endif; ?>
				<?php
					} 
		}
	*/?>
                    <!-- /*added 08072015*/ -->

                    <?
                    $sql3	= 'SELECT a.NOMR, b.NOBILL
				FROM t_bayarrajal a
				JOIN t_billrajal b ON a.NOBILL = b.NOBILL 
				WHERE a.NOMR = "'.$_REQUEST['nomr'].'" AND a.STATUS !="BATAL" AND b.IDXDAFTAR = "'.$_REQUEST['idxdaftar'].'" 
				AND b.KODETARIF not like "07%"
				AND b.KODETARIF not like "01.01.18%"
				GROUP BY 
				a.NOMR, b.NOBILL,
				a.TGLBAYAR , b.IDXDAFTAR';
                    $qry3 = mysql_query($sql3)or die(mysql_error());
                    $data2=mysql_fetch_array($qry3);
                    ?>

                    <!-- //added 14082015 -->
                    <tr>
                        <td>&nbsp;</td>
                    </tr>
                    <tr style="font-size: 9pt; color: #FF0000">
                        <?php
                            $sql8       = mysql_query("SELECT
                                                          SUM(TOTTARIFRS) AS tottarif,
                                                          SUM(jaminan) AS jaminan,
                                                          CARABAYAR
                                                        FROM t_bayarrajal
                                                        WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']." AND NOMR='".$_REQUEST['nomr']."'");
                            $dsql8      = mysql_fetch_array($sql8);
                            $tottarif   = $dsql8['tottarif'];
                            $jaminan    = $dsql8['jaminan'];
                            $crbyr      = $dsql8['CARABAYAR'];
                            $sisa       = getsisapembayaran($_REQUEST['idxdaftar']);

                            if($crbyr == 1) {
                                if ($tottarif >= 250000 && $tottarif <= 1000000) {
                                    $kodetarif = '11.01';

                                    $sql9               = mysql_query("SELECT COUNT(*) AS jml
                                                                    FROM t_billrajal
                                                                    WHERE KODETARIF='".$kodetarif."'
                                                                        AND IDXDAFTAR=".$_REQUEST['idxdaftar']."
                                                                        AND NOMR='".$_REQUEST['nomr']."'");
                                    $dsql9              = mysql_fetch_array($sql9);
                                    $jml                = $dsql9['jml'];

                                    if($jml == 0) {
                                        $sql7               = mysql_query("SELECT * FROM m_tarif2012 WHERE kode_tindakan='" . $kodetarif . "'");
                                        $dsql7              = mysql_fetch_array($sql7);
                                        $jasa_sarana        = $dsql7['jasa_sarana'];
                                        $jasa_pelayanan     = $dsql7['jasa_pelayanan'];
                                        $tarifrs            = $dsql7['tarif'];

                                        $last_bill          = getLastNoBILL(1);
                                        $last_billplus1     = $last_bill;
                                        $updatenobill       = updatenobill($last_billplus1);

                                        $last_nobyr         = getmaxnobyr();
                                        $last_nobyrplus1    = $last_nobyr + 1;
                                        $updatenobyr        = updatenobyr($last_nobyrplus1);
                                        $qty                = 1;

                                        mysql_query("INSERT INTO t_billrajal(KODETARIF, NOMR, TANGGAL, SHIFT, NIP, QTY, IDXDAFTAR, NOBILL,
                                                      JASA_SARANA,JASA_PELAYANAN,TARIFRS,KDPOLY,CARABAYAR,APS,KDDOKTER,UNIT)
                                                      VALUES('" . $kodetarif . "','" . $_REQUEST['nomr'] . "',DATE(NOW())," . getAutomaticShift() . ",
                                                      '" . $_SESSION['NIP'] . "'," . $qty . "," . $_REQUEST['idxdaftar'] . "," . $last_billplus1 . ",
                                                      " . $jasa_sarana . "," . $jasa_pelayanan . "," . $tarifrs . "," . $_REQUEST['poly'] . ",
                                                      " . $crbyr . ",0," . $dokter . "," . $_REQUEST['poly'] . ")");

                                        mysql_query("INSERT INTO t_bayarrajal(NOMR,SHIFT,NIP,IDXDAFTAR,NOBILL, TOTJASA_SARANA,
                                                      TOTJASA_PELAYANAN,TOTTARIFRS,sisabayar,CARABAYAR,APS,JMBAYAR,TBP,LUNAS,STATUS,
                                                      UNIT,flag_pend)
                                                      VALUES('" . $_REQUEST['nomr'] . "'," . getAutomaticShift() . ",'" . $_SESSION['NIP'] . "',
                                                      " . $_REQUEST['idxdaftar'] . "," . $last_billplus1 . "," . $jasa_sarana . "," . $jasa_pelayanan . ",
                                                      " . $tarifrs . "," . $tarifrs . "," . $crbyr . ",0,0,0,0,'TRX',
                                                      " . $_REQUEST['poly'] . ",0)");

//                                        parent.window.location.reload();
                                        header("Refresh:0");
                                        echo "<script>location.reload();</script>";
                                    }
                                } else if ($tottarif > 1000000) {
                                    $kodetarif = '11.02';

                                    $sql9               = mysql_query("SELECT COUNT(*) AS jml
                                                                    FROM t_billrajal
                                                                    WHERE KODETARIF='".$kodetarif."'
                                                                        AND IDXDAFTAR=".$_REQUEST['idxdaftar']."
                                                                        AND NOMR='".$_REQUEST['nomr']."'");
                                    $dsql9              = mysql_fetch_array($sql9);
                                    $jml                = $dsql9['jml'];

                                    if($jml == 0) {
                                        $sql7               = mysql_query("SELECT * FROM m_tarif2012 WHERE kode_tindakan='" . $kodetarif . "'");
                                        $dsql7              = mysql_fetch_array($sql7);
                                        $jasa_sarana        = $dsql7['jasa_sarana'];
                                        $jasa_pelayanan     = $dsql7['jasa_pelayanan'];
                                        $tarifrs            = $dsql7['tarif'];

                                        $last_bill          = getLastNoBILL(1);
                                        $last_billplus1     = $last_bill;
                                        $updatenobill       = updatenobill($last_billplus1);

                                        $last_nobyr         = getmaxnobyr();
                                        $last_nobyrplus1    = $last_nobyr + 1;
                                        $updatenobyr        = updatenobyr($last_nobyrplus1);
                                        $qty                = 1;

                                        mysql_query("INSERT INTO t_billrajal(KODETARIF, NOMR, TANGGAL, SHIFT, NIP, QTY, IDXDAFTAR, NOBILL,
                                                      JASA_SARANA,JASA_PELAYANAN,TARIFRS,KDPOLY,CARABAYAR,APS,KDDOKTER,UNIT)
                                                      VALUES('" . $kodetarif . "','" . $_REQUEST['nomr'] . "',DATE(NOW())," . getAutomaticShift() . ",
                                                      '" . $_SESSION['NIP'] . "'," . $qty . "," . $_REQUEST['idxdaftar'] . "," . $last_billplus1 . ",
                                                      " . $jasa_sarana . "," . $jasa_pelayanan . "," . $tarifrs . "," . $_REQUEST['poly'] . ",
                                                      " . $crbyr . ",0," . $dokter . "," . $_REQUEST['poly'] . ")");

                                        mysql_query("INSERT INTO t_bayarrajal(NOMR,SHIFT,NIP,IDXDAFTAR,NOBILL, TOTJASA_SARANA,
                                                      TOTJASA_PELAYANAN,TOTTARIFRS,sisabayar,CARABAYAR,APS,JMBAYAR,TBP,LUNAS,STATUS,
                                                      UNIT,flag_pend)
                                                      VALUES('" . $_REQUEST['nomr'] . "'," . getAutomaticShift() . ",'" . $_SESSION['NIP'] . "',
                                                      " . $_REQUEST['idxdaftar'] . "," . $last_billplus1 . "," . $jasa_sarana . "," . $jasa_pelayanan . ",
                                                      " . $tarifrs . "," . $tarifrs . "," . $crbyr . ",0,0,0,0,'TRX',
                                                      " . $_REQUEST['poly'] . ",0)");

//                                        parent.window.location.reload();
                                        header("Refresh:0");
                                        echo "<script>location.reload();</script>";
                                    }
                                }
                            }
                            else{
                                if($jaminan > 0){
                                    $total  = $tottarif - $jaminan;
                                    if($total >= 250000 && $total <= 1000000){
                                        $kodetarif = '11.01';

                                        $sql9               = mysql_query("SELECT COUNT(*) AS jml
                                                                    FROM t_billrajal
                                                                    WHERE KODETARIF='".$kodetarif."'
                                                                        AND IDXDAFTAR=".$_REQUEST['idxdaftar']."
                                                                        AND NOMR='".$_REQUEST['nomr']."'");
                                        $dsql9              = mysql_fetch_array($sql9);
                                        $jml                = $dsql9['jml'];

                                        if($jml == 0) {
                                            $sql7               = mysql_query("SELECT * FROM m_tarif2012 WHERE kode_tindakan='" . $kodetarif . "'");
                                            $dsql7              = mysql_fetch_array($sql7);
                                            $jasa_sarana        = $dsql7['jasa_sarana'];
                                            $jasa_pelayanan     = $dsql7['jasa_pelayanan'];
                                            $tarifrs            = $dsql7['tarif'];

                                            $last_bill          = getLastNoBILL(1);
                                            $last_billplus1     = $last_bill;
                                            $updatenobill       = updatenobill($last_billplus1);

                                            $last_nobyr         = getmaxnobyr();
                                            $last_nobyrplus1    = $last_nobyr + 1;
                                            $updatenobyr        = updatenobyr($last_nobyrplus1);
                                            $qty                = 1;

                                            mysql_query("INSERT INTO t_billrajal(KODETARIF, NOMR, TANGGAL, SHIFT, NIP, QTY, IDXDAFTAR, NOBILL,
                                                          JASA_SARANA,JASA_PELAYANAN,TARIFRS,KDPOLY,CARABAYAR,APS,KDDOKTER,UNIT)
                                                          VALUES('" . $kodetarif . "','" . $_REQUEST['nomr'] . "',DATE(NOW())," . getAutomaticShift() . ",
                                                          '" . $_SESSION['NIP'] . "'," . $qty . "," . $_REQUEST['idxdaftar'] . "," . $last_billplus1 . ",
                                                          " . $jasa_sarana . "," . $jasa_pelayanan . "," . $tarifrs . "," . $_REQUEST['poly'] . ",
                                                          " . $crbyr . ",0," . $dokter . "," . $_REQUEST['poly'] . ")");

                                            mysql_query("INSERT INTO t_bayarrajal(NOMR,SHIFT,NIP,IDXDAFTAR,NOBILL, TOTJASA_SARANA,
                                                          TOTJASA_PELAYANAN,TOTTARIFRS,sisabayar,CARABAYAR,APS,JMBAYAR,TBP,LUNAS,STATUS,
                                                          UNIT,flag_pend)
                                                          VALUES('" . $_REQUEST['nomr'] . "'," . getAutomaticShift() . ",'" . $_SESSION['NIP'] . "',
                                                          " . $_REQUEST['idxdaftar'] . "," . $last_billplus1 . "," . $jasa_sarana . "," . $jasa_pelayanan . ",
                                                          " . $tarifrs . "," . $tarifrs . "," . $crbyr . ",0,0,0,0,'TRX',
                                                          " . $_REQUEST['poly'] . ",0)");

//                                            parent.window.location.reload();
                                            header("Refresh:0");
                                            echo "<script>location.reload();</script>";
                                        }
                                    }else if ($total > 1000000) {
                                        $kodetarif = '11.02';

                                        $sql9               = mysql_query("SELECT COUNT(*) AS jml
                                                                    FROM t_billrajal
                                                                    WHERE KODETARIF='".$kodetarif."'
                                                                        AND IDXDAFTAR=".$_REQUEST['idxdaftar']."
                                                                        AND NOMR='".$_REQUEST['nomr']."'");
                                        $dsql9              = mysql_fetch_array($sql9);
                                        $jml                = $dsql9['jml'];

                                        if($jml == 0) {
                                            $sql7               = mysql_query("SELECT * FROM m_tarif2012 WHERE kode_tindakan='" . $kodetarif . "'");
                                            $dsql7              = mysql_fetch_array($sql7);
                                            $jasa_sarana        = $dsql7['jasa_sarana'];
                                            $jasa_pelayanan     = $dsql7['jasa_pelayanan'];
                                            $tarifrs            = $dsql7['tarif'];

                                            $last_bill          = getLastNoBILL(1);
                                            $last_billplus1     = $last_bill;
                                            $updatenobill       = updatenobill($last_billplus1);

                                            $last_nobyr         = getmaxnobyr();
                                            $last_nobyrplus1    = $last_nobyr + 1;
                                            $updatenobyr        = updatenobyr($last_nobyrplus1);
                                            $qty                = 1;

                                            mysql_query("INSERT INTO t_billrajal(KODETARIF, NOMR, TANGGAL, SHIFT, NIP, QTY, IDXDAFTAR, NOBILL,
                                                          JASA_SARANA,JASA_PELAYANAN,TARIFRS,KDPOLY,CARABAYAR,APS,KDDOKTER,UNIT)
                                                          VALUES('" . $kodetarif . "','" . $_REQUEST['nomr'] . "',DATE(NOW())," . getAutomaticShift() . ",
                                                          '" . $_SESSION['NIP'] . "'," . $qty . "," . $_REQUEST['idxdaftar'] . "," . $last_billplus1 . ",
                                                          " . $jasa_sarana . "," . $jasa_pelayanan . "," . $tarifrs . "," . $_REQUEST['poly'] . ",
                                                          " . $crbyr . ",0," . $dokter . "," . $_REQUEST['poly'] . ")");

                                            mysql_query("INSERT INTO t_bayarrajal(NOMR,SHIFT,NIP,IDXDAFTAR,NOBILL, TOTJASA_SARANA,
                                                          TOTJASA_PELAYANAN,TOTTARIFRS,sisabayar,CARABAYAR,APS,JMBAYAR,TBP,LUNAS,STATUS,
                                                          UNIT,flag_pend)
                                                          VALUES('" . $_REQUEST['nomr'] . "'," . getAutomaticShift() . ",'" . $_SESSION['NIP'] . "',
                                                          " . $_REQUEST['idxdaftar'] . "," . $last_billplus1 . "," . $jasa_sarana . "," . $jasa_pelayanan . ",
                                                          " . $tarifrs . "," . $tarifrs . "," . $crbyr . ",0,0,0,0,'TRX',
                                                          " . $_REQUEST['poly'] . ",0)");

//                                            parent.window.location.reload();
                                            header("Refresh:0");
                                            echo "<script>location.reload();</script>";
                                        }
                                    }
                                }
                            }
                        ?>
                        <td colspan="5"><b>Total yang Belum di Bayar: <input type="text" id="totbelumbayar" disabled value="<?php echo "Rp. ". CurFormat(getsisatarifrajal2($_REQUEST['idxdaftar'],$_REQUEST['nomr']),2); ?>" style="font-size: 9pt; color: #FF0000; font-weight:bold;" /></b></td>
                    </tr>
                    <tr style="font-size: 9pt; color: #FF0000">
                        <td colspan="5">
                            <b>
                                <label id="label_bayar">Bayar: </label>
                                <input type="number" id="bayarsisa" style="font-size: 12pt; color: #FF0000; font-weight:bold;" />
                            </b>
                            <input type="button" id="btn_bayarsisa" value="Bayar" class="text" style="font-size:10pt;"/>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                    </tr>
                    <!-- //added 14082015 -->

                    <tr style="border:1px;">
                        <td colspan="2"> No.Bill : <?php echo $data2['NOBILL']; ?>
                        </td>
                        <td colspan="6">
                            <?php
                            if($tutup_pend == 0){
                                ?>
                                <input type="button" class="text refresh" value="Refresh" style="display:block; float:right; padding:5px; margin:5px;" />
                                <input type="button" name="tutup_pembayaran" value="Tutup Pembayaran Pasien" class="text tutup_pembayaran" id="tutup_<?php echo $data2['NOBILL']; ?>" rel="<?php echo $userdata['IDXDAFTAR']; ?>" svn="<?php echo $_REQUEST['nomr']; ?>" style="display:block; float:right; padding:5px; margin:5px;"/>
<!--                                <input type="button" name="print" value="Print" class="text print" id="print_--><?php //echo $data2['NOBILL']; ?><!--" rel="--><?php //echo $userdata['IDXDAFTAR']; ?><!--" svn="--><?php //echo $data2['NOBILL']; ?><!--" onclick="print_pembayaran()" style="display:block; float:right; padding:5px; margin:5px;"/>-->
                                <input type="button" name="print" value="Print" class="text print" id="print_<?php echo $data2['NOBILL']; ?>" rel="<?php echo $userdata['IDXDAFTAR']; ?>" svn="<?php echo $data2['NOBILL']; ?>" style="display:block; float:right; padding:5px; margin:5px;"/>
                                <!-- added 03072015 -->
                                <input type="hidden" id="rel" name="rel" value="<?php echo $userdata['IDXDAFTAR']; ?>" />
                                <input type="hidden" id="svn" name="svn" value="<?php echo $data2['NOBILL']; ?>" />
                                <!-- added 03072015 -->

                                <div id="callback_<?php echo $data2['NOBILL']; ?>" style="float:right;"></div>
                                <?php
                                    if($_SESSION['ROLES'] == 23) {
                                        ?>
                                        <input type="button" class="text edit" id="edit_pasien"
                                               style="display:block; float:right; padding:5px; margin:5px;"
                                               value="Edit"/>
                                        <input type="button" class="text tambah" id="tambah"
                                               style="display:block; float:right; padding:5px; margin:5px;"
                                               value="Tambah"/>
                                    <?php
                                    }
                            }
                            else{
                                ?>
                                <input type="button" name="buka_pembayaran" value="Buka Pembayaran Pasien" class="text buka_pembayaran" id="buka_<?php echo $data2['NOBILL']; ?>" rel="<?php echo $userdata['IDXDAFTAR']; ?>" svn="<?php echo $_REQUEST['nomr']; ?>" style="display:block; float:right; padding:5px; margin:5px;"/>
                            <?php
                            }
                            ?>
                            <input type="hidden" id="status_editor" value="0"/>
                            <?php
                            if($_SESSION["success"] > 0){
                                $success = $_SESSION["success"];
                                unset($_SESSION["success"]);
                            }
                            else{
                                $success = 0;
                            }
                            ?>
                            <input type="hidden" id="success" value="<?php echo $success; ?>" />
                        </td>
                    </TR>
                </table>
            </fieldset>
        </form>
    </div>
</div>

<div id="dialog-form" >
    <p class="validateTips">Harap isi semua field yang dibutuhkan..</p>

    <form method="post">
        <fieldset>
            <table>
                <tr>
                    <td>
                        <label>NAMA JASA</label>
                    </td>
                    <td>:</td>
                    <td>
                        <input type="hidden" name="nomr" value="<?php echo $_REQUEST['nomr']; ?>" />
                        <input type="hidden" name="idxdaftar" value="<?php echo $_REQUEST['idxdaftar']; ?>" />
                        <input type="hidden" name="kdpoly" value="<?php echo $_REQUEST['poly']; ?>" />
                        <input type="hidden" name="jnsp" id="jnsp" />
                        <select name="jasa_tindakan" id="jasa_tindakan" class="select2 jasa_tindakan" style="width:250px;">
                            <option></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>DOKTER</td>
                    <td>:</td>
                    <td>
                        <select name="kddokter" id="kddokter_add" class="select2 kddokter_add" style="width:250px;">
                            <option></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>UNIT</td>
                    <td>:</td>
                    <td>
                        <select name="unit" id="unit" class="select2 unit" style="width:250px;">
                            <option></option>
                        </select>
                    </td>
                </tr>
            </table>
        </fieldset>
    </form>
</div>

<div id="dialog-print" >
    <form method="post">
        <fieldset>
            <table>
                <tr>
                    <td>
                        <input type="button" id="btn_print_gabungan"
                               name="btn_print_gabungan"
                               rel="<?php echo $_REQUEST['IDXDAFTAR']; ?>"
                               svn="<?php echo $data2['NOBILL']; ?>"
                               value="Print Gabungan" />
                    </td>
                </tr>
                <?php
                $sql_lab    = mysql_query("SELECT *
                                                FROM t_orderlab
                                                WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']."
                                                AND NOMR='".$_REQUEST['nomr']."'");
                $jml_lab    = mysql_num_rows($sql_lab);
                if($jml_lab > 0) {
                    $dlab   = mysql_fetch_array($sql_lab);
                    ?>
                    <tr>
                        <td>
                            <input type="button" value="Print Rincian LAB"
                                   id="btn_print_rincian_lab"
                                   name="btn_print_rincian_lab"
                                   nomr="<?php echo $_REQUEST['nomr']; ?>"
                                   idx="<?php echo $_REQUEST['idxdaftar']; ?>" />
                        </td>
                    </tr>
                <?php
                }
                ?>
                <?php
                $sql_rad    = mysql_query("SELECT *
                                                FROM t_radiologi
                                                WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']."
                                                AND NOMR='".$_REQUEST['nomr']."'");
                $jml_rad    = mysql_num_rows($sql_rad);
                if($jml_rad > 0) {
                    $drad   = mysql_fetch_array($sql_rad);
                    ?>
                    <tr>
                        <td>
                            <input type="button" value="Print Rincian Radiologi"
                                   id="btn_print_rincian_rad"
                                   name="btn_print_rincian_rad"
                                   nomr="<?php echo $_REQUEST['nomr']; ?>"
                                   idx="<?php echo $_REQUEST['idxdaftar']; ?>" />
                        </td>
                    </tr>
                <?php
                }
                ?>
                <?php
                $sql_fio    = mysql_query("SELECT *
                                                FROM t_fisioterapi
                                                WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']."
                                                AND NOMR='".$_REQUEST['nomr']."'");
                $jml_fio    = mysql_num_rows($sql_fio);
                if($jml_fio > 0) {
                    $dfio   = mysql_fetch_array($sql_fio);
                    ?>
                    <tr>
                        <td>
                            <input type="button" value="Print Rincian Fisioterapi"
                                   id="btn_print_rincian_fisio"
                                   name="btn_print_rincian_fisio"
                                   nomr="<?php echo $_REQUEST['nomr']; ?>"
                                   idx="<?php echo $_REQUEST['idxdaftar']; ?>" />
                        </td>
                    </tr>
                <?php
                }
                ?>
                <?php
                $sql_pa     = mysql_query("SELECT *
                                                FROM t_patologi_anatomi
                                                WHERE IDXDAFTAR=".$_REQUEST['idxdaftar']."
                                                AND NOMR='".$_REQUEST['nomr']."'");
                $jml_pa     = mysql_num_rows($sql_pa);
                if($jml_pa > 0) {
                    $dpa    = mysql_fetch_array($sql_pa);
                    ?>
                    <tr>
                        <td>
                            <input type="button" value="Print Rincian PA"
                                   id="btn_print_rincian_pa"
                                   name="btn_print_rincian_pa"
                                   nomr="<?php echo $_REQUEST['nomr']; ?>"
                                   idx="<?php echo $_REQUEST['idxdaftar']; ?>"
                                   idxpa="<?php echo $dpa['IDXPA']; ?>"/>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </table>
        </fieldset>
    </form>
</div>

<!-- added 03072015 || bug_003 -->
<script type="text/javascript">
    jQuery("fieldset").css({padding:'0',border:'0', marginTop:'25px'});

    jQuery(".select2").select2();

    jQuery('#pj_pasien').autocomplete("include/autocomplete_perusahaan.php", {
        width: 260,
        selectFirst: true
    });

    function print_pembayaran(){
        var idxdaftar 		= jQuery('#rel').val();
        var idxbayar 		= jQuery('#svn').val();
        var subcarabayar	= jQuery('.carabayarumum').val();

        window.open("print_pembayaran.php?idxb="+idxbayar+"&idxdaftar="+idxdaftar+"&nomr=<?php echo $_REQUEST['nomr']; ?>&subcrbyr="+subcarabayar);
    }

    jQuery(".edit").button({icons: {primary: "ui-icon-pencil"}});
    jQuery(".print").button({icons: {primary: "ui-icon-print"}});
    jQuery(".tutup_pembayaran").button({icons: {primary: "ui-icon-print"}});
    jQuery(".buka_pembayaran").button({icons: {primary: "ui-icon-print"}});
    jQuery(".tambah").button({icons: {primary: "ui-icon-print"}});
    jQuery("#btn_print_gabungan").button({icons: {primary: "ui-icon-print"}});
    jQuery("#btn_print_rincian_pa").button({icons: {primary: "ui-icon-print"}});
    jQuery("#btn_print_rincian_lab").button({icons: {primary: "ui-icon-print"}});
    jQuery("#btn_print_rincian_rad").button({icons: {primary: "ui-icon-print"}});
    jQuery("#btn_print_rincian_fisio").button({icons: {primary: "ui-icon-print"}});
    jQuery(".refresh").button({icons: {primary: "ui-icon-print"}});

    function showEditor(){
        jQuery(".label_rp").show();
        jQuery(".tarif").hide();
        jQuery(".input_tarif").show();
        jQuery(".hapus").show();
    }

    function hideEditor(){
        jQuery(".label_rp").hide();
        jQuery(".tarif").show();
        jQuery(".input_tarif").hide();
        jQuery(".hapus").hide();

        //menampilkan success status
        var success = jQuery("#success").val();
        if(success > 0){
            alert("Perubahan berhasil dilakukan");
        }
    }
    hideEditor();

    jQuery(".refresh").click(function(){
        location.reload();
    });

    jQuery(".print").click(function(){
        jQuery("#dialog-print").dialog({
            title: "Print Pembayaran"
        }).dialog("open");
    });

    jQuery("#btn_print_gabungan").click(function () {
        print_pembayaran();
    });

    jQuery("#btn_print_rincian_fisio").click(function () {
        var nomr 	= jQuery(this).attr('nomr');
        var idx 	= jQuery(this).attr('idx');

        window.open('fisioterapi/print_rincian_fisioterapi.php?nomr='+nomr+'&idx='+idx);
    });

    jQuery("#btn_print_rincian_lab").click(function () {
        var nomr 	= jQuery(this).attr('nomr');
        var idx 	= jQuery(this).attr('idx');

        window.open('lab/print_rincian_periksa_lab.php?nomr='+nomr+'&idx='+idx);
    });

    jQuery("#btn_print_rincian_rad").click(function () {
        var nomr 	= jQuery(this).attr('nomr');
        var idx 	= jQuery(this).attr('idx');

        window.open('radiologi/print_rincian_radiologi.php?nomr='+nomr+'&idx='+idx);
    });

    jQuery("#btn_print_rincian_pa").click(function () {
        var nomr 	= jQuery(this).attr('nomr');
        var idx 	= jQuery(this).attr('idx');
        var idxpa	= jQuery(this).attr('idxpa');

        window.open('patologi_anatomi/print_rincian.php?nomr='+nomr+'&idx='+idx+'&idxpa='+idxpa);
    });

    jQuery(".edit").click(function(){
        var status 	= jQuery("#status_editor").val();

        if(status == 0){
            showEditor();
            jQuery(this).val("Batal");
            jQuery("#status_editor").val(1);
        }
        else{
            hideEditor();
            jQuery(this).val("Edit");
            jQuery("#status_editor").val(0);
        }
    });

    jQuery(".simpan").click(function(){
        var nobill 	= jQuery(this).attr('id').substring(7);
        var nomr 	= jQuery(this).attr('rel');
        var idxd 	= jQuery(this).attr('idxd');
        var tarif 	= jQuery("#input_tarif_" + nobill).val();
        var jaminan = jQuery("#jaminan_" + nobill).val();
        var diskon 	= jQuery("#diskon_" + nobill).val();

        window.location.href	= '<?php echo _BASE_ ?>include/pasien.php?opsi=5&nobill='+nobill+'&nomr='+nomr+'&idxd='+idxd+'&tarif='+tarif+'&kdpoly=<?php echo $_REQUEST['poly']?>&jaminan='+jaminan+'&diskon='+diskon;
    });

    jQuery(".hapus").click(function(){
        var nobill 	= jQuery(this).attr('id').substring(6);
        var nomr 	= jQuery(this).attr('rel');
        var idxd 	= jQuery(this).attr('idxd');

        var bool 	= confirm("Apakah Anda yakin untuk menghapus data ini?");
        if(bool == true){
            window.location.href	= '<?php echo _BASE_ ?>include/pasien.php?opsi=6&nobill='+nobill+'&nomr='+nomr+'&idxd='+idxd+'&kdpoly=<?php echo $_REQUEST['poly']?>';
        }
    });

    jQuery(".tutup_pembayaran").click(function(){
        var nomr 	= jQuery(this).attr('svn');
        var idxd 	= jQuery(this).attr('rel');

        window.location.href	= '<?php echo _BASE_ ?>include/pasien.php?opsi=7&nomr='+nomr+'&idxd='+idxd;
    });

    jQuery(".buka_pembayaran").click(function(){
        var nomr 	= jQuery(this).attr('svn');
        var idxd 	= jQuery(this).attr('rel');

        window.location.href	= '<?php echo _BASE_ ?>include/pasien.php?opsi=9&nomr='+nomr+'&idxd='+idxd;
    });

    jQuery("#btn_ubahpj").click(function(){
        var pj 		= jQuery("#pj_pasien").val();
        var hub 	= jQuery("#hub_pasien").val();
        var idxd 	= jQuery("#rel").val();
        var nomr 	= jQuery('#nomr').val();

        jQuery.post('<?php echo _BASE_ ?>include/pasien.php?opsi=13',{idxd:idxd,nomr:nomr,pj:pj,hub:hub},function(data){
            alert("Perubahan berhasil dilakukan");
            location.reload();
        });
    });

    jQuery("#btn_jenispasien").click(function(){
        var jnsp	= jQuery("#jenis_pasien").val();
        var idxd 	= jQuery("#rel").val();
        var nomr 	= jQuery('#nomr').val();

        jQuery.post('<?php echo _BASE_ ?>include/pasien.php?opsi=14',{idxd:idxd,nomr:nomr,jnsp:jnsp},function(data){
            alert("Perubahan berhasil dilakukan");
            location.reload();
        });
    });

    jQuery(".dokter").change(function(){
        var idxd 		= jQuery("#rel").val();
        var nomr 		= jQuery('#nomr').val();
        var nobill 		= jQuery(this).attr('id').substring(7);
        var kddokter	= jQuery(this).val();

        jQuery.post('<?php echo _BASE_ ?>include/pasien.php?opsi=15',{idxd:idxd,nomr:nomr,nobill:nobill,kddokter:kddokter},function(data){
            alert("Perubahan berhasil dilakukan");
            location.reload();
        });
    });

    jQuery(".alkes").click(function(){
        var nomr		= jQuery('#nomr').val();
        var idxdaftar	= jQuery("#rel").val();
        var carabayar	= jQuery('#jenis_pasien').val();
        var poly		= jQuery(this).attr('id');

        popUp('daftarAlkes.php?nomr='+nomr+'&idx='+idxdaftar+'&carabayar='+carabayar+'&poly='+poly);
    });

    jQuery(".obat_ruangan").click(function(){
        var nomr		= jQuery('#nomr').val();
        var idxdaftar	= jQuery("#rel").val();
        var carabayar	= jQuery('#jenis_pasien').val();
        var poly		= jQuery(this).attr('id');

        popUp('daftarObatRuangan.php?nomr='+nomr+'&idx='+idxdaftar+'&carabayar='+carabayar+'&poly='+poly);
    });

    jQuery(".tambah").click(function(){
        var url 	= "include/pasien.php";
        var jnsp 	= jQuery("#jenis_pasien").val();

        jQuery("#jnsp").val(jnsp);
        jQuery("#dialog-form").find("form").attr("action", url + "?opsi=16");
        jQuery("#dialog-form").dialog({
            title: "Tambah Jasa Pemeriksaan"
        }).dialog("open");
    });

    jQuery("#dialog-print").dialog({
        autoOpen: false,
        height: 250,
        width: 350,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        buttons: {
            Batal: function() {
                jQuery(this).dialog("close");
            }
        },
        close: function() {
            jQuery(".validateTips").html("Harap isi semua field yang dibutuhkan..");
        }
    });

    jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 250,
        width: 350,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        buttons: {
            Simpan: function(){
                sendFormData();
            },
            Batal: function() {
                jQuery(this).dialog("close");
            }
        },
        close: function() {
            jQuery(".validateTips").html("Harap isi semua field yang dibutuhkan..");
        }
    });

    function sendFormData(){
        jQuery("#dialog-form").find("form").submit();
    }

    jQuery("#jasa_tindakan").select2({
        allowClear: true,
        placeholder: "Ketikkan nama Tindakan..",
        ajax: {
            url: "include/RsudUtility.php",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    n: params.term, // search term
                    function: 'getTarif'
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });

    jQuery("#unit").select2({
        allowClear: true,
        placeholder: "Ketikkan nama Unit..",
        ajax: {
            url: "include/RsudUtility.php",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    n: params.term, // search term
                    function: 'getUnit'
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });

    jQuery("#kddokter_add").select2({
        allowClear: true,
        placeholder: "Ketikkan nama Dokter..",
        ajax: {
            url: "include/RsudUtility.php",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    n: params.term, // search term
                    function: 'getDokter'
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });

    jQuery('.btn_tarik_tarif_apo').click(function(){
        var register_apo = jQuery('.register_apo').val();
        var nomr		 = jQuery('#nomr').val();
        var idxdaftar	 = jQuery('#idxdaftar').val();

        jQuery.post('<?php echo _BASE_ ?>models/get_tarif_apotik.php',{register_apo:register_apo, nomr:nomr, idxdaftar: idxdaftar},function(data){
            alert(data);
            location.reload();
        });
    });
</script>
<!-- added 03072015 || bug_003 -->
