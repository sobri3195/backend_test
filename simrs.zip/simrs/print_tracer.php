<?php
ob_start();
?>

<style type="text/css" media="print">
    #tbl_rs {	width:20cm;
        font-family: "Courier New", Courier, monospace;
        font-size: 13pt;
        padding: 0px;
        width:500px;
        margin-top:20px;
        margin-left:0px;
        margin-right:0px;
    }
</style>
<?php
if(isset($_REQUEST['idx']) && isset($_REQUEST['poly'])){
    include("include/connect.php");
    $idx	= $_REQUEST['idx'];
    $poly	= $_REQUEST['poly'];
    /*if(isset($_REQUEST['tglreg'])){
        $tglreg = str_replace("/","-",$_REQUEST['tglreg']);
    } else{
        $tglreg = date('Y-m-d');
    }*/

    $sql	= 	'select t_pendaftaran.NOMR, 
						m_pasien.nama as pasien, 
						m_poly.nama as poly, 
						m_carabayar.nama as carabayar,
						t_pendaftaran.NIP, 
						t_pendaftaran.PASIENBARU, 
						t_pendaftaran.KDDOKTER, 
						t_pendaftaran.KDPOLY,
						m_dokter.NAMADOKTER, 
						NOW() AS now,
						t_pendaftaran.KETBAYAR,
						m_pasien.nomr_old,
						t_pendaftaran.kode_p,
						t_pendaftaran.kode_t,
						t_pendaftaran.TGLREG,
						t_pendaftaran.NIP AS user
	            from t_pendaftaran
				join m_pasien on t_pendaftaran.NOMR = m_pasien.NOMR
				join m_poly on m_poly.kode = t_pendaftaran.KDPOLY
				join m_carabayar on m_carabayar.KODE = t_pendaftaran.KDCARABAYAR
				JOIN m_dokter on m_dokter.KDDOKTER=t_pendaftaran.KDDOKTER
				where t_pendaftaran.KDPOLY ='.$poly.' and t_pendaftaran.IDXDAFTAR="'.$idx.'"';
    $res	= mysql_query($sql) or die(mysql_error());
    $a		= mysql_num_rows($res);
    $data	= mysql_fetch_array($res);
    echo '<div id="print_tracer_ah">';
    //echo 'Anda Pasien Ke =>'.$a;
    if($data['PASIENBARU'] == 0){
        $tpb = 'LAMA';
    }else{
        $tbp = 'BARU';
    }
	
	if($data['KDPOLY'] == 53){
		$sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
	} else if($data['KDPOLY'] == 47){
		$sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
	} else if($data['KDPOLY'] == 52){
		$sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
	} else if($data['KDPOLY'] == 31){
		$sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
	} else{
		$sql_nourut = 'SELECT * FROM 
				(SELECT (@row:=@row+1) AS row,
								NOMR
				FROM `t_pendaftaran`, (SELECT @row := 0) r 
				WHERE KDPOLY = "'.$data['KDPOLY'].'"
					AND KDDOKTER = "'.$data['KDDOKTER'].'"
					AND TGLREG = "'.$data['TGLREG'].'"
					AND kode_p = 0
				ORDER BY IDXDAFTAR) AS EMP
				WHERE NOMR = "'.$data['NOMR'].'";';
	}
	$rs_nourut  = mysql_query($sql_nourut);
	$row_nourut = mysql_fetch_array($rs_nourut);
	$nourut	    = $row_nourut['row'];
    ?>
    <!--<div id="tbl_rs">
			<div style="float:left;
						width:30%;">
				<b style="margin-bottom:10px;">TRACER</b><br/>
				<label style="padding-bottom:10px;">STATUS</label><br/>
				<label>NAMA</label><br/>
				<label>NOMR RM</label><br/>
				<label>TUJUAN</label><br/>
				<label>TANGGAL</label><br/>
				<label>JNS PASIEN</label><br/>
				<label>PETUGAS</label>   
			</div>
			<div style="float:left;
						width:70%;">
				<br/>: <?= $tbp; ?>
				<br/>: <?= $data['pasien']; ?>
				<br/>: <?= $data['NOMR']; ?>
				<br/>: <?= $data['poly']; ?>
				<br/>: <label style="font-size:10pt;"><?= $data['now']; ?></label>
				<br/>: <?= $data['carabayar'] . "/" . $data['KETBAYAR']; ?>
				<br/>: <?= $data['NIP']; ?><br/>
			</div>
		</div>-->
    <table id="tbl_rs" width="500px">
        <tr>
            <th width="100px;"><h3>TRACER</h3></th>
            <th style="text-align:center"><h3><?= $data['PASIENBARU'] == 1 ? "(B)" : "(L)"; ?></h3><br/></th>
        </tr>
		<tr>
            <td width="100px" >NOMOR URUT</td>
            <td>: <?php echo $nourut; ?><br/></td>
        </tr>
        <tr>
            <td width="100px" >NAMA</td>
            <td>: <?php echo $data['pasien']; ?><br/></td>
        </tr>
        <tr>
            <td>NOMR BARU</td>
            <td>: <?php echo $data['NOMR'];?><br/></td>
        </tr>
        <tr>
            <td>TUJUAN</td>
            <td>: <?php echo $data['poly']; ?><br/></td>
        </tr>
        <tr>
            <td>DOKTER</td>
            <td>: <?php echo $data['NAMADOKTER']; ?><br/></td>
        </tr>
        <tr>
            <td>TANGGAL</td>
            <td>: <?php echo date('d-m-Y', strtotime(str_replace('/','-',$data['now'])))." ".substr($data['now'],11); ?><br/></td>
        </tr>
        <tr>
            <td>CARA BAYAR</td>
            <td>: <?php echo $data['carabayar']; ?><br/></td>
        </tr>
        <!--<tr>
                <td>PETUGAS</td>
                <td>: <?php echo $data['NIP'];?><br/></td>
            </tr>-->
        <tr>
            <td>NOMR LAMA</td>
            <td>: <?php echo $data['nomr_old'];?><br/></td>
        </tr>
        <tr>
            <td colspan="2">
                    <?= $data['kode_p'] > 0 ? "KODE P" : ''; ?>
                    <?= $data['kode_t'] > 0 ? "KODE T" : ''; ?>
            </td>
        </tr>
        <tr>
            <td align="center" colspan="2"><h3>--- <?= $data['user']; ?> ---</h3></td>
        </tr>
    </table>
    <?php
    echo '</div>';
}

$html      = ob_get_contents();
$file_name = "Tracer";
ob_end_clean();
include "include/PDF.php";
//include "include/cetak_pdf.php";
// Generate Ke PDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor("RSUD Kota Bogor");
$pdf->SetTitle($file_name);
$pdf->SetSubject('Radiologi');
$pdf->SetKeywords('Radiologi, Report');

// remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('courier', '', 11);

// add a page
$pdf->AddPage();

// set some text to print
//$txt = <<<EOD
//
//EOD;

$txt = $html;
$tagvs = array('tr' => array(0 => array('h' => 5, 'n' => 5), 1 => array('h' => 5, 'n' => 5)));
$pdf->setHtmlVSpace($tagvs);
// print a block of text using Write()
$pdf->writeHTML($txt, true, false, true, false, '');
// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output($file_name.'.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+



?>
