<?
$sql_soap = "SELECT * FROM t_diagnosadanterapi a 
		  LEFT JOIN icd b ON (a.ICD_CODE=b.icd_code) 
		  LEFT JOIN icd_cm c ON (a.ICDCM=c.kode)
		  WHERE a.IDXDAFTAR=".$idxdaftar."
		  AND a.NOMR='".$_REQUEST['nomr']."'";


$get_soap = mysql_query($sql_soap); //get_anamnesa
$dat_soap = mysql_fetch_assoc($get_soap); //get_anamnesa

$diag_qry = mysql_query($diag_sql); //pake $sql_soap aja - punya diagnosa
$dvd = mysql_fetch_assoc($diag_qry);

$tekanan_darah	= !empty($dat_soap['TEKANAN_DARAH']) ? $dat_soap['TEKANAN_DARAH'] : '';
$golongan_darah	= !empty($dat_soap['GOLONGAN_DARAH']) ? $dat_soap['GOLONGAN_DARAH'] : '';
$tinggi_badan	= !empty($dat_soap['TINGGI_BADAN']) ? $dat_soap['TINGGI_BADAN'] : '';
$berat_badan	= !empty($dat_soap['BERAT_BADAN']) ? $dat_soap['BERAT_BADAN'] : '';

?>

<div class="box">
    <div id="frame">
        <div id="frame_title">
            <h3>PENGKAJIAN KEPERAWATAN RAWAT JALAN</h3>
        </div>

        <form method="post" action="rajal/save_anamnesa_baru.php" name="soap" id="soap"> <!-- ## EDIT DI AKHIR -->

            <input name="txtNoMR" id="txtNoMR" type="hidden"
                   value =<?php echo $_REQUEST['nomr'];?> >
            <input name="txtIdxDaftar" id="txtIdxDaftar" type="hidden"
                   value=<?php echo $idxdaftar;?> >
            <input name="txtKdPoly" id="txtKdPoly" type="hidden"
                   value=<?php echo $kdpoly;?> >
            <input name="txtKdDokter" id="txtKdDokter" type="hidden"
                   value=<?php echo $kddokter;?> >
            <input name="txtTglReg" id="txtTglReg" type="hidden"
                   value=<?php echo $tglreg;?> >
            <input name="txtNip" id="txtNip" type="hidden"
                   value=<?php echo $_SESSION['NIP'];?> >
            <input type="hidden" name="idxterapi"
                   value="<? echo $dat_soap['IDXTERAPI'];?>" >
            <br>
            <br>

            <table class="tbl-pemeriksaan1" width="100%" border="0" align="top" >

                <tr>
                    <td>Hubungan pasien dengan anggota keluarga</td>
                    <td>
                        <input type="radio" value="1"  name="new_kasus"/> Baik
                        <input type="radio" value="0"  name="new_kasus" /> Tidak Baik
                    </td>
                    <td></td>

                    <td>Tekanan Darah</td>
                    <td>
                        <input type="text" name="tekanan_darah" value="<?php echo $tekanan_darah;?>" id="tekanan_darah">
                    </td>
                    <td></td>

                    <td>Berat Badan</td>
                    <td>
                        <input type="text" name="berat_badan" value="" id="berat_badan">
                    </td>
                    <td></td>
                    <td>Pernafasan</td>
                    <td>
                        <input type="text" name="pernafasan" value="" id="pernafasan">
                    </td>
                    <td></td>
                    <td>Berat Badan</td>
                    <td>
                        <input type="text" name="berat_badan" value="" id="berat_badan">
                    </td>
                </tr>

                <tr>
                    <td>Data Psikologis</td>
                    <td>
                        <input type="radio" value="1"  name="new_visit" /> Tenang
                        <input type="radio" value="0"  name="new_visit" /> Cemas
                        <input type="radio" value="2"  name="new_visit" /> Takut
                        <input type="radio" value="3"  name="new_visit" /> Marah
                    </td>
                    <td></td>
                    <td>Golongan Darah</td>
                    <td>
                        <select name="golongan_darah" id="golongan_darah">
                            <option value=""> Pilih Golongan Darah </option>
                            <option value="A" <?php if($golongan_darah == 'A'): echo 'selected="selected"'; endif;?>> Gol A </option>
                            <option value="B" <?php if($golongan_darah == 'B'): echo 'selected="selected"'; endif;?>> Gol B </option>
                            <option value="AB"<?php if($golongan_darah == 'AB'): echo 'selected="selected"'; endif;?>> Gol AB </option>
                            <option value="O" <?php if($golongan_darah == 'O'): echo 'selected="selected"'; endif;?>> Gol O </option>
                        </select>
                    </td>
                    <td></td>
                    <td>Tinggi Badan</td>
                    <td>
                        <input type="text" name="tinggi_badan" value="" id="tinggi_badan">
                    </td>
                    <td></td>
                    <td>Nadi</td>
                    <td>
                        <input type="text" name="nadi" value="" id="nadi">
                    </td>
                </tr>

            </table>

            <br>
            <br>


            <table class="tbl-soap" width="100%" border="0" align="top" >

                <tr>
                    <th valign="top">Alasan Kunjungan</th>
                    <td></td>
                    <th valign="top"><strong>[O]</strong>Pemeriksaan Fisik</th>
                </tr>

                <tr>
                    <td>
                        <textarea name="resume_anamnesa" id="resume_anamnesa" cols="70" rows="7" style="width:99%"><?=$dat_soap['ANAMNESA']?></textarea>
                    </td>
                    <td></td>
                    <td>
                        <textarea name="resume_fisik" id="resume_fisik" cols="70" rows="7" style="width:99%"><?=$dat_soap['pemeriksaan_fisik']?></textarea>
                    </td>
                </tr>

                <tr>
                    <th valign="top"><strong>[A]</strong>Diagnosa</th>
                    <td></td>
                    <th valign="top"><strong>[P]</strong>Terapi</th>
                </tr>

                <tr>
                    <td>
                        <textarea name="resume_diagnosa" id="resume_diagnosa" cols="70" rows="7" style="width:99%"><?=$dat_soap['DIAGNOSA']?></textarea>
                    </td>
                    <td></td>
                    <td>
                        <textarea name="resume_terapi" id="resume_terapi" cols="70" rows="7" style="width:99%"><?=$dat_soap['TERAPI']?></textarea>
                    </td>
                </tr>

            </table>

            <tr>
                <td colspan="2">
                    <div  align="left" style="margin:5px; padding:5px;">
                        <input name="txtNoMR" id="txtNoMR" type="hidden" value=<?php echo $nomr; ?> >
                        <input name="txtIdxDaftar" id="txtIdxDaftar" type="hidden" value=<?php echo $idxdaftar; ?> >
                        <input name="txtKdPoly" id="txtKdPoly" type="hidden" value=<?php echo $kdpoly; ?> >
                        <input name="txtKdDokter" id="txtKdDokter" type="hidden" value=<?php echo $kddokter; ?> >
                        <input name="txtTglReg" id="txtTglReg" type="hidden" value=<?php echo $tglreg; ?> >
                        <input name="txtNip" id="txtNip" type="hidden" value=<?php echo $_SESSION['NIP'];?> >
                        <input type="hidden" name="idxterapi" value="<? echo $dat_soap['IDXTERAPI']; ?>" />
                        <!-- TOMBOL -->
                        <input type="submit" class="text" name="save" value=" S i m p a n " />
                        <input type="reset" class="text" name="reset" value=" R e s e t " />
                    </div>
                </td>
            </tr>

        </form>
    </div>
</div>