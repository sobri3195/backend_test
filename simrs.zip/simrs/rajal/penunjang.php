<?php
/**
 * Created by PhpStorm.
 * User: Fernalia
 * Date: 01/02/2016
 * Time: 15:08
 */
?>

<table width="95%">
    <tr>
        <th colspan="3">Catatan</th>
    </tr>
    <tr>
        <td colspan="3" style="text-align: center">
            <form method="post" action="rajal/model/catatan_medik.php">
                <?php
                    $sql    = mysql_query('SELECT catatan_medik FROM m_pasien WHERE NOMR="'.$_REQUEST['nomr'].'"');
                    $dsql   = mysql_fetch_array($sql);
                ?>
                <textarea class="text" id="catatan" name="catatan" rows="20" cols="150" style="width:80%" ><?php echo $dsql['catatan_medik'];?></textarea>
                <br/>
                <div style="text-align: right; padding-top: 10px; margin-right: 15%">
                    <input type="hidden" name="link" id="link" value="<?php echo $_REQUEST['link']; ?>">
                    <input type="hidden" name="idx" id="idx" value="<?php echo $_REQUEST['idx']; ?>">
                    <input type="hidden" name="nomr" id="nomr" value="<?php echo $_REQUEST['nomr']; ?>">
                    <input type="submit" class="text" name="save" value=" S i m p a n " />
                    <input type="reset" class="text" name="reset" value=" R e s e t " />
                </div>
            </form>
        </td>
    </tr>
    <tr>
        <td>
            &nbsp;
        </td>
    </tr>
    <tr>
        <td width="40%">
            <table width="100%" border="0" cellpadding="1" cellspacing="1">
                <tr>
                    <th width="49%">Laboratorium</th>
                </tr>
                <tr>
                    <td valign="top">
                        <?php
                        $myquery   = "SELECT * FROM sysmex_reshd
									   WHERE PID = '".$_REQUEST['nomr']."'
								  	   ORDER BY ONO DESC";
                        $get 	   = mysql_query($myquery)or die(mysql_error());
						if(mysql_num_rows($get) > 0){
							$row_reshd = mysql_fetch_array($get); 
							$ono 	   = $row_reshd['ONO'];
							$clinician = $row_reshd['CLINICIAN_NM']; 
							$source    = $row_reshd['SOURCE_NM']; 
							$request_dt = $row_reshd['REQUEST_DT']; 
							
							$sql_resdt  = "SELECT * FROM sysmex_resdt
										   WHERE ONO = '".$ono."' ";
							$rs_resdt   = mysql_query($sql_resdt);
							?>
							<table width="100%" class="table" id="lab">
								<thead>
									<tr>
										<th></th>
										<th></th>
										<th></th>
										<th></th>
									</tr>
								</thead>
								<tbody>
										<tr>
											<td>No Lab</td>
											<td>:&nbsp;<?= $ono; ?></td>
											<td>Dokter</td>
											<td>:&nbsp;<?= $clinician; ?></td>
										</tr>
										<tr>
											<td>Tanggal</td>
											<td>:&nbsp;<?= $request_dt; ?></td>
											<td>Ruangan</td>
											<td>:&nbsp;<?= $source; ?></td>
										</tr>
										<tr>
											<td colspan="4" width="100%">
												<table width="100%">
													<tr>
														<th>Jenis Pemeriksaan</th>
														<th>Hasil</th>
														<th>Unit</th>
														<th>Nilai Normal</th>
														<th>Di validasi</th>
													</tr>
													<?php 
														if(mysql_num_rows($rs_resdt) > 0){
															while($row_resdt = mysql_fetch_assoc($rs_resdt)) { 
													?>
															<tr>
																<td><?= $row_resdt['TEST_NM']; ?></td>
																<td><?= $row_resdt['RESULT_VALUE']; ?></td>
																<td><?= $row_resdt['UNIT']; ?></td>
																<td><?= $row_resdt['REF_RANGE']; ?></td>
																<td><?= $row_resdt['VALIDATE_BY']; ?></td>
															</tr>

													<?php 
															} 
														}
													?>
												</table>
											</td>
										</tr>
								</tbody>
							</table>
						<?php } ?>
                    </td>
                </tr>
            </table>
        </td>
        <td>
            &nbsp;&nbsp;
        </td>
        <td>
            <table align="center" width="100%" border="0" cellpadding="1" cellspacing="1">
                <tr>
                    <th width="49%">Radiologi</th>
                </tr>
                <tr>
                    <td valign="top">
                        <?php
                        $myquerys = "SELECT a.`TGLORDER`, b.`nama_tindakan`, a.`DIAGNOSA`, c.`nama` AS POLY, d.`NAMADOKTER`, a.`HASILRESUME`
                                        FROM t_radiologi a
                                        JOIN m_tarif2012 b ON a.`JENISPHOTO` = b.`kode_tindakan`
                                        JOIN m_poly c ON a.`POLYPENGIRIM` = c.`kode`
                                        JOIN m_dokter d ON a.`DRPENGIRIM` = d.`KDDOKTER`
                                        WHERE a.APS=0
                                        AND a.nomr = '".$_REQUEST['nomr']."'
                                        ORDER BY a.TGLORDER DESC
										LIMIT 10";
                        ?>
                        <table width="95%" border="0" cellspacing="1" class="table" id="radiologi">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Foto</th>
                                    <th>Dokter</th>
                                    <th>Poly</th>
                                    <th>Hasil</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $rowxx= mysql_query($myquerys)or die(mysql_error());
                            while($data = mysql_fetch_array($rowxx)){  ?>
                                <tr>
                                    <td><?php echo $data['TGLORDER']; ?></td>
                                    <td><strong>-<?php echo $data['nama_tindakan']?></strong></td>
                                    <td><?php echo $data['NAMADOKTER'];?></td>
                                    <td><?php echo $data['POLY'];?></td>
                                    <td><?php echo $data['HASILRESUME'];?></td>
                                </tr>

                            <?
                            }
                            ?>
                            </tbody>
                        </table>

                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<script>
    jQuery(document).ready(function() {
        jQuery('#lab').dataTable({
            "paging":   true,
            "ordering": false,
            "info":     false,
            "searching": false,
            "header": false,
            "bLengthChange": false,
            "bJQueryUI": true,
            "sDom": 'lfrtip',
            lengthMenu: [
                [3],
                [3, "All"]
            ]
        });

        jQuery('#radiologi').dataTable({
            "paging":   true,
            "ordering": false,
            "info":     false,
            "searching": false,
            "header": false,
            "bLengthChange": false,
            "bJQueryUI": true,
            "sDom": 'lfrtip',
            lengthMenu: [
                [5],
                [5, "All"]
            ]
        });
    });
</script>