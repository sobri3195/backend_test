<?php 
	include("../include/connect.php");

	$kondisi='';
	if ($_GET['poly']!=0){
		$kpoly=' and r.KDPOLY = '.$_GET['poly'];
	}
	if($_GET['crbayar'] !=''){
		$kbyr=' and r.CARABAYAR = '.$_GET['crbayar'];
	}
	if ($_GET['cnama']!=""){
		$knama=" and A.NAMA like '%".$_GET['cnama']."%'";
	}
	if ($_GET['cnomr']!=""){
		$knomr=" and r.NOMR = '".$_GET['cnomr']."'";
	}
	
	$start	= 'CURDATE()';
	$end	= 'CURDATE()';
	if ($_GET['start']!=""){
		$start 	= "'".$_REQUEST['start']."'";
	}
	if ($_GET['end']!=""){
		$end 	= "'".$_REQUEST['end']."'";
	}
	$waktu	= ' and (r.tanggal between '.$start.' and '.$end.')';
?>

<div align="center">
    <div id="frame">
	    <div id="frame_title">
	      <h3>PASIEN ANGSURAN</h3>
	      <br/>
	      <br/>
	      <div align="center" style="margin:5px;">
		      <form name="formsearch" id="cari" method="get" action="<?php ?>">
		      	   cari nama  <input type="text" name="cnama" class="text" <?php echo $_REQUEST['cnama']; ?>/>
                   / No MR 
        		  <input type="text" name="cnomr" size="10" class="text" <?php echo $_REQUEST['cnomr']; ?>/> 
        		  <?php /*?><select name="crbayar" id="crbayar" class="text select2" >
		             <option value="" <?php if($_GET['crbayar'] == ''): echo 'selected="selected"'; endif; ?>>--Pilih Cara Bayar--</option>
		             <?php 
		             	$carabayar 	= getCaraBayar();
		             	while($crbyr = mysql_fetch_array($carabayar)){
		             ?>
		             <option value="<?php echo $crbyr['KODE']; ?>" <?php if($_GET['crbayar'] == $crbyr['KODE']): echo 'selected="selected"'; endif; ?>><?php echo $crbyr['NAMA']; ?></option>
		             <?php 
		             	}
		             ?>
		          </select>
		          <?php*/ ?>
			      <input type="text" size="10" class="text datepicker3" id="TGLREG" name="start" value="<?php if($_REQUEST['start'] != ''): echo $_REQUEST['start']; else: echo date('Y/m/d'); endif;?>" readonly /> - 
			      <input type="text" size="10" class="text datepicker3" id="TGLREG2" name="end" value="<?php if($_REQUEST['end'] != ''): echo $_REQUEST['end']; else: echo date('Y/m/d'); endif;?>" readonly />
				  <input type="submit" class="text" value="Cari" />
				  <input type="hidden" name="link" value="3angsuran" />
	    	  </form> 
    	  </div> 
	      <br/>
	      <br/>
	      <table class="table">
	      	<thead>
		      	<tr>
		      		<th>No</th>
		      		<th>NO RM</th>
		      		<th>Nama Pasien</th>
		      		<th>Poly</th>
		      		<th>Cara Bayar</th>
		      		<th>Status</th>
		      		<th>Aksi</th>
		      	</tr>
	      	</thead>
	      	<tbody>
	      		<?php 
	      			$i = 1;
	      			//$dataBillLab	= getBillLab($nomr, $nama, $crbayar, $start, $end);
	      			$sql 			= "SELECT DISTINCT A.NOMR,A.NAMA,p.NAMA AS POLY1,C.NAMA AS CARABAYAR1, r.IDXDAFTAR, r.KDPOLY, d.tutup_pembayaran  FROM t_billrajal r
										JOIN m_pasien A ON r.nomr=A.nomr
										JOIN t_bayarrajal b ON b.idxdaftar = r.idxdaftar
										JOIN m_poly p ON r.KDPOLY=p.KODE
										JOIN m_carabayar C ON r.CARABAYAR=C.KODE 
										JOIN t_pendaftaran d ON d.IDXDAFTAR=r.IDXDAFTAR
										WHERE 1 = 1 AND d.tutup_pembayaran=0 AND d.subcarabayar=4 ".$kondisi.$waktu;
	      			$rs 			= mysql_query($sql);
	      			while($data 	= mysql_fetch_array($rs)){
	      		?>
	      		<tr>
		      		<td>
		      			<?php
		      				echo $i++;	
		      			?>
		      		</td>
		      		<td>
		      			<?php
		      				echo $data['NOMR'];
		      			?>
		      		</td>
		      		<td>
		      			<?php 
		      				echo $data['NAMA'];
		      			?>
		      		</td>
		      		<td>
		      			<?php 
		      				echo $data['POLY1'];
		      			?>
		      		</td>
		      		<td>
		      			<?php 
		      				echo $data['CARABAYAR1'];
		      			?>
		      		</td>
		      		<td>
		      			<?php 
			      			$ssql	= mysql_query('select COUNT(*) as tagihan from t_bayarrajal where NOMR = "'.$data['NOMR'].'" and IDXDAFTAR = "'.$data['IDXDAFTAR'].'" AND LUNAS = 0');
							$sqry 	= mysql_fetch_array($ssql);
							if($sqry['tagihan'] == 0){
								$status_billing = 'Lunas';
							}else{
								$status_billing = '';
							}
							
							echo $status_billing;
		      			?>
		      		</td>
		      		<td>
		      			<a href="index.php?link=34&nomr=<?php echo $data['NOMR']; ?>&poly=<?php echo $data['KDPOLY'];?>&idxdaftar=<?php echo $data['IDXDAFTAR'];?>"> <input type="button" class="text" value="Prosess" /></a>
		      		</td>
		      	</tr>
		      	<?php 
	      			}
		      	?>
	      	</tbody>
	      </table>
	    </div>
   	</div>
</div>
</div>

<script type="text/javascript">
	jQuery(".table").dataTable();
	jQuery(".select2").select2();
</script>