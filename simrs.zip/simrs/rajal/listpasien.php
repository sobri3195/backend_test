<?php 
session_start();
include("../include/connect.php");
//include('../ps_pagination_x.php');
require_once('ps_pagebill.php');
include("../include/function.php");

$_SESSION['page']=$_GET['page'];
$_SESSION['tgl_reg']=$_GET['tgl_reg'];
$_SESSION['tgl_reg2']=$_GET['tgl_reg2'];
$_SESSION['nama']=$_GET['nama'];
$_SESSION['norm']=$_GET['norm'];

$qry_poly 	= mysql_query("SELECT * FROM m_poly WHERE kode='".$_SESSION['KDUNIT']."'");
$poly 		= mysql_fetch_assoc($qry_poly);

$start		= date('Y/m/d');
if($_REQUEST['tgl_reg'] != ''){
	$start	= $_REQUEST['tgl_reg'];
}
$end	= date('Y/m/d');
if($_REQUEST['tgl_reg2'] != ''){
	$end	= $_REQUEST['tgl_reg2'];
}


$search = 'and ( b.tglreg between "'.$start.'" and "'.$end.'" )';

$norm = "";
if(!empty($_GET['norm'])) {
    $norm =$_GET['norm'];
}

if($norm !="") {
    $search = $search." AND a.NOMR = '".$norm."' ";
}

$nama = "";
if(!empty($_GET['nama'])) {
    $nama =$_GET['nama'];
}

if($_REQUEST['sort'] != ''){
    $search = $search . $_REQUEST['sort'];
}

if($nama !="") {
    $search = $search." AND b.NAMA LIKE '%".$nama."%' ";
}

?>
<div align="center">
    <div id="frame" style="width:100%;">
        <div id="frame_title"><h3>LIST DATA PASIEN POLIKLINIK <?php echo $poly['nama']; ?></h3></div>
        <div style="margin:5px;">
			<div align="left" style="width:50%;float:left;">
				<table width="500" border="0" cellspacing="10" class="tb">
					<tr>
						<td colspan="2" align="center"><font style="font-weight:bold;font-size:11pt;">Form Kedatangan Status</font></td>
					</tr>
					<tr>
						<td width="80">No. Register</td>
						<td>
							<input type="hidden" id="user" value="<?= $_SESSION['NIP']; ?>"/>
							<input type="hidden" id="ip_address" value="<?= getRealIpAddr(); ?>"/>
							<input type="text" class="text" name="no_register" id="no_register" value="" placeholder="No. Register Pendaftaran" style="width:370px"/>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<div id="alert_form_kedatangan_status"></div>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<font style="color:#B71C1C;font-size:7pt;">Note: Ketikan nomor register yang terletak disebelah bawah QR Code pada lembar tracer jika QR Code tidak dapat terbaca oleh alat.</font>
						</td>
					</tr>
				</table>
			</div>
			<div align="right" style="width:50%;float:right;">
				<form name="formsearch" method="get" >
					<table width="248" border="0" cellspacing="0" class="tb">
						<tr>
							<td width="52">No RM</td>
							<td width="192"><input type="text" name="norm" id="norm" class="text" value="<? if($norm!="") {
									echo $norm;
												   }?>" style="width:80px;"></td>
						</tr>
						<tr>
							<td>Nama</td>
							<td><input type="text" name="nama" id="nama" class="text" value="<? if($nama!="") {
									echo $nama;
									   }?>"></td>
						</tr>
						<tr>
							<td>Tanggal</td>
							<td><input type="text" name="tgl_reg" id="tgl_pesan" class="text datepicker" style="width:100px;"
									   value="<? if($_REQUEST['tgl_reg'] != ''): echo $_REQUEST['tgl_reg']; else: echo date('Y-m-d'); endif; ?>"/></td>
						</tr>
						<tr>
							<td>S/d</td>
							<td><input type="text" name="tgl_reg2" id="tgl_pesan2" class="text datepicker" style="width:100px;"
									   value="<? if($_REQUEST['tgl_reg2'] != ''): echo $_REQUEST['tgl_reg2']; else: echo date('Y-m-d'); endif; ?>"/></td>
						</tr>
						<tr>
							<td>Berdasarkan</td>
							<td>
								<select class="select2" name="sort">
									<option value="" <?php if($_REQUEST['sort'] == ""){echo 'selected';} ?>>Semua</option>
									<option value="AND b.STATUS=0" <?php if($_REQUEST['sort'] == "AND b.STATUS=0"){echo 'selected';} ?>>Belum diproses</option>
									<option value="AND b.STATUS!=0" <?php if($_REQUEST['sort'] == "AND b.STATUS!=0"){echo 'selected';} ?>>Sudah diproses</option>
								</select>
							</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td><input type="submit" value="Cari" class="text"/>
								<input type="hidden" name="link" value="5" /></td>
						</tr>
					</table>
				</form>
			</div>
			<div style="clear:both;"></div>
            <div id="table_search">
                <input type="button" class="text refresh" value="Refresh" style="display:block; float:right; padding:5px; margin:5px;" />
                <table id="table">
                    <thead>
                        <tr>
                            <td>No.</td>
                            <td>NOMR Baru</td>
							<td>NOMR Lama</td>
                            <td>Nama Pasien</td>
                            <td>Alamat</td>
                            <td>Jenis Kelamin</td>
                            <td>Jenis Pasien</td>
                            <td>Nama Dokter</td>
                            <td>Tanggal</td>
                            <td>Status Datang</td>
                            <td>TTV</td>
                            <td>Masuk</td>
                            <td>Keluar</td>
                            <td>Status Keluar</td>
                            <td>Keterangan</td>
                            <td>&nbsp;</td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $style 	= '';
                    $sql    = "SELECT a.NOMR,
									  a.nomr_old,
									  a.NAMA,ALAMAT,
									  a.TGLLAHIR,
									  a.JENISKELAMIN, 
									  b.KDDOKTER, 
									  b.MASUKPOLY, 
									  b.TGLREG, 
									  b.kode_p,
									  b.KELUARPOLY, 
									  b.STATUS AS STATKELUAR, 
									  b.IDXDAFTAR, 
									  b.pasien_bermasalah, 
									  b.note_problem, 
									  b.tutup_pembayaran,
									  b.jam_kedatangan_status,
									  b.jam_ttv,
									  k.keterangan,
									  CASE b.minta_rujukan WHEN '1' THEN 'Minta Rujukan' END AS minta_rujukan,
                        			  CASE b.STATUS 
										WHEN '6' THEN (SELECT f.nama FROM m_dasarrujuk f WHERE f.kode = c.alasan_rujuk)
                        				WHEN '5' THEN (SELECT f.nama FROM m_poly f WHERE f.kode = c.poly)
                        				ELSE NULL END AS namapoly, 
									  b.KDCARABAYAR, 
									  b.kode_t, 
									  b.KDPOLY,
									  SUM(t_billrajal.TARIFRS * t_billrajal.QTY) AS total,
									  b.NIP
                        	   FROM m_pasien a, t_pendaftaran b
                        	   LEFT JOIN m_statuskeluar k ON b.status=k.status
                        	   LEFT JOIN t_alasan_rujuk c ON b.idxdaftar=c.idxdaftar
							   JOIN t_billrajal ON t_billrajal.IDXDAFTAR = b.IDXDAFTAR AND t_billrajal.NOMR = b.NOMR
                        	   JOIN t_bayarrajal d ON d.NOBILL = t_billrajal.NOBILL
                        	   WHERE a.nomr=b.nomr ".$search."
                        		 AND b.kdpoly='".$_SESSION['KDUNIT']."'
                        	   GROUP by IDXDAFTAR
                        	   ORDER BY b.IDXDAFTAR ASC";
                    $rs     = mysql_query($sql);
                    while($data = mysql_fetch_array($rs)) {
                        $kode_p = $data['kode_p'];
                        $kode_t = $data['kode_t'];
                        if ($kode_p > 0) {
                            $style = 'style="background-color: #e91e63;"';
                        } else if($kode_t > 0){
							$style = 'style="background-color: #9c27b0;"';
						}else {
                            $style = '';
                        }

                        $pasien_bermasalah = $data['pasien_bermasalah'];
                        if ($pasien_bermasalah > 0) {
                            $style = 'style="background-color: red;"';
                        } else {
                            $style = $style;
                        }
                    ?>
                        <tr <?   echo "class =";
                        $count++;
                        if ($count % 2) {
                            echo "tr1";
                        }
                        else {
                            echo "tr2";
                        }
                        ?> <?php echo $style; ?>>
                            <td><? $NO=($NO+1);
                                if ($_GET['page']==0) {
                                    $hal=0;
                                }else {
                                    $hal=$_GET['page']-1;
                                } echo
                                    ($hal*15)+$NO;?>
                                <input type="hidden" id="note_<?php echo $data['IDXDAFTAR']; ?>" value="<?php echo $data['note_problem']; ?>" />
                            </td>
                            <td><? echo $data['NOMR'];?></td>
							<td><?= $data['nomr_old']; ?></td>
                            <td><? echo $data['NAMA']; ?></td>
                            <td><? echo $data['ALAMAT']; ?></td>
                            <td><? if($data['JENISKELAMIN']=="l" || $data['JENISKELAMIN']=="L") {
                                    echo"Laki-Laki";
                                }elseif($data['JENISKELAMIN']=="p" || $data['JENISKELAMIN']=="P") {
                                    echo"Perempuan";
                                } ?>
                            </td>
                            <td>
                                <?php
                                    if($data['KDCARABAYAR']<=5) {
                                        $sql1   = mysql_query('SELECT NAMA FROM m_carabayar WHERE KODE='.$data['KDCARABAYAR']);
                                        $dsql1  = mysql_fetch_array($sql1);

                                        echo $dsql1['NAMA'];
                                    }
                                    else{
                                        echo 'Perusahaan';
                                    }
                                ?>
                            </td>
                            <td>
                                <?php
                                $kddokter	= $data['KDDOKTER'];
                                $getdokter	= getDokter($kddokter);
                                $namadokter	= $getdokter['NAMADOKTER'];

                                echo $namadokter;
                                ?>
                            </td>
                            <td><? echo $data['TGLREG']; ?></td>
                            <td><? echo $data['jam_kedatangan_status']; ?></td>
                            <td><? echo $data['jam_ttv']; ?></td>
                            <td><? echo $data['MASUKPOLY']; ?></td>
                            <td><? echo $data['KELUARPOLY']; ?></td>
                            <td>
								<?php 
									if($data['tutup_pembayaran'] == 0){
										echo $data['keterangan']." (".$data['namapoly'].")"; 
									} else{
										if($data['keterangan']=="") { 
											echo "Transaksi tidak dapat dibatalkan karena sudah ditutup oleh kasir";
										} else{
											echo $data['keterangan']." (".$data['namapoly'].")"; 
										}
									}
								?>
							</td>
                            <td>
								<?php 
									if($data['NIP'] == "sms" || $data['NIP'] == "APM"){
								?>
										<strong>
											<font style="font-size:14pt;color:#BF360C;"><?= $data['NIP']; ?></font>
										</strong>
								<?php
									}
									echo $data['minta_rujukan']; 
								?>
							</td>
                            <td>
                                <a href="index.php?link=51&nomr=<?=$data['NOMR'];?>&idx=<? echo $data['IDXDAFTAR']; ?>"><input type="button" class="text" value="Prosess" /></a>
                                <? if($data['tutup_pembayaran'] == 0){
										if($data['keterangan']=="") { 
										$sql_bill = "SELECT * FROM rsud_trans_rj
													 WHERE idxdaftar = '". $data['IDXDAFTAR'] ."' ;";
										$rs_bill  = mysql_query($sql_bill);
											if(mysql_num_rows($rs_bill) == 0){
								?>
                                    | <button class="btn_batal text" idxdaftar="<?= $data['IDXDAFTAR']; ?>" nomr="<?= $data['NOMR']; ?>" poli="<?= $data['KDPOLY'];  ?>" total_tarif="<?= $data['total']; ?>">BATAL</button>
                                <? 
											}
										}
									} 
								?>
                                <?php
                                /*if($data['note_problem'] != ''){
                                    ?>
                                    <input type="button" id="lihat_note_<?php echo $data['IDXDAFTAR']; ?>" class="text button lihat_note" value="Lihat Note" idxd="<?php echo $data['IDXDAFTAR']; ?>" nomr="<?php echo $data['NOMR']; ?>" />
                                <?php
                                }*/
                                ?>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <br />
    <?
    $qry_excel = "SELECT  b.IDXDAFTAR AS INDEX_DAFTAR,
					a.nomr AS NORM, 
					a.NAMA AS NAMA_PASIEN,
					a.ALAMAT,
					a.JENISKELAMIN AS JNS_KELAMIN,
					b.MASUKPOLY AS TGL_MASUK, 
					b.KELUARPOLY AS TGL_KELUAR, 
					b.STATUS as STATKELUAR					 
	      	FROM m_pasien a, t_pendaftaran b 
		  	LEFT JOIN m_statuskeluar k on b.status=k.status
		  	LEFT JOIN t_alasan_rujuk c on b.idxdaftar=c.idxdaftar
		  	LEFT JOIN m_poly d on d.kode=c.poly
		  	WHERE a.nomr=b.nomr ".$search." and b.kdpoly='".$_SESSION['KDUNIT']."' 
		  	ORDER BY b.IDXDAFTAR ASC";
?>
    <div align="left">
<!--        <form name="formprint" method="post" action="gudang/excelexport.php" target="_blank" >-->
<!--            <input type="hidden" name="query" value="--><?//=$sql?><!--" />-->
<!--            <input type="hidden" name="header" value="DATA KUNJUNGAN PASIEN POLIKLINIK --><?php //echo $poly['nama'];?><!--" />-->
<!--            <input type="hidden" name="filename" value="data_kunjungan_pasien" />-->
<!--            <input type="submit" value="Export To Ms Excel Document" class="text" />-->
<!--        </form>-->
    </div>
</div>
<p></p>

<div id="dialog-form2" >
    <form method="post">
        <fieldset>
        	<label for="note_problem" id="lbl_note">NOTE</label>
        	<textarea rows="3" cols="50" name="note" id="note_problem" readonly></textarea>
        </fieldset>
    </form>
</div>

<div id="dialog-form" >
    <form method="post">
        <fieldset>
			<div id="keterangan_batal">Apakah Anda yakin akan membatalkan transaksi ini? </div><br/><br/>
            <label>Alasan Pembatalan : <label>
			<input type="hidden" id="idxdaftar_batal"/>
			<input type="hidden" id="nomr_batal"/>
			<input type="hidden" id="poli_batal"/>
			<input type="text" id="alasan_batal"/>
			<button class="text" id="btn_batal_yes">Batalkan</button>
        </fieldset>
    </form>
</div>

<script type="text/javascript">
	jQuery("label").css({display: 'block',marginBottom: '10px'});
	jQuery("textarea").css({marginBottom:'12px',width: '450px',height: '200px',padding: '.4em'});
	jQuery("fieldset").css({padding:'0',border:'0', marginTop:'25px'});
	
	jQuery(".lihat_note").click(function(){
		var idxd 	= jQuery(this).attr('id').substring(11);
		var nomr 	= jQuery(this).attr('nomr');
		var note 	= jQuery("#note_" + idxd).val();

		jQuery("#note_problem").val(note);

		jQuery("#dialog-form2").dialog({
            title: "Note Pasien Bermasalah"
        }).dialog("open");
	});
	
	 jQuery(".btn_batal").click(function(){
        var idxdaftar 	= jQuery(this).attr("idxdaftar");
        var nomr      	= jQuery(this).attr("nomr");
        var poli      	= jQuery(this).attr("poli");
		var total_tarif = jQuery(this).attr("total_tarif");
		
		jQuery('#idxdaftar_batal').val(idxdaftar);
		jQuery('#nomr_batal').val(nomr);
		jQuery('#poli_batal').val(poli);
		
		if(total_tarif > 82000){
			jQuery('#keterangan_batal').html('Perhatian! Pada transaksi ini terdapat rincian penunjang dan pemeriksaan lainnya. Apakah Anda yakin akan membatalkan transaksi ini?');
		}
  
		jQuery("#dialog-form").dialog("open");
    });
	
	jQuery("#btn_batal_yes").click(function(){
		var idxdaftar = jQuery('#idxdaftar_batal').val();
		var nomr 	  = jQuery('#nomr_batal').val();
		var poli 	  = jQuery('#poli_batal').val();
		var alasan 	  = jQuery('#alasan_batal').val();
		if(alasan == ""){
			alert("Harap diisi dulu alasan pembatalan, untuk membatalkan transaksi ini...");
		} else{
			jQuery.ajax({
				url: "models/pembatalan_pasien.php",
				method: "post",
				data: {idxdaftar:idxdaftar,nomr:nomr,poli:poli,alasan:alasan},
				success: function(data){
					alert("Pasien sudah dibatalkan");
					location.reload();
				},
				error: function(jqXHR, textStatus, errorThrown){
					alert("Perubahan tidak gagal dilakukan!");
				}
			});
		}
	});
	
	jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 200,
        width: 700,
        modal: true,
        show: {
            effect: "clip",
            duration: 240
        },
        close: function() {
            jQuery("#dialog-form").dialog('destroy');
        }
    });
	
	jQuery("#dialog-form2").dialog({
	    autoOpen: false,
	    height: 410,
	    width: 490,
	    modal: true, 
	    show: {
	        effect: "clip",
	        duration: 240
	    },
	    buttons: {
	        OK: function() {
	            jQuery(this).dialog("close");
	        }
	    }
	});

    jQuery(".refresh").button({icons: {primary: "ui-icon-print"}});
    jQuery(".refresh").click(function(){
        location.reload();
    });

    jQuery("#table").dataTable();
    jQuery(".select2").select2();
	
	jQuery("#no_register").focus();
	jQuery("#alert_form_kedatangan_status").val('');
	jQuery('#no_register').bind("enterKey",function(e){
		var no_register = jQuery(this).val();
		var user 		= jQuery('#user').val();
		var ip_address  = jQuery('#ip_address').val();
		jQuery.ajax({
            url: "rajal/model/kedatangan_status_by_register.php",
            method: "post",
            data: {no_register:no_register,user:user,ip_address:ip_address},
            success: function(data){
                if(data == 1){
					jQuery("#alert_form_kedatangan_status").html('Jam kedatangan no register = <font style="font-size:12pt;font-weight:bold;">' + no_register + '</font> sudah terekam.');
					jQuery('#no_register').val('');
					jQuery('#no_register').focus();
					//location.reload();
				} else{
					alert('Record jam kedatangan no register = ' + no_register + ' tidak dapat dilakukan. Silahkan coba kembali!');
					jQuery('#no_register').val('');
					jQuery('#no_register').focus();
				}
            },
            error: function(jqXHR, textStatus, errorThrown){
                alert("Perubahan tidak gagal dilakukan!");
            }
		});
	});

	jQuery('#no_register').keyup(function(e){
		if(e.keyCode == 13) {
			jQuery(this).trigger("enterKey");
		}
	});
</script>