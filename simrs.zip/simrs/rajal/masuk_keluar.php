<?php
	$SQL = "SELECT `STATUS`,MASUKPOLY,KELUARPOLY,jam_ttv,jam_kedatangan_status,jam_status_kembali FROM t_pendaftaran WHERE IDXDAFTAR='".$_GET['idx']."'";
    $QUERY = mysql_query($SQL);
    $JAM = mysql_fetch_assoc($QUERY);
?>
<table width="98%" class="tb">
	<tr>
        <td>
            <!-- -->
            <form name="rm_status" id="rm_status" action="rajal/valid_keluar-masuk.php" method="post">
                <input type="hidden" name="NOMR" value="<? echo $nomr; ?>" />
                <input type="hidden" name="IDXDAFTAR2" value="<?php echo $userdata['IDXDAFTAR']; ?>"/>
				<input type="hidden" name="user" value="<?= $_SESSION['NIP']; ?>"/>
				<input type="hidden" name="ip_address" value="<?= getRealIpAddr(); ?>"/>
                <table width="98%" >
                    <tr>
                        <td width="5%">Status Datang</td>
                        <td width="15%"> <input type="text" name="status" class="text" value="" id="status" style="width:80px" /></td>

                        <td width="20%">
                            <? if($JAM['jam_kedatangan_status']=="00:00:00") { ?>
                                <input type="submit" name="btn_ttv" class="text" value=" S T A T U S " onclick="submitform (document.getElementById('rm_status'),'rajal/valid_keluar-masuk.php','valid_status',validatetask); return false;"/>
                            <?  }else {
                                echo "<strong> Jam Datang Status ".$JAM['jam_kedatangan_status']."</strong>";
                            } ?>
                        </td><td><span id="valid_status">&nbsp;</span></td>
                    </tr>
                </table>
            </form>
            <!-- -->
        </td>
    </tr>
	<tr>
        <td>
            <!-- -->
            <form name="pasien_ttv" id="pasien_ttv" action="rajal/valid_keluar-masuk.php" method="post">
                <input type="hidden" name="NOMR" value="<? echo $nomr; ?>" />
                <input type="hidden" name="IDXDAFTAR2" value="<?php echo $userdata['IDXDAFTAR']; ?>"/>
                <table width="98%" >
                    <tr>
                        <td width="5%">TTV</td>
                        <td width="15%"> <input type="text" name="ttv" class="text" value="" id="ttv" style="width:80px" /></td>
                        <td width="20%">
                            <? if($JAM['jam_ttv']=="00:00:00") { ?>
                                <input type="submit" name="btn_ttv" class="text" value=" T T V " onclick="submitform (document.getElementById('pasien_ttv'),'rajal/valid_keluar-masuk.php','valid_ttv',validatetask); return false;"/>
                            <?  }else {
                                echo "<strong> Jam TTV ".$JAM['jam_ttv']."</strong>";
                            } ?>
                        </td><td><span id="valid_ttv">&nbsp;</span></td>
                    </tr>
                </table>
            </form>
            <!-- -->
        </td>
    </tr>
    <tr>
        <td>
            <!-- -->
            <form name="pasien_masuk" id="pasien_masuk" action="rajal/valid_keluar-masuk.php" method="post">
                <input type="hidden" name="NOMR" value="<? echo $nomr; ?>" />
                <input type="hidden" name="IDXDAFTAR2" value="<?php echo $userdata['IDXDAFTAR']; ?>"/>
                <table width="98%" >
                    <tr>
                        <td width="5%">Masuk</td>
                        <td width="15%"><input type="text" class="text" name="Masuk" value="" id="Masuk" style="width:80px" /></td>
                        <td width="10%">Dokter</td>
                        <td width="25%">
                            <?php
							if($kdpoly == 9){
								$kdpoly = 39;
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="'.$kdpoly.'"';
							}
							elseif ($kdpoly == 40){
								$kdpoly	= 30;
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="'.$kdpoly.'"';
							}
							else if($kdpoly == 47){
								$kdpoly     = 1;
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="'.$kdpoly.'"';
							}
							else if($kdpoly == 48){
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="42" OR kdpoly="4"';
							}
							else if($kdpoly == 49){
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="1"';
							}
							else if($kdpoly == 39){
								$kondisi    = ' WHERE st_aktif=0 AND (kdpoly="39" OR kdpoly = "53")';
							}
							else if($kdpoly == 53){
								$kondisi    = ' WHERE st_aktif=0';
							}
							else if($kdpoly == 52){
								$kondisi    = ' WHERE st_aktif=0';
							}
							else if($kdpoly == 57){
								$kondisi    = ' WHERE st_aktif=0';
							}
                            else if($kdpoly == 61){
                                $kondisi    = ' WHERE kdpoly="41" AND st_aktif=0';
                            }
                            else if($kdpoly == 62){
                                $kondisi    = ' WHERE (kdpoly="3" OR kdpoly = "34") AND st_aktif=0';
                            }
							else{
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="'.$kdpoly.'"';
							}
                            ?>
                            <select name="dokter" id="dokter_pemeriksa" class="text">
                                <?
                                //$sql_dokter = "SELECT a.kdpoly,a.kddokter, b.NAMADOKTER,b.KDDOKTER FROM m_dokter_jaga a join m_dokter b on a.kddokter = b.KDDOKTER WHERE a.kdpoly = ".$kdpoly;
                                $sql_dokter	= "SELECT KDDOKTER, NAMADOKTER FROM m_dokter ".$kondisi;
                                $get_dokter = mysql_query($sql_dokter);
                                while($dat_dokter = mysql_fetch_array($get_dokter)) {
                                    ?>
                                    <option value="<?=$dat_dokter['KDDOKTER']?>" <? if($dat_dokter['KDDOKTER']==$kddokter) echo "selected=selected"; ?> ><?=$dat_dokter['NAMADOKTER']?></option>
                                <? } ?>
                            </select>
                        </td>
                        <td width="20%">
                            <?
                            if($JAM['MASUKPOLY']=="00:00:00") {
                                ?>
                                <input type="submit" class="text" name="save2" onclick="submitform (document.getElementById('pasien_masuk'),'rajal/valid_keluar-masuk.php','valid_masuk',validatetask); return false;" value=" M a s u k " />
                            <? }else {
                                echo "<strong> Jam Masuk ".$JAM['MASUKPOLY']."</strong>";
                            } ?>
                        </td>
                        <td><span id="valid_masuk">&nbsp;</span></td>
                    </tr>
                </table>
            </form>
            <!-- -->
        </td>
    </tr>
    <tr>
        <td>
            <!-- -->
            <form name="pasien_keluar" id="pasien_keluar" action="rajal/valid_keluar-masuk.php" method="post">
                <input type="hidden" name="NOMR" value="<? echo $nomr; ?>" />
                <input type="hidden" name="IDXDAFTAR2" value="<?php echo $userdata['IDXDAFTAR']; ?>"/>
                <table width="98%" >
                    <tr>
                        <td width="5%">Keluar</td>
                        <td width="15%"> <input type="text" name="Keluar" class="text" value="" id="Keluar" style="width:80px" /></td>
                        <td width="10%">Status Keluar</td>
                        <td width="25%">
                            <select name="Status" class="text statusmasukkeluar" onchange="MyAjaxRequest('rujuk','rujukan/alasan_rujuk.php?rujuk=' + this.value); return false;">
                                <?
                                $qey = mysql_query("SELECT * FROM m_statuskeluar Where `status` <> 11");
                                while ($show = mysql_fetch_array($qey)) { ?>
                                    <option value="<?=$show['status']?>" <?
                                    if($JAM['STATUS']==$show['status']) {
                                        echo "selected='selected'";
                                    }
                                    ?>class=""><?=$show['keterangan']?></option>
                                <?
                                }
                                ?>
                            </select>
							
							<span>
								<input type="text" name="tgl_kontrol" id="tgl_kontrol" readonly="readonly" class="text datepicker" value="<?= date('Y-m-d'); ?>"/>
							</span>
							
							<br/>
							<br/>
							<div id="jumlah_book">
								<input type="hidden" id="kdpoly_pemeriksa" value="<?= $kdpoly; ?>"/>
								<div style="margin-bottom:10px;">
									<label>No. Telpon</label>
									<input type="text" class="text" name="no_telp" id="no_telp" value="<?= $userdata['NOTELP']; ?>"/><br/><br/>
                                    <label>No. Surat Kontrol</label>
                                    <input type="text" class="text" name="no_surat_kontrol" id="no_surat_kontrol" value="<?= $userdata['no_surat_kontrol']; ?>"/>
								</div>
								Jumlah pasien perjanjian saat ini &nbsp;&nbsp;&nbsp;: <span id="book"></span><br/>
                                Pasien akan terdaftar pada perjanjian ke-<span id="no_urut"></span>
                                Kuota dokter pada tanggal tersebut : <span id="kuota"></span>
							</div>
                        </td>
                        <td width="20%">
                            <? if($JAM['KELUARPOLY']=="00:00:00") { ?>
                                <input type="submit" name="keluar" class="text" value=" K e l u a r " onclick="submitform (document.getElementById('pasien_keluar'),'rajal/valid_keluar-masuk.php','valid_keluar',validatetask); return false;"/>
                            <?  }else {
                                echo "<strong> Jam Keluar ".$JAM['KELUARPOLY']."</strong>";
                            } ?>
                        </td><td><span id="valid_keluar">&nbsp;</span></td>
                    </tr>
                </table>

                <div id="rujuk" >

                </div>
            </form>
            <!-- -->
        </td>
    </tr>
</table>
<script>
    <!--
    /*By George Chiang (JK's JavaScript tutorial)
     http://javascriptkit.com
     Credit must stay intact for use*/
    function show(){
        var Digital=new Date();
        var hours=Digital.getHours();
        var minutes=Digital.getMinutes();
        var seconds=Digital.getSeconds();
        var curTime =
            ((hours < 10) ? "0" : "") + hours + ":"
            + ((minutes < 10) ? "0" : "") + minutes + ":"
            + ((seconds < 10) ? "0" : "") + seconds;
        var dn="AM";

        if (hours>12){
            dn="PM";
            hours=hours-12
        }
        if (hours==0)
            hours=12;
        if (minutes<=9)
            minutes="0"+minutes;
        if (seconds<=9)
            seconds="0"+seconds;
        document.pasien_masuk.Masuk.value=curTime;
        document.pasien_keluar.Keluar.value=curTime;
        document.pasien_ttv.ttv.value=curTime;
        document.rm_status.status.value=curTime;
        setTimeout("show()",1000)
    }
    show();
    //-->
    <!-- hide; from; old; browsers;
    var curDateTime = new Date();
    var curHour = curDateTime.getHours();
    var curMin = curDateTime.getMinutes();
    var curSec = curDateTime.getSeconds();
    var curTime =
        ((curHour < 10) ? "0" : "") + curHour + ":"
        + ((curMin < 10) ? "0" : "") + curMin + ":"
        + ((curSec < 10) ? "0" : "") + curSec;
    //-->
</script>  
