<link rel="stylesheet" type="text/css" href="style.css" />
<!--autocomplete-->
<!--
<script type="text/javascript" src="rajal/jscripts/jquery-1.2.6.pack.js"></script>
-->
<script type="text/javascript">
    function enter_pressed(e){
        var keycode;
        if (window.event) keycode = window.event.keyCode;
        else if (e) keycode = e.which;
        else return false;
        return (keycode == 13);
        return false;
    }

</script>

<script language="javascript">
    function printIt(){
        content=document.getElementById('askep');
        w=window.open('about:blank');
        w.document.write( content.innerHTML );
        w.document.writeln("<script>");
        w.document.writeln("window.print()");
        w.document.writeln("</"+"script>");
    }
    function printIt(){
        content=document.getElementById('valid');
        head=document.getElementById('head_report');
        w=window.open('about:blank');
        w.document.writeln("<link href='dq_sirs.css' type='text/css' rel='stylesheet' />");
        w.document.write( head.innerHTML );
        w.document.write( content.innerHTML );
        w.document.writeln("<script>");
        w.document.writeln("window.print()");
        w.document.writeln("</"+"script>");
    }
    function popUp(URL) {
        day = new Date();
        id = 'keringanan';
        eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=1000,height=400,left=50,top=50');");
    }

    jQuery(document).ready(function(){

        jQuery('.tindakan').click(function(){
            var nomr		= jQuery('#nomr').val();
            var idxdaftar	= jQuery('#idxdaftar').val();
            var carabayar	= jQuery('#carabayar').val();
            var poly		= jQuery(this).attr('id');
            popUp('daftar_tindakan_poly.php?nomr='+nomr+'&idx='+idxdaftar+'&carabayar='+carabayar+'&poly='+poly);
        });

        jQuery('.konsultasi_gizi').click(function(){
            var nomr		= jQuery('#nomr').val();
            var idxdaftar	= jQuery('#idxdaftar').val();
            var dokter		= jQuery('#dokter').val();
            var carabayar	= jQuery('#carabayar').val();
            var poly		= jQuery(this).attr('id');
            var rajal		= 1;
            jQuery.get('cartbill_save_bayar_gizi.php?nomr='+nomr+'&idx='+idxdaftar+'&carabayar='+carabayar+'&dokter='+dokter+'&poly='+poly+'&rajal='+rajal,function(data){
                if(!data){
                    alert("Berhasil didaftarkan di Konsultasi Gizi");
                }
            });
        });
    });
</script>

<?php
include("include/connect.php");
require_once('ps_pagination.php');

?>
<div align="center">
    <div id="frame">
        <div id="frame_title">
            <h3 align="left">IDENTITAS PASIEN</h3>
        </div>

        <div id="all">

            <fieldset class="fieldset">
                <legend>Identitas </legend>
                <?php
                $myquery = "select a.NOMR,
								   a.KDPOLY,
								   a.KDDOKTER,
								   a.TGLREG,
								   b.NAMA,
								   b.ALAMAT,
								   b.NOTELP,
								   b.JENISKELAMIN,
								   b.TGLLAHIR,
								   c.NAMA as CARABAYAR, 
								   a.IDXDAFTAR, 
								   d.NAMA as POLY, 
								   e.NAMADOKTER,
								   a.KDCARABAYAR,
								   a.no_surat_kontrol
							from t_pendaftaran a, 
								 m_pasien b, 
								 m_carabayar c, 
								 m_poly d, 
								 m_dokter e
							where a.NOMR=b.NOMR 
							  AND a.KDCARABAYAR=c.KODE 
							  AND d.KODE=a.KDPOLY 
							  and a.KDDOKTER=e.KDDOKTER
							  and a.IDXDAFTAR='".$_GET["idx"]."'";
                //echo $myquery;
                $get = mysql_query ($myquery)or die(mysql_error());
                $userdata = mysql_fetch_assoc($get);
                $nomr=$userdata['NOMR'];
                $idxdaftar=$userdata['IDXDAFTAR'];
                $kdpoly=$userdata['KDPOLY'];
                $kddokter=$userdata['KDDOKTER'];
                $tglreg=$userdata['TGLREG'];
                $_SESSION['nomrx123'] = $nomr;
                $_SESSION['kdpoly']   = $kdpoly;
                #print_r($_SESSION);
                ?>
                <table width="95%" border="0">
                    <tr>
                        <td width="60%">
                            <table width="100%" border="0" class="tb" align="left" cellpadding="0" cellspacing="0">
                                <tr><td><strong>No MR</strong></td><td>: <?php echo $userdata['NOMR'];?></td></tr>
                                <tr>
                                    <td width="25%"><strong>Nama Lengkap Pasien</strong></td>
                                    <td width="75%">: <?php echo $userdata['NAMA'];?></td>
                                </tr>
                                <tr>
                                    <td valign="top"><strong>Alamat Pasien</strong></td>
                                    <td>: <?php echo $userdata['ALAMAT'];?></td>
                                </tr>
                                <tr>
                                    <td valign="top"><strong>Jenis Kelamin</strong></td>
                                    <td colspan="2">: <? if($userdata['JENISKELAMIN']=="l" || $userdata['JENISKELAMIN']=="L"){echo"Laki-Laki";}elseif($userdata['JENISKELAMIN']=="p" || $userdata['JENISKELAMIN']=="P"){echo"Perempuan";} ?>            <?php echo"( ". $userdata['JENISKELAMIN']." )";?></td>
                                </tr>
                                <tr>
                                    <td valign="top"><strong>Tanggal Lahir</strong></td>
                                    <td>: <?php echo date('d/m/Y', strtotime($userdata['TGLLAHIR']));?> </td>
                                </tr>
                                <tr>
                                    <td valign="top"><strong>Umur</strong></td>
                                    <td>: <?php
                                        $a = datediff($userdata['TGLLAHIR'], date("Y-m-d"));
                                        echo $a[years]." tahun ".$a[months]." bulan ".$a[days]." hari"; ?></td>
                                </tr>
                                <tr>
                                    <td valign="top"><strong>Poly</strong></td>
                                    <td>: <?php echo $userdata['POLY'];?></td>
                                </tr>
                                <tr>
                                    <td valign="top"><strong>Cara Bayar</strong></td>
                                    <td>: <?php echo $userdata['CARABAYAR'];?></td>
                                </tr>
                            </table>
                        </td>
                        <td width="31%" valign="top" align="right">
                            <div class="tb">
                                <div id="frame_title">
                                    <h3>History Pasien</h3></div>
                                <div>
                                    <!--<a href="index.php?link=3r&nomr=<?=$_GET['nomr']?>&idx=<?php echo $_GET['idx']; ?>">
                	<input type="button" align="right" class="text" name="bayar" value="Jasa Rumah Sakit" /> |
                </a> -->
                                    <a href="?link=detail_billing&nomr=<?=$_GET['nomr']?>&idxdaftar=<?php echo $_REQUEST['idx'];?>"><input type="button" class="text" name="Riwayat Pasien" value="Status Pembayaran" /></a>
                                    |
                                    <a href="?link=rm6&nomr=<?=$_GET['nomr']?>&nama=<?=$userdata['NAMA']?>"><input type="button" class="text" name="Riwayat Pasien" value="Riwayat Pasien" /></a>
                                    <!--<a href="index.php?link=34x&nomr=<?=$nomr?>&idxdaftar=<?=$userdata['IDXDAFTAR'];?>" class="text">List Pembayaran</a>-->
                                </div>
                            </div>
                            <?php if($_SESSION['ROLES'] == 26 || $_SESSION['ROLES'] == 4): ?>
                                <br />
                                <div class="tb">
                                    <div id="frame_title">
                                        <h3>Jasa Tindakan</h3></div>
                                    <div>
                                        <input type="hidden" name="nomr" id="nomr" value="<?php echo $userdata['NOMR']; ?>" />
                                        <input type="hidden" name="idxdaftar" id="idxdaftar" value="<?php echo $userdata['IDXDAFTAR']; ?>" />
                                        <input type="hidden" name="carabayar" id="carabayar" value="<?php echo $userdata['KDCARABAYAR']; ?>" />
                                        <input type="hidden" name="dokter" id="dokter" value="<?php echo $userdata['KDDOKTER']; ?>" />

                                        <input type="button" name="tindakan_poly" class="tindakan text" id="<?php echo $kdpoly;?>" value="Jasa Tindakan Poly" /> |
                                        <input type="button" name="tindakan_poly" class="tindakan text" id="0" value="Jasa Tindakan Lain Lain" />
                                        <input type="hidden" name="konsultasi_gizi" class="konsultasi_gizi text" id="<?php echo $kdpoly;?>" value="Konsultasi Gizi" />


                                    </div>
                                </div>
                                <div class="tb">
                                    <div id="frame_title">
                                        <h3>Alat Kesehatan & Obat Ruangan</h3></div>
                                    <div>
                                        <input type="button" name="tindakan_poly" class="alkes text" id="<?php echo $kdpoly;?>" value="Alat Kesehatan" />
                                        <input type="button" name="obat_ruangan" class="obat_ruangan text" id="<?php echo $kdpoly;?>" value="Obat Ruangan" />
                                    </div>
                                </div>
                            <?php endif;?>
                        </td>
                    </tr>
                </table>
            </fieldset>
            <div id="list_data"></div>
            <fieldset class="fieldset">
                <legend>Data Rekam Medik</legend>
                <div id="tabmenu">
                    <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=5&idx=<?=$idxdaftar?>">PASIEN KELUAR/MASUK</a>
                    <!-- <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=10&idx=<?=$idxdaftar?>">ANAMNESA DAN PEMERIKSAAN FISIK</a> -->
                    <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=2&idx=<?=$idxdaftar?>">CATATAN PERKEMBANGAN PASIEN TERINTEGRASI</a>
                    <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=10soap&idx=<?=$idxdaftar?>">PENGKAJIAN KEPERAWATAN RAWAT JALAN</a>
                    <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=14&idx=<?=$idxdaftar?>">DIAGNOSA</a>
                    <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=1&idx=<?=$idxdaftar?>">RESEP</a>
                    <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=13&idx=<?=$idxdaftar?>">PENUNJANG</a>
      
      <!-- <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=8&idx=<?=$idxdaftar?>">EKG</a> -->
      
                    <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=3&idx=<?=$idxdaftar?>">ORDER RADIOLOGI</a>
                    <a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=4&idx=<?=$idxdaftar?>">ORDER LAB</a>
                    <a href="?link=51&nomr=<?php echo $_GET['nomr']; ?>&menu=11&idx=<?php echo $idxdaftar; ?>">ORDER FISIOTERAPI</a>
                    <a href="?link=51&nomr=<?php echo $_GET['nomr']; ?>&menu=12&idx=<?php echo $idxdaftar; ?>">ORDER PA</a>

                    <!--      <a href="?link=51&nomr=--><?//= $_GET['nomr'];?><!--&menu=6&idx=--><?//=$idxdaftar?><!--">ORDER KAMAR OPERASI</a>-->
                    <?php
                    if($_SESSION['KDUNIT']=='2'){
                        ?>
                        <!--<a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=7&idx=<?=$idxdaftar?>">USG</a>-->
                    <?
                    }
                    if($_SESSION['KDUNIT']=='29'){
                        ?>
                        <!--<a href="?link=51&nomr=<?= $_GET['nomr'];?>&menu=9&idx=<?=$idxdaftar?>">MATA</a>-->
                    <?
                    }
                    ?>
                </div>

                <div id="wrapper">

                    <div class="boxholder">
                        <div id="cart_resep">
                            <? if(!empty($pesan)){ ?>
                                <div style="border:1px solid #DF7; padding:5px; margin:5px; color:#093; width:95%; background-color:#FFF;" align="left">
                                    <strong><?=$pesan;?></strong>
                                </div>
                            <? } ?>
                        </div>

                        <? if ($_GET['menu']=='1')
 {?> 
<div class="box">
<div id="frame">
    <div id="frame_title">
  <h3>Resep</h3>
    </div>
    <? include("resep/addresep.php"); ?>
        </div>
</div>
   
   
 <? } 
 elseif ($_GET['menu']=='2')
                        {
                            ?>
                            <div class="box">
                                <div id="frame">
                                    <div id="frame_title">
                                        <h3>Diagnosa & Terapi</h3>
                                    </div>
                                    <? include("diagnosa_terapi.php"); ?>
                                </div>
                            </div>



                        <? }
                        elseif ($_GET['menu']=='3')
                        {?>
                            <div class="box">
                                <div id="frame">
                                    <div id="frame_title"><h3>Pengantar Rontgen</h3></div>
                                    <? include("rad/order_rad.php");?>
                                </div>
                            </div>

                        <? }
                        elseif ($_GET['menu']=='4')
                        {?>
                            <div class="box">
                                <!--<div id="frame">
                                    <div id="frame_title"><h3>Pengantar Laboratorium</h3></div>-->
                                <? include("lab/order_lab.php"); ?>
                                <!--</div>-->
                            </div>









                        <? }
                        elseif ($_GET['menu']=='5' || $_GET['menu']=='')
                        {?>

                            <div class="box">
                                <div id="frame"><div id="frame_title"><h3>Pasien Keluar Masuk</h3></div>
                                    <? include("masuk_keluar.php"); ?>
                                </div>
                            </div>



                        <? }
                        /*elseif ($_GET['menu']=='7')
                        {

                       include("usg/form_usg.php");

                        } */
                        elseif ($_GET['menu']=='6')
                        {?>
                        <div class="box">
                            <p>
                                <? include("rajal/operasi/form_daftar_operasi.php");?>
                        </div>


                    </div>
                </div>
                <div id="autocompletediv" class="autocomp"></div>
            </fieldset>
        </div>
    </div></div>
<? }
/*elseif ($_GET['menu']=='8')
{?>


        <? include("ekg/form_ekg.php"); ?>

<? } else if ($_GET['menu']=='9')
{?>

        <? include("mata/form_mata.php"); ?>

<? }*/ elseif ($_GET['menu']=='10')
{?>


    <? include("anamnesa.php"); ?>

<?
} elseif($_GET['menu'] == '10soap'){
    ?>
        <? include("anamnesa_baru.php"); ?>

<?
} elseif($_GET['menu'] == '14'){
    ?>
        <? include("diagnosa_kerja.php"); ?>
    <?php
} elseif($_GET['menu'] == '11'){
    ?>
    <div id="frame">
        <div id="frame_title"><h3>ORDER FISIOTERAPI</h3></div>

        <?php
        include 'rajal/fisio/order_fisioterapi.php';
        ?>
    </div>
<?php
} elseif($_GET['menu'] == '12'){
    ?>
    <div id="frame">
        <div id="frame_title"><h3>ORDER PATOLOGI ANATOMI</h3></div>
        <?php
        include 'rajal/PA/order_PA.php';
        ?>
    </div>
<?php
} elseif($_GET['menu'] == '13'){
?>
<div id="frame">
    <div id="frame_title"><h3>PEMERIKSAAN PENUNJANG</h3></div>
    <?php
    include 'penunjang.php';
    ?>
</div>
<?php
}
?>

<script type="text/javascript">
    jQuery(".alkes").click(function(){
        var nomr		= jQuery('#nomr').val();
        var idxdaftar	= jQuery('#idxdaftar').val();
        var carabayar	= jQuery('#carabayar').val();
        var poly		= jQuery(this).attr('id');
        popUp('daftarAlkes.php?nomr='+nomr+'&idx='+idxdaftar+'&carabayar='+carabayar+'&poly='+poly);
    });

    jQuery(".obat_ruangan").click(function(){
        var nomr		= jQuery('#nomr').val();
        var idxdaftar	= jQuery('#idxdaftar').val();
        var carabayar	= jQuery('#carabayar').val();
        var poly		= jQuery(this).attr('id');

        popUp('daftarObatRuangan.php?nomr='+nomr+'&idx='+idxdaftar+'&carabayar='+carabayar+'&poly='+poly);
    });

    function parse_day(date){
        var date      = new Date(date);
        var day_index =  date.getDay();

        var weekday = new Array(7);

        weekday[0] = "Minggu";
        weekday[1] = "Senin";
        weekday[2] = "Selasa";
        weekday[3] = "Rabu";
        weekday[4] = "Kamis";
        weekday[5] = "Jumat";
        weekday[6] = "Sabtu";

        return weekday[day_index];
    }

	function start_page(){
		var statuskeluar = jQuery('.statusmasukkeluar').val();
		
		if(statuskeluar == 13){
			var nomr        = jQuery('#nomr').val();
			var poli   		= jQuery('#kdpoly_pemeriksa').val();
			var dokter 		= jQuery('#dokter_pemeriksa').val();
			var tgl_kontrol = jQuery('#tgl_kontrol').val();
            var day         = parse_day(tgl_kontrol);

            jQuery.ajax({
                url: "models/get_alert_pasien_perjanjian.php",
                method: "post",
                data: {nomr:nomr,tgl_kontrol:tgl_kontrol},
                success: function(data){
                    if(data != 0){
                        alert("Pasien sudah terdaftar pada sistem perjanjian tanggal: " + tgl_kontrol);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown){
                
                }
            });
			
			jQuery.ajax({
				url: "models/jumlah_pasien_perjanjian_by_poli_and_dokter.php",
				method: "post",
				data: {poli:poli,dokter:dokter,tgl_kontrol:tgl_kontrol},
				success: function(data){
                    // alert(JSON.stringify(data));
                    var jml_sudah_book   = 0;
                    var estimasi_no_urut = 0;

                    var obj = jQuery.parseJSON(data);

                    jQuery.each(obj, function() {
                        jml_sudah_book   = this['jml_sudah_book'];
                        estimasi_no_urut = this['estimasi_no_urut'];
                    });

					jQuery('#book').html(jml_sudah_book);
                    jQuery('#no_urut').html(estimasi_no_urut);
				},
				error: function(jqXHR, textStatus, errorThrown){
				
				}
			});

            jQuery.ajax({
                url: "models/api_get_kuota_dokter_by_day.php",
                method: "post",
                data: {dokter:dokter,hari:day},
                success: function(data){
                    jQuery('#kuota').html(data);
                },
                error: function(jqXHR, textStatus, errorThrown){
                
                }
            });
			
			jQuery('#tgl_kontrol').show();
			jQuery('#jumlah_book').show();
		} else{
			jQuery('#tgl_kontrol').hide();
			jQuery('#jumlah_book').hide();
		}
	}
	
	start_page();
	
	jQuery('.statusmasukkeluar').change(function(){
		start_page();
	});
	
	jQuery('#tgl_kontrol').change(function(){
		start_page();
		
		var tgl_kontrol = jQuery(this).val();
		jQuery.ajax({
            url: "models/perjanjian/cek_hari_libur.php",
            method: "post",
            data: {tgl_kontrol:tgl_kontrol},
            success: function(data){
                if(data != ''){
                    alert("Pasien tidak dapat di daftarkan perjanjian pada tanggal " + tgl_kontrol + " (" + data + ")");
                }
			},
            error: function(jqXHR, textStatus, errorThrown){
                
            }
        });
	});
</script>

