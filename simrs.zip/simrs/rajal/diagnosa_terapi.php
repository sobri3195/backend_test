<?
$diag_sql = "SELECT a.IDXTERAPI, a.DIAGNOSA, a.TERAPI, a.ICD_CODE, a.KASUS_BL, a.ICDCM, b.jenis_penyakit, c.keterangan, a.KUNJUNGAN_BL, TEKANAN_DARAH, GOLONGAN_DARAH, TINGGI_BADAN, BERAT_BADAN
            FROM t_diagnosadanterapi a 
            left join icd b on (a.ICD_CODE=b.icd_code) 
            left join icd_cm c on (a.ICDCM=c.kode)
            WHERE a.IDXDAFTAR=".$idxdaftar."
            AND a.NOMR='".$_REQUEST['nomr']."'";
$diag_qry = mysql_query($diag_sql);
$dvd = mysql_fetch_assoc($diag_qry);

$tekanan_darah	= !empty($dvd['TEKANAN_DARAH']) ? $dvd['TEKANAN_DARAH'] : '';
$golongan_darah	= !empty($dvd['GOLONGAN_DARAH']) ? $dvd['GOLONGAN_DARAH'] : '';
$tinggi_badan	= !empty($dvd['TINGGI_BADAN']) ? $dvd['TINGGI_BADAN'] : '';
$berat_badan	= !empty($dvd['BERAT_BADAN']) ? $dvd['BERAT_BADAN'] : '';
//print_r($dvd);
?>
<script type='text/javascript' src='rajal/jscripts/jquery.autocomplete.pack.js'></script>
<link rel="stylesheet" type="text/css" href="rajal/jscripts/jquery.autocomplete.css" />
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery("#icd").autocomplete("rajal/jscripts/mysql.php", { width: 260, selectFirst: true });
        jQuery("#icdcm").autocomplete("rajal/jscripts/mysql2.php", { width: 260, selectFirst: true });
        jQuery("#nm_barang2").autocomplete("rajal/jscripts/nm_barang.php", { width: 260, selectFirst: true });
    });
</script>

<form method="post" action="rajal/valid_dignosa.php" name="diagnosa" id="diagnosa">
    <input name="txtNoMR" id="txtNoMR" type="hidden" value=<?php echo $_REQUEST['nomr']; ?> >
    <input name="txtIdxDaftar" id="txtIdxDaftar" type="hidden" value=<?php echo $idxdaftar; ?> >
    <input name="txtKdPoly" id="txtKdPoly" type="hidden" value=<?php echo $kdpoly; ?> >
    <input name="txtKdDokter" id="txtKdDokter" type="hidden" value=<?php echo $kddokter; ?> >
    <input name="txtTglReg" id="txtTglReg" type="hidden" value=<?php echo $tglreg; ?> >
    <input name="txtNip" id="txtNip" type="hidden" value=<?php echo $_SESSION['NIP'];?> >
    <input type="hidden" name="idxterapi" value="<? echo $dvd['IDXTERAPI']; ?>" />
    <table class="tb" width="98%" align="center" >
        <tr>
            <td width="50%">
                <table width="100%" style="vertical-align:top">
                    <tr><td>Kasus</td><td><input type="radio" value="1" <?php if($dvd['KASUS_BL'] == 1): echo 'checked="checked"'; endif;?> name="new_kasus"/> Kasus Baru
                            <input type="radio" value="0" <?php if($dvd['KASUS_BL'] == 0): echo 'checked="checked"'; endif;?> name="new_kasus" /> Kasus Lama</td></tr>
                    <tr><td>Kunjungan</td><td><input type="radio" value="1" <?php if($dvd['KUNJUNGAN_BL'] == 1): echo 'checked="checked"'; endif;?> name="new_visit" /> Kunjungan Baru
                            <input type="radio" value="0" <?php if($dvd['KUNJUNGAN_BL'] == 0): echo 'checked="checked"'; endif;?> name="new_visit" /> Kunjungan Lama</td></tr>

                </table>
                <div align="left" id="diagnosa_valid"></div>
                <table align="center" width="95%" border="0" cellpadding="1" cellspacing="1">
                    <tr>
                        <th width="49%">Hasil Pemeriksaan, Analisis, Rencana Penatalaksanaan Pasien</th>
                    </tr>
                    <tr>
                        <?
                        if(isset($_GET['elm1'])){
                            $elm1   = $_GET['elm1'];
                        }else{
                            if(!empty($dvd['DIAGNOSA'])) $elm1 = $dvd['DIAGNOSA'];
                        }
                        ?>
                        <td valign="top"><textarea class="text" id="elm1" name="elm1" rows="10" cols="50" style="width:100%" ><?php echo $elm1;?></textarea></td>
                    </tr>
                </table>
            </td>

            <td>
                <table width="100%" style="vertical-align:top">
                    <tr>
                        <td>Tekanan Darah</td><td><input type="text" name="tekanan_darah" value="<?php echo $tekanan_darah;?>" id="tekanan_darah"></td>
                        <td></td>
                        <td>Dokter</td>
                        <td>
                            <?php
							if($kdpoly == 9){
								$kdpoly = 39;
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="'.$kdpoly.'"';
							}
							elseif ($kdpoly == 40){
								$kdpoly	= 30;
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="'.$kdpoly.'"';
							}
							else if($kdpoly == 47){
								$kdpoly     = 1;
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="'.$kdpoly.'"';
							}
							else if($kdpoly == 48){
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="42" OR kdpoly="4"';
							}
							else if($kdpoly == 49){
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="1"';
							}
							else if($kdpoly == 39){
								$kondisi    = ' WHERE st_aktif=0 AND (kdpoly="39" OR kdpoly = "53")';
							}
							else if($kdpoly == 53){
								$kondisi    = ' WHERE st_aktif=0';
							}
							else if($kdpoly == 52){
								$kondisi    = ' WHERE st_aktif=0';
							}
							else if($kdpoly == 57){
								$kondisi    = ' WHERE st_aktif=0';
							}
                            else if($kdpoly == 61){
                                $kondisi    = ' WHERE kdpoly="41" AND st_aktif=0';
                            }
                            else if($kdpoly == 62){
                                $kondisi    = ' WHERE (kdpoly="3" OR kdpoly = "34") AND st_aktif=0';
                            }
							else{
								$kondisi    = ' WHERE st_aktif=0 AND kdpoly="'.$kdpoly.'"';
							}
                            ?>
                            <select name="dokter" id="dokter_pemeriksa" class="text">
                                <?
                                //$sql_dokter = "SELECT a.kdpoly,a.kddokter, b.NAMADOKTER,b.KDDOKTER FROM m_dokter_jaga a join m_dokter b on a.kddokter = b.KDDOKTER WHERE a.kdpoly = ".$kdpoly;
                                $sql_dokter	= "SELECT KDDOKTER, NAMADOKTER FROM m_dokter ".$kondisi;
                                $get_dokter = mysql_query($sql_dokter);
                                while($dat_dokter = mysql_fetch_array($get_dokter)) {
                                    ?>
                                    <option value="<?=$dat_dokter['KDDOKTER']?>" <? if($dat_dokter['KDDOKTER']==$kddokter) echo "selected=selected"; ?> ><?=$dat_dokter['NAMADOKTER']?></option>
                                <? } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Golongan Darah</td>
                        <td>
                            <select name="golongan_darah" id="golongan_darah">
                                <option value=""> Pilih Golongan Darah </option>
                                <option value="A" <?php if($golongan_darah == 'A'): echo 'selected="selected"'; endif;?>> Gol A </option>
                                <option value="B" <?php if($golongan_darah == 'B'): echo 'selected="selected"'; endif;?>> Gol B </option>
                                <option value="AB"<?php if($golongan_darah == 'AB'): echo 'selected="selected"'; endif;?>> Gol AB </option>
                                <option value="O" <?php if($golongan_darah == 'O'): echo 'selected="selected"'; endif;?>> Gol O </option>
                            </select>
                        </td>
                        <td></td>
                        
                    </tr>
                </table>
                
                <table align="center" width="95%" border="0" cellpadding="1" cellspacing="1">
                    <tr>
                        <th valign="top">Instruksi PPA Termasuk Pasca Bedah</th>
                    </tr>
                    <tr>
                        <?
                        if(isset($_GET['elm2'])){
                            $elm2   = $_GET['elm2'];
                        }else{
                            if(!empty($dvd['TERAPI'])) $elm2 = $dvd['TERAPI'];
                        }?>
                        <td valign="top"><textarea class="text"id="elm2" name="elm2" rows="10" cols="50" style="width:100%"><?php echo $elm2; ?></textarea></td>
                    </tr>
                </table> 
            <td>
        </tr>
    </table>
</form>
        
    <tr>
        <td colspan="2">
            <div align="left" style="margin:5px; padding:5px;">
                <input type="submit" class="text" name="save" value=" S i m p a n " />
                <input type="reset" class="text" name="reset" value=" R e s e t " />
            </div>
        </td>
    </tr>
    </table>
</form>