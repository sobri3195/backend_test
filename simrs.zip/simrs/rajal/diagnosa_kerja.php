<?
$diag_sql = "SELECT a.IDXTERAPI, a.DIAGNOSA, a.TERAPI, a.ICD_CODE, a.KASUS_BL, a.ICDCM, b.jenis_penyakit, c.keterangan, a.KUNJUNGAN_BL, TEKANAN_DARAH, GOLONGAN_DARAH, TINGGI_BADAN, BERAT_BADAN
            FROM t_diagnosadanterapi a 
            left join icd b on (a.ICD_CODE=b.icd_code) 
            left join icd_cm c on (a.ICDCM=c.kode)
            WHERE a.IDXDAFTAR=".$idxdaftar."
            AND a.NOMR='".$_REQUEST['nomr']."'";
$diag_qry = mysql_query($diag_sql);
$dvd = mysql_fetch_assoc($diag_qry);

$tekanan_darah	= !empty($dvd['TEKANAN_DARAH']) ? $dvd['TEKANAN_DARAH'] : '';
$golongan_darah	= !empty($dvd['GOLONGAN_DARAH']) ? $dvd['GOLONGAN_DARAH'] : '';
$tinggi_badan	= !empty($dvd['TINGGI_BADAN']) ? $dvd['TINGGI_BADAN'] : '';
$berat_badan	= !empty($dvd['BERAT_BADAN']) ? $dvd['BERAT_BADAN'] : '';
//print_r($dvd);
?>
<script type='text/javascript' src='rajal/jscripts/jquery.autocomplete.pack.js'></script>
<link rel="stylesheet" type="text/css" href="rajal/jscripts/jquery.autocomplete.css" />
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery("#icd").autocomplete("rajal/jscripts/mysql.php", { width: 260, selectFirst: true });
    });
</script>


    <table class="tb" width="98%" align="center" >
        <tr>
            <td>
                <table style="vertical-align:top">
                <tr>
                    <td>ICD 10</td>
                    <td>   
                        <input type="text" class="text" name="icd" id="icd" size="50" onkeypress="if(enter_pressed(event))
                        {
                        var str=document.getElementById('icd').value;
                        var kode=str.split('++');
                        document.getElementById('icd_code').value=kode[0];  
                        document.getElementById('elm1').focus();                    
                        }" value="<?
                if(isset($_GET['icd'])){
                    echo $_GET['icd'];
                }else{
                    if(!empty($dvd['jenis_penyakit'])){
                        echo $dvd['jenis_penyakit'];
                    }
                } ?>" /></td>
                </tr>
                </table>
                <table align="center" border="0" cellpadding="1" cellspacing="1">
                    <tr>
                        <th valign="top">Diagnosa Kerja</th>
                    </tr>
                    <tr>
                        <?
                        if(isset($_GET['elm2'])){
                            $elm2   = $_GET['elm2'];
                        }else{
                            if(!empty($dvd[''])) $elm2 = $dvd[''];
                        }?>
                        <td valign="top"><textarea class="text"id="elm2" name="elm2" rows="10" cols="50" style="width:100%"><?php echo $elm2; ?></textarea></td>
                    </tr>
                </table>
            <td>
        </tr>
    </table>
        
    <tr>
        <td colspan="2">
            <div align="left" style="margin:5px; padding:5px;">
                <input type="submit" class="text" name="save" value=" S i m p a n " />
                <input type="reset" class="text" name="reset" value=" R e s e t " />
            </div>
        </td>
    </tr>
    </table>
</form>

<script src="rajal/jscripts/multi-input.js"></script>
<script src="rajal/jscripts/script.js"></script>

