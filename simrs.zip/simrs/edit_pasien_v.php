<?php 
	include 'include/connect.php';
	include 'include/function.php';
?>
<div align="center">
	<div id="frame">
		<div id="frame_title"><h3>Edit Data Pasien</h3></div>
	   	<fieldset class="fieldset">
	   		<legend>Identitas</legend>
	   		<div style="margin:35px; text-align:left;">
	   			<?php 
	   				$cekPasien		= cek_pasienStatus($_REQUEST['nomr'], $_REQUEST['idx']);
	   				$cekPasienAPS	= cek_pasienAPSStatus($_REQUEST['nomr'], $_REQUEST['idx']);
	   				$statuspasien	= 0;
	   				
	   				if($cekPasien > 0){
	   					$data_pasien 		= cek_pasien($_REQUEST['nomr']);
	   					while($dp = mysql_fetch_array($data_pasien)){
	   						$nomr 			= $dp['NOMR'];
	   						$title 			= $dp['TITLE'];
	   						$nama			= $dp['NAMA'];
	   						$tempat 		= $dp['TEMPAT'];
	   						$tgllhr			= $dp['TGLLAHIR'];
	   						$jenkel			= $dp['JENISKELAMIN'];
	   						$detailjenkel	= getJenkelDetail($jenkel);
	   						$alamat			= $dp['ALAMAT'];
	   						$kel 			= $dp['KELURAHAN'];
	   						$namakel		= getkelurahan($kel);
	   						$kec 			= $dp['KDKECAMATAN'];
	   						$namakec 		= getkecamatan($kec);
	   						$kota 			= $dp['KOTA'];
	   						$namakota 		= getkota($kota);
	   						$prov 			= $dp['KDPROVINSI'];
	   						$namaprov 		= getprovinsi($prov);
	   						$telp 			= $dp['NOTELP'];
	   						$status 		= $dp['STATUS'];
	   						$statusdetail 	= getStatusDetail($status);
	   						$agama 			= $dp['AGAMA'];
	   						$agamadetail	= getAgamaDetail($agama);
	   						$pend	 		= $dp['PENDIDIKAN'];
	   						$penddetail 	= getPendidikanDetail($pend);
	   						$crbayar 		= $dp['KDCARABAYAR'];
	   						$crbyralldata	= getallcarabayar($crbayar);
	   						$namacrbayar	= $crbyralldata['NAMA']; 
	   					}
	   					$statuspasien = 1;
	   				}
	   				else{
	   					$data_pasien 		= getPasienAPS($_REQUEST['nomr']);
	   					while($dp = mysql_fetch_array($data_pasien)){
	   						$nomr 			= $dp['NOMR'];
	   						$title 			= $dp['TITLE'];
	   						$nama			= $dp['NAMA'];
	   						$tempat 		= $dp['TEMPAT'];
	   						$tgllhr			= $dp['TGLLAHIR'];
	   						$jenkel			= $dp['JENISKELAMIN'];
	   						$detailjenkel	= getJenkelDetail($jenkel);
	   						$alamat			= $dp['ALAMAT'];
	   						$kel 			= $dp['KELURAHAN'];
	   						$namakel		= getkelurahan($kel);
	   						$kec 			= $dp['KDKECAMATAN'];
	   						$namakec 		= getkecamatan($kec);
	   						$kota 			= $dp['KOTA'];
	   						$namakota 		= getkota($kota);
	   						$prov 			= $dp['KDPROVINSI'];
	   						$namaprov 		= getprovinsi($prov);
	   						$telp 			= $dp['NOTELP'];
	   						$status 		= $dp['STATUS'];
	   						$statusdetail 	= getStatusDetail($status);
	   						$agama 			= $dp['AGAMA'];
	   						$agamadetail	= getAgamaDetail($agama);
	   						$pend	 		= $dp['PENDIDIKAN'];
	   						$penddetail 	= getPendidikanDetail($pend);
	   						$crbayar 		= $dp['KDCARABAYAR'];
	   						$crbyralldata	= getallcarabayar($crbayar);
	   						$namacrbayar	= $crbyralldata['NAMA'];
	   					}
	   					$statuspasien = 2;
	   				}
	   			?>
	   			<form id="form_datapasien">
	   			<table width="100%">
		   			<tr>
		   				<td>
		   					<label for="nomr" id="label_nomr">No. MR</label>
		   				</td>
		   				<td> : </td>
		   				<td>
		   					<input type="text" name="nomr" id="nomr" value="<?php echo $nomr; ?>" autofocus  class="text ui-widget-content ui-corner-all" readonly>
		   					<input type="hidden" name="idxdaftar" value="<?php echo $_REQUEST['idx']; ?>">
		   					<input type="hidden" name="statuspasien" value="<?php echo $statuspasien; ?>">
		   				</td>
		   			</tr>
		   			<tr>
		   				<td>
		   					<label for="title" id="label_title">Title</label>
		   				</td>
		   				<td> : </td>
		   				<td>
		   					<select type="text" name="title" id="title"  class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   						<option value="Tn" <? if($title=="Tn") echo "selected=selected"; ?>> Tn </option>
					            <option value="Ny" <? if($title=="Ny") echo "selected=selected"; ?>> Ny </option>
					            <option value="Nn" <? if($title=="Nn") echo "selected=selected"; ?>> Nn </option>
						    	<option value="An" <? if($title=="An") echo "selected=selected"; ?>> An </option>
						    </select>
		   				</td>
		   			</tr>
		   			<tr>
		   				<td>
		   					<label for="nama" id="label_nama">Nama</label>
		   				</td>
		   				<td> : </td>
		   				<td>
		   					<input type="text" name="nama" id="nama" value="<?php echo $nama; ?>"  class="text ui-widget-content ui-corner-all">
		   				</td>
		   			</tr>
		   			<tr>
		   				<td>
		   					<label for="tempat" id="label_tempat">Tempat Lahir</label>
		   				</td>
		   				<td> : </td>
		  				<td>
		   					<input type="text" name="tempat" id="tempat" value="<?php echo $tempat; ?>"   class="text ui-widget-content ui-corner-all">
		   				</td>
		   			</tr>
		   			<tr>
		  				<td>
		   					<label for="tgllhr" id="label_tgllhr">Tanggal Lahir</label>
		   				</td>
		   				<td> : </td>
		   				<td>
		   					<input type="text" name="tgllhr" id="tgllhr" value="<?php echo $tgllhr; ?>"  class="text ui-widget-content ui-corner-all datepicker">
		   				</td>
		   			</tr>
		   			<tr>
		   				<td>
		   					<label for="jenkel" id="jenkel">Jenis Kelamin</label>
		   				</td>
		   				<td> : </td>
		   				<td>
		   					<input type="hidden" id="jenkel_temp" value="<?php echo $jenkel ?>"/>
		   					<select name="jenkel" id="jenkel" class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   						<option value="L" <?php if($jenkel == 'L'){ echo 'selected';} ?>>Laki-laki</option>
		   						<option value="P" <?php if($jenkel == 'P'){ echo 'selected';} ?>>Perempuan</option>
		   					</select>
		   				</td>
		   			</tr>
		   				<tr>
		   					<td>
		   						<label for="alamat" id="alamat">Alamat</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<input type="text" name="alamat" id="alamat" value="<?php echo $alamat; ?>" class="text ui-widget-content ui-corner-all">
		   					</td>
		   				</tr>
		   				<tr>
		   					<td>
		   						<label for="provinsi" id="label_provinsi">Provinsi</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<select name="provinsi" id="provinsi" class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   							<option></option>
		   						</select>
		   					</td>
		   				</tr>
		   				<tr>
		   					<td>
		   						<label for="kota" id="label_kota">Kota</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<select name="kota" id="kota" class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   							<option></option>
		   						</select>
		   					</td>
		   				</tr>
		   				<tr>
		   					<td>
		   						<label for="kecamatan" id="label_kecamatan">Kecamatan</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<select name="kecamatan" id="kecamatan" class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   							<option></option>
		   						</select>
		   					</td>
		   				</tr>
		   				<tr>
		   					<td>
		   						<label for="kelurahan" id="label_kelurahan">Kelurahan</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<select name="kelurahan" id="kelurahan" class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   							<option></option>
		   						</select>
		   					</td>
		   				</tr>
		   				<tr>
		   					<td>
		   						<label for="telepon" id="label_telepon">Telepon</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<input type="text" name="telepon" id="telepon" value="<?php echo $telp; ?>" class="text ui-widget-content ui-corner-all">
		   					</td>
		   				</tr>
		   				<tr>
		   					<td>
		   						<label for="status" id="label_status">Status</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<select name="status" id="status" class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   							<option value="1" <?php if($status == 1){ echo 'selected'; } ?>>Belum Kawin</option>
		   							<option value="2" <?php if($status == 2){ echo 'selected'; } ?>>Kawin</option>
		   							<option value="3" <?php if($status == 3){ echo 'selected'; } ?>>Janda / Duda</option>
		   						</select>	
		   					</td>
		   				</tr>
		   				<tr>
		   					<td>
		   						<label for="agama" id="label_agama">Agama</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<select name="agama" id="agama" class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   							<option value="1" <?php if($agama == 1){ echo 'selected'; } ?>>Islam</option>
		   							<option value="2" <?php if($agama == 2){ echo 'selected'; } ?>>Kristen Protestan</option>
		   							<option value="3" <?php if($agama == 3){ echo 'selected'; } ?>>Khatolik</option>
		   							<option value="4" <?php if($agama == 4){ echo 'selected'; } ?>>Hindu</option>
		   							<option value="5" <?php if($agama == 5){ echo 'selected'; } ?>>Budha</option>
		   							<option value="6" <?php if($agama > 5){ echo 'selected'; } ?>>Lain - lain</option>
		   						</select>
		   					</td>
		   				</tr>
		   				<tr>
		   					<td>
		   						<label for="pendidikan" id="label_pendidikan">Pendidikan</label>
		   					</td>
		   					<td> : </td>
		   					<td>
		   						<select name="pendidikan" id="pendidikan" class="text ui-widget-content ui-corner-all select2" style="width:140px;">
		   							<option value="1" <?php if($pend == 1){ echo 'selected'; } ?>>SD</option>
		   							<option value="2" <?php if($pend == 2){ echo 'selected'; } ?>>SLTP</option>
		   							<option value="3" <?php if($pend == 3){ echo 'selected'; } ?>>SMU</option>
		   							<option value="4" <?php if($pend == 4){ echo 'selected'; } ?>>D3 / Akademik</option>
		   							<option value="5" <?php if($pend == 5){ echo 'selected'; } ?>>Universitas</option>
		   						</select>
		   					</td>
		   				</tr>
	   				<tr>
	   					<td>
	   						<label for="carabayar" id="label_carabayar">Cara Bayar</label>
	   					</td>
	   					<td> : </td>
	   					<td>
	   						<input type="text" name="carabayar" id="carabayar" value="<?php echo $namacrbayar; ?>" class="text ui-widget-content ui-corner-all" disabled>
	   					</td>
	   					<td>
	   						<br/>
	   					</td>
	   					<td style="text-align: right">
	   						<!--<button class="button add" id="add_pasien">Simpan</button>-->
	   						<input type="button" class="button add" id="add_pasien" value="Simpan">
	   					</td>
	   				</tr>
	   			</table>
	   			</form>
	   		</div>
	   	</fieldset>
	</div>
</div>

<script type="text/javascript">
	jQuery(".datepicker").datepicker({dateFormat: "yy-mm-dd", changeMonth:true, changeYear:true, currentText: "Now"});
	jQuery(".select2").select2();
								
	jQuery(".add").button({icons: {primary: "ui-icon-circle-plus"}});

	jQuery(".add").click(function(){
		var form_datapasien = jQuery("#form_datapasien").serialize();

		jQuery.ajax({
    		/*url: "<?php echo _BASE_?>index.php?link=pasien01&opsi=3",*/
    		url : "<?php echo _BASE_?>include/pasien.php?opsi=3",
    		data: form_datapasien,
    		type: "post",
    		success: function(data){
    			alert(data);
    			location.reload();
    		},
			error: function(data){
				alert("Update Tidak Berhasil. Coba Lagi...");
				location.reload();
			}
    	});
	});

	jQuery("#provinsi").select2({
        allowClear: true,
        placeholder: "Ketikkan nama Provinsi..",
        ajax: {
            url: "include/RsudAddressUtility.php",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    n: params.term, // search term
					function: 'getProvinsi'
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });

	jQuery("#kota").select2({
        allowClear: true,
        placeholder: "Ketikkan nama Kota..",
        ajax: {
            url: "include/RsudAddressUtility.php",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    n: params.term, // search term
                    idprov: jQuery("#provinsi").val(),
					function: 'getKota'
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });

	jQuery("#kecamatan").select2({
        allowClear: true,
        placeholder: "Ketikkan nama Kecamatan..",
        ajax: {
            url: "include/RsudAddressUtility.php",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    n: params.term, // search term
                    idkota: jQuery("#kota").val(),
					function: 'getKecamatan'
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });

	jQuery("#kelurahan").select2({
        allowClear: true,
        placeholder: "Ketikkan nama Kelurahan..",
        ajax: {
            url: "include/RsudAddressUtility.php",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    n: params.term, // search term
                    idkec: jQuery("#kecamatan").val(),
					function: 'getkelurahan'
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 1
    });
</script>