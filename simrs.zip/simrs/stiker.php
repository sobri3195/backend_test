<?php
	if($_GET['ttl'] == ""){
		echo "Stiker Gagal Dicetak karena tanggal lahir kosong. Cek kembali tanggal lahir.";
		exit(0);
	}

	header('Content-type: Content-type: text/plain');
	header('Content-Disposition: attachment; filename="output.zpl"');

	for($i=0; $i<5; $i++):
?>
I8,A,001


Q184,024
q863
rN
S3
D7
ZT
JF
O
R20,0
f100
N
A463,73,0,4,1,1,N,"<?= date_format(date_create($_REQUEST['ttl']),"d/m/Y"); ?>"
A460,105,0,4,1,2,N,"<?= substr($_REQUEST['nama'],0,20); ?>"
A39,72,0,4,1,1,N,"<?= date_format(date_create($_REQUEST['ttl']),"d/m/Y"); ?>"
A463,17,0,4,1,2,N,"<?= sprintf("%06d", $_REQUEST['nomr']); ?>"
A36,104,0,4,1,2,N,"<?= substr($_REQUEST['nama'],0,20); ?>"
A39,16,0,4,1,2,N,"<?= sprintf("%06d", $_REQUEST['nomr']); ?>"
B638,15,0,1,2,6,35,B,"<?= sprintf("%06d", $_REQUEST['nomr']); ?>"
B214,16,0,1,2,6,35,B,"<?= sprintf("%06d", $_REQUEST['nomr']); ?>"
P1

<?php
	endfor;
?>