<?php 
	include 'include/connect.php';
	
	extract($_POST);
	$nik	= $nokaryawan;
	$opsi	= $pilihan;
	
	$stts	= $status;
	
	if($opsi == 1){
		$sql	= mysql_query("SELECT * FROM karyawan WHERE NoKar='".$nik."'");
		$data	= mysql_fetch_array($sql);
		
		echo json_encode($data);
	}
	else{
		$sql	= mysql_query("SELECT status FROM statuskaryawan WHERE nostatusnya=".$stts);
		$data	= mysql_fetch_array($sql);
		
		echo $data['status'];
	}
?>