<?php
	if($_GET['ttl'] == ""){
		echo "Stiker Gagal Dicetak karena tanggal lahir kosong. Cek kembali tanggal lahir.";
		exit(0);
	}

	include('include/connect.php');
	include('include/function.php');
	include('include/TCPDF/tcpdf.php');

	// Ukuran kertas Stiker
	$STICKER_3x10_SIZE = array(16.5, 21);

	// Create new PDF document
	$pdf = new TCPDF('P', 'cm', $STICKER_3x10_SIZE, true, 'UTF-8', false);
	
	// set document information
	$PDF_CREATOR  = "SIMRS RSUD Kota Bogor";
	$PDF_AUTHOR   = "Ahmad Isyfalana Amin & Fernalia";
	$TITLE        = 'Stiker Data Pasien';
	$SUBJECT      = "Pendaftaran RSUD Kota Bogor";
	$PDF_KEYWORDS = "SIMRS Pendaftaran Sticker Stiker";
	
    $pdf->SetCreator($PDF_CREATOR);
    $pdf->SetAuthor($PDF_AUTHOR);
    $pdf->SetTitle($TITLE);
    $pdf->SetSubject($SUBJECT);
    $pdf->SetKeywords($PDF_KEYWORDS);

    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);


    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // Set margins kertas sticker 3 x 10
    $STICKER_MARGIN_LEFT   = 0.5;
    $STICKER_MARGIN_TOP    = 0.6;
    $STICKER_MARGIN_RIGHT  = 0;
	$STICKER_MARGIN_BOTTOM = 0;

    $pdf->SetMargins($STICKER_MARGIN_LEFT, $STICKER_MARGIN_TOP, $STICKER_MARGIN_RIGHT);
	$pdf->SetAutoPageBreak(FALSE, $STICKER_MARGIN_BOTTOM);

    // set font
    $pdf->SetFont('times', '', 10);

    // add a page
    $pdf->AddPage();
	$pdf->setCellPaddings(0, 0, 0, 0);
	$pdf->setCellMargins(0.25, 0.1, 0.25, 0.1);
	
	// Parameter
	// MultiCell($w, $h, $txt, $border=0, $align='J', $fill=0, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0)
	$w           = 5; 
	$h           = 1.8; 
	$txt         = 'Percobaan'; 
	$border      = 0; 
	$align       = 'L'; 
	$fill        = 0; 
	$ln          = 0; // pindah baris 
	$x           = ''; 
	$y           = ''; 
	$reseth      = true; 
	$stretch     = 0; 
	$ishtml      = false; 
	$autopadding = false; 
	$maxh        = 0;
	$fitcell     = false;
	
	// Isi Sticker
	// TODO: Ganti isi sticker
	$no_mr       = sprintf("%06d", $_REQUEST['nomr']);
	$tgl         = date_format(date_create($_REQUEST['ttl']),"d/m/Y");
	$nama        = $_REQUEST['nama']; 
	$jam_daftar  = $_REQUEST['jam_daftar'];
	//$a 			 = datediff($_REQUEST['ttl'], date("Y-m-d"));
	//$umur        = $a[years] . " Thn, " . $a[months] . " Bln, " . $a[days] . " Hr ";
	$umur		 = "";
	$txt         = $no_mr . "\n"  . $tgl .  "   " . $jam_daftar .  "\n" . $nama;

	// Cetak
	for($i=1;$i<=15;$i++){
		$ln = $i %3 == 0 ? 1 : 0;		
		$pdf->MultiCell($w, $h, $txt, $border, $align, $fill, $ln, $x, $y, $reseth, $stretch, $ishtml, $autopadding, $maxh, $fitcell);
	}
    
    //Close and output PDF document
	$nama_file = "sticker_" . $no_mr . ".pdf";
    $pdf->Output($nama_file , 'I');
